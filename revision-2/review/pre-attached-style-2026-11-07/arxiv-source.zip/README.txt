Manuscript source bundle

Auditing Privacy Claims in Split Language-Model Training
Georgios Politis and Evangelos Pappas
7 November 2026

Compile from the archive root with pdfLaTeX, repeating three times for
cross-references. The inline bibliography requires no BibTeX invocation.

pdflatex -interaction=nonstopmode -halt-on-error main.tex

The bundled arxiv.sty is George Kour's community preprint style, unchanged
from commit 920514696f6e7270cab0558fd97c44515c63b4c4.
https://github.com/kourgeorge/arxiv-style
Its MIT licence is included in template/LICENSE-arxiv-style.txt.
Times body typography follows the template. Latin Modern Mono provides
scalable code and path text. Figure fonts are embedded in the supplied PDFs.

This bundle contains the manuscript build inputs. The experiment records
and secondary-analysis code remain in the companion artifact collection
identified in the paper. They are not required to compile this source bundle.
