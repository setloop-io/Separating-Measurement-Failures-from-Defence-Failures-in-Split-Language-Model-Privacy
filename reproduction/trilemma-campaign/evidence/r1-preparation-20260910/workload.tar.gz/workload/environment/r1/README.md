# R1 remote environment acceptance

These JSON files are **unsigned draft templates**, with no budget or environment
accepted. They intentionally cannot unlock execution. Do not fill approval fields
on behalf of the authors without their actual acceptance.

The prepared workload contains the source and raw input, but no installed GPU
environment. Its unpinned project dependency list is not a reproducible cloud
lock. Select and test a CUDA image, retain its immutable registry digest, resolve
and archive the package lock and required wheels/image, and retain the deployment
configuration. Record driver and GPU identity from the actual remote machine.
Do not invent an image digest or assume the local macOS environment matches CUDA.

On that environment, `python scripts/run_r1.py inspect-environment` emits the
actual Python/PyTorch/CUDA, GPU and package-freeze record with digests. Acceptance
must bind this record and the exact `r1_bundle.json` hash. The runtime checks the
same environment again before execution. The container digest in the review is
an operator-supplied identity, not hardware attestation or an independent registry
verification; retain provider/image evidence supporting it.

`budget-review.template.json` requires the accepted stage, bundle hash, rate,
maximum process wall time, spending limit and reviewer reference. Its arithmetic
check covers process compute time only. Provider setup/idle time, storage, taxes
and any CPU/RAM charges must also be addressed in the actual billing budget.
An external provider controller must stop billed compute even if Python stalls.
The runner does not implement a cloud shutdown or promise a hard disk quota:
its output threshold is checked between and after runs, so a run can overshoot.

The engineering source and input bundle stays immutable. Retain acceptance and
execution records as additional files, leaving bundled templates unchanged. A
changed code, matrix or input requires a new bundle and acceptance. Independent
timestamping, full scientific data/attack instrumentation and scientific admission
are separate requirements before calibration or exploration.

The runner consumes an approval in its local bundle using an exclusive claim.
Changing the execution ID or regenerating an admission does not replenish that
approval. This filesystem record is not a global billing ledger: do not delete
it or clone an unconsumed bundle to reuse authorization. The provider controller
must enforce the accepted aggregate budget across machines and retries.
