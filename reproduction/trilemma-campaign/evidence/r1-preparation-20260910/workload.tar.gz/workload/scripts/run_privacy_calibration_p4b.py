#!/usr/bin/env python3
"""Run the 12 P4b privacy re-qualification calibration runs (calibration
cohort; no confirmatory claims) per docs/PREREGISTRATION_P4B.md.

Enumeration (frozen by the preregistration; there is no matrix yaml):
  * dense-capture: seeds {9390, 9490} x q {4, 32} — trained mode, medium span
    {start 2, span 4}, width 256, 600 steps, transcript_sample_every=10,
    capture_probe_batches=2 (run ids p4b-dense-q{q}-s{seed});
  * canary-injection: seeds {9590, 9690} x q {4, 32} — 64 canaries x 10
    repeats, 32 bytes, dedicated stream seed 9790 (p4b-canary-q{q}-s{seed});
    plus matched no-canary runs (p4b-nocanary-q{q}-s{seed}).

All runs: cohort="calibration", protocol_version="p4b-privacy-requalification-1.0";
fixed protocol from experiments/configs/confirmatory_matrix.yaml (q_bits and
logging knobs injected into an in-memory copy; the frozen yaml is never
modified). Uses the additive P4a canary machinery (count parameterized) —
P4a artifacts and code paths are untouched; outputs go to
outputs/privacy_calibration_p4b/.

Historical protocol: <= 1 retry with identical cell identity;
every attempt appended to <output-root>/run_attempts.jsonl.

Usage:
  .venv/bin/python scripts/run_privacy_calibration_p4b.py            # execute
  .venv/bin/python scripts/run_privacy_calibration_p4b.py --dry-run  # enumerate and verify; never train

Prospective preservation rule: existing incomplete/unverifiable evidence stops
execution and is never overwritten by an automatic retry. A separate execution
identity/output directory is required after such a failure. Use --manifest-dir
with --output-root to keep a new execution separate from the original records.

"""

from __future__ import annotations

import argparse
import copy
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

from pcr import manifest as manifest_state  # noqa: E402
from pcr.manifest import ManifestVerificationError, completed_manifest_exists, report_resume_status, write_manifest  # noqa: E402
from pcr.run_experiment import resolve_cell  # noqa: E402
from pcr.train import run_cell  # noqa: E402

import pilot_common as pc  # noqa: E402
from run_confirmatory import log_attempt  # noqa: E402

DEFAULT_CONFIG = ROOT / "experiments" / "configs" / "confirmatory_matrix.yaml"
DEFAULT_OUTPUT_ROOT = ROOT / "outputs" / "privacy_calibration_p4b"


def resolve_p4b_cell(matrix: dict, entry: dict, output_root: str | Path) -> dict:
    """Resolve one P4b calibration run; q_bits/logging/canary injected into an
    in-memory copy of the fixed protocol (frozen yaml untouched)."""
    injected = copy.deepcopy(matrix)
    injected["fixed"]["boundary_defense"]["q_bits"] = entry["q_bits"]
    injected["fixed"]["transcript_sample_every"] = entry["transcript_sample_every"]
    injected["factors"]["segment_span"] = {"medium": {"start": 2, "span": 4}}
    injected["factors"]["latent_width"] = {"high": 256}
    resolved = resolve_cell(
        injected, entry["mode"], entry["seed"], span="medium", width="high",
        steps=entry["steps"], run_id=entry["run_id"], cohort=entry["cohort"],
        output_root=output_root, pairing_block_id=f"pb-{entry['seed']}",
    )
    resolved["protocol_version"] = entry["protocol_version"]
    resolved["logging"]["transcript_sample_every"] = entry["transcript_sample_every"]
    if entry.get("capture_probe_batches"):
        resolved["logging"]["capture_probe_batches"] = entry["capture_probe_batches"]
    if entry.get("canary"):
        resolved["canary"] = dict(entry["canary"])
    return resolved


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(DEFAULT_CONFIG),
                        help="fixed protocol source (confirmatory_matrix.yaml)")
    parser.add_argument("--output-root", default=str(DEFAULT_OUTPUT_ROOT))
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--manifest-dir", help="separate manifest namespace for a new execution; requires fresh outputs")
    args = parser.parse_args()
    if args.manifest_dir:
        manifest_state.MANIFEST_DIR = Path(args.manifest_dir).resolve()

    matrix = pc.load_matrix_forgiving(args.config)
    entries = pc.expected_p4b_runs()
    runs = [resolve_p4b_cell(matrix, entry, args.output_root) for entry in entries]

    print(f"enumerated {len(runs)} P4b calibration runs")
    if args.dry_run:
        return report_resume_status(runs)

    output_root = Path(args.output_root)
    attempts_log = output_root / "run_attempts.jsonl"
    max_retries = 1  # frozen failure policy
    done, failed, skipped = 0, 0, 0
    for index, resolved in enumerate(runs, start=1):
        run_id = resolved["run_id"]
        if completed_manifest_exists(run_id, resolved=resolved):
            print(f"[{index}/{len(runs)}] skip {run_id} (artifacts and execution identity verified)")
            skipped += 1
            continue
        succeeded = False
        for attempt in range(1, max_retries + 2):
            print(
                f"[{index}/{len(runs)}] run {run_id} (attempt {attempt}): "
                f"mode={resolved['mode']} seed={resolved['seed']} split={resolved['split']} "
                f"steps={resolved['optim']['steps']} "
                f"sample_every={resolved['logging']['transcript_sample_every']} "
                f"probe_batches={resolved['logging'].get('capture_probe_batches', 1)}",
                flush=True,
            )
            log_attempt(attempts_log, run_id, attempt, "start")
            t0 = time.perf_counter()
            try:
                summary = run_cell(resolved)
            except ManifestVerificationError:
                raise  # Never relabel or overwrite preserved evidence on a retry.
            except Exception as exc:  # operational failure: audit; retry at most once
                out_dir = Path(resolved["output_dir"])
                leftover = [p for p in out_dir.glob("*") if p.is_file()] if out_dir.is_dir() else []
                write_manifest(
                    resolved, status="operational_failure", artifact_paths=leftover,
                    captured_channels=[],
                    extra={"failure_error": repr(exc), "attempt": attempt,
                           "max_retries": max_retries},
                )
                log_attempt(attempts_log, run_id, attempt, "failure", repr(exc))
                print(f"[{index}/{len(runs)}] FAILED {run_id} (attempt {attempt}): {exc}",
                      flush=True)
                continue
            succeeded = True
            elapsed = time.perf_counter() - t0
            log_attempt(attempts_log, run_id, attempt, "success",
                        f"final_eval_loss={summary['final_eval_loss']:.4f}")
            print(
                f"[{index}/{len(runs)}] done {run_id}: final_eval_loss="
                f"{summary['final_eval_loss']:.4f} wall_time={elapsed:.1f}s",
                flush=True,
            )
            break
        if succeeded:
            done += 1
        else:
            failed += 1
    print(f"finished: {done} executed, {failed} failed after retries, {skipped} pre-existing")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
