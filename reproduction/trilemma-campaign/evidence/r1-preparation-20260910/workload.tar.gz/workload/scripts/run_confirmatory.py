#!/usr/bin/env python3
"""Run the frozen P2 confirmatory matrix: 128 cell runs + 1 calibration run.

Enumeration (per experiments/configs/confirmatory_matrix.yaml, protocol
p2-confirmatory-1.0, fresh seeds [11, 22, 33, 44, 55, 66, 77, 88]):
  * 8 all_local            (one per seed)
  * 24 removed_remote      (per seed x span, width low per controls section)
  * 96 trained/frozen_random (per seed x span x width)
  * 1 calibration run      (seed 919, width high 256; the width-low seed-909
                           artifact is reused from P1 and is NOT rerun)

Cohort is "confirmatory" for cell runs and "calibration" for the 919 run;
pairing block id is "pb-conf-{seed}" from the frozen config.

Resume skips require verified artifacts, configuration, output path and retained
execution source. Unverifiable legacy evidence is preserved and stops execution.
Runs execute sequentially. Historical protocol: at most ONE retry
with identical cell identity; every attempt is appended to
<output-root>/run_attempts.jsonl; failures are recorded with manifest status
operational_failure and are never excluded based on outcome.

Usage:
  .venv/bin/python scripts/run_confirmatory.py            # execute remaining runs
  .venv/bin/python scripts/run_confirmatory.py --dry-run  # enumerate and verify; never train

Prospective preservation rule: existing incomplete/unverifiable evidence stops
execution and is never overwritten by an automatic retry. A separate execution
identity/output directory is required after such a failure. Use --manifest-dir
with --output-root to keep a new execution separate from the original records.

"""

from __future__ import annotations

import argparse
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import yaml  # noqa: E402,F401  (kept for symmetry with run_pilot.py; parsing goes through pilot_common)

from pcr import manifest as manifest_state  # noqa: E402
from pcr.manifest import ManifestVerificationError, completed_manifest_exists, report_resume_status, write_manifest  # noqa: E402
from pcr.run_experiment import resolve_cell  # noqa: E402
from pcr.train import run_cell  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parent))  # pilot_common
import pilot_common as pc  # noqa: E402

DEFAULT_CONFIG = ROOT / "experiments" / "configs" / "confirmatory_matrix.yaml"
DEFAULT_OUTPUT_ROOT = ROOT / "outputs" / "confirmatory"


def enumerate_confirmatory_runs(matrix: dict, output_root: str | Path) -> list[dict]:
    """128 confirmatory cell runs + the width-high calibration run (seed 919).

    The width-low calibration entry (seed 909) is a reused P1 artifact
    (reuse: p1_pilot_artifact) and is deliberately not enumerated.
    """
    seeds = matrix["factors"]["seed"]
    spans = list(matrix["factors"]["segment_span"].keys())
    widths = list(matrix["factors"]["latent_width"].keys())
    runs: list[dict] = []
    for seed in seeds:
        runs.append(resolve_cell(matrix, "all_local", seed, output_root=output_root))
    for seed in seeds:
        for span in spans:
            runs.append(resolve_cell(matrix, "removed_remote", seed, span=span,
                                     output_root=output_root))
    for seed in seeds:
        for span in spans:
            for width in widths:
                for mode in ("trained", "frozen_random"):
                    runs.append(resolve_cell(matrix, mode, seed, span=span, width=width,
                                             output_root=output_root))
    calibration = matrix["calibration"]
    new_entries = [entry for entry in calibration.values()
                   if isinstance(entry, dict) and entry.get("reuse", "none") == "none"]
    for cal in new_entries:
        resolved = resolve_cell(
            matrix,
            mode=cal["mode"],
            seed=cal["seed"],
            span=cal["span"],
            width=cal["width"],
            steps=cal["steps"],
            run_id=f"calibration-s{cal['seed']}",
            cohort="calibration",
            output_root=output_root,
            pairing_block_id=f"pb-{cal['seed']}",
        )
        resolved["calibration"] = {
            "capture_every": cal["capture_every"],
            "capture_max_pairs": cal["capture_max_pairs"],
        }
        runs.append(resolved)
    return runs


def log_attempt(log_path: Path, run_id: str, attempt: int, event: str, detail: str = "") -> None:
    log_path.parent.mkdir(parents=True, exist_ok=True)
    record = {
        "ts": datetime.now(timezone.utc).isoformat(),
        "run_id": run_id,
        "attempt": attempt,
        "event": event,
        "detail": detail,
    }
    with log_path.open("a") as handle:
        handle.write(json.dumps(record) + "\n")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument("--output-root", default=str(DEFAULT_OUTPUT_ROOT))
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--manifest-dir", help="separate manifest namespace for a new execution; requires fresh outputs")
    args = parser.parse_args()
    if args.manifest_dir:
        manifest_state.MANIFEST_DIR = Path(args.manifest_dir).resolve()

    matrix = pc.load_matrix_forgiving(args.config)
    if matrix.get("protocol_status") != "frozen_for_confirmation":
        raise SystemExit("confirmatory matrix is not frozen_for_confirmation; refusing to run")
    if "_config_load_repair" in matrix:
        print(f"WARNING: frozen config required a notes-prose repair to parse: "
              f"{matrix['_config_load_repair']}; the on-disk file is untouched and machine-"
              f"consumed sections are unaffected. File a versioned amendment to fix the yaml.")
    runs = enumerate_confirmatory_runs(matrix, args.output_root)

    print(f"enumerated {len(runs)} runs (128 confirmatory cells + 1 calibration)")
    if args.dry_run:
        return report_resume_status(runs)

    output_root = Path(args.output_root)
    attempts_log = output_root / "run_attempts.jsonl"
    max_retries = int(matrix.get("failure_policy", {}).get("max_retries", 1))
    done, failed, skipped = 0, 0, 0
    for index, resolved in enumerate(runs, start=1):
        run_id = resolved["run_id"]
        if completed_manifest_exists(run_id, resolved=resolved):
            print(f"[{index}/{len(runs)}] skip {run_id} (artifacts and execution identity verified)")
            skipped += 1
            continue
        succeeded = False
        for attempt in range(1, max_retries + 2):
            print(
                f"[{index}/{len(runs)}] run {run_id} (attempt {attempt}): "
                f"mode={resolved['mode']} seed={resolved['seed']} split={resolved['split']} "
                f"steps={resolved['optim']['steps']}",
                flush=True,
            )
            log_attempt(attempts_log, run_id, attempt, "start")
            t0 = time.perf_counter()
            try:
                summary = run_cell(resolved)
            except ManifestVerificationError:
                raise  # Never relabel or overwrite preserved evidence on a retry.
            except Exception as exc:  # operational failure: audit; retry at most once
                out_dir = Path(resolved["output_dir"])
                leftover = [p for p in out_dir.glob("*") if p.is_file()] if out_dir.is_dir() else []
                write_manifest(
                    resolved, status="operational_failure", artifact_paths=leftover,
                    captured_channels=[],
                    extra={"failure_error": repr(exc), "attempt": attempt,
                           "max_retries": max_retries},
                )
                log_attempt(attempts_log, run_id, attempt, "failure", repr(exc))
                print(f"[{index}/{len(runs)}] FAILED {run_id} (attempt {attempt}): {exc}",
                      flush=True)
                continue
            succeeded = True
            elapsed = time.perf_counter() - t0
            log_attempt(attempts_log, run_id, attempt, "success",
                        f"final_eval_loss={summary['final_eval_loss']:.4f}")
            print(
                f"[{index}/{len(runs)}] done {run_id}: final_eval_loss="
                f"{summary['final_eval_loss']:.4f} wall_time={elapsed:.1f}s",
                flush=True,
            )
            break
        if succeeded:
            done += 1
        else:
            failed += 1
    print(f"finished: {done} executed, {failed} failed after retries, {skipped} pre-existing")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
