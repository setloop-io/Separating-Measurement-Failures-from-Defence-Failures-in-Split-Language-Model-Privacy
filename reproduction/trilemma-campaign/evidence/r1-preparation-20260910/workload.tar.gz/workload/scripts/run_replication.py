#!/usr/bin/env python3
"""Run the frozen P3 external-replication matrix: 96 runs.

Enumeration (per experiments/configs/replication_matrix.yaml, protocol
p3-replication-1.0, fresh seeds [9, 19, 29, 39, 49, 59, 69, 89]):
  3 settings (a2c1, a1c2, a2c2) x {all_local, removed_remote, trained,
  frozen_random} x 8 seeds. Run ids are setting-qualified
  (a2c2-trained-s9, ...) so they cannot collide with prior cohorts.

Each setting is resolved by injecting its backbone/corpus/segment into an
IN-MEMORY copy of the matrix and calling pcr.run_experiment.resolve_cell; the
frozen yaml is never modified. For A2C2 trained and all_local runs the
additive save_final_state flag is enabled (final_state.pt for the downstream
probes; no effect on training semantics).

Resumable via completed manifests. Historical protocol: at most ONE retry
with identical cell identity; every attempt appended to
<output-root>/run_attempts.jsonl.

Usage:
  .venv/bin/python scripts/run_replication.py            # execute remaining runs
  .venv/bin/python scripts/run_replication.py --dry-run  # enumerate and verify; never train
  .venv/bin/python scripts/run_replication.py --smoke    # ONE tiny run: a2c2
      trained seed 9, 60 steps, cohort exploratory, run id smoke-a2c2-s9,
      save_final_state on — proves the arch2 split path (width 256 > d_model
      192) trains; not part of the cohort

Prospective preservation rule: existing incomplete/unverifiable evidence stops
execution and is never overwritten by an automatic retry. A separate execution
identity/output directory is required after such a failure. Use --manifest-dir
with --output-root to keep a new execution separate from the original records.

"""

from __future__ import annotations

import argparse
import copy
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

from pcr import manifest as manifest_state  # noqa: E402
from pcr.manifest import ManifestVerificationError, completed_manifest_exists, report_resume_status, write_manifest  # noqa: E402
from pcr.run_experiment import resolve_cell  # noqa: E402
from pcr.train import run_cell  # noqa: E402

import pilot_common as pc  # noqa: E402
from run_confirmatory import log_attempt  # noqa: E402

DEFAULT_CONFIG = ROOT / "experiments" / "configs" / "replication_matrix.yaml"
DEFAULT_OUTPUT_ROOT = ROOT / "outputs" / "replication"

CHECKPOINT_SETTINGS = {("a2c2", "trained"), ("a2c2", "all_local")}


def resolve_replication_cell(matrix: dict, entry: dict, output_root: str | Path,
                             steps: int | None = None, run_id: str | None = None,
                             cohort: str | None = None,
                             save_final_state: bool | None = None) -> dict:
    """Resolve one enumerated run; injects the setting's backbone/corpus/segment
    into an in-memory copy of the matrix (frozen yaml untouched)."""
    injected = copy.deepcopy(matrix)
    setting = matrix["settings"][entry["setting"]]
    injected["fixed"]["backbone"] = dict(matrix["architectures"][setting["architecture"]])
    corpus = matrix["corpora"][setting["corpus"]]
    injected["fixed"]["corpus"] = corpus["path"]
    injected["fixed"]["corpus_sha256"] = corpus["sha256"]
    injected["fixed"]["corpus_split_digest"] = corpus["corpus_split_digest"]
    injected["factors"]["segment_span"] = {"medium": dict(setting["segment"])}
    injected["factors"]["latent_width"] = {"high": 256}
    save = ((entry["setting"], entry["mode"]) in CHECKPOINT_SETTINGS
            if save_final_state is None else save_final_state)
    return resolve_cell(
        injected, entry["mode"], entry["seed"], span="medium", width="high",
        steps=steps, run_id=run_id or entry["run_id"], cohort=cohort,
        output_root=output_root, save_final_state=save,
    )


def enumerate_replication_runs(matrix: dict, output_root: str | Path) -> list[dict]:
    return [resolve_replication_cell(matrix, entry, output_root)
            for entry in pc.expected_replication_runs(matrix)]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument("--output-root", default=str(DEFAULT_OUTPUT_ROOT))
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--smoke", action="store_true",
                        help="run ONE tiny smoke cell (a2c2 trained s9, 60 steps, "
                             "cohort exploratory) and exit")
    parser.add_argument("--manifest-dir", help="separate manifest namespace for a new execution; requires fresh outputs")
    args = parser.parse_args()
    if args.manifest_dir:
        manifest_state.MANIFEST_DIR = Path(args.manifest_dir).resolve()

    matrix = pc.load_matrix_forgiving(args.config)
    if matrix.get("protocol_status") != "frozen_for_confirmation":
        raise SystemExit("replication matrix is not frozen_for_confirmation; refusing to run")

    if args.smoke:
        entry = {"setting": "a2c2", "mode": "trained", "seed": 9}
        resolved = resolve_replication_cell(
            matrix, entry, args.output_root, steps=60, run_id="smoke-a2c2-s9",
            cohort="exploratory", save_final_state=True)
        print(f"smoke run: {resolved['run_id']} backbone={resolved['backbone']['n_layers']}L/"
              f"d{resolved['backbone']['d_model']} split={resolved['split']} steps=60",
              flush=True)
        summary = run_cell(resolved)
        state = Path(resolved["output_dir"]) / "final_state.pt"
        print(f"smoke done: final_eval_loss={summary['final_eval_loss']:.4f}; "
              f"final_state.pt saved: {state.is_file()}")
        return 0

    runs = enumerate_replication_runs(matrix, args.output_root)
    print(f"enumerated {len(runs)} runs (3 settings x 4 modes x 8 seeds)")
    if args.dry_run:
        return report_resume_status(runs)

    output_root = Path(args.output_root)
    attempts_log = output_root / "run_attempts.jsonl"
    max_retries = int(matrix.get("failure_policy", {}).get("max_retries", 1))
    done, failed, skipped = 0, 0, 0
    for index, resolved in enumerate(runs, start=1):
        run_id = resolved["run_id"]
        if completed_manifest_exists(run_id, resolved=resolved):
            print(f"[{index}/{len(runs)}] skip {run_id} (artifacts and execution identity verified)")
            skipped += 1
            continue
        succeeded = False
        for attempt in range(1, max_retries + 2):
            print(
                f"[{index}/{len(runs)}] run {run_id} (attempt {attempt}): "
                f"mode={resolved['mode']} seed={resolved['seed']} split={resolved['split']} "
                f"steps={resolved['optim']['steps']}",
                flush=True,
            )
            log_attempt(attempts_log, run_id, attempt, "start")
            t0 = time.perf_counter()
            try:
                summary = run_cell(resolved)
            except ManifestVerificationError:
                raise  # Never relabel or overwrite preserved evidence on a retry.
            except Exception as exc:  # operational failure: audit; retry at most once
                out_dir = Path(resolved["output_dir"])
                leftover = [p for p in out_dir.glob("*") if p.is_file()] if out_dir.is_dir() else []
                write_manifest(
                    resolved, status="operational_failure", artifact_paths=leftover,
                    captured_channels=[],
                    extra={"failure_error": repr(exc), "attempt": attempt,
                           "max_retries": max_retries},
                )
                log_attempt(attempts_log, run_id, attempt, "failure", repr(exc))
                print(f"[{index}/{len(runs)}] FAILED {run_id} (attempt {attempt}): {exc}",
                      flush=True)
                continue
            succeeded = True
            elapsed = time.perf_counter() - t0
            log_attempt(attempts_log, run_id, attempt, "success",
                        f"final_eval_loss={summary['final_eval_loss']:.4f}")
            print(
                f"[{index}/{len(runs)}] done {run_id}: final_eval_loss="
                f"{summary['final_eval_loss']:.4f} wall_time={elapsed:.1f}s",
                flush=True,
            )
            break
        if succeeded:
            done += 1
        else:
            failed += 1
    print(f"finished: {done} executed, {failed} failed after retries, {skipped} pre-existing")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
