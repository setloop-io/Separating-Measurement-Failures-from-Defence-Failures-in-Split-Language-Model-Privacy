# Proposed R1 CUDA runtime — unresolved on hardware

This directory is a **resolved dependency proposal**, not an accepted GPU image or
proof of CUDA execution.

- Python: 3.12.x
- PyTorch: `2.14.0+cu130`
- Wheel index: `https://download.pytorch.org/whl/cu130`
- Lock: `uv.lock`, including wheel hashes for Linux x86_64/aarch64
- CUDA runtime: bundled with the PyTorch wheel; do not mix in a host CUDA toolkit

PyTorch's official 2.14 release supports CUDA 12.6, 13.0 and 13.2, with CUDA 13.0
as the default wheel. The selected host must therefore have a driver branch that
supports the bundled CUDA 13 runtime; current infrastructure guidance requires
R580 or newer for CUDA 13.x. Recheck the official compatibility pages when choosing
the provider image.

Before accepting an image:

1. Record `IMAGE@sha256:DIGEST`; a mutable tag is insufficient.
2. Require one exclusively assigned GPU and successful `nvidia-smi`.
3. Run `dcgmi health -c` and `dcgmi diag -r 1`; any fault or nonzero result rejects the node.
4. Inside the exact image, record PyTorch, bundled CUDA, cuDNN, NCCL, device count
   and GPU name; `torch.cuda.is_available()` must be true and device count must be one.
5. Run a real tensor forward/backward/optimizer/checkpoint smoke operation before
   creating an engineering admission.
6. Record allocated/reserved/free memory, allocator retries, peak client memory,
   peak remote-process memory, output bytes, actual wire bytes and paid lifetime.
7. Keep an external provider shutdown independent of the Python watchdog.

No Dockerfile is frozen here because no provider image digest or host driver has
been reviewed. Creating one with an invented base digest would be false evidence.
