#!/usr/bin/env python3
"""P2c stage 1: train the calibration all-local backbone (seed 929) and measure
the five candidate segment statistics for every contiguous segment.

Protocol: identical fixed section to the P2 confirmatory study (read from
experiments/configs/confirmatory_matrix.yaml); 2000 steps, AdamW, same corpus
split; cohort "calibration". Statistics are measured on 64 fixed held-out
batches from the dedicated measurement stream (label "measure", seed 929).

Writes outputs/stats/segment_stats_s929.json and the calibration-cohort
manifest experiments/manifests/segment-stats-s929.json.

Usage:
  .venv/bin/python scripts/measure_segment_stats.py            # real run (~5 min)
  .venv/bin/python scripts/measure_segment_stats.py --steps 40 --batches 4 \
      --device cpu --run-id segment-stats-smoke --output /tmp/stats.json \
      --skip-manifest                                          # dev smoke
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

import pilot_common as pc  # noqa: E402
from pcr.data import load_corpus, make_eval_batches, make_train_sampler, split_corpus  # noqa: E402
from pcr.manifest import write_manifest  # noqa: E402
from pcr.model import BackboneConfig  # noqa: E402
from pcr.segment_stats import (  # noqa: E402
    MEASURE_BATCHES,
    MEASURE_SEED,
    STATISTIC_NAMES,
    all_segments,
    make_measure_batches,
    measure_all_segments,
)
from pcr.train import OptimConfig, build_initialized_model, train_model  # noqa: E402
from pcr.utils import resolve_device  # noqa: E402

DEFAULT_CONFIG = ROOT / "experiments" / "configs" / "confirmatory_matrix.yaml"
DEFAULT_OUTPUT = ROOT / "outputs" / "stats" / "segment_stats_s929.json"
PROTOCOL_VERSION = "p2c-segment-statistics-1.0"  # stage 1 per docs/PREREGISTRATION_P2C.md


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(DEFAULT_CONFIG),
                        help="fixed protocol source (confirmatory_matrix.yaml)")
    parser.add_argument("--output", default=str(DEFAULT_OUTPUT))
    parser.add_argument("--run-id", default="segment-stats-s929")
    parser.add_argument("--device", default="auto")
    # dev/smoke knobs (not used for the real measurement)
    parser.add_argument("--steps", type=int, default=None)
    parser.add_argument("--batches", type=int, default=None)
    parser.add_argument("--skip-manifest", action="store_true")
    args = parser.parse_args(argv)

    matrix = pc.load_matrix_forgiving(args.config)
    fixed = matrix["fixed"]
    steps = args.steps if args.steps is not None else fixed["steps"]
    n_batches = args.batches if args.batches is not None else MEASURE_BATCHES

    device = resolve_device(args.device)
    backbone_cfg = BackboneConfig(**fixed["backbone"])

    corpus = load_corpus(ROOT / fixed["corpus"])
    train_region, heldout_region = split_corpus(corpus, fixed["corpus_split"]["train_fraction"])
    sampler = make_train_sampler(train_region, fixed["batch_size"], fixed["sequence_length"],
                                 MEASURE_SEED)
    eval_batches = make_eval_batches(heldout_region, fixed["eval_batches"],
                                     fixed["batch_size"], fixed["sequence_length"], MEASURE_SEED)
    measure_batches = make_measure_batches(heldout_region, fixed["batch_size"],
                                           fixed["sequence_length"], n_batches)

    resolved = {
        "run_id": args.run_id,
        "cohort": "calibration",
        "protocol_version": PROTOCOL_VERSION,
        "protocol_document": "docs/PREREGISTRATION_P2C.md",
        "mode": "all_local",
        "seed": MEASURE_SEED,
        "pairing_block_id": None,
        "device": str(device),
        "backbone": fixed["backbone"],
        "split": None,
        "data": {
            "path": fixed["corpus"],
            "corpus_sha256": fixed["corpus_sha256"],
            "train_fraction": fixed["corpus_split"]["train_fraction"],
            "batch_size": fixed["batch_size"],
            "seq_len": fixed["sequence_length"],
        },
        "optim": {
            "lr": fixed["optimizer"]["lr"], "min_lr": fixed["optimizer"]["min_lr"],
            "betas": list(fixed["optimizer"]["betas"]),
            "weight_decay": fixed["optimizer"]["weight_decay"],
            "warmup_steps": fixed["scheduler"]["warmup_steps"],
            "grad_clip": fixed["optimizer"]["grad_clip"], "steps": steps,
        },
        "measurement": {
            "stream_label": "measure", "stream_seed": MEASURE_SEED,
            "n_batches": n_batches, "statistics": list(STATISTIC_NAMES),
        },
        "output_dir": str(Path(args.output).parent),
    }

    print(f"training calibration all-local backbone: seed={MEASURE_SEED} steps={steps} "
          f"device={device}", flush=True)
    t0 = time.perf_counter()
    model = build_initialized_model(backbone_cfg, "all_local", None, MEASURE_SEED, None).to(device)
    optim_cfg = OptimConfig(
        lr=fixed["optimizer"]["lr"], min_lr=fixed["optimizer"]["min_lr"],
        betas=tuple(fixed["optimizer"]["betas"]),
        weight_decay=fixed["optimizer"]["weight_decay"],
        warmup_steps=fixed["scheduler"]["warmup_steps"],
        grad_clip=fixed["optimizer"]["grad_clip"], steps=steps,
    )
    result = train_model(model, sampler, optim_cfg, device, capture=None, instrument=None,
                         eval_batches=eval_batches, eval_every=fixed["eval_every"],
                         ema_beta=fixed.get("ema_beta", 0.95))
    train_time = time.perf_counter() - t0
    print(f"trained: final_eval_loss={result['curve'][-1]['eval_loss']:.4f} "
          f"({train_time:.0f}s); measuring {len(all_segments(backbone_cfg.n_layers))} "
          f"segments on {n_batches} probe batches ...", flush=True)

    t1 = time.perf_counter()
    segments = measure_all_segments(model, measure_batches, device)
    measure_time = time.perf_counter() - t1
    print(f"measured {len(segments)} segments ({measure_time:.0f}s)", flush=True)

    payload = {
        "note": "P2c calibration-cohort segment statistics on one all-local backbone "
                "(seed 929); statistics characterize the family attractor, not each seed; "
                "not validated evidence for any claim.",
        "run_id": args.run_id,
        "protocol_version": PROTOCOL_VERSION,
        "seed": MEASURE_SEED,
        "device": str(device),
        "steps": steps,
        "final_eval_loss": result["curve"][-1]["eval_loss"],
        "eval_series": [{"step": r["step"], "eval_loss": r["eval_loss"]}
                        for r in result["curve"]],
        "wall_time_seconds": train_time + measure_time,
        "measurement": resolved["measurement"],
        "n_layers": backbone_cfg.n_layers,
        "segments": segments,
    }
    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(payload, indent=2, sort_keys=True))
    print(f"wrote {out_path}")

    if not args.skip_manifest:
        manifest_path = write_manifest(
            resolved, status="completed", artifact_paths=[out_path],
            captured_channels=[],
            extra={"statistics": list(STATISTIC_NAMES),
                   "n_segments": len(segments),
                   "final_eval_loss": result["curve"][-1]["eval_loss"]},
        )
        print(f"wrote {manifest_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
