#!/usr/bin/env python3
"""P1 go/no-go pilot analysis (exploratory cohort; hypothesis-generating only).

Discovers completed runs from experiments/manifests (missing/failed runs are
operational failures per the frozen failure policy), computes the frozen
contrasts per seed and span x width cell:

  G_R  = eval_loss(frozen_random) - eval_loss(trained)   (causal remote gain)
  Delta_U = eval_loss(trained) - eval_loss(all_local)    (replacement penalty)
  removed-remote reference = eval_loss(removed_remote) - eval_loss(all_local)

and evaluates the predeclared go criteria (RESEARCH_PLAN.md section 4 and the
go_rule block of the frozen experiments/configs/pilot_matrix.yaml):

  1. FROZEN RULE: a cell qualifies if trained-minus-frozen eval-loss gain
     (L_frozen - L_trained) > 0 at the final step (2000) for all three seeds;
     go only if >= 2 of the 6 span x width cells qualify.
  2. magnitude supports a power calculation (descriptive): mean/SD of G_R
     across seeds per cell and the naive n for 80% power at alpha=.05
     two-sided paired design.
  3. persistence: gain positive at the final three eval points (1800/1900/2000).
  4. remote resource accounting nonzero in trained cells (FLOPs and bytes).
  5. >= 1 cell privacy-eligible per privacy_scores.json (runs
     scripts/score_privacy.py first if that file is missing).

Outputs outputs/pilot/pilot_analysis.json, outputs/pilot/pilot_summary.md,
prints the GO/NO-GO verdict, and writes paper/figures/pilot_learning_curves.png
when matplotlib is available.

Usage (after the pilot finishes):
  .venv/bin/python scripts/analyze_pilot.py
"""

from __future__ import annotations

import argparse
import json
import math
import subprocess
import sys
from pathlib import Path
from statistics import NormalDist, mean, stdev

sys.path.insert(0, str(Path(__file__).resolve().parent))  # pilot_common

import pilot_common as pc  # noqa: E402

GO_MIN_QUALIFYING_CELLS = 2  # frozen: "go ... only if >= 2 of the 6 span x width cells qualify"
ALPHA = 0.05
POWER = 0.80
DEFAULT_FIGURE_PATH = pc.REPO_ROOT / "paper" / "figures" / "pilot_learning_curves.png"


# --------------------------------------------------------------------------- #
# data collection
# --------------------------------------------------------------------------- #
def collect_run(output_root: Path, entry: dict) -> tuple[dict | None, str | None]:
    """Build one run record from curve.jsonl + metrics_summary.json."""
    run_dir = output_root / entry["run_id"]
    curve_path = run_dir / "curve.jsonl"
    if not curve_path.is_file():
        return None, "missing curve.jsonl despite completed manifest"
    curve = pc.load_curve(run_dir)
    series = pc.eval_series_from_curve(curve)
    if not series:
        return None, "curve.jsonl has no eval rows"
    final_row = max(curve, key=lambda r: int(r["step"]))
    flops = final_row.get("cumulative_remote_flops") or {"fwd_only": 0, "fwd_bwd": 0}
    bytes_counters = final_row.get("cumulative_bytes") or {}
    record = {
        "run_id": entry["run_id"],
        "mode": entry["mode"],
        "span": entry["span"],
        "width": entry["width"],
        "seed": entry["seed"],
        "eval_series": series,
        "final_step": max(series),
        "final_eval_loss": series[max(series)],
        # preserve ints for the big counters but keep fractional fields (e.g.
        # P5's remote_share) as floats — int() truncation zeroed them (P5 bug)
        "cumulative_remote_flops": {k: (int(v) if float(v).is_integer() else float(v))
                                    for k, v in flops.items()},
        "cumulative_bytes": {k: int(v) for k, v in bytes_counters.items()},
        "cumulative_bytes_total": int(sum(bytes_counters.values())),
        "wall_time_seconds": float(final_row.get("wall_time") or 0.0),
    }
    summary_path = run_dir / "metrics_summary.json"
    if summary_path.is_file():
        summary = pc.load_json(summary_path)
        record["bits_per_token_total"] = summary.get("bits_per_token_total")
        record["wall_time_seconds"] = float(summary.get("wall_time_seconds") or record["wall_time_seconds"])
    config_path = run_dir / "config.resolved.json"
    if config_path.is_file():
        config = pc.load_json(config_path)
        record["split"] = config.get("split")
        record["steps_configured"] = (config.get("optim") or {}).get("steps")
    return record, None


# --------------------------------------------------------------------------- #
# contrasts
# --------------------------------------------------------------------------- #
def naive_paired_n(mean_gain: float, sd_gain: float, alpha: float = ALPHA, power: float = POWER):
    """Naive n for 80% power, alpha=.05 two-sided, one-sample (paired) design.

    Descriptive only (RESEARCH_PLAN.md section 9 requires a simulation-based
    power analysis before confirmatory execution; this is the pilot magnitude
    check). Returns (n, cohens_d); n is None when mean_gain <= 0.
    """
    if mean_gain <= 0:
        return None, None
    if sd_gain == 0:
        return 1, None  # zero across-seed variance; descriptive only
    z_alpha = NormalDist().inv_cdf(1 - alpha / 2)
    z_power = NormalDist().inv_cdf(power)
    n = math.ceil(((z_alpha + z_power) * sd_gain / mean_gain) ** 2)
    return max(n, 2), mean_gain / sd_gain


def build_cells(records: dict[str, dict], matrix: dict) -> dict[str, dict]:
    """Per span x width cell: G_R by seed, Delta_U, qualification, persistence."""
    spans = list(matrix["factors"]["segment_span"].keys())
    widths = list(matrix["factors"]["latent_width"].keys())
    seeds = matrix["factors"]["seed"]
    cells: dict[str, dict] = {}
    for span in spans:
        for width in widths:
            key = pc.cell_key(span, width)
            trained = {s: records.get(pc.expected_run_id("trained", s, span, width)) for s in seeds}
            frozen = {s: records.get(pc.expected_run_id("frozen_random", s, span, width)) for s in seeds}
            present = [r for r in list(trained.values()) + list(frozen.values()) if r]
            if not present:
                cells[key] = {"span": span, "width": width, "status": "no_data",
                              "qualifies": False, "persists": False}
                continue
            eval_steps = sorted({st for r in present for st in r["eval_series"]})
            final_step = eval_steps[-1]
            persistence_steps = eval_steps[-3:]
            gains: dict[str, dict | None] = {}
            for s in seeds:
                t, f = trained[s], frozen[s]
                if t is None or f is None:
                    gains[str(s)] = None
                    continue
                shared = sorted(set(t["eval_series"]) & set(f["eval_series"]))
                by_step = {st: f["eval_series"][st] - t["eval_series"][st] for st in shared}
                gains[str(s)] = {
                    "by_step": by_step,
                    "final": by_step.get(final_step),
                    "persistence": {st: by_step.get(st) for st in persistence_steps},
                }
            finals = [g["final"] for g in gains.values() if g and g["final"] is not None]
            complete = len(finals) == len(seeds)
            qualifies = complete and all(g > 0 for g in finals)
            persists = complete and all(
                gains[str(s)] is not None
                and all(v is not None and v > 0 for v in gains[str(s)]["persistence"].values())
                for s in seeds
            )
            cell_mean = mean(finals) if finals else None
            cell_sd = stdev(finals) if len(finals) > 1 else 0.0
            naive_n, cohens_d = (naive_paired_n(cell_mean, cell_sd)
                                 if cell_mean is not None else (None, None))
            delta_u = {}
            for s in seeds:
                t = trained[s]
                local = records.get(pc.expected_run_id("all_local", s))
                if t is None or local is None or final_step not in local["eval_series"]:
                    delta_u[str(s)] = None
                else:
                    delta_u[str(s)] = t["eval_series"].get(final_step) - local["eval_series"][final_step]
            cells[key] = {
                "span": span,
                "width": width,
                "status": "ok",
                "final_step": final_step,
                "persistence_steps": persistence_steps,
                "gains_by_seed": gains,
                "mean_final_gain": cell_mean,
                "sd_final_gain": cell_sd,
                "cohens_d": cohens_d,
                "naive_n_80pct_power": naive_n,
                "qualifies": qualifies,
                "persists": persists,
                "delta_u_by_seed": delta_u,
            }
    return cells


def removed_remote_reference(records: dict[str, dict], matrix: dict) -> dict:
    """eval_loss(removed_remote) - eval_loss(all_local) per span x seed, final step."""
    refs: dict[str, dict] = {}
    for span in matrix["factors"]["segment_span"]:
        per_seed = {}
        for s in matrix["factors"]["seed"]:
            removed = records.get(pc.expected_run_id("removed_remote", s, span=span))
            local = records.get(pc.expected_run_id("all_local", s))
            if not removed or not local:
                per_seed[str(s)] = None
                continue
            step = removed["final_step"]
            per_seed[str(s)] = (
                removed["eval_series"][step] - local["eval_series"][step]
                if step in local["eval_series"] else None
            )
        refs[span] = per_seed
    return refs


def pairing_sanity(records: dict[str, dict], matrix: dict) -> list[dict]:
    """First two eval points of trained vs frozen per cell/seed (report only).

    Paired runs share trusted init, remote init, and data stream; they differ
    only via remote updating, so step-0 eval losses should be identical and the
    step-100 difference reflects 100 steps of remote updates only.
    """
    rows = []
    for span in matrix["factors"]["segment_span"]:
        for width in matrix["factors"]["latent_width"]:
            for s in matrix["factors"]["seed"]:
                t = records.get(pc.expected_run_id("trained", s, span, width))
                f = records.get(pc.expected_run_id("frozen_random", s, span, width))
                if not t or not f:
                    continue
                shared = sorted(set(t["eval_series"]) & set(f["eval_series"]))[:2]
                rows.append({
                    "cell": pc.cell_key(span, width),
                    "seed": s,
                    "points": [
                        {"step": st, "trained": t["eval_series"][st],
                         "frozen": f["eval_series"][st],
                         "diff_frozen_minus_trained": f["eval_series"][st] - t["eval_series"][st]}
                        for st in shared
                    ],
                })
    return rows


# --------------------------------------------------------------------------- #
# go criteria
# --------------------------------------------------------------------------- #
def evaluate_go_criteria(cells: dict, records: dict, matrix: dict,
                         privacy_scores: dict | None, privacy_detail: str) -> tuple[dict, str]:
    qualified_cells = sorted(k for k, c in cells.items()
                             if c.get("status") == "ok" and c["qualifies"])
    n_qualified = len(qualified_cells)

    criterion_1 = {
        "name": "frozen go rule: G_R > 0 at final step for all three seeds in >= 2 of 6 cells",
        "frozen_rule_text": matrix.get("go_rule"),
        "min_qualifying_cells": GO_MIN_QUALIFYING_CELLS,
        "qualified_cells": qualified_cells,
        "n_qualified": n_qualified,
        "pass": n_qualified >= GO_MIN_QUALIFYING_CELLS,
    }

    power_cells = {
        k: {"mean_final_gain": c["mean_final_gain"], "sd_final_gain": c["sd_final_gain"],
            "cohens_d": c["cohens_d"], "naive_n_80pct_power": c["naive_n_80pct_power"]}
        for k, c in cells.items() if c.get("status") == "ok"
    }
    n_feasible = sum(1 for v in power_cells.values()
                     if v["mean_final_gain"] is not None and v["mean_final_gain"] > 0
                     and v["naive_n_80pct_power"] is not None)
    criterion_2 = {
        "name": "magnitude supports a confirmatory power calculation (descriptive)",
        "per_cell": power_cells,
        "n_cells_with_feasible_naive_power": n_feasible,
        "note": ("naive n uses NormalDist z-values for alpha=.05 two-sided paired design "
                 "at 80% power; the confirmatory study still requires the predeclared "
                 "simulation-based power analysis"),
        "pass": n_feasible >= GO_MIN_QUALIFYING_CELLS,
    }

    persists_by_cell = {k: c.get("persists", False) for k, c in cells.items()
                        if c.get("status") == "ok"}
    criterion_3 = {
        "name": "gain persists at the final three eval points",
        "per_cell": persists_by_cell,
        "pass": bool(qualified_cells) and all(persists_by_cell.get(c, False) for c in qualified_cells),
    }

    resource_rows = []
    for run_id in sorted(records):
        r = records[run_id]
        if r["mode"] != "trained":
            continue
        flops = r["cumulative_remote_flops"]
        ok = flops.get("fwd_only", 0) > 0 and flops.get("fwd_bwd", 0) > 0 \
            and r["cumulative_bytes_total"] > 0
        resource_rows.append({"run_id": run_id, "cell": pc.cell_key(r["span"], r["width"]),
                              "seed": r["seed"], "fwd_only_flops": flops.get("fwd_only", 0),
                              "fwd_bwd_flops": flops.get("fwd_bwd", 0),
                              "bytes_total": r["cumulative_bytes_total"],
                              "bits_per_token_total": r.get("bits_per_token_total"),
                              "wall_time_seconds": r["wall_time_seconds"], "nonzero": ok})
    criterion_4 = {
        "name": "remote resource accounting nonzero in trained cells",
        "per_run": resource_rows,
        "pass": bool(resource_rows) and all(row["nonzero"] for row in resource_rows),
    }

    eligible_cells = (privacy_scores or {}).get("privacy_eligible_cells") or []
    criterion_5 = {
        "name": ">= 1 cell privacy-eligible per privacy_scores.json",
        "eligible_cells": sorted(eligible_cells),
        "instrument_qualified": (privacy_scores or {}).get("instrument", {}).get("qualified"),
        "source": privacy_detail,
        "pass": len(eligible_cells) >= 1,
    }

    criteria = {"1_frozen_go_rule": criterion_1, "2_power_magnitude": criterion_2,
                "3_persistence": criterion_3, "4_resource_accounting": criterion_4,
                "5_privacy_eligible": criterion_5}
    verdict = "GO" if all(c["pass"] for c in criteria.values()) else "NO-GO"
    return criteria, verdict


# --------------------------------------------------------------------------- #
# privacy scores (run the scorer first if missing)
# --------------------------------------------------------------------------- #
def load_privacy_scores(path: Path, autoscore: bool, args) -> tuple[dict | None, str]:
    if path.is_file():
        return pc.load_json(path), str(path)
    if not autoscore:
        return None, f"{path} missing and autoscore disabled"
    scorer = Path(__file__).resolve().parent / "score_privacy.py"
    cmd = [sys.executable, str(scorer), "--config", args.config,
           "--output-root", args.output_root, "--manifest-dir", args.manifest_dir,
           "--output", str(path)]
    print(f"privacy_scores.json missing; running {' '.join(cmd)}")
    proc = subprocess.run(cmd, check=False)
    if proc.returncode != 0 or not path.is_file():
        return None, f"score_privacy.py failed (exit {proc.returncode})"
    return pc.load_json(path), f"{path} (generated by score_privacy.py)"


# --------------------------------------------------------------------------- #
# figure
# --------------------------------------------------------------------------- #
def ensure_matplotlib():
    try:
        import matplotlib
        return matplotlib
    except ImportError:
        pass
    venv_python = pc.REPO_ROOT / ".venv" / "bin" / "python"
    print(f"matplotlib not installed; running: uv pip install --python {venv_python} matplotlib")
    subprocess.run(["uv", "pip", "install", "--python", str(venv_python), "matplotlib"], check=False)
    try:
        import matplotlib
        return matplotlib
    except ImportError:
        return None


def make_figure(records: dict[str, dict], matrix: dict, figure_path: Path) -> bool:
    mpl = ensure_matplotlib()
    if mpl is None:
        print("matplotlib unavailable; skipping learning-curve figure")
        return False
    mpl.use("Agg")
    import matplotlib.pyplot as plt

    spans = list(matrix["factors"]["segment_span"].keys())
    widths = list(matrix["factors"]["latent_width"].keys())
    groups = [("all_local", None, "all_local", "black"),
              ("removed_remote", None, "removed_remote", "gray")]
    for w in widths:
        groups.append(("trained", w, f"trained ({w})", "tab:blue" if w == widths[0] else "tab:cyan"))
    for w in widths:
        groups.append(("frozen_random", w, f"frozen_random ({w})",
                       "tab:red" if w == widths[0] else "tab:orange"))

    fig, axes = plt.subplots(1, len(spans), figsize=(6 * len(spans), 4.5), sharey=True)
    if len(spans) == 1:
        axes = [axes]
    for ax, span in zip(axes, spans):
        for mode, width, label, color in groups:
            members = [r for r in records.values()
                       if r["mode"] == mode and r["span"] == span
                       and (width is None or r["width"] == width)]
            if mode == "all_local":
                members = [r for r in records.values() if r["mode"] == "all_local"]
            if not members:
                continue
            steps = sorted({st for r in members for st in r["eval_series"]})
            per_seed = []
            for r in sorted(members, key=lambda r: r["seed"]):
                ys = [r["eval_series"].get(st) for st in steps]
                per_seed.append(ys)
                ax.plot(steps, [y if y is not None else float("nan") for y in ys],
                        color=color, alpha=0.25, linewidth=0.8)
            mean_ys = []
            for i, st in enumerate(steps):
                vals = [ys[i] for ys in per_seed if ys[i] is not None]
                mean_ys.append(mean(vals) if vals else float("nan"))
            ax.plot(steps, mean_ys, color=color, linewidth=2.0, label=label)
        ax.set_title(f"span = {span}")
        ax.set_xlabel("step")
        ax.grid(alpha=0.3)
    axes[0].set_ylabel("held-out eval loss")
    axes[-1].legend(fontsize=8, loc="upper right")
    fig.suptitle("P1 pilot learning curves (mean over seeds; faint = individual seeds)")
    fig.tight_layout()
    figure_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(figure_path, dpi=150)
    print(f"wrote {figure_path}")
    return True


# --------------------------------------------------------------------------- #
# summary markdown
# --------------------------------------------------------------------------- #
def _fmt(value, digits=4):
    return "-" if value is None else f"{value:.{digits}f}"


def render_markdown(analysis: dict) -> str:
    lines = [
        "# P1 pilot analysis (exploratory cohort)",
        "",
        f"> {pc.EXPLORATORY_NOTE}",
        "",
        f"**Verdict: {analysis['verdict']}**",
        "",
        f"final eval step: {analysis['final_step']} "
        f"(persistence steps: {', '.join(map(str, analysis['persistence_steps']))})",
        "",
        "## Go-criteria checklist",
        "",
        "| # | Criterion | Result | Detail |",
        "|---|---|---|---|",
    ]
    for key, c in analysis["go_criteria"].items():
        idx = key.split("_", 1)[0]
        result = "PASS" if c["pass"] else "FAIL"
        if key.startswith("1"):
            detail = f"qualified cells ({len(c['qualified_cells'])}): {', '.join(c['qualified_cells']) or 'none'}"
        elif key.startswith("2"):
            detail = f"cells with feasible naive n: {c['n_cells_with_feasible_naive_power']}"
        elif key.startswith("3"):
            detail = "; ".join(f"{k}: {'persists' if v else 'no'}" for k, v in c["per_cell"].items())
        elif key.startswith("4"):
            n_ok = sum(1 for r in c["per_run"] if r["nonzero"])
            detail = f"{n_ok}/{len(c['per_run'])} trained runs with nonzero remote FLOPs and bytes"
        else:
            detail = f"eligible cells: {', '.join(c['eligible_cells']) or 'none'}; instrument qualified: {c['instrument_qualified']}"
        lines.append(f"| {idx} | {c['name']} | {result} | {detail} |")

    seeds = analysis["seeds"]
    lines += [
        "",
        "## Causal remote-learning gain G_R = L(frozen) - L(trained), final step",
        "",
        "| Cell | " + " | ".join(f"s{s}" for s in seeds) + " | mean | SD | naive n (80%) | qualifies | persists |",
        "|---|" + "---:|" * (len(seeds) + 5),
    ]
    for key, c in analysis["cells"].items():
        if c.get("status") != "ok":
            lines.append(f"| {key} | " + " | ".join("-" for _ in seeds)
                         + f" | - | - | - | no ({c.get('status')}) | - |")
            continue
        per_seed = [c["gains_by_seed"].get(str(s)) for s in seeds]
        vals = [_fmt(g["final"]) if g else "MISSING" for g in per_seed]
        lines.append(
            f"| {key} | " + " | ".join(vals)
            + f" | {_fmt(c['mean_final_gain'])} | {_fmt(c['sd_final_gain'])}"
            + f" | {c['naive_n_80pct_power'] if c['naive_n_80pct_power'] is not None else '-'}"
            + f" | {'yes' if c['qualifies'] else 'no'} | {'yes' if c['persists'] else 'no'} |"
        )

    lines += [
        "",
        "## Replacement penalty Delta_U = L(trained) - L(all_local), final step",
        "",
        "| Cell | " + " | ".join(f"s{s}" for s in seeds) + " |",
        "|---|" + "---:|" * len(seeds),
    ]
    for key, c in analysis["cells"].items():
        if c.get("status") != "ok":
            continue
        lines.append(f"| {key} | " + " | ".join(
            _fmt(c["delta_u_by_seed"].get(str(s))) for s in seeds) + " |")

    lines += [
        "",
        "## Removed-remote reference: L(removed) - L(all_local), final step",
        "",
        "| Span | " + " | ".join(f"s{s}" for s in seeds) + " |",
        "|---|" + "---:|" * len(seeds),
    ]
    for span, per_seed in analysis["removed_remote_reference"].items():
        lines.append(f"| {span} | " + " | ".join(
            _fmt(per_seed.get(str(s))) for s in seeds) + " |")

    privacy = analysis.get("privacy") or {}
    runs = privacy.get("runs") or {}
    lines += [
        "",
        "## Privacy: token-inversion advantage over matched null",
        "",
        f"source: {privacy.get('source', 'unavailable')}; "
        f"instrument qualified: {privacy.get('instrument_qualified')}",
        "",
        "| Run | Cell | Advantage | Null acc | Bits/token | Eligible |",
        "|---|---|---:|---:|---:|---|",
    ]
    scored = [(rid, r) for rid, r in sorted(runs.items()) if r.get("advantage") is not None]
    for rid, r in scored:
        lines.append(f"| {rid} | {r.get('cell', '-')} | {_fmt(r['advantage'])}"
                     f" | {_fmt(r.get('null_accuracy'))}"
                     f" | {_fmt(r.get('bits_per_token_total'), 1)} | {r.get('eligible')} |")
    if not scored:
        lines.append("| (no scored runs) | - | - | - | - | - |")

    lines += [
        "",
        "## Remote resource accounting (trained cells)",
        "",
        "| Run | fwd FLOPs | fwd+bwd FLOPs | bytes | bits/token | wall (s) | nonzero |",
        "|---|---:|---:|---:|---:|---:|---|",
    ]
    for row in analysis["go_criteria"]["4_resource_accounting"]["per_run"]:
        lines.append(f"| {row['run_id']} | {row['fwd_only_flops']} | {row['fwd_bwd_flops']}"
                     f" | {row['bytes_total']} | {_fmt(row.get('bits_per_token_total'), 1)}"
                     f" | {_fmt(row['wall_time_seconds'], 1)} | {row['nonzero']} |")

    lines += [
        "",
        "## Pairing sanity: trained vs frozen at the first two eval points (report only)",
        "",
        "| Cell | Seed | Step | trained | frozen | frozen - trained |",
        "|---|---|---:|---:|---:|---:|",
    ]
    for row in analysis["pairing_sanity"]:
        for point in row["points"]:
            lines.append(f"| {row['cell']} | {row['seed']} | {point['step']}"
                         f" | {_fmt(point['trained'])} | {_fmt(point['frozen'])}"
                         f" | {_fmt(point['diff_frozen_minus_trained'], 6)} |")

    lines += ["", "## Operational failures", ""]
    if analysis["operational_failures"]:
        for failure in analysis["operational_failures"]:
            lines.append(f"- `{failure['run_id']}`: {failure['reason']}")
    else:
        lines.append("- none")
    if analysis["non_pilot_manifests_ignored"]:
        lines += ["", "## Non-pilot manifests ignored", ""]
        for run_id in analysis["non_pilot_manifests_ignored"]:
            lines.append(f"- `{run_id}`")
    lines.append("")
    return "\n".join(lines)


# --------------------------------------------------------------------------- #
# main
# --------------------------------------------------------------------------- #
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(pc.DEFAULT_MATRIX_PATH))
    parser.add_argument("--output-root", default=str(pc.DEFAULT_OUTPUT_ROOT))
    parser.add_argument("--manifest-dir", default=str(pc.DEFAULT_MANIFEST_DIR))
    parser.add_argument("--privacy-scores", default=None,
                        help="default: <output-root>/privacy_scores.json")
    parser.add_argument("--analysis-path", default=None,
                        help="default: <output-root>/pilot_analysis.json")
    parser.add_argument("--summary-path", default=None,
                        help="default: <output-root>/pilot_summary.md")
    parser.add_argument("--figure-path", default=str(DEFAULT_FIGURE_PATH))
    parser.add_argument("--no-figure", action="store_true")
    parser.add_argument("--no-autoscore", action="store_true",
                        help="do not run score_privacy.py when privacy_scores.json is missing")
    args = parser.parse_args(argv)

    output_root = Path(args.output_root)
    analysis_path = Path(args.analysis_path) if args.analysis_path else output_root / "pilot_analysis.json"
    summary_path = Path(args.summary_path) if args.summary_path else output_root / "pilot_summary.md"
    privacy_path = Path(args.privacy_scores) if args.privacy_scores else output_root / "privacy_scores.json"

    matrix = pc.load_matrix(args.config)
    expected = pc.expected_pilot_runs(matrix)
    manifests, unreadable = pc.scan_manifests(args.manifest_dir)
    completed, failures, extras = pc.classify_runs(expected, manifests, unreadable)

    records: dict[str, dict] = {}
    for entry in completed:
        if entry["cohort"] == "calibration":
            continue  # calibration artifacts feed score_privacy.py, not the curves
        record, error = collect_run(output_root, entry)
        if error:
            failures.append({"run_id": entry["run_id"], "mode": entry["mode"],
                             "seed": entry["seed"], "reason": error})
        else:
            records[entry["run_id"]] = record

    cells = build_cells(records, matrix)
    refs = removed_remote_reference(records, matrix)
    sanity = pairing_sanity(records, matrix)

    privacy_scores, privacy_detail = load_privacy_scores(privacy_path, not args.no_autoscore, args)
    if privacy_scores is None:
        print(f"WARNING: privacy scores unavailable: {privacy_detail}")

    criteria, verdict = evaluate_go_criteria(cells, records, matrix, privacy_scores, privacy_detail)

    ok_cells = [c for c in cells.values() if c.get("status") == "ok"]
    analysis = {
        "note": pc.EXPLORATORY_NOTE,
        "protocol_version": matrix.get("protocol_version"),
        "config": args.config,
        "seeds": matrix["factors"]["seed"],
        "final_step": max((c["final_step"] for c in ok_cells), default=None),
        "persistence_steps": (ok_cells[0]["persistence_steps"] if ok_cells else []),
        "runs": records,
        "cells": cells,
        "removed_remote_reference": refs,
        "pairing_sanity": sanity,
        "operational_failures": sorted(failures, key=lambda f: f["run_id"]),
        "non_pilot_manifests_ignored": extras,
        "privacy": {
            "source": privacy_detail,
            "instrument_qualified": (privacy_scores or {}).get("instrument", {}).get("qualified"),
            "privacy_eligible_cells": (privacy_scores or {}).get("privacy_eligible_cells", []),
            "runs": (privacy_scores or {}).get("runs", {}),
        },
        "go_criteria": criteria,
        "verdict": verdict,
    }
    analysis_path.parent.mkdir(parents=True, exist_ok=True)
    analysis_path.write_text(json.dumps(analysis, indent=2, sort_keys=True))
    summary_path.write_text(render_markdown(analysis))

    print(render_markdown(analysis))
    print(f"wrote {analysis_path}")
    print(f"wrote {summary_path}")
    print(f"VERDICT: {verdict}")

    if not args.no_figure:
        if records:
            make_figure(records, matrix, Path(args.figure_path))
        else:
            print("no completed runs; skipping figure")
    return 0


if __name__ == "__main__":
    sys.exit(main())
