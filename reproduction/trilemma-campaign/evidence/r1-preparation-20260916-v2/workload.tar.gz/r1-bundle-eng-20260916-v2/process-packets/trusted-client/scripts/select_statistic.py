#!/usr/bin/env python3
"""P2c stage 1: select the primary segment statistic under the FROZEN rule.

Frozen rule (docs/PREREGISTRATION_P2C.md, frozen 2026-09-04):
  the primary statistic is the candidate with the highest absolute Pearson
  correlation with mean Delta_U across the six exploratory cells
  {2@3, 4@2, 6@1} x {64, 256} at q=8. Ties broken by the higher correlation
  within the width-256 subset.

Selection data: P2 confirmatory mean Delta_U per cell (primary source); P1
pilot means are reported as a sanity cross-check (never used for selection).
Statistics: outputs/stats/segment_stats_s929.json (calibration backbone,
seed 929). All five correlations are written to the table so the selection is
auditable and non-cherry-picked.

Writes outputs/stats/selection_table.json and outputs/stats/selection_table.md.
Exit code 2 without a selection if the rule is degenerate (unresolved tie or
no computable correlation) — that case must be reported, not improvised.

Usage:
  .venv/bin/python scripts/select_statistic.py
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "src"))

import pilot_common as pc  # noqa: E402
import stats_utils as su  # noqa: E402
from pcr.segment_stats import STATISTIC_NAMES  # noqa: E402

SELECTION_RULE_TEXT = (
    "the primary statistic is the candidate with the highest absolute Pearson "
    "correlation with mean Delta_U across the six exploratory cells "
    "{2@3, 4@2, 6@1} x {64, 256}; ties broken by the higher correlation "
    "within the width-256 subset"
)
TIE_TOL = 1e-12


def cell_delta_u_means(analysis_path: Path) -> dict[str, dict]:
    """{cell_key: {mean, n, per_seed}} from a pilot/confirmatory analysis JSON."""
    analysis = json.loads(Path(analysis_path).read_text())
    out = {}
    for cell_key, cell in analysis["cells"].items():
        if cell.get("status") != "ok":
            continue
        values = [v for v in cell["delta_u_by_seed"].values() if v is not None]
        out[cell_key] = {"mean": sum(values) / len(values), "n": len(values),
                         "per_seed": cell["delta_u_by_seed"]}
    return out


def selection_cells(matrix: dict) -> list[dict]:
    """The six exploratory selection cells as (span, start, width_dim) rows."""
    spans = matrix["factors"]["segment_span"]
    widths = matrix["factors"]["latent_width"]
    rows = []
    for span_name, level in spans.items():
        for width_name, width_dim in widths.items():
            rows.append({
                "span": level["span"], "start": level["start"],
                "segment": f"{level['span']}@{level['start']}",
                "width": width_dim,
                "analysis_cell": pc.cell_key(span_name, width_name),
            })
    return sorted(rows, key=lambda r: (r["span"], r["start"], r["width"]))


def safe_pearson(xs: list[float], ys: list[float]) -> float | None:
    try:
        return su.pearson(list(xs), list(ys))
    except (ValueError, ZeroDivisionError):
        return None


def correlation_table(cells: list[dict]) -> list[dict]:
    """Per candidate statistic: r over all six cells and per-width subsets."""
    delta_u = [c["delta_u_mean"] for c in cells]
    rows = []
    for name in STATISTIC_NAMES:
        xs = [c["statistics"].get(name) for c in cells]
        r_all = safe_pearson(xs, delta_u) if all(v is not None for v in xs) else None
        high = [i for i, c in enumerate(cells) if c["width"] == 256]
        low = [i for i, c in enumerate(cells) if c["width"] == 64]
        r_high = safe_pearson([xs[i] for i in high], [delta_u[i] for i in high]) \
            if r_all is not None else None
        r_low = safe_pearson([xs[i] for i in low], [delta_u[i] for i in low]) \
            if r_all is not None else None
        rows.append({"statistic": name, "r_all_six": r_all,
                     "abs_r_all_six": abs(r_all) if r_all is not None else None,
                     "r_width256": r_high, "r_width64": r_low})
    return rows


def apply_selection_rule(rows: list[dict]) -> dict:
    """Frozen rule: max |r_all_six|; ties (within TIE_TOL) broken by the higher
    (signed) width-256 correlation. Degenerate outcomes select nothing."""
    computable = [r for r in rows if r["abs_r_all_six"] is not None]
    if not computable:
        return {"selected": None, "reason": "no computable correlation", "degenerate": True}
    best = max(r["abs_r_all_six"] for r in computable)
    top = [r for r in computable if r["abs_r_all_six"] >= best - TIE_TOL]
    if len(top) == 1:
        return {"selected": top[0]["statistic"], "tie_broken_by": None,
                "candidates_tied": None, "degenerate": False,
                "winning_abs_r": best}
    best_high = max(r["r_width256"] for r in top)
    top2 = [r for r in top if r["r_width256"] >= best_high - TIE_TOL]
    if len(top2) == 1:
        return {"selected": top2[0]["statistic"], "tie_broken_by": "width_256_subset",
                "candidates_tied": [r["statistic"] for r in top], "degenerate": False,
                "winning_abs_r": best}
    return {"selected": None, "degenerate": True,
            "reason": f"unresolved tie among {[r['statistic'] for r in top2]} "
                      f"(|r| = {best:.6f}, width-256 r = {best_high:.6f})",
            "candidates_tied": [r["statistic"] for r in top]}


def render_markdown(table: dict) -> str:
    lines = [
        "# P2c stage-1 statistic selection table",
        "",
        f"Frozen rule: {SELECTION_RULE_TEXT}",
        "",
        f"**Selected statistic: {table['selection']['selected']}**"
        + (f" (tie broken by {table['selection']['tie_broken_by']})"
           if table["selection"].get("tie_broken_by") else ""),
        "",
        "## Selection cells (Delta_U means: P2 primary, P1 sanity)",
        "",
        "| Cell | Segment | Width | Delta_U P2 mean | Delta_U P1 mean | "
        + " | ".join(STATISTIC_NAMES) + " |",
        "|---|---|---:|---:|---:|" + "---:|" * len(STATISTIC_NAMES),
    ]
    for cell in table["cells"]:
        stats = " | ".join(f"{cell['statistics'][s]:.6g}" for s in STATISTIC_NAMES)
        lines.append(f"| {cell['analysis_cell']} | {cell['segment']} | {cell['width']}"
                     f" | {cell['delta_u_mean']:.6f} | {cell['delta_u_p1_mean']:.6f} | {stats} |")
    lines += [
        "",
        "## Correlations with mean Delta_U (P2 means)",
        "",
        "| Statistic | r (6 cells) | |r| | r (width 256) | r (width 64) | r vs P1 means (sanity) |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for row in table["correlations"]:
        lines.append(
            f"| {row['statistic']} | {row['r_all_six']:.4f} | {row['abs_r_all_six']:.4f}"
            f" | {row['r_width256']:.4f} | {row['r_width64']:.4f}"
            f" | {row['r_p1_sanity']:.4f} |"
        )
    lines.append("")
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--p2-analysis", default=str(
        ROOT / "outputs" / "confirmatory" / "confirmatory_analysis.json"))
    parser.add_argument("--p1-analysis", default=str(
        ROOT / "outputs" / "pilot" / "pilot_analysis.json"))
    parser.add_argument("--stats", default=str(ROOT / "outputs" / "stats" / "segment_stats_s929.json"))
    parser.add_argument("--p2-config", default=str(pc.DEFAULT_CONFIRMATORY_MATRIX_PATH),
                        help="cell-name -> segment mapping source")
    parser.add_argument("--output-json", default=str(ROOT / "outputs" / "stats" / "selection_table.json"))
    parser.add_argument("--output-md", default=str(ROOT / "outputs" / "stats" / "selection_table.md"))
    args = parser.parse_args(argv)

    matrix = pc.load_matrix_forgiving(args.p2_config)
    cells = selection_cells(matrix)
    p2_means = cell_delta_u_means(args.p2_analysis)
    p1_means = cell_delta_u_means(args.p1_analysis)
    stats_doc = json.loads(Path(args.stats).read_text())
    stats_by_segment = {(s["span"], s["start"]): s for s in stats_doc["segments"]}

    for cell in cells:
        key = cell["analysis_cell"]
        if key not in p2_means:
            raise SystemExit(f"missing P2 Delta_U for selection cell {key}")
        cell["delta_u_mean"] = p2_means[key]["mean"]
        cell["n_seeds_p2"] = p2_means[key]["n"]
        cell["delta_u_p1_mean"] = p1_means.get(key, {}).get("mean")
        measured = stats_by_segment.get((cell["span"], cell["start"]))
        if measured is None:
            raise SystemExit(f"segment {cell['segment']} not found in {args.stats}")
        cell["statistics"] = {name: measured[name] for name in STATISTIC_NAMES}

    correlations = correlation_table(cells)
    p1_delta_u = [c["delta_u_p1_mean"] for c in cells]
    for row in correlations:
        name = row["statistic"]
        row["r_p1_sanity"] = safe_pearson([c["statistics"][name] for c in cells], p1_delta_u)
    selection = apply_selection_rule(correlations)

    table = {
        "note": "P2c stage-1 selection; exploratory data only (P1/P2 spent cohorts + "
                "seed-929 calibration measurement). Selection is frozen after this point.",
        "selection_rule": SELECTION_RULE_TEXT,
        "selection_rule_source": "docs/PREREGISTRATION_P2C.md (frozen 2026-09-04)",
        "statistics_measured_on": {
            "run_id": stats_doc["run_id"], "seed": stats_doc["seed"],
            "n_batches": stats_doc["measurement"]["n_batches"],
            "stream_label": stats_doc["measurement"]["stream_label"],
        },
        "cells": cells,
        "correlations": correlations,
        "selection": selection,
        "sources": {"p2_analysis": args.p2_analysis, "p1_analysis": args.p1_analysis,
                    "stats": args.stats},
    }
    out_json = Path(args.output_json)
    out_json.parent.mkdir(parents=True, exist_ok=True)
    out_json.write_text(json.dumps(table, indent=2, sort_keys=True))
    Path(args.output_md).write_text(render_markdown(table))
    print(render_markdown(table))
    print(f"wrote {out_json}\nwrote {args.output_md}")
    if selection["degenerate"]:
        print(f"SELECTION DEGENERATE: {selection['reason']} — stopping per protocol; "
              f"no statistic selected.")
        return 2
    print(f"SELECTED STATISTIC: {selection['selected']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
