#!/usr/bin/env python3
"""P2c confirmatory analysis — implements the frozen confirmatory_rule of
experiments/configs/segment_stats_matrix.yaml (protocol
p2c-segment-statistics-1.0; docs/PREREGISTRATION_P2C.md stage 2).

Discovery: completed p2c runs from manifests (cohort="confirmatory",
protocol_version="p2c-segment-statistics-1.0"); missing/failed runs are
reported operational failures. Frozen missing-data rule: a cell missing its
all_local partner seed drops that seed from the cell mean (predeclared, never
outcome-based).

Frozen rule:
  * Target: per-cell mean Delta_U (trained - all_local eval loss, step 2000).
  * Model S: Delta_U ~ a + b * (selected statistic); model N: Delta_U ~ a +
    b * span — both OLS-fit on the SIX exploratory selection points only
    (loaded from selection_table.json; confirmatory cells never enter the fit).
  * Primary: per-cell absolute out-of-sample errors |yhat - y| under S vs N;
    one-sided paired t-test over the 8 cells (S better), alpha 0.05.
    H2 CONFIRMED iff p < 0.05 AND mean abs error S < N AND out-of-sample
    R^2 of S > 0 (R^2 against the exploratory-mean baseline).
  * Secondary (H4, descriptive, flagged low-power): out-of-sample R^2 of
    Delta_U ~ span vs Delta_U ~ span + position + statistic.

Outputs: outputs/segment_stats/segment_stats_analysis.json,
outputs/segment_stats/segment_stats_summary.md, and
paper/figures/segment_stats_prediction.png (measured vs predicted scatter with
identity line and per-cell labels; if matplotlib is available).

Usage (after scripts/run_segment_stats.py finishes):
  .venv/bin/python scripts/analyze_segment_stats.py
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from statistics import mean

sys.path.insert(0, str(Path(__file__).resolve().parent))

import pilot_common as pc  # noqa: E402
import stats_utils as su  # noqa: E402
from analyze_pilot import _fmt, collect_run, ensure_matplotlib  # noqa: E402

DEFAULT_CONFIG = pc.REPO_ROOT / "experiments" / "configs" / "segment_stats_matrix.yaml"
DEFAULT_OUTPUT_ROOT = pc.REPO_ROOT / "outputs" / "segment_stats"
DEFAULT_SELECTION_TABLE = pc.REPO_ROOT / "outputs" / "stats" / "selection_table.json"
DEFAULT_STATS = pc.REPO_ROOT / "outputs" / "stats" / "segment_stats_s929.json"
DEFAULT_FIGURE_PATH = pc.REPO_ROOT / "paper" / "figures" / "segment_stats_prediction.png"

P2C_NOTE = (
    "Confirmatory analysis under protocol p2c-segment-statistics-1.0 (frozen "
    "2026-09-04, fresh seeds [3..83]); per docs/PREREGISTRATION_P2C.md. "
    "Statistics derive from ONE calibration backbone (seed 929)."
)


# --------------------------------------------------------------------------- #
# core computation (pure functions; unit-tested)
# --------------------------------------------------------------------------- #
def fit_predictors(selection_cells: list[dict], statistic: str) -> dict:
    """Fit models S and N by OLS on the six exploratory selection points."""
    xs_stat = [c["statistics"][statistic] for c in selection_cells]
    xs_span = [float(c["span"]) for c in selection_cells]
    ys = [c["delta_u_mean"] for c in selection_cells]
    slope_s, intercept_s = su.ols_slope(xs_stat, ys)
    slope_n, intercept_n = su.ols_slope(xs_span, ys)
    return {
        "model_S": {"intercept": intercept_s, "coefficients": [slope_s],
                    "predictor": statistic},
        "model_N": {"intercept": intercept_n, "coefficients": [slope_n],
                    "predictor": "span"},
        "fit_mean_delta_u": mean(ys),
        "fit_points": [{"segment": c["segment"], "width": c["width"],
                        "span": c["span"], "start": c["start"],
                        "statistic_value": c["statistics"][statistic],
                        "delta_u_mean": c["delta_u_mean"]} for c in selection_cells],
    }


def evaluate_h2(cell_rows: list[dict], fits: dict, alpha: float) -> dict:
    """Frozen primary rule over per-cell absolute out-of-sample errors."""
    err_s = [r["abs_error_S"] for r in cell_rows]
    err_n = [r["abs_error_N"] for r in cell_rows]
    diffs = [s - n for s, n in zip(err_s, err_n)]
    test = su.paired_t_test(diffs, alternative="less")
    y_true = [r["delta_u_mean"] for r in cell_rows]
    y_s = [r["pred_S"] for r in cell_rows]
    y_n = [r["pred_N"] for r in cell_rows]
    baseline = fits["fit_mean_delta_u"]
    r2_s = su.r2_out_of_sample(y_true, y_s, baseline)
    r2_n = su.r2_out_of_sample(y_true, y_n, baseline)
    mean_s, mean_n = mean(err_s), mean(err_n)
    p_pass = test["p"] is not None and test["p"] < alpha
    magnitude_pass = mean_s < mean_n
    r2_pass = r2_s == r2_s and r2_s > 0  # NaN fails
    confirmed = bool(p_pass and magnitude_pass and r2_pass)
    failed = []
    if not p_pass:
        failed.append("p_value")
    if not magnitude_pass:
        failed.append("mean_absolute_error")
    if not r2_pass:
        failed.append("r2_S_positive")
    return {
        "alpha": alpha,
        "paired_t_on_error_differences": test,
        "mean_abs_error_S": mean_s, "mean_abs_error_N": mean_n,
        "r2_out_of_sample_S": r2_s, "r2_out_of_sample_N": r2_n,
        "r2_baseline": "exploratory fit-set mean Delta_U",
        "p_pass": p_pass, "magnitude_pass": magnitude_pass, "r2_S_positive_pass": r2_pass,
        "confirmed": confirmed, "failed_conditions": failed,
        "verdict": "CONFIRMED" if confirmed else "NOT CONFIRMED",
    }


def evaluate_h4(selection_cells: list[dict], cell_rows: list[dict], statistic: str) -> dict:
    """Secondary descriptive: R^2_oos of span-only vs span+position+statistic.

    The augmented model has 4 parameters fit on 6 exploratory points — flagged
    low-power, reported without gating.
    """
    x_expl = [[float(c["span"]), float(c["start"]), c["statistics"][statistic]]
              for c in selection_cells]
    y_expl = [c["delta_u_mean"] for c in selection_cells]
    fit_full = su.ols_multivariate(x_expl, y_expl)
    y_true = [r["delta_u_mean"] for r in cell_rows]
    baseline = mean(y_expl)
    pred_full = [su.predict_linear(fit_full, [float(r["span"]), float(r["start"]),
                                              r["statistic_value"]]) for r in cell_rows]
    return {
        "statistic": statistic,
        "fit_full": fit_full,
        "low_power": True,
        "note": "4 parameters fit on 6 exploratory points; descriptive only, not gated",
        "r2_out_of_sample_full": su.r2_out_of_sample(y_true, pred_full, baseline),
        "per_cell_residual_full": [t - p for t, p in zip(y_true, pred_full)],
    }


# --------------------------------------------------------------------------- #
# figure
# --------------------------------------------------------------------------- #
def make_prediction_figure(cell_rows: list[dict], figure_path: Path) -> bool:
    mpl = ensure_matplotlib()
    if mpl is None:
        print("matplotlib unavailable; skipping prediction figure")
        return False
    mpl.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(6.5, 6))
    lo = min(min(r["pred_S"] for r in cell_rows), min(r["pred_N"] for r in cell_rows),
             min(r["delta_u_mean"] for r in cell_rows))
    hi = max(max(r["pred_S"] for r in cell_rows), max(r["pred_N"] for r in cell_rows),
             max(r["delta_u_mean"] for r in cell_rows))
    pad = 0.1 * (hi - lo)
    ax.plot([lo - pad, hi + pad], [lo - pad, hi + pad], color="0.5", linestyle="--",
            linewidth=1, label="identity")
    for row in cell_rows:
        ax.scatter([row["pred_S"]], [row["delta_u_mean"]], color="tab:blue", s=50,
                   zorder=3)
        ax.scatter([row["pred_N"]], [row["delta_u_mean"]], color="tab:red", marker="^",
                   s=50, zorder=3)
        ax.annotate(row["segment"], (row["pred_S"], row["delta_u_mean"]),
                    textcoords="offset points", xytext=(6, 4), fontsize=8)
    ax.scatter([], [], color="tab:blue", label="model S (statistic)")
    ax.scatter([], [], color="tab:red", marker="^", label="model N (span)")
    ax.set_xlabel("predicted mean Delta_U (out of sample)")
    ax.set_ylabel("measured mean Delta_U")
    ax.set_title("P2c held-out cells: measured vs predicted replacement penalty")
    ax.legend(fontsize=8)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    figure_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(figure_path, dpi=150)
    print(f"wrote {figure_path}")
    return True


# --------------------------------------------------------------------------- #
# markdown
# --------------------------------------------------------------------------- #
def render_markdown(analysis: dict) -> str:
    h2 = analysis["h2"]
    lines = [
        "# P2c segment-statistics analysis (protocol p2c-segment-statistics-1.0)",
        "",
        f"> {P2C_NOTE}",
        "",
        "## Verdict",
        "",
        f"- **H2 (segment statistic beats nominal span out of sample): {h2['verdict']}**",
        f"  - p(one-sided paired t on |err_S| - |err_N|) = {_fmt(h2['paired_t_on_error_differences']['p'], 5)} "
        f"(alpha {h2['alpha']}); mean |err| S {_fmt(h2['mean_abs_error_S'])} vs N {_fmt(h2['mean_abs_error_N'])}; "
        f"R^2_oos S {_fmt(h2['r2_out_of_sample_S'])}, N {_fmt(h2['r2_out_of_sample_N'])}",
        f"  - failed conditions: {h2['failed_conditions'] or 'none'}",
        "",
        "## Predictor fits (OLS on the six exploratory selection points only)",
        "",
        f"- model S: Delta_U = {_fmt(analysis['fits']['model_S']['intercept'])} "
        f"+ {_fmt(analysis['fits']['model_S']['coefficients'][0])} * {analysis['fits']['model_S']['predictor']}",
        f"- model N: Delta_U = {_fmt(analysis['fits']['model_N']['intercept'])} "
        f"+ {_fmt(analysis['fits']['model_N']['coefficients'][0])} * span",
        "",
        "## Per-cell table (held-out cells)",
        "",
        "| Cell | Segment | stat value | measured Delta_U [95% CI] | pred S | pred N "
        "| |err S| | |err N| |",
        "|---|---|---:|---|---:|---:|---:|---:|",
    ]
    for row in analysis["cell_rows"]:
        du = row["delta_u"]
        lines.append(
            f"| {row['cell']} | {row['segment']} | {_fmt(row['statistic_value'], 5)}"
            f" | {_fmt(du['mean'])} [{_fmt(du['ci_low'])}, {_fmt(du['ci_high'])}]"
            f" | {_fmt(row['pred_S'])} | {_fmt(row['pred_N'])}"
            f" | {_fmt(row['abs_error_S'])} | {_fmt(row['abs_error_N'])} |"
        )
    h4 = analysis["h4"]
    lines += [
        "",
        "## Secondary (H4, descriptive, low-power)",
        "",
        f"- R^2_oos Delta_U ~ span: {_fmt(analysis['h2']['r2_out_of_sample_N'])}",
        f"- R^2_oos Delta_U ~ span + position + statistic: {_fmt(h4['r2_out_of_sample_full'])}"
        f" ({h4['note']})",
        "",
        "## Operational failures",
        "",
    ]
    if analysis["operational_failures"]:
        for failure in analysis["operational_failures"]:
            lines.append(f"- `{failure['run_id']}`: {failure['reason']}")
    else:
        lines.append("- none")
    lines.append("")
    return "\n".join(lines)


# --------------------------------------------------------------------------- #
# main
# --------------------------------------------------------------------------- #
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument("--output-root", default=str(DEFAULT_OUTPUT_ROOT))
    parser.add_argument("--manifest-dir", default=str(pc.DEFAULT_MANIFEST_DIR))
    parser.add_argument("--selection-table", default=str(DEFAULT_SELECTION_TABLE))
    parser.add_argument("--stats", default=str(DEFAULT_STATS))
    parser.add_argument("--analysis-path", default=None)
    parser.add_argument("--summary-path", default=None)
    parser.add_argument("--figure-path", default=str(DEFAULT_FIGURE_PATH))
    parser.add_argument("--no-figure", action="store_true")
    args = parser.parse_args(argv)

    output_root = Path(args.output_root)
    analysis_path = (Path(args.analysis_path) if args.analysis_path
                     else output_root / "segment_stats_analysis.json")
    summary_path = (Path(args.summary_path) if args.summary_path
                    else output_root / "segment_stats_summary.md")

    matrix = pc.load_matrix_forgiving(args.config)
    rule = matrix["confirmatory_rule"]
    statistic = matrix["selection"]["statistic"]
    selection_table = json.loads(Path(args.selection_table).read_text())
    stats_doc = json.loads(Path(args.stats).read_text())
    stats_by_segment = {(s["span"], s["start"]): s for s in stats_doc["segments"]}
    alpha = float(rule["primary"]["alpha"])

    fits = fit_predictors(selection_table["cells"], statistic)

    expected = pc.expected_segment_stats_runs(matrix)
    manifests, unreadable = pc.scan_manifests(args.manifest_dir)
    completed, failures, extras = pc.classify_runs(
        expected, manifests, unreadable,
        required_manifest_fields={"cohort": "confirmatory",
                                  "protocol_version": matrix["protocol_version"]},
    )
    records: dict[str, dict] = {}
    for entry in completed:
        if entry["cohort"] == "calibration":
            continue
        record, error = collect_run(output_root, entry)
        if error:
            failures.append({"run_id": entry["run_id"], "mode": entry["mode"],
                             "seed": entry["seed"], "reason": error})
        else:
            records[entry["run_id"]] = record

    width = next(iter(matrix["factors"]["latent_width"]))
    cell_rows = []
    for span_name, level in matrix["factors"]["segment_span"].items():
        span, start = level["span"], level["start"]
        segment = f"{span}@{start}"
        per_seed = {}
        dropped = []
        for s in matrix["factors"]["seed"]:
            trained = records.get(pc.expected_run_id("trained", s, span=span_name, width=width))
            local = records.get(pc.expected_run_id("all_local", s))
            if trained is None or local is None:
                dropped.append(s)  # frozen rule: drop the seed from the cell mean
                continue
            step = trained["final_step"]
            if step not in local["eval_series"]:
                dropped.append(s)
                continue
            per_seed[str(s)] = trained["eval_series"][step] - local["eval_series"][step]
        measured = stats_by_segment.get((span, start))
        stat_value = measured[statistic] if measured else None
        du = su.mean_ci(list(per_seed.values()))
        pred_s = su.predict_linear(fits["model_S"], [stat_value]) if stat_value is not None else None
        pred_n = su.predict_linear(fits["model_N"], [float(span)])
        row = {
            "cell": span_name, "segment": segment, "span": span, "start": start,
            "statistic_value": stat_value,
            "delta_u_by_seed": per_seed, "dropped_seeds": dropped,
            "delta_u": du, "delta_u_mean": du["mean"],
            "pred_S": pred_s, "pred_N": pred_n,
        }
        row["abs_error_S"] = abs(pred_s - du["mean"]) if pred_s is not None and du["mean"] is not None else None
        row["abs_error_N"] = abs(pred_n - du["mean"]) if du["mean"] is not None else None
        cell_rows.append(row)

    evaluable = [r for r in cell_rows
                 if r["abs_error_S"] is not None and r["abs_error_N"] is not None]
    h2 = evaluate_h2(evaluable, fits, alpha) if evaluable else {
        "verdict": "NOT CONFIRMED", "confirmed": False,
        "failed_conditions": ["no_evaluable_cells"], "alpha": alpha,
        "paired_t_on_error_differences": su.paired_t_test([], "less"),
    }
    h4 = evaluate_h4(selection_table["cells"], evaluable, statistic) if evaluable else None

    analysis = {
        "note": P2C_NOTE,
        "protocol_version": matrix.get("protocol_version"),
        "config": args.config,
        "selection_table": str(args.selection_table),
        "selection_table_sha256": matrix["selection"].get("selection_table_sha256"),
        "statistic": statistic,
        "confirmatory_rule": rule,
        "fits": fits,
        "cell_rows": cell_rows,
        "h2": h2,
        "h4": h4,
        "operational_failures": sorted(failures, key=lambda f: f["run_id"]),
        "non_study_manifests_ignored": extras,
        "verdict": h2["verdict"],
    }
    analysis_path.parent.mkdir(parents=True, exist_ok=True)
    analysis_path.write_text(json.dumps(analysis, indent=2, sort_keys=True))
    summary_path.write_text(render_markdown(analysis))

    print(render_markdown(analysis))
    print(f"wrote {analysis_path}")
    print(f"wrote {summary_path}")
    print(f"VERDICT H2: {h2['verdict']}")

    if not args.no_figure:
        if evaluable:
            make_prediction_figure(evaluable, Path(args.figure_path))
        else:
            print("no evaluable cells; skipping figure")
    return 0


if __name__ == "__main__":
    sys.exit(main())
