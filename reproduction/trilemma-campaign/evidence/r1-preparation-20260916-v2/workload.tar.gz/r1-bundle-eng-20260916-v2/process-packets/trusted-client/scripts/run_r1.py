#!/usr/bin/env python3
"""Prepare a fresh R1 remote workload; scientific execution is deliberately unavailable.

Examples (preparation only; these commands do not train or provision a GPU):
  python scripts/run_r1.py plan
  python scripts/run_r1.py prepare --destination /tmp/paper3-r1-bundle-v1
  python /tmp/paper3-r1-bundle-v1/scripts/run_r1.py verify-bundle

After separate paid-budget approval and measured remote-environment acceptance:
  python scripts/run_r1.py inspect-environment
  python scripts/run_r1.py freeze-engineering --stage engineering --budget REVIEW.json --environment-review ENV_REVIEW.json --admission admission.json
  python scripts/run_r1.py execute-engineering --admission admission.json --execution-id eng001

The caller must supply an external wall-time watchdog for provider billing caps.
No automatic resume, scientific cohort execution or legacy result reuse exists.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from pcr import r1  # noqa: E402


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("plan", "prepare"):
        command = sub.add_parser(name)
        command.add_argument("--matrix", type=Path, default=ROOT / "experiments/configs/r1_exploration.yaml")
        if name == "prepare":
            command.add_argument("--destination", type=Path, required=True)
        else:
            command.add_argument("--stage", default="engineering",
                                 choices=["local_validation", "engineering", "performance_calibration", "calibration", "exploratory"])
    command = sub.add_parser("local-validate")
    command.add_argument("--matrix", type=Path, default=ROOT / "experiments/configs/r1_exploration.yaml")
    command.add_argument("--output", type=Path, required=True)
    command.add_argument("--execution-id", required=True)
    command = sub.add_parser("prepare-process-packets")
    command.add_argument("--destination", type=Path, required=True)
    command.add_argument("--corpus", type=Path, default=ROOT / "data/raw/tinyshakespeare.txt")
    sub.add_parser("verify-bundle")
    sub.add_parser("inspect-environment")
    command = sub.add_parser("freeze-engineering")
    command.add_argument("--stage", required=True, choices=r1.ENGINEERING_STAGES)
    command.add_argument("--budget", type=Path, required=True)
    command.add_argument("--admission", type=Path, required=True)
    command.add_argument("--environment-review", type=Path, required=True)
    command = sub.add_parser("execute-engineering")
    command.add_argument("--admission", type=Path, required=True)
    command.add_argument("--execution-id", required=True)
    args = parser.parse_args(argv)
    try:
        if args.command == "plan":
            matrix = r1.load_matrix(args.matrix)
            runs = r1.enumerate_runs(matrix, args.stage, Path("outputs") / matrix["study_id"] / args.stage)
            result = {"study_id": matrix["study_id"], "stage": args.stage, "run_count": len(runs),
                      "training_steps": sum(r["optim"]["steps"] for r in runs), "scientific_evidence": False,
                      "scientific_execution_admitted": False, "runs": runs, "blockers": r1.BLOCKERS}
        elif args.command == "local-validate":
            from pcr.r1_local_validation import run_local_validation
            result = run_local_validation(ROOT, args.matrix, args.output, args.execution_id)
        elif args.command == "prepare-process-packets":
            from pcr.r1_packets import prepare_process_packets
            result = prepare_process_packets(ROOT, args.destination, args.corpus)
        elif args.command == "prepare":
            result = r1.prepare_bundle(ROOT, args.matrix, args.destination)
            result = {"destination": str(args.destination.resolve()), "files": len(result["files"]),
                      "bundle_sha256": r1.sha256_file(str(args.destination / "r1_bundle.json")),
                      "scientific_execution_admitted": False}
        elif args.command == "verify-bundle":
            result = r1.verify_bundle(ROOT)
            result = {"status": "verified", "study_id": result["study_id"], "files": len(result["files"]),
                      "scientific_execution_admitted": False}
        elif args.command == "freeze-engineering":
            result = r1.freeze_engineering(ROOT, args.stage, args.budget, args.admission, args.environment_review)
        elif args.command == "inspect-environment":
            environment = r1.environment_record()
            result = {"environment": environment, "environment_sha256": r1.sha256_json(environment),
                      "pip_freeze_sha256": r1.sha256_bytes(environment["pip_freeze"].encode()),
                      "status": "measured_only_not_accepted"}
        else:
            result = r1.execute_engineering(ROOT, args.admission, args.execution_id)
        print(json.dumps(result, indent=2, sort_keys=True, allow_nan=False))
        return 0
    except (ValueError, KeyError, OSError, RuntimeError) as exc:
        print(f"R1 blocked: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
