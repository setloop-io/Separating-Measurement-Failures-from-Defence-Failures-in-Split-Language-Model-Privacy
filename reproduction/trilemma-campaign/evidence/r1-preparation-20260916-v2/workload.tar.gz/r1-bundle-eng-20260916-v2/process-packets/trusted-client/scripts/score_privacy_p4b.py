#!/usr/bin/env python3
"""P4b privacy re-qualification scoring (docs/PREREGISTRATION_P4B.md, frozen
2026-09-07).

Qualifies the four redesigned families on the fresh P4b calibration captures
(and the width-matched seed-919 calibration for families 1-2), scores the four
P2b frontier cells (trained runs, q in {4,8,16,32}) on qualified families 1-2
via stored probe tensors with 919 latents quantized to the cell's q, scores
families 3-4 on the P4b dense/canary captures at q in {4,32} (declared
limitation: confirmatory runs lack dense transcripts), and applies the frozen
survival rule (cells with no qualified families remain UNDETERMINED).

Thresholds: families 1-3 advantage <= 0.02; family 4: AUC - null-band upper
edge <= 0. Floors are frozen; a family whose positive control fails is
DISQUALIFIED with numbers, never tuned.

Writes outputs/privacy_extended_p4b/privacy_extended_p4b.json + _summary.md.

Usage:
  .venv/bin/python scripts/score_privacy_p4b.py
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "src"))

import pilot_common as pc  # noqa: E402
from score_privacy_extended import compute_survival  # noqa: E402  (unchanged rule)

DEFAULT_OUTPUT_ROOT = ROOT / "outputs" / "privacy_extended_p4b"
RATE_SWEEP_ROOT = ROOT / "outputs" / "rate_sweep"
CALIBRATION_919 = ROOT / "outputs" / "confirmatory" / "calibration-s919" / "calibration_pairs.pt"
P4B_ROOT = ROOT / "outputs" / "privacy_calibration_p4b"
FRONTIER_SEEDS = [7, 17, 27, 37, 47, 57, 67, 87]
FRONTIER_Q = [4, 8, 16, 32]
THRESHOLD_ADVANTAGE = 0.02

OMISSIONS = [
    "timing channels",
    "attacks on optimizer state beyond the remote module",
    "active/adaptive attackers that modify queries",
    "semantic attacks beyond byte-structure classes",
    "membership inference of natural (non-canary) sequences",
    "joint cross-run attacks",
    "families 3-4 (history accumulation, canary membership) evaluated on "
    "calibration captures only: confirmatory runs lack dense transcripts",
    "family-4 scalar score = mean of the frozen 64-dim feature vector "
    "(feature set frozen; reducer fixed by construction and documented)",
    "family-3 evaluation step at q=4 reuses the step selected by the frozen "
    "saturation rule on the q=32 capture (rule is defined at q=32)",
]


def load_dense_samples(run_dir: Path) -> list[dict]:
    import torch

    samples = torch.load(run_dir / "transcript_tensors.pt", map_location="cpu",
                         weights_only=False)
    return sorted(samples, key=lambda s: (s["step"], s.get("probe_batch_index", 0)))


def stack_per_batch(samples: list[dict]) -> dict[int, "torch.Tensor"]:
    """Per probe_batch_index: (S, B, T, W) stacked over captured steps."""
    import torch

    by_batch: dict[int, list] = {}
    for s in samples:
        by_batch.setdefault(s.get("probe_batch_index", 0), []).append(s["forward_values"])
    return {b: torch.stack(v) for b, v in by_batch.items()}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-root", default=str(DEFAULT_OUTPUT_ROOT))
    parser.add_argument("--rate-sweep-root", default=str(RATE_SWEEP_ROOT))
    parser.add_argument("--p4b-root", default=str(P4B_ROOT))
    parser.add_argument("--calibration-919", default=str(CALIBRATION_919))
    parser.add_argument("--device", default="cpu")
    args = parser.parse_args(argv)

    import torch

    import pcr.privacy_attacks_p4b as pb
    from pcr.data import load_corpus, make_probe_batches, split_corpus
    from pcr.utils import resolve_device

    device = resolve_device(args.device)
    output_root = Path(args.output_root)
    p4b_root = Path(args.p4b_root)

    matrix = pc.load_matrix_forgiving(pc.DEFAULT_CONFIRMATORY_MATRIX_PATH)
    _, heldout = split_corpus(load_corpus(ROOT / matrix["fixed"]["corpus"]),
                              matrix["fixed"]["corpus_split"]["train_fraction"])
    probe_batches = make_probe_batches(heldout, matrix["fixed"]["probe_batch_size"],
                                       matrix["fixed"]["sequence_length"], 2)
    tokens_per_batch = [b[0] for b in probe_batches]
    probe_tokens_np = [b[0].numpy().astype(np.int64) for b in probe_batches]

    out = {"note": "P4b privacy re-qualification per docs/PREREGISTRATION_P4B.md; "
                   "floors frozen before measurement; no tuning.",
           "protocol_version": pc.P4B_PROTOCOL,
           "threshold_advantage": THRESHOLD_ADVANTAGE,
           "omissions": OMISSIONS,
           "families": {}}

    # ---------------- family 1 v2 (qualify on 919, score frontier cells) ----
    events = torch.load(args.calibration_919, map_location="cpu", weights_only=False)
    print("qualifying family 1 v2 on calibration-s919 (ridge, continuous targets) ...")
    q1 = pb.family1_v2_qualify(events, seed=919)
    out["families"]["sequence_property_v2"] = {"qualification": q1}
    print(f"  sequence_property_v2: {'QUALIFIED' if q1['qualified'] else 'DISQUALIFIED'} "
          + "; ".join(f"{k}: r_adv={v['r_advantage']:+.4f}" for k, v in q1["per_target"].items()))

    # ---------------- load dense captures -----------------------------------
    print("loading P4b dense captures ...")
    dense_samples = {}
    dense_stacked = {}  # run_id -> {batch_index: (S,B,T,W)}
    for seed in pc.P4B_DENSE_SEEDS:
        for q in pc.P4B_Q_LEVELS:
            run_id = f"p4b-dense-q{q}-s{seed}"
            dense_samples[run_id] = load_dense_samples(p4b_root / run_id)
            dense_stacked[run_id] = stack_per_batch(dense_samples[run_id])
            steps = [s["step"] for s in dense_samples[run_id]]
            print(f"  {run_id}: {len(dense_samples[run_id])} samples, steps "
                  f"{steps[0]}..{steps[-1]}")

    # ---------------- family 2 v2 (qualify on dense q=32) -------------------
    dense_q32_events = []
    for seed in pc.P4B_DENSE_SEEDS:
        dense_q32_events += pb.dense_samples_to_events(
            dense_samples[f"p4b-dense-q32-s{seed}"], tokens_per_batch)
    print(f"qualifying family 2 v2 on dense q=32 captures "
          f"({len(dense_q32_events)} events) ...")
    q2 = pb.family2_v2_qualify(dense_q32_events, seed=919, device=device)
    out["families"]["structure_semantic_v2"] = {"qualification": q2}
    print(f"  structure_semantic_v2: {'QUALIFIED' if q2['qualified'] else 'DISQUALIFIED'} "
          f"adv={q2['advantage']:+.4f} null={q2['null_pipeline_advantage']:+.4f}")

    # ---------------- family 3 v2 (saturation rule on dense q=32) -----------
    captured_steps = sorted({s["step"] for s in dense_samples[f"p4b-dense-q32-s{pc.P4B_DENSE_SEEDS[0]}"]})
    print(f"qualifying family 3 v2 (saturation rule over {len(captured_steps)} captures) ...")
    dense_q32_by_run = {}
    for seed in pc.P4B_DENSE_SEEDS:
        per_batch = dense_stacked[f"p4b-dense-q32-s{seed}"]
        dense_q32_by_run[f"p4b-dense-q32-s{seed}"] = torch.cat(
            [per_batch[0], per_batch[1]], dim=1)  # (S, 16, T, W)
    tokens_16 = np.concatenate([probe_tokens_np[0].reshape(-1),
                                probe_tokens_np[1].reshape(-1)])
    q3 = pb.family3_v2_qualify(dense_q32_by_run, tokens_16, seed=979, device=device,
                               captured_steps=captured_steps)
    out["families"]["history_accumulation_v2"] = {"qualification": q3}
    print(f"  history_accumulation_v2: {'QUALIFIED' if q3['qualified'] else 'DISQUALIFIED'}"
          + (f" ({q3['disqualify_cause']})" if q3.get("disqualify_cause") else ""))

    # ---------------- family 4 v2 (canary) ----------------------------------
    print("scoring canary membership (v2 features, bootstrap null bands) ...")
    q4_out = {"family": "canary_membership_v2", "floors": pb.FLOORS_P4B["canary_membership_v2"],
              "per_q": {}}
    for q in pc.P4B_Q_LEVELS:
        pooled = torch.cat([torch.cat([dense_stacked[f"p4b-dense-q{q}-s{s}"][0],
                                       dense_stacked[f"p4b-dense-q{q}-s{s}"][1]], dim=1)
                            for s in pc.P4B_DENSE_SEEDS])  # (2S, 16, T, W) over both seeds
        n_entries = pooled.shape[0]  # 2S (both seeds' capture series)
        feats = pooled.reshape(-1, pooled.shape[-1]).numpy()
        labels = np.tile(tokens_16, n_entries)
        from pcr.privacy import train_probe
        probe = train_probe(feats, labels, pooled.shape[-1], 20, 4096, 1e-3, 919, device)
        per_seed = {}
        for seed in pc.P4B_CANARY_SEEDS:
            canaries = torch.load(p4b_root / f"p4b-canary-q{q}-s{seed}" / "canaries.pt",
                                  map_location="cpu", weights_only=False)
            null_canaries = torch.load(
                p4b_root / f"p4b-nocanary-q{q}-s{seed}" / "canaries.pt",
                map_location="cpu", weights_only=False)
            per_seed[str(seed)] = pb.family4_v2_score_run(probe, canaries, null_canaries,
                                                          seed, device)
        min_auc = min(v["auc"] for v in per_seed.values())
        nulls_ok = all(v["null_within_band"] for v in per_seed.values())
        q4_out["per_q"][str(q)] = {"per_seed": per_seed, "min_auc": min_auc,
                                   "nulls_within_band": nulls_ok}
    q32 = q4_out["per_q"]["32"]
    q4_out["qualified"] = bool(q32["min_auc"] >= pb.FLOORS_P4B["canary_membership_v2"]["auc"]
                               and q32["nulls_within_band"])
    out["families"]["canary_membership_v2"] = q4_out
    print(f"  canary_membership_v2: {'QUALIFIED' if q4_out['qualified'] else 'DISQUALIFIED'} "
          f"(min AUC {q32['min_auc']:.4f})")

    # ---------------- scoring ------------------------------------------------
    scores = {"families_1_2_frontier_cells": {}, "family_3_dense": {}, "family_4_canary": {}}

    for q in FRONTIER_Q:
        cell = f"medium-high-q{q}"
        banks = {}
        if q1["qualified"]:
            print(f"  family-1 v2 ridge probes at q={q} ...", flush=True)
            banks["sequence_property_v2"] = pb.family1_v2_train(events, q, seed=919)
        if q2["qualified"]:
            print(f"  family-2 v2 strong probe at q={q} (200 epochs) ...", flush=True)
            banks["structure_semantic_v2"] = pb.family2_v2_train(events, q, 919, device)
        cell_result = {}
        for seed in FRONTIER_SEEDS:
            run_dir = Path(args.rate_sweep_root) / f"trained-medium-high-q{q}-s{seed}"
            tensors = torch.load(run_dir / "transcript_tensors.pt", map_location="cpu",
                                 weights_only=False)
            final = max((s for s in tensors if s.get("probe_batch_index", 0) == 0),
                        key=lambda s: s["step"])
            entry = {}
            if "sequence_property_v2" in banks:
                entry["sequence_property_v2"] = pb.family1_v2_apply(
                    banks["sequence_property_v2"], final["forward_values"],
                    probe_batches[0][0], q)
            if "structure_semantic_v2" in banks:
                entry["structure_semantic_v2"] = pb.family2_v2_apply(
                    banks["structure_semantic_v2"], final["forward_values"],
                    probe_batches[0][0], q, device)
            cell_result[str(seed)] = entry
        summary = {}
        if q1["qualified"]:
            props = {}
            for prop in ("vowel_fraction", "punctuation_fraction", "newline_count"):
                advs = [cell_result[s]["sequence_property_v2"][prop]["r_advantage"]
                        for s in cell_result]
                props[prop] = {"max_advantage": max(advs), "per_seed": advs,
                               "pass": max(advs) <= THRESHOLD_ADVANTAGE}
            summary["sequence_property_v2"] = {
                "scored": True, "per_property": props,
                "pass": all(p["pass"] for p in props.values())}
        else:
            summary["sequence_property_v2"] = {"scored": False,
                                               "reason": "family disqualified"}
        if q2["qualified"]:
            advs = [cell_result[s]["structure_semantic_v2"]["advantage"]
                    for s in cell_result]
            summary["structure_semantic_v2"] = {"scored": True, "max_advantage": max(advs),
                                                "per_seed": advs,
                                                "pass": max(advs) <= THRESHOLD_ADVANTAGE}
        else:
            summary["structure_semantic_v2"] = {"scored": False,
                                                "reason": "family disqualified"}
        scores["families_1_2_frontier_cells"][cell] = {"per_seed": cell_result,
                                                       "summary": summary}
        print(f"  {cell}: " + "; ".join(
            f"{f} pass={v.get('pass')}" if v.get("scored") else f"{f} not-scored"
            for f, v in summary.items()), flush=True)

    # family 3 v2 scores on dense captures at q in {4, 32}: same evaluation
    # step as selected by the frozen saturation rule at q=32 (per seed)
    for q in pc.P4B_Q_LEVELS:
        per_run = {}
        for seed in pc.P4B_DENSE_SEEDS:
            run_q32 = f"p4b-dense-q32-s{seed}"
            idx = q3["per_run"][run_q32]["saturation_index"]
            run_q = f"p4b-dense-q{q}-s{seed}"
            lat = torch.cat([dense_stacked[run_q][0], dense_stacked[run_q][1]], dim=1)
            if idx is None:
                per_run[run_q] = {"scored": False,
                                  "cause": q3["per_run"][run_q32]["cause"]}
                continue
            result = pb.family3_v2_evaluate_at(lat, tokens_16, idx, 979, device)
            result["scored"] = True
            result["evaluation_step"] = captured_steps[idx]
            per_run[run_q] = result
        evaluated = [r for r in per_run.values() if r.get("scored")]
        max_adv = max((r["advantage"] for r in evaluated), default=None)
        scores["family_3_dense"][f"q{q}"] = {
            "per_run": per_run,
            "max_advantage": max_adv,
            "pass": (max_adv <= THRESHOLD_ADVANTAGE
                     if (q3["qualified"] and evaluated) else None),
            "scored": bool(q3["qualified"] and evaluated),
        }

    # family 4 v2 scores per q: pass iff max over seeds of (AUC - band_high) <= 0
    for q in pc.P4B_Q_LEVELS:
        per_q = q4_out["per_q"][str(q)]
        margins = {seed: v["auc"] - v["null_band"]["band_high"]
                   for seed, v in per_q["per_seed"].items()}
        scores["family_4_canary"][f"q{q}"] = {
            "auc_minus_band_high_per_seed": margins,
            "max_margin": max(margins.values()),
            "pass": (max(margins.values()) <= 0 if q4_out["qualified"] else None),
            "scored": bool(q4_out["qualified"]),
        }

    survival = compute_survival(scores, FRONTIER_Q, q3["qualified"], q4_out["qualified"])

    out["scores"] = scores
    out["frontier_survival"] = survival
    out["verdicts"] = {
        "qualified_families": [f for f, v in out["families"].items()
                               if v.get("qualified") or v.get("qualification", {}).get("qualified")],
        "disqualified_families": [f for f, v in out["families"].items()
                                  if not (v.get("qualified")
                                          or v.get("qualification", {}).get("qualified"))],
        "surviving_cells": [c for c, v in survival.items() if v["survives"] is True],
        "shrunk_cells": [c for c, v in survival.items() if v["survives"] is False],
        "undetermined_cells": [c for c, v in survival.items() if v["survives"] is None],
    }

    output_root.mkdir(parents=True, exist_ok=True)
    json_path = output_root / "privacy_extended_p4b.json"
    json_path.write_text(json.dumps(out, indent=2, sort_keys=True))
    md_path = output_root / "privacy_extended_p4b_summary.md"
    md_path.write_text(render_markdown(out))
    print(render_markdown(out))
    print(f"wrote {json_path}\nwrote {md_path}")
    return 0


def render_markdown(out: dict) -> str:
    lines = [
        "# P4b privacy re-qualification (protocol p4b-privacy-requalification-1.0)",
        "",
        "## Qualification verdicts (frozen floors)",
        "",
        "| Family | verdict | key numbers |",
        "|---|---|---|",
    ]
    fams = out["families"]
    q1 = fams["sequence_property_v2"]["qualification"]
    nums = "; ".join(f"{t}: r_adv {v['r_advantage']:+.4f}, null {v['null_pipeline_advantage']:+.4f}"
                     for t, v in q1["per_target"].items())
    lines.append(f"| sequence_property_v2 | {'QUALIFIED' if q1['qualified'] else 'DISQUALIFIED'}"
                 f" | {nums} |")
    q2 = fams["structure_semantic_v2"]["qualification"]
    lines.append(f"| structure_semantic_v2 | {'QUALIFIED' if q2['qualified'] else 'DISQUALIFIED'}"
                 f" | adv {q2['advantage']:+.4f} (floor {q2['floor']}), "
                 f"null {q2['null_pipeline_advantage']:+.4f} |")
    q3 = fams["history_accumulation_v2"]["qualification"]
    if q3.get("disqualify_cause"):
        extra = q3["disqualify_cause"]
    else:
        extra = (f"min adv {q3.get('min_advantage'):+.4f} (floor {q3['floor']}), "
                 f"max |null| {q3.get('max_abs_null_advantage'):.4f} (band {q3['null_band']})")
    lines.append(f"| history_accumulation_v2 | {'QUALIFIED' if q3['qualified'] else 'DISQUALIFIED'}"
                 f" | {extra} |")
    q4 = fams["canary_membership_v2"]
    lines.append(f"| canary_membership_v2 | {'QUALIFIED' if q4['qualified'] else 'DISQUALIFIED'}"
                 f" | min AUC {q4['per_q']['32']['min_auc']:.4f} (floor 0.75), "
                 f"nulls within band: {q4['per_q']['32']['nulls_within_band']} |")
    lines += ["", "## Frontier survival", "",
              "| Cell | qualified-family checks | survives |", "|---|---|---|"]
    for cell, v in out["frontier_survival"].items():
        checks = "; ".join(f"{k}: {'pass' if val else 'FAIL'}"
                           for k, val in v["qualified_family_checks"].items())
        status = "YES" if v["survives"] is True else ("NO" if v["survives"] is False
                                                      else "UNDETERMINED")
        lines.append(f"| {cell} | {checks or 'none (no qualified family)'} | {status} |")
    lines += ["", "## Named omissions (per AGENTS.md rule 6)", ""]
    for omission in out["omissions"]:
        lines.append(f"- {omission}")
    lines.append("")
    return "\n".join(lines)


if __name__ == "__main__":
    sys.exit(main())
