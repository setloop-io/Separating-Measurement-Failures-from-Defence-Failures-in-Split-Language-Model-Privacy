"""Statistical utilities for the frozen confirmatory analysis (no scipy).

t- and F-distribution CDFs via the regularized incomplete beta function
(continued fraction, Numerical Recipes betacf), paired t-tests, balanced
two-way ANOVA, and Wilcoxon signed-rank (normal approximation with continuity
and tie correction). All implementations are validated against textbook
reference values in tests/test_confirmatory.py.

Inferential unit everywhere here: the independent training run/seed.
"""

from __future__ import annotations

import math
from statistics import NormalDist, mean, stdev

_FLOORED = 1e-300


# --------------------------------------------------------------------------- #
# regularized incomplete beta I_x(a, b)
# --------------------------------------------------------------------------- #
def _betacf(a: float, b: float, x: float, max_iter: int = 500, eps: float = 3e-14) -> float:
    """Continued fraction for the incomplete beta function (Numerical Recipes)."""
    qab, qap, qam = a + b, a + 1.0, a - 1.0
    c = 1.0
    d = 1.0 - qab * x / qap
    if abs(d) < _FLOORED:
        d = _FLOORED
    d = 1.0 / d
    h = d
    for m in range(1, max_iter + 1):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d
        if abs(d) < _FLOORED:
            d = _FLOORED
        c = 1.0 + aa / c
        if abs(c) < _FLOORED:
            c = _FLOORED
        d = 1.0 / d
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d
        if abs(d) < _FLOORED:
            d = _FLOORED
        c = 1.0 + aa / c
        if abs(c) < _FLOORED:
            c = _FLOORED
        d = 1.0 / d
        delta = d * c
        h *= delta
        if abs(delta - 1.0) < eps:
            break
    return h


def regularized_incomplete_beta(x: float, a: float, b: float) -> float:
    """I_x(a, b) = B(x; a, b) / B(a, b)."""
    if not 0.0 <= x <= 1.0:
        raise ValueError(f"x must be in [0, 1], got {x}")
    if a <= 0 or b <= 0:
        raise ValueError(f"a, b must be positive, got {a}, {b}")
    if x == 0.0:
        return 0.0
    if x == 1.0:
        return 1.0
    ln_bt = (
        math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b)
        + a * math.log(x) + b * math.log1p(-x)
    )
    bt = math.exp(ln_bt)
    if x < (a + 1.0) / (a + b + 2.0):
        return bt * _betacf(a, b, x) / a
    return 1.0 - bt * _betacf(b, a, 1.0 - x) / b


# --------------------------------------------------------------------------- #
# t and F distributions
# --------------------------------------------------------------------------- #
def t_cdf(t: float, df: float) -> float:
    """P(T <= t) for Student's t with df degrees of freedom."""
    if df <= 0:
        raise ValueError(f"df must be positive, got {df}")
    x = df / (df + t * t)
    ib = regularized_incomplete_beta(x, df / 2.0, 0.5)
    return 1.0 - 0.5 * ib if t >= 0 else 0.5 * ib


def t_sf(t: float, df: float) -> float:
    return 1.0 - t_cdf(t, df)


def t_ppf(p: float, df: float) -> float:
    """Inverse CDF of the t distribution (bisection; fine for fixed alphas)."""
    if not 0.0 < p < 1.0:
        raise ValueError(f"p must be in (0, 1), got {p}")
    lo, hi = -1.0, 1.0
    while t_cdf(lo, df) > p:
        lo *= 2.0
    while t_cdf(hi, df) < p:
        hi *= 2.0
    for _ in range(200):
        mid = 0.5 * (lo + hi)
        if t_cdf(mid, df) < p:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


def f_cdf(f: float, d1: float, d2: float) -> float:
    """P(F <= f) for the F distribution with (d1, d2) degrees of freedom."""
    if d1 <= 0 or d2 <= 0:
        raise ValueError(f"df must be positive, got {d1}, {d2}")
    if f <= 0:
        return 0.0
    x = d1 * f / (d1 * f + d2)
    return regularized_incomplete_beta(x, d1 / 2.0, d2 / 2.0)


def f_sf(f: float, d1: float, d2: float) -> float:
    return 1.0 - f_cdf(f, d1, d2)


# --------------------------------------------------------------------------- #
# paired t-test over per-seed gains
# --------------------------------------------------------------------------- #
def paired_t_test(gains: list[float], alternative: str = "two-sided") -> dict:
    """Paired (one-sample) t-test on per-seed contrasts.

    alternative: "two-sided" | "greater" | "less". The 95% CI is two-sided
    regardless of the test directionality.
    """
    n = len(gains)
    if n < 2:
        return {"n": n, "mean": mean(gains) if gains else None, "sd": None,
                "se": None, "t": None, "df": n - 1, "p": None,
                "ci95_low": None, "ci95_high": None, "alternative": alternative,
                "note": "fewer than 2 seeds; test not computable"}
    mu = mean(gains)
    sd = stdev(gains)
    se = sd / math.sqrt(n)
    df = n - 1
    tcrit = t_ppf(0.975, df)
    if se == 0.0:
        # zero across-seed variance: t is degenerate; p pinned by sign of mean
        if alternative == "greater":
            p = 0.0 if mu > 0 else 1.0
        elif alternative == "less":
            p = 0.0 if mu < 0 else 1.0
        else:
            p = 0.0 if mu != 0 else 1.0
        return {"n": n, "mean": mu, "sd": sd, "se": se, "t": None, "df": df, "p": p,
                "ci95_low": mu, "ci95_high": mu, "alternative": alternative,
                "note": "zero across-seed variance; t degenerate (sign-pinned p)"}
    t = mu / se
    if alternative == "greater":
        p = t_sf(t, df)
    elif alternative == "less":
        p = t_cdf(t, df)
    else:
        p = min(1.0, 2.0 * t_sf(abs(t), df))
    return {"n": n, "mean": mu, "sd": sd, "se": se, "t": t, "df": df, "p": p,
            "ci95_low": mu - tcrit * se, "ci95_high": mu + tcrit * se,
            "alternative": alternative, "note": None}


# --------------------------------------------------------------------------- #
# balanced two-way ANOVA on seed-level gains: factor A (span) x factor B (width)
# --------------------------------------------------------------------------- #
def two_way_anova_balanced(cell_values: dict[tuple[str, str], list[float]],
                           levels_a: list[str], levels_b: list[str]) -> dict:
    """Balanced two-way ANOVA with replication (equal n per cell).

    cell_values maps (a_level, b_level) -> per-seed gains. Raises ValueError
    on missing cells or unequal cell sizes (unbalanced design is out of scope
    for the frozen analysis and must be reported instead).
    """
    a, b = len(levels_a), len(levels_b)
    ns = set()
    for la in levels_a:
        for lb in levels_b:
            values = cell_values.get((la, lb))
            if not values:
                raise ValueError(f"missing cell ({la}, {lb}); design is unbalanced")
            ns.add(len(values))
    if len(ns) != 1:
        raise ValueError(f"unequal cell sizes {sorted(ns)}; design is unbalanced")
    n = ns.pop()

    cell_means = {(la, lb): mean(cell_values[(la, lb)]) for la in levels_a for lb in levels_b}
    a_means = {la: mean(cell_means[(la, lb)] for lb in levels_b) for la in levels_a}
    b_means = {lb: mean(cell_means[(la, lb)] for la in levels_a) for lb in levels_b}
    grand = mean(v for values in cell_values.values() for v in values)

    ss_a = b * n * sum((a_means[la] - grand) ** 2 for la in levels_a)
    ss_b = a * n * sum((b_means[lb] - grand) ** 2 for lb in levels_b)
    ss_ab = n * sum(
        (cell_means[(la, lb)] - a_means[la] - b_means[lb] + grand) ** 2
        for la in levels_a for lb in levels_b
    )
    ss_e = sum(
        (v - cell_means[(la, lb)]) ** 2
        for la in levels_a for lb in levels_b for v in cell_values[(la, lb)]
    )
    ss_t = sum((v - grand) ** 2 for values in cell_values.values() for v in values)

    df_a, df_b, df_ab, df_e = a - 1, b - 1, (a - 1) * (b - 1), a * b * (n - 1)
    ms_e = ss_e / df_e if df_e else float("nan")

    def factor(ss: float, df: int) -> dict:
        ms = ss / df
        f = ms / ms_e if ms_e > 0 else (math.inf if ms > 0 else float("nan"))
        return {"ss": ss, "df": df, "ms": ms, "F": f,
                "p": f_sf(f, df, df_e) if math.isfinite(f) else (0.0 if f > 0 else None)}

    return {
        "levels_a": list(levels_a), "levels_b": list(levels_b), "n_per_cell": n,
        "factor_a": factor(ss_a, df_a), "factor_b": factor(ss_b, df_b),
        "interaction": factor(ss_ab, df_ab),
        "error": {"ss": ss_e, "df": df_e, "ms": ms_e},
        "total": {"ss": ss_t, "df": a * b * n - 1},
    }


# --------------------------------------------------------------------------- #
# OLS slope, Pearson/Spearman correlations, mean + t-based CI
# --------------------------------------------------------------------------- #
def ols_slope(xs: list[float], ys: list[float]) -> tuple[float, float]:
    """Simple linear regression of y on x; returns (slope, intercept)."""
    if len(xs) != len(ys) or len(xs) < 2:
        raise ValueError(f"need >= 2 paired points, got {len(xs)} / {len(ys)}")
    x_bar, y_bar = mean(xs), mean(ys)
    sxx = sum((x - x_bar) ** 2 for x in xs)
    if sxx == 0:
        raise ValueError("zero variance in x; slope undefined")
    sxy = sum((x - x_bar) * (y - y_bar) for x, y in zip(xs, ys))
    slope = sxy / sxx
    return slope, y_bar - slope * x_bar


def pearson(xs: list[float], ys: list[float]) -> float:
    if len(xs) != len(ys) or len(xs) < 2:
        raise ValueError(f"need >= 2 paired points, got {len(xs)} / {len(ys)}")
    x_bar, y_bar = mean(xs), mean(ys)
    sxx = sum((x - x_bar) ** 2 for x in xs)
    syy = sum((y - y_bar) ** 2 for y in ys)
    if sxx == 0 or syy == 0:
        raise ValueError("zero variance; correlation undefined")
    sxy = sum((x - x_bar) * (y - y_bar) for x, y in zip(xs, ys))
    return sxy / math.sqrt(sxx * syy)


def spearman(xs: list[float], ys: list[float]) -> float | None:
    """Spearman rank correlation: Pearson on average ranks (ties averaged).

    Returns None when either series is constant (correlation undefined);
    reported as unavailable, never gated.
    """
    if len(xs) != len(ys) or len(xs) < 2:
        raise ValueError(f"need >= 2 paired points, got {len(xs)} / {len(ys)}")
    rx = _average_ranks(list(xs))
    ry = _average_ranks(list(ys))
    if len(set(rx)) < 2 or len(set(ry)) < 2:
        return None
    return pearson(rx, ry)


def mean_ci(values: list[float], level: float = 0.95) -> dict:
    """Mean with a two-sided t-based CI at the given level (seed-level data)."""
    n = len(values)
    if n == 0:
        return {"n": 0, "mean": None, "sd": None, "ci_low": None, "ci_high": None}
    mu = mean(values)
    if n < 2:
        return {"n": n, "mean": mu, "sd": None, "ci_low": None, "ci_high": None}
    sd = stdev(values)
    se = sd / math.sqrt(n)
    half = t_ppf(1 - (1 - level) / 2, n - 1) * se
    return {"n": n, "mean": mu, "sd": sd, "ci_low": mu - half, "ci_high": mu + half}


def ols_multivariate(X: list[list[float]], y: list[float]) -> dict:
    """Least-squares fit y ~ intercept + X (numpy lstsq; min-norm when
    rank-deficient). Returns intercept, coefficients, and the design rank."""
    import numpy as np

    x_arr = np.asarray(X, dtype=float)
    y_arr = np.asarray(y, dtype=float)
    if x_arr.ndim != 2 or x_arr.shape[0] != y_arr.shape[0] or x_arr.shape[0] < 1:
        raise ValueError(f"bad shapes: X {x_arr.shape}, y {y_arr.shape}")
    n, k = x_arr.shape
    design = np.column_stack([np.ones(n), x_arr])
    beta, _residuals, rank, _sv = np.linalg.lstsq(design, y_arr, rcond=None)
    return {"intercept": float(beta[0]), "coefficients": beta[1:].tolist(),
            "rank": int(rank), "n": n, "k": k}


def predict_linear(fit: dict, xs: list[float]) -> float:
    """Predict from an ols_multivariate/OLS fit dict at one point."""
    return fit["intercept"] + sum(b * x for b, x in zip(fit["coefficients"], xs))


def r2_out_of_sample(y_true: list[float], y_pred: list[float], baseline_mean: float) -> float:
    """Out-of-sample R^2 against the exploratory (fit-set) mean baseline:
    1 - SSE / SST with SST = sum((y - baseline_mean)^2)."""
    sse = sum((t - p) ** 2 for t, p in zip(y_true, y_pred))
    sst = sum((t - baseline_mean) ** 2 for t in y_true)
    if sst == 0:
        return float("nan")
    return 1.0 - sse / sst
def _average_ranks(values: list[float]) -> list[float]:
    order = sorted(range(len(values)), key=lambda i: values[i])
    ranks = [0.0] * len(values)
    i = 0
    while i < len(order):
        j = i
        while j + 1 < len(order) and values[order[j + 1]] == values[order[i]]:
            j += 1
        rank = (i + j) / 2.0 + 1.0
        for k in range(i, j + 1):
            ranks[order[k]] = rank
        i = j + 1
    return ranks


def wilcoxon_signed_rank(gains: list[float]) -> dict:
    """One-sided (greater) Wilcoxon signed-rank, normal approx with continuity
    correction and tie-corrected variance. Reported, not gated, per the frozen
    confirmatory rule (sensitivity analysis for the primary cells)."""
    nonzero = [g for g in gains if g != 0]
    n = len(nonzero)
    if n < 2:
        return {"n": n, "w_plus": None, "z": None, "p_one_sided": None,
                "note": "fewer than 2 nonzero gains; not computable"}
    magnitudes = [abs(g) for g in nonzero]
    ranks = _average_ranks(magnitudes)
    w_plus = sum(r for r, g in zip(ranks, nonzero) if g > 0)
    mean_w = n * (n + 1) / 4.0
    tie_term = 0.0
    i = 0
    order = sorted(magnitudes)
    while i < n:
        j = i
        while j + 1 < n and order[j + 1] == order[i]:
            j += 1
        t = j - i + 1
        tie_term += t ** 3 - t
        i = j + 1
    var_w = (n * (n + 1) * (2 * n + 1) - tie_term / 2.0) / 24.0
    sd_w = math.sqrt(var_w)
    # continuity correction toward the mean
    correction = 0.5 if w_plus > mean_w else (-0.5 if w_plus < mean_w else 0.0)
    z = (w_plus - mean_w - correction) / sd_w
    p_one_sided = 1.0 - NormalDist().cdf(z)
    note = "normal approximation with continuity correction"
    if n < 10:
        note += f"; n={n} is small, interpret with care"
    return {"n": n, "w_plus": w_plus, "mean_w": mean_w, "sd_w": sd_w,
            "z": z, "p_one_sided": p_one_sided, "note": note}
