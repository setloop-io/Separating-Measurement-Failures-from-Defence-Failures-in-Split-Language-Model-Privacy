#!/usr/bin/env python3
"""P2b rate-sweep analysis — implements the frozen confirmatory_rule of
experiments/configs/rate_sweep_matrix.yaml verbatim (protocol
p2b-rate-sweep-1.0; docs/PREREGISTRATION_P2B.md).

Discovery: completed runs from manifests (cohort="confirmatory",
protocol_version="p2b-rate-sweep-1.0" required on cell-run manifests);
missing/failed runs are reported operational failures. Frozen missing-data
rule: a seed missing a trained/frozen pair member is dropped from that q
cell's paired test and from the primary slope fit (predeclared, never
outcome-based).

Primary (H3): per-seed OLS slope of trained-mode step-2000 eval loss on
q_bits in {4, 8, 16, 32}; one-sided t-test over the 8 slopes (slope < 0) at
alpha 0.05; practical effect = mean eval-loss reduction q=4 -> q=32 >= 0.01
nats. CONFIRMED iff p < alpha AND practical effect met.

Secondary: per q_bits cell, one-sided paired t-test of G_R
(frozen - trained, step 2000) at Bonferroni alpha 0.0125 (4 tests);
persistence of mean G_R > 0 at steps 1800/1900/2000 reported; Delta_U and
removed-remote reference per q (mean + 95% CI, descriptive).

Sensitivity: per-seed Spearman rank correlation of loss vs q_bits (reported,
not gated).

Privacy: token-inversion advantage <= 0.02 per q cell; probes are calibrated
on the reused width-256 seed-919 artifact quantized on-the-fly to each cell's
q_bits (score_privacy.py already routes per-run q_bits). Auto-invokes the
scorer when outputs/rate_sweep/privacy_scores.json is missing.

Frontier: per q cell, measured bits/token from the byte counters
(metrics_summary.json), eval loss mean/CI, G_R mean/CI, privacy advantage;
feasible iff the secondary G_R test confirms AND privacy passes.

Outputs: outputs/rate_sweep/rate_sweep_analysis.json,
outputs/rate_sweep/rate_sweep_summary.md, and
paper/figures/rate_sweep_frontier.png (if matplotlib is available).

Usage (after scripts/run_rate_sweep.py finishes):
  .venv/bin/python scripts/analyze_rate_sweep.py
"""

from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from pathlib import Path
from statistics import mean

sys.path.insert(0, str(Path(__file__).resolve().parent))  # pilot_common, stats_utils, ...

import pilot_common as pc  # noqa: E402
import stats_utils as su  # noqa: E402
from analyze_confirmatory import cell_privacy  # noqa: E402
from analyze_pilot import _fmt, collect_run, ensure_matplotlib  # noqa: E402

DEFAULT_FIGURE_PATH = pc.REPO_ROOT / "paper" / "figures" / "rate_sweep_frontier.png"

P2B_NOTE = (
    "Confirmatory rate-sweep analysis under protocol p2b-rate-sweep-1.0 "
    "(frozen 2026-09-04, fresh seeds [7..87]); per docs/PREREGISTRATION_P2B.md. "
    "Privacy scope: token-inversion family only; membership, property, and "
    "history-accumulation attacks remain out of scope."
)


def parse_number_from_prose(text: str, pattern: str) -> float:
    """Extract a frozen threshold embedded in rule prose, e.g. '>= 0.01 nats'."""
    match = re.search(pattern, text)
    if not match:
        raise ValueError(f"could not parse threshold from rule prose: {text!r} (pattern {pattern!r})")
    return float(match.group(1))


# --------------------------------------------------------------------------- #
# per-q cell construction
# --------------------------------------------------------------------------- #
def build_q_cells(records: dict[str, dict], matrix: dict) -> tuple[dict, dict]:
    """Per q cell: per-seed G_R (by step + final), trained final losses,
    Delta_U, removed reference, persistence means. Returns (cells, meta)."""
    span = next(iter(matrix["factors"]["segment_span"]))   # medium
    width = next(iter(matrix["factors"]["latent_width"]))  # high
    seeds = matrix["factors"]["seed"]
    q_levels = matrix["factors"]["q_bits"]
    cells: dict[str, dict] = {}
    final_step_seen, persistence_seen = None, []
    for q in q_levels:
        key = pc.rate_sweep_cell_key(span, width, q)
        gains_by_seed: dict[str, dict] = {}
        dropped: list[int] = []
        trained_final: dict[str, float] = {}
        delta_u: dict[str, float | None] = {}
        removed_ref: dict[str, float | None] = {}
        for s in seeds:
            trained = records.get(pc.rate_sweep_run_id("trained", s, q, span, width))
            frozen = records.get(pc.rate_sweep_run_id("frozen_random", s, q, span, width))
            if trained is not None:
                trained_final[str(s)] = trained["final_eval_loss"]
            local = records.get(pc.rate_sweep_run_id("all_local", s))
            removed = records.get(pc.rate_sweep_run_id("removed_remote", s, q, span=span))
            if trained is not None and local is not None \
                    and trained["final_step"] in local["eval_series"]:
                delta_u[str(s)] = (trained["final_eval_loss"]
                                   - local["eval_series"][trained["final_step"]])
            else:
                delta_u[str(s)] = None
            if removed is not None and local is not None \
                    and removed["final_step"] in local["eval_series"]:
                removed_ref[str(s)] = (removed["final_eval_loss"]
                                       - local["eval_series"][removed["final_step"]])
            else:
                removed_ref[str(s)] = None
            if trained is None or frozen is None:
                dropped.append(s)  # frozen missing-data rule: drop the seed
                continue
            shared = sorted(set(trained["eval_series"]) & set(frozen["eval_series"]))
            by_step = {st: frozen["eval_series"][st] - trained["eval_series"][st]
                       for st in shared}
            gains_by_seed[str(s)] = {"by_step": by_step}
        eval_steps = sorted({st for g in gains_by_seed.values() for st in g["by_step"]})
        if not eval_steps:
            cells[key] = {"q_bits": q, "status": "no_paired_seeds", "seeds_used": [],
                          "dropped_seeds": dropped}
            continue
        final_step = max(eval_steps)
        persistence_steps = eval_steps[-3:]
        final_step_seen = final_step
        persistence_seen = persistence_steps
        final_gains = {s: g["by_step"][final_step] for s, g in gains_by_seed.items()
                       if final_step in g["by_step"]}
        mean_gain_by_step = {}
        for st in persistence_steps:
            values = [g["by_step"][st] for g in gains_by_seed.values() if st in g["by_step"]]
            mean_gain_by_step[str(st)] = mean(values) if values else None
        bits = [records[pc.rate_sweep_run_id("trained", s, q, span, width)].get("bits_per_token_total")
                for s in seeds
                if pc.rate_sweep_run_id("trained", s, q, span, width) in records]
        cells[key] = {
            "q_bits": q, "status": "ok",
            "seeds_used": sorted(int(s) for s in final_gains),
            "dropped_seeds": dropped,
            "final_step": final_step,
            "persistence_steps": persistence_steps,
            "gains_by_seed": gains_by_seed,
            "final_gains": final_gains,
            "mean_gain_by_step": mean_gain_by_step,
            "trained_final_loss": trained_final,
            "delta_u_by_seed": delta_u,
            "removed_ref_by_seed": removed_ref,
            "bits_per_token": su.mean_ci([b for b in bits if b is not None]),
        }
    return cells, {"final_step": final_step_seen, "persistence_steps": persistence_seen}


# --------------------------------------------------------------------------- #
# frozen rules
# --------------------------------------------------------------------------- #
def evaluate_primary(cells: dict, q_levels: list[int], seeds: list[int],
                     span: str, width: str, primary_rule: dict) -> dict:
    """H3: one-sided t over per-seed OLS slopes (slope < 0) + practical effect."""
    alpha = float(primary_rule["alpha"])
    threshold = parse_number_from_prose(primary_rule["practical_effect"], r">=\s*([0-9.]+)")
    # frozen missing-data rule: a seed missing ANY pair member (at any q) is
    # dropped from the slope fit
    slope_seeds = [
        s for s in seeds
        if all(str(s) in cells[pc.rate_sweep_cell_key(span, width, q)]["final_gains"]
               for q in q_levels)
    ]
    slopes: dict[str, float] = {}
    reductions: dict[str, float] = {}
    spearmans: dict[str, float] = {}
    for s in slope_seeds:
        ys = [cells[pc.rate_sweep_cell_key(span, width, q)]["trained_final_loss"][str(s)]
              for q in q_levels]
        slope, _intercept = su.ols_slope([float(q) for q in q_levels], ys)
        slopes[str(s)] = slope
        reductions[str(s)] = ys[0] - ys[-1]
        spearmans[str(s)] = su.spearman([float(q) for q in q_levels], ys)
    slope_values = [slopes[str(s)] for s in slope_seeds]
    test = su.paired_t_test(slope_values, alternative="less")
    reduction_ci = su.mean_ci([reductions[str(s)] for s in slope_seeds])
    p_pass = test["p"] is not None and test["p"] < alpha
    practical_pass = (reduction_ci["mean"] is not None and reduction_ci["mean"] >= threshold)
    confirmed = bool(p_pass and practical_pass)
    failed = []
    if not p_pass:
        failed.append("p_value")
    if not practical_pass:
        failed.append("practical_effect")
    return {
        "alpha": alpha, "practical_effect_threshold": threshold,
        "practical_effect_prose": primary_rule["practical_effect"],
        "endpoint": primary_rule["endpoint"],
        "slope_seeds": slope_seeds,
        "dropped_seeds": [s for s in seeds if s not in slope_seeds],
        "slopes_by_seed": slopes, "reduction_q4_q32_by_seed": reductions,
        "spearman_by_seed": spearmans,
        "t_test": test, "reduction_q4_q32": reduction_ci,
        "p_pass": p_pass, "practical_pass": practical_pass,
        "confirmed": confirmed, "failed_conditions": failed,
        "verdict": "CONFIRMED" if confirmed else "NOT CONFIRMED",
    }


def evaluate_secondary_cell(cell: dict, alpha: float) -> dict:
    gains = [cell["final_gains"][s] for s in sorted(cell["final_gains"], key=int)]
    test = su.paired_t_test(gains, alternative="greater")
    significant = test["p"] is not None and test["p"] < alpha
    persistence = bool(cell["mean_gain_by_step"]) and all(
        v is not None and v > 0 for v in cell["mean_gain_by_step"].values())
    return {"t_test": test, "alpha": alpha, "significant": significant,
            "persistence_mean_gains": cell["mean_gain_by_step"],
            "persistence_positive": persistence}


# --------------------------------------------------------------------------- #
# privacy (auto-invoke scorer when missing)
# --------------------------------------------------------------------------- #
def load_privacy_scores(path: Path, autoscore: bool, args) -> tuple[dict | None, str]:
    if path.is_file():
        return pc.load_json(path), str(path)
    if not autoscore:
        return None, f"{path} missing and autoscore disabled"
    scorer = Path(__file__).resolve().parent / "score_privacy.py"
    cmd = [sys.executable, str(scorer), "--config", args.config,
           "--output-root", args.output_root, "--manifest-dir", args.manifest_dir,
           "--output", str(path)]
    print(f"privacy scores missing; running {' '.join(cmd)}")
    proc = subprocess.run(cmd, check=False)
    if proc.returncode != 0 or not path.is_file():
        return None, f"score_privacy.py failed (exit {proc.returncode})"
    return pc.load_json(path), f"{path} (generated by score_privacy.py)"


# --------------------------------------------------------------------------- #
# figure
# --------------------------------------------------------------------------- #
def frontier_panel_data(frontier: list[dict]) -> dict:
    """Assemble the two panels' plotting data from frontier rows (pure).

    Left panel: trained eval loss vs measured bits/token, per-seed eval losses.
    Right panel: G_R vs measured bits/token, per-seed paired gains
    (frozen minus trained). Regression guard: the G_R panel must carry
    per-seed G_R values, never the absolute eval-loss values.
    """
    rows = [row for row in frontier if row.get("status") == "ok"]
    return {
        "xs": [row["bits_per_token"]["mean"] for row in rows],
        "feasible": [bool(row["feasible"]) for row in rows],
        "panels": {
            "eval_loss": {
                "means": [row["eval_loss"]["mean"] for row in rows],
                "errs": [row["eval_loss"]["mean"] - row["eval_loss"]["ci_low"] for row in rows],
                "per_seed": [row.get("per_seed_eval_loss") for row in rows],
                "ylabel": "held-out eval loss (step 2000)",
                "title": "trained utility vs measured rate",
            },
            "gain": {
                "means": [row["gain"]["mean"] for row in rows],
                "errs": [row["gain"]["mean"] - row["gain"]["ci_low"] for row in rows],
                "per_seed": [row.get("per_seed_gain") for row in rows],
                "ylabel": "G_R = L(frozen) - L(trained)",
                "title": "causal remote-learning gain vs measured rate",
            },
        },
    }


def make_frontier_figure(frontier: list[dict], figure_path: Path) -> bool:
    mpl = ensure_matplotlib()
    if mpl is None:
        print("matplotlib unavailable; skipping rate-sweep frontier figure")
        return False
    mpl.use("Agg")
    import matplotlib.pyplot as plt

    data = frontier_panel_data(frontier)
    xs, feasible = data["xs"], data["feasible"]

    fig, axes = plt.subplots(1, 2, figsize=(12, 4.8))
    for ax, panel in zip(axes, (data["panels"]["eval_loss"], data["panels"]["gain"])):
        means, errs = panel["means"], panel["errs"]
        ax.errorbar(xs, means, yerr=errs, fmt="o-", color="tab:blue", capsize=4,
                    label="mean +/- 95% CI")
        first_feasible = True
        for x, m, f in zip(xs, means, feasible):
            if f:
                ax.scatter([x], [m], s=180, facecolors="none", edgecolors="tab:green",
                           linewidths=2.0,
                           label="frontier-feasible" if first_feasible else None)
                first_feasible = False
        # faint per-seed points (panel-specific series: losses vs gains)
        for x, per_seed in zip(xs, panel["per_seed"]):
            if per_seed:
                ax.scatter([x] * len(per_seed), per_seed, color="tab:blue", alpha=0.25, s=12)
        ax.set_xscale("log", base=2)
        ax.set_xlabel("measured bits/token (log2 scale)")
        ax.set_ylabel(panel["ylabel"])
        ax.set_title(panel["title"])
        ax.grid(alpha=0.3)
    axes[0].legend(fontsize=8)
    fig.suptitle("P2b rate sweep: feasible frontier (green ring = G_R confirmed and privacy pass)")
    fig.tight_layout()
    figure_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(figure_path, dpi=150)
    print(f"wrote {figure_path}")
    return True


# --------------------------------------------------------------------------- #
# markdown
# --------------------------------------------------------------------------- #
def render_markdown(analysis: dict) -> str:
    lines = [
        "# P2b rate-sweep analysis (protocol p2b-rate-sweep-1.0)",
        "",
        f"> {P2B_NOTE}",
        "",
        "## Verdicts",
        "",
        f"- **H3 (rate response): {analysis['primary']['verdict']}** "
        f"(p={'%s' % _fmt(analysis['primary']['t_test']['p'], 5)}, "
        f"mean q4->q32 reduction {_fmt(analysis['primary']['reduction_q4_q32']['mean'])} nats, "
        f"threshold {analysis['primary']['practical_effect_threshold']})",
        f"- frontier-feasible cells: {analysis['verdicts']['feasible_cells'] or 'none'}",
        "",
        "## Primary: per-seed OLS slope of trained eval loss on q_bits",
        "",
        f"- slope seeds used: {analysis['primary']['slope_seeds']} "
        f"(dropped: {analysis['primary']['dropped_seeds'] or 'none'})",
        f"- mean slope {_fmt(analysis['primary']['t_test']['mean'], 6)} nats/bit, "
        f"SD {_fmt(analysis['primary']['t_test']['sd'], 6)}, "
        f"t={_fmt(analysis['primary']['t_test']['t'], 3)}, "
        f"df={analysis['primary']['t_test']['df']}, "
        f"p(one-sided, slope<0)={_fmt(analysis['primary']['t_test']['p'], 5)}, "
        f"95% CI [{_fmt(analysis['primary']['t_test']['ci95_low'], 6)}, "
        f"{_fmt(analysis['primary']['t_test']['ci95_high'], 6)}]",
        f"- q4->q32 reduction: mean {_fmt(analysis['primary']['reduction_q4_q32']['mean'])}, "
        f"95% CI [{_fmt(analysis['primary']['reduction_q4_q32']['ci_low'])}, "
        f"{_fmt(analysis['primary']['reduction_q4_q32']['ci_high'])}]",
        "",
        "| Seed | slope | q4->q32 reduction | Spearman |",
        "|---:|---:|---:|---:|",
    ]
    for s in analysis["primary"]["slope_seeds"]:
        lines.append(f"| {s} | {_fmt(analysis['primary']['slopes_by_seed'][str(s)], 6)}"
                     f" | {_fmt(analysis['primary']['reduction_q4_q32_by_seed'][str(s)])}"
                     f" | {_fmt(analysis['primary']['spearman_by_seed'][str(s)], 3)} |")

    lines += [
        "",
        "## Secondary: per-q causal gain G_R (one-sided paired t, alpha 0.0125)",
        "",
        "| Cell | n | dropped | mean G_R | SD | t | df | p | 95% CI | persists | significant |",
        "|---|---:|---|---:|---:|---:|---:|---:|---|---|---|",
    ]
    for cell, res in analysis["secondary"].items():
        t = res["t_test"]
        lines.append(
            f"| {cell} | {t['n']} | {analysis['cells'][cell].get('dropped_seeds') or 'none'}"
            f" | {_fmt(t['mean'])} | {_fmt(t['sd'])} | {_fmt(t['t'])} | {t['df']}"
            f" | {_fmt(t['p'], 5)} | [{_fmt(t['ci95_low'])}, {_fmt(t['ci95_high'])}]"
            f" | {'yes' if res['persistence_positive'] else 'no'}"
            f" | {'yes' if res['significant'] else 'no'} |"
        )

    lines += [
        "",
        "## Privacy per q (width-256 calibration, quantized to the cell's q_bits; threshold 0.02)",
        "",
        "| Cell | status | per-seed advantage | cell max | pass |",
        "|---|---|---|---:|---|",
    ]
    for cell, p in analysis["privacy"]["per_cell"].items():
        advs = ", ".join(f"s{s}:{v:+.4f}" for s, v in sorted(p["advantages_by_seed"].items(),
                                                             key=lambda kv: int(kv[0])))
        lines.append(f"| {cell} | {p['status']} | {advs or '-'} | {_fmt(p['cell_advantage_max'])}"
                     f" | {'yes' if p['pass'] else 'no'} |")

    lines += [
        "",
        "## Frontier (feasible = G_R confirmed AND privacy pass)",
        "",
        "| q_bits | bits/token | eval loss mean [CI] | G_R mean [CI] | Delta_U mean [CI] "
        "| removed ref mean [CI] | privacy max adv | feasible |",
        "|---:|---:|---|---|---|---|---:|---|",
    ]
    for row in analysis["frontier"]:
        if row.get("status") != "ok":
            lines.append(f"| {row['q_bits']} | - | no paired data | - | - | - | - | no |")
            continue
        lines.append(
            f"| {row['q_bits']} | {_fmt(row['bits_per_token']['mean'], 1)}"
            f" | {_fmt(row['eval_loss']['mean'])} [{_fmt(row['eval_loss']['ci_low'])}, "
            f"{_fmt(row['eval_loss']['ci_high'])}]"
            f" | {_fmt(row['gain']['mean'])} [{_fmt(row['gain']['ci_low'])}, "
            f"{_fmt(row['gain']['ci_high'])}]"
            f" | {_fmt(row['delta_u']['mean'])} [{_fmt(row['delta_u']['ci_low'])}, "
            f"{_fmt(row['delta_u']['ci_high'])}]"
            f" | {_fmt(row['removed_ref']['mean'])} [{_fmt(row['removed_ref']['ci_low'])}, "
            f"{_fmt(row['removed_ref']['ci_high'])}]"
            f" | {_fmt(row['privacy']['cell_advantage_max'])}"
            f" | {'YES' if row['feasible'] else 'no'} |"
        )

    lines += ["", "## Operational failures", ""]
    if analysis["operational_failures"]:
        for failure in analysis["operational_failures"]:
            lines.append(f"- `{failure['run_id']}`: {failure['reason']}")
    else:
        lines.append("- none")
    lines.append("")
    return "\n".join(lines)


# --------------------------------------------------------------------------- #
# main
# --------------------------------------------------------------------------- #
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(
        pc.REPO_ROOT / "experiments" / "configs" / "rate_sweep_matrix.yaml"))
    parser.add_argument("--output-root", default=str(pc.REPO_ROOT / "outputs" / "rate_sweep"))
    parser.add_argument("--manifest-dir", default=str(pc.DEFAULT_MANIFEST_DIR))
    parser.add_argument("--privacy-scores", default=None)
    parser.add_argument("--analysis-path", default=None)
    parser.add_argument("--summary-path", default=None)
    parser.add_argument("--figure-path", default=str(DEFAULT_FIGURE_PATH))
    parser.add_argument("--no-figure", action="store_true")
    parser.add_argument("--no-autoscore", action="store_true")
    args = parser.parse_args(argv)

    output_root = Path(args.output_root)
    analysis_path = (Path(args.analysis_path) if args.analysis_path
                     else output_root / "rate_sweep_analysis.json")
    summary_path = (Path(args.summary_path) if args.summary_path
                    else output_root / "rate_sweep_summary.md")
    privacy_path = (Path(args.privacy_scores) if args.privacy_scores
                    else output_root / "privacy_scores.json")

    matrix = pc.load_matrix_forgiving(args.config)
    rule = matrix["confirmatory_rule"]
    span = next(iter(matrix["factors"]["segment_span"]))
    width = next(iter(matrix["factors"]["latent_width"]))
    seeds = matrix["factors"]["seed"]
    q_levels = matrix["factors"]["q_bits"]

    expected = pc.expected_rate_sweep_runs(matrix)
    manifests, unreadable = pc.scan_manifests(args.manifest_dir)
    completed, failures, extras = pc.classify_runs(
        expected, manifests, unreadable,
        required_manifest_fields={"cohort": "confirmatory",
                                  "protocol_version": matrix["protocol_version"]},
    )

    records: dict[str, dict] = {}
    for entry in completed:
        if entry["cohort"] == "calibration":
            continue
        record, error = collect_run(output_root, entry)
        if error:
            failures.append({"run_id": entry["run_id"], "mode": entry["mode"],
                             "seed": entry["seed"], "reason": error})
        else:
            records[entry["run_id"]] = record

    cells, meta = build_q_cells(records, matrix)

    primary = evaluate_primary(cells, q_levels, seeds, span, width, rule["primary"])

    secondary_alpha = parse_number_from_prose(rule["secondary"]["gain_per_q"],
                                              r"[Aa]lpha\s+([0-9.]+)")
    secondary = {}
    for q in q_levels:
        key = pc.rate_sweep_cell_key(span, width, q)
        cell = cells[key]
        if cell.get("status") != "ok":
            secondary[key] = {"significant": False, "t_test": su.paired_t_test([], "greater"),
                              "alpha": secondary_alpha, "persistence_positive": False,
                              "persistence_mean_gains": {}}
            continue
        secondary[key] = evaluate_secondary_cell(cell, secondary_alpha)

    privacy_scores, privacy_detail = load_privacy_scores(privacy_path, not args.no_autoscore, args)
    if privacy_scores is None:
        print(f"WARNING: privacy scores unavailable: {privacy_detail}")
    threshold = float(rule["privacy_criterion"]["threshold_advantage"])
    scored_runs = (privacy_scores or {}).get("runs", {})
    privacy_per_cell = {}
    for q in q_levels:
        key = pc.rate_sweep_cell_key(span, width, q)
        run_records = []
        for s in seeds:
            rid = pc.rate_sweep_run_id("trained", s, q, span, width)
            record = scored_runs.get(rid)
            if record is not None:
                record = {**record, "run_id": rid}
            run_records.append(record)
        privacy_per_cell[key] = cell_privacy(run_records, threshold)

    frontier = []
    for q in q_levels:
        key = pc.rate_sweep_cell_key(span, width, q)
        cell = cells[key]
        if cell.get("status") != "ok":
            frontier.append({"q_bits": q, "cell": key, "status": "no_data", "feasible": False})
            continue
        losses = [cell["trained_final_loss"][s] for s in
                  sorted(cell["trained_final_loss"], key=int)]
        gains = [cell["final_gains"][s] for s in sorted(cell["final_gains"], key=int)]
        dus = [v for v in cell["delta_u_by_seed"].values() if v is not None]
        rrefs = [v for v in cell["removed_ref_by_seed"].values() if v is not None]
        row = {
            "q_bits": q, "cell": key, "status": "ok",
            "bits_per_token": cell["bits_per_token"],
            "eval_loss": su.mean_ci(losses),
            "gain": su.mean_ci(gains),
            "delta_u": su.mean_ci(dus),
            "removed_ref": su.mean_ci(rrefs),
            "gain_significant": secondary[key]["significant"],
            "persistence_positive": secondary[key]["persistence_positive"],
            "privacy": privacy_per_cell[key],
            # per-seed series behind the two figure panels: eval losses for the
            # utility panel, paired frozen-minus-trained gains for the G_R panel
            "per_seed_eval_loss": losses,
            "per_seed_gain": gains,
        }
        row["feasible"] = bool(row["gain_significant"] and row["privacy"]["pass"])
        frontier.append(row)

    feasible_cells = [row["cell"] for row in frontier if row.get("feasible")]
    verdicts = {"h3": primary["verdict"], "feasible_cells": feasible_cells}

    analysis = {
        "note": P2B_NOTE,
        "protocol_version": matrix.get("protocol_version"),
        "config": args.config,
        "config_load_repair": matrix.get("_config_load_repair"),
        "confirmatory_rule": rule,
        "seeds": seeds, "q_levels": q_levels,
        "final_step": meta["final_step"], "persistence_steps": meta["persistence_steps"],
        "runs": records, "cells": cells,
        "primary": primary, "secondary": secondary,
        "privacy": {"source": privacy_detail, "threshold": threshold,
                    "per_cell": privacy_per_cell,
                    "instrument_qualified_by_width":
                        {w: i.get("qualified") for w, i in
                         (privacy_scores or {}).get("instruments", {}).items()}},
        "frontier": frontier,
        "operational_failures": sorted(failures, key=lambda f: f["run_id"]),
        "non_study_manifests_ignored": extras,
        "verdicts": verdicts,
    }
    analysis_path.parent.mkdir(parents=True, exist_ok=True)
    analysis_path.write_text(json.dumps(analysis, indent=2, sort_keys=True))
    summary_path.write_text(render_markdown(analysis))

    print(render_markdown(analysis))
    print(f"wrote {analysis_path}")
    print(f"wrote {summary_path}")
    print(f"VERDICT H3: {primary['verdict']}")
    print(f"VERDICT frontier-feasible cells: {feasible_cells or 'none'}")

    if not args.no_figure:
        if any(row.get("status") == "ok" for row in frontier):
            make_frontier_figure(frontier, Path(args.figure_path))
        else:
            print("no completed cells; skipping figure")
    return 0


if __name__ == "__main__":
    sys.exit(main())
