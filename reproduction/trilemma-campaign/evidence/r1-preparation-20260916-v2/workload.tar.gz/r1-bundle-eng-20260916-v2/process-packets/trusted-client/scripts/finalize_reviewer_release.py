#!/usr/bin/env python3
"""Finish an authorized private evidence upload after verifying every asset.

This command never changes repository visibility, source files, or experimental
evidence. It can wait for an existing upload coordinator, repair missing uploads,
attach a verification record, and publish the release to repository collaborators.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import time


def gh(*args):
    for attempt in range(5):
        try:
            return subprocess.check_output(['gh', *args], text=True)
        except subprocess.CalledProcessError:
            if attempt == 4:
                raise
            time.sleep(2 ** attempt)


def sha256(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            h.update(data)
    return h.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--index', type=Path, required=True)
    parser.add_argument('--staging', type=Path, required=True)
    parser.add_argument('--target', required=True, help='Already pushed source commit for the release tag')
    parser.add_argument('--wait-for-upload-pid', type=int)
    parser.add_argument('--check-only', action='store_true', help='Check the target and uploaded assets without uploads or publication')
    args = parser.parse_args()
    idx = json.loads(args.index.read_text())
    repo, tag = idx['repository'], idx['release_tag']
    expected = {p['name']: p for archive in idx['archives'].values() for p in archive['parts']}
    for name in [args.index.name, 'SHA256SUMS']:
        path = args.staging / name
        expected[name] = {'name': name, 'bytes': path.stat().st_size, 'sha256': sha256(path)}
    status_path = args.staging / 'publication-status.json'

    def status(state, **kwargs):
        value = {'updated_at': datetime.now(timezone.utc).isoformat(), 'state': state,
                 'repository': repo, 'release_tag': tag, **kwargs}
        temporary = status_path.with_suffix('.partial')
        temporary.write_text(json.dumps(value, indent=2) + '\n')
        temporary.replace(status_path)
        print(json.dumps(value), flush=True)

    def private():
        if json.loads(gh('repo', 'view', repo, '--json', 'visibility'))['visibility'] != 'PRIVATE':
            raise RuntimeError('Repository is not private; publication stopped')

    def release():
        return next(r for r in json.loads(gh('api', f'repos/{repo}/releases')) if r['tag_name'] == tag)

    def upload_active():
        if args.wait_for_upload_pid is None:
            return False
        p = subprocess.run(['ps', '-p', str(args.wait_for_upload_pid), '-o', 'command='], capture_output=True, text=True)
        return p.returncode == 0 and 'upload_reviewer_release.py 3' in p.stdout

    try:
        private()
        source = gh('api', '-H', 'Accept: application/vnd.github.raw+json',
                    f'repos/{repo}/contents/evidence/{args.index.name}?ref={args.target}')
        if hashlib.sha256(source.encode()).hexdigest() != sha256(args.index):
            raise RuntimeError('Release target does not contain the expected evidence index')
        attempts = {}
        while True:
            current = release()
            actual = {a['name']: a for a in current['assets']}
            missing = []
            verified = []
            for name, p in expected.items():
                a = actual.get(name)
                if a is None or a['state'] != 'uploaded':
                    missing.append(name)
                    continue
                if a['size'] != p['bytes'] or a.get('digest') != 'sha256:' + p['sha256']:
                    raise RuntimeError(f'Uploaded asset differs from the frozen index: {name}')
                verified.append({'name': name, 'bytes': p['bytes'], 'sha256': p['sha256'],
                                 'github_digest': a['digest'], 'asset_id': a['id']})
            if args.check_only:
                status('check_only', verified_assets=len(verified), total_assets=len(expected), missing_assets=missing)
                return
            if not missing:
                break
            if not current['draft']:
                raise RuntimeError('Incomplete release was already published; refusing to modify it')
            active = upload_active()
            status('uploading', verified_assets=len(verified), total_assets=len(expected),
                   verified_bytes=sum(a['bytes'] for a in verified),
                   total_bytes=sum(a['bytes'] for a in expected.values()),
                   upload_coordinator_active=active, missing_assets=missing)
            if active:
                time.sleep(30)
                continue
            # Once the original coordinator has stopped, repair any missing assets.
            name = missing[0]
            attempts[name] = attempts.get(name, 0) + 1
            if attempts[name] > 3:
                raise RuntimeError(f'Upload still missing after three repair attempts: {name}')
            path = args.staging / name
            if path.stat().st_size != expected[name]['bytes'] or sha256(path) != expected[name]['sha256']:
                raise RuntimeError(f'Local staged asset changed: {name}')
            subprocess.run(['gh', 'release', 'upload', tag, str(path), '--repo', repo], check=False)

        private()
        verification = {'checked_at': datetime.now(timezone.utc).isoformat(),
                        'repository': repo, 'visibility': 'PRIVATE', 'release_tag': tag,
                        'target_commit': args.target, 'assets': verified, 'failures': [],
                        'method': 'All indexed asset sizes and SHA-256 values match GitHub server metadata.',
                        'scope': 'Evidence distribution and byte identity, not historical source recovery or new scientific validation.'}
        record = args.staging / 'VERIFICATION.json'
        # Preserve a previous verification record when resuming after publication.
        if 'VERIFICATION.json' not in actual:
            record.write_text(json.dumps(verification, indent=2) + '\n')
            subprocess.run(['gh', 'release', 'upload', tag, str(record), '--repo', repo], check=True)
        if current['draft']:
            subprocess.run(['gh', 'release', 'edit', tag, '--repo', repo,
                            '--target', args.target, '--draft=false'], check=True)
        final = release()
        private()
        if final['draft'] or final['target_commitish'] != args.target:
            raise RuntimeError('Published release target did not match the verified target')
        status('complete', verified_assets=len(verified), url=final['html_url'],
               target_commit=args.target, verification_file='VERIFICATION.json')
    except BaseException as exc:
        status('failed', error=str(exc))
        raise


if __name__ == '__main__':
    main()
