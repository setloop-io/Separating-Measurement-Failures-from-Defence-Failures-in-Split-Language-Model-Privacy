#!/usr/bin/env python3
"""Generate experiments/configs/segment_stats_matrix.yaml (P2c confirmatory config).

Copies the frozen shape of confirmatory_matrix.yaml with:
  * protocol_version p2c-segment-statistics-1.0, cohort confirmatory;
  * factors: the 8 held-out segments {2@1, 2@5, 3@2, 3@4, 4@3, 5@1, 5@3, 6@2}
    (as named levels s<span>at<start>) x width 256 x q_bits 8, trained mode,
    seeds [3, 13, 23, 33, 43, 53, 63, 83]; pairing pb-p2c-{seed};
  * controls: all_local per seed (no frozen/removed runs per prereg scope);
  * a selection: section embedding the selected statistic, the sha256 of the
    selection table, and the frozen selection rule text;
  * the confirmatory_rule from docs/PREREGISTRATION_P2C.md.

Run AFTER scripts/select_statistic.py; refuses to generate if the selection
was degenerate. Idempotent: regenerating from the same selection table yields
the same file.

Usage:
  .venv/bin/python scripts/make_segment_stats_config.py
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "src"))

import pilot_common as pc  # noqa: E402
from pcr.utils import sha256_file  # noqa: E402

HELD_OUT_SEGMENTS = [  # (span, start), frozen by docs/PREREGISTRATION_P2C.md
    (2, 1), (2, 5), (3, 2), (3, 4), (4, 3), (5, 1), (5, 3), (6, 2),
]
SEEDS = [3, 13, 23, 33, 43, 53, 63, 83]

DEFAULT_OUT = ROOT / "experiments" / "configs" / "segment_stats_matrix.yaml"


def build_config(selection_table: dict, source_matrix: dict) -> dict:
    selection = selection_table["selection"]
    statistic = selection["selected"]
    fixed = dict(source_matrix["fixed"])
    fixed["boundary_defense"] = {
        "type": "uniform_per_tensor_affine_quantization",
        "q_bits": 8,
        "ste_in_training": True,
        "serialization": "true_quantized_packed_codes_plus_8_byte_affine_metadata",
    }
    return {
        "protocol_status": "frozen_for_confirmation",
        "protocol_version": "p2c-segment-statistics-1.0",
        "study": "remote_substitutability_segment_statistics",
        "purpose": "confirmatory_out_of_sample_predictive_test_of_segment_statistic",
        "cohort": "confirmatory",
        "freeze_note": (
            "Frozen for the P2c segment-statistics confirmatory on 2026-09-04, AFTER "
            "stage-1 statistic selection (seed-929 calibration measurement plus the frozen "
            "selection rule over the six exploratory cells) and BEFORE any confirmatory run "
            "under this config. Seeds are fresh and disjoint from exploratory [101, 202, 303], "
            "P2 confirmatory [11, 22, 33, 44, 55, 66, 77, 88], P2b rate-sweep "
            "[7, 17, 27, 37, 47, 57, 67, 87], and calibration [909, 919, 929]. The selected "
            "statistic and the selection table hash are embedded in the selection section; "
            "changes after this freeze require a versioned amendment written before "
            "inspecting affected outcomes."
        ),
        "fixed": fixed,
        "factors": {
            "segment_span": {
                f"s{span}at{start}": {"start": start, "span": span}
                for span, start in HELD_OUT_SEGMENTS
            },
            "latent_width": {"high": 256},
            "remote_mode": ["trained"],
            "seed": SEEDS,
        },
        "controls": {"all_local": {}},
        "pairing": {
            "block_id": "pb-p2c-{seed}",
            "shared_encoder_decoder_initialization": True,
            "shared_minibatch_order": True,
            "shared_trusted_random_streams": True,
            "note": "frozen_random/removed_remote are not run in p2c (prereg scope note); "
                    "pairing fields kept for protocol continuity",
        },
        "operational_rate": {
            "unit": "bits_per_token",
            "measurement_stage": "serialized_remote_transcript",
            "includes_repeated_releases": True,
        },
        "matched_controls": ["all_local"],
        "primary_outcomes": ["heldout_replacement_penalty"],
        "selection": {
            "statistic": statistic,
            "selection_rule": selection_table["selection_rule"],
            "selection_rule_source": selection_table["selection_rule_source"],
            "selection_table": "outputs/stats/selection_table.json",
            "selection_table_sha256": sha256_file(
                str(ROOT / "outputs" / "stats" / "selection_table.json")),
            "selection_cells": [f"{c['segment']}x{c['width']}" for c in selection_table["cells"]],
            "statistics_measured_on": selection_table["statistics_measured_on"],
            "note": "Statistics derive from ONE calibration backbone (seed 929); they "
                    "characterize the family attractor, not each seed. The selection cannot "
                    "change after this freeze.",
        },
        "confirmatory_rule": {
            "inferential_unit": "independent_training_run_seed",
            "target": "per-cell mean Delta_U = mean over seeds of (trained eval loss - "
                      "all_local eval loss) at step 2000, fixed convergence",
            "predictors": {
                "model_S": f"Delta_U ~ a + b * {statistic}; OLS fit on the six exploratory "
                           "selection points only",
                "model_N": "Delta_U ~ a + b * span; OLS fit on the six exploratory "
                           "selection points only",
            },
            "primary": {
                "test": "one_sided_paired_t_test_over_8_cells on per-cell absolute "
                        "out-of-sample prediction errors (model S better)",
                "alpha": 0.05,
                "confirm_if": "p < 0.05 AND mean absolute error of S < mean absolute error "
                              "of N AND out-of-sample R^2 of S > 0",
            },
            "secondary": {
                "h4_descriptive": "out-of-sample R^2 of Delta_U ~ span vs Delta_U ~ span + "
                                  "position + statistic (latter fit flagged low-power, "
                                  "reported without gating); per-cell residuals",
            },
            "missing_data": "at most one retry per run with identical cell identity; a cell "
                            "missing its all_local partner seed drops that seed from the "
                            "cell mean (predeclared, never outcome-based)",
        },
        "failure_policy": {
            "operational_failure_classes": ["device_error", "out_of_memory", "io_error",
                                            "schema_validation_error"],
            "max_retries": 1,
            "rule": "Failures are recorded with manifest status operational_failure and "
                    "partial artifacts; never excluded based on outcome.",
        },
        "notes": [
            "Trained mode only per held-out cell; frozen_random/removed_remote are not run "
            "in p2c (medium-high causal gain is already confirmed under p2-confirmatory-1.0).",
            "Privacy is not evaluated in p2c: no new boundary regimes (width 256, q=8 was "
            "scored in P2 and P2b).",
            "Prediction targets are replacement penalties Delta_U, not causal gains.",
            "Timing is logged for systems accounting only and enters no privacy claim.",
        ],
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--selection-table", default=str(ROOT / "outputs" / "stats"
                                                                 / "selection_table.json"))
    parser.add_argument("--source-config", default=str(pc.DEFAULT_CONFIRMATORY_MATRIX_PATH))
    parser.add_argument("--output", default=str(DEFAULT_OUT))
    args = parser.parse_args(argv)

    selection_table = json.loads(Path(args.selection_table).read_text())
    if not selection_table["selection"].get("selected"):
        raise SystemExit(f"selection is degenerate ({selection['selection'].get('reason')}); "
                         f"refusing to generate the p2c config — report, do not improvise")
    source_matrix = pc.load_matrix_forgiving(args.source_config)
    config = build_config(selection_table, source_matrix)
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    text = yaml.safe_dump(config, sort_keys=False, allow_unicode=True, width=100)
    out.write_text(text)
    # round-trip check: the generated config must parse cleanly
    reloaded = yaml.safe_load(text)
    assert reloaded["protocol_version"] == "p2c-segment-statistics-1.0"
    print(f"wrote {out} (selected statistic: {selection_table['selection']['selected']})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
