#!/usr/bin/env python3
"""Run the 4 P5 gradient-channel attack qualification captures (calibration
cohort) per docs/PREREGISTRATION_P5.md.

Enumeration (frozen): trained mode, span 4@2, width 256, remote_depth=2, 600
steps, dense 4-channel probe captures (transcript_sample_every=1), seeds
{9391, 9491}, at defenses d0 (q8, no gradient defense) and d1 (q4 + gradient
clip 1.0 + noise 0.1). Run ids p5cal-{d0|d1}-s{seed}; cohort="calibration";
protocol_version="p5-delegation-sweep-1.0".

The fixed protocol comes from experiments/configs/delegation_matrix.yaml
(frozen); per-run knobs are injected into an in-memory copy only.

Usage:
  .venv/bin/python scripts/run_p5_calibration.py            # execute
  .venv/bin/python scripts/run_p5_calibration.py --dry-run  # enumerate and verify; never train

Prospective preservation rule: existing incomplete/unverifiable evidence stops
execution and is never overwritten by an automatic retry. A separate execution
identity/output directory is required after such a failure. Use --manifest-dir
with --output-root to keep a new execution separate from the original records.

"""

from __future__ import annotations

import argparse
import copy
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

from pcr import manifest as manifest_state  # noqa: E402
from pcr.manifest import ManifestVerificationError, completed_manifest_exists, report_resume_status, write_manifest  # noqa: E402
from pcr.run_experiment import resolve_cell  # noqa: E402
from pcr.train import run_cell  # noqa: E402

import pilot_common as pc  # noqa: E402
from run_confirmatory import log_attempt  # noqa: E402

DEFAULT_CONFIG = ROOT / "experiments" / "configs" / "delegation_matrix.yaml"
DEFAULT_OUTPUT_ROOT = ROOT / "outputs" / "p5_calibration"


def resolve_p5cal_cell(matrix: dict, entry: dict, output_root: str | Path) -> dict:
    injected = copy.deepcopy(matrix)
    defense = matrix["factors"]["defenses"][entry["defense"]]
    injected["fixed"]["boundary_defense"]["q_bits"] = defense["q_bits"]
    injected["fixed"]["transcript_sample_every"] = entry["transcript_sample_every"]
    injected["factors"]["segment_span"] = {"medium": dict(entry["segment"])}
    injected["factors"]["latent_width"] = {"high": 256}
    resolved = resolve_cell(
        injected, entry["mode"], entry["seed"], span="medium", width="high",
        steps=entry["steps"], run_id=entry["run_id"], cohort=entry["cohort"],
        output_root=output_root, pairing_block_id=f"pb-{entry['seed']}",
    )
    resolved["protocol_version"] = entry["protocol_version"]
    resolved["split"]["remote_depth"] = entry["remote_depth"]
    if defense["grad_defense"] is not None:
        resolved["split"]["grad_defense"] = dict(defense["grad_defense"])
    return resolved


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument("--output-root", default=str(DEFAULT_OUTPUT_ROOT))
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--manifest-dir", help="separate manifest namespace for a new execution; requires fresh outputs")
    args = parser.parse_args()
    if args.manifest_dir:
        manifest_state.MANIFEST_DIR = Path(args.manifest_dir).resolve()

    matrix = pc.load_matrix_forgiving(args.config)
    if matrix.get("protocol_status") != "frozen_for_confirmation":
        raise SystemExit("delegation matrix is not frozen_for_confirmation; refusing to run")
    runs = [resolve_p5cal_cell(matrix, entry, args.output_root) for entry in pc.P5_CAL_RUNS]

    print(f"enumerated {len(runs)} P5 calibration captures")
    if args.dry_run:
        return report_resume_status(runs)

    output_root = Path(args.output_root)
    attempts_log = output_root / "run_attempts.jsonl"
    max_retries = 0  # immutable failures require a separately identified attempt
    done, failed, skipped = 0, 0, 0
    for index, resolved in enumerate(runs, start=1):
        run_id = resolved["run_id"]
        if completed_manifest_exists(run_id, resolved=resolved):
            print(f"[{index}/{len(runs)}] skip {run_id} (artifacts and execution identity verified)")
            skipped += 1
            continue
        succeeded = False
        for attempt in range(1, max_retries + 2):
            print(
                f"[{index}/{len(runs)}] run {run_id} (attempt {attempt}): "
                f"mode={resolved['mode']} seed={resolved['seed']} split={resolved['split']} "
                f"steps={resolved['optim']['steps']}",
                flush=True,
            )
            log_attempt(attempts_log, run_id, attempt, "start")
            t0 = time.perf_counter()
            try:
                summary = run_cell(resolved)
            except ManifestVerificationError:
                raise  # Never relabel or overwrite preserved evidence on a retry.
            except Exception as exc:  # preserve failure; a new attempt needs a new identity
                out_dir = Path(resolved["output_dir"])
                leftover = [p for p in out_dir.glob("*") if p.is_file()] if out_dir.is_dir() else []
                write_manifest(
                    resolved, status="operational_failure", artifact_paths=leftover,
                    captured_channels=[],
                    extra={"failure_error": repr(exc), "attempt": attempt,
                           "max_retries": max_retries},
                )
                log_attempt(attempts_log, run_id, attempt, "failure", repr(exc))
                print(f"[{index}/{len(runs)}] FAILED {run_id} (attempt {attempt}): {exc}",
                      flush=True)
                continue
            succeeded = True
            elapsed = time.perf_counter() - t0
            log_attempt(attempts_log, run_id, attempt, "success",
                        f"final_eval_loss={summary['final_eval_loss']:.4f}")
            print(
                f"[{index}/{len(runs)}] done {run_id}: final_eval_loss="
                f"{summary['final_eval_loss']:.4f} wall_time={elapsed:.1f}s",
                flush=True,
            )
            break
        if succeeded:
            done += 1
        else:
            failed += 1
    print(f"finished: {done} executed, {failed} failed; new attempts require new identities, {skipped} pre-existing")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
