#!/usr/bin/env python3
"""Privacy scoring: instrument qualification + per-run token-inversion scoring.

Works for both frozen configs:
  * P1 pilot (pilot_matrix.yaml): single width-low calibration (seed 909);
    width-high runs are skipped as privacy-not-eligible.
  * P2 confirmatory (confirmatory_matrix.yaml): width-low runs are scored
    against the reused seed-909 calibration artifact, width-high runs against
    the new seed-919 calibration artifact, each with its own instrument
    qualification dose curve.

Step 1 qualifies the token-inversion instrument per calibration width on the
calibration cohort (seeds 909/919, disjoint from all pilot/confirmatory
seeds): the dose curve over q_bits {4,8,16,32} must be monotone
non-decreasing, strictly increase across endpoints, pass the 0.05 detection
floor at 32 bits, and keep the broken-alignment null pipeline within
|advantage| < 0.02. Calibration data only — never cohort outcomes.

Step 2 scores every completed split-mode run of the config's cohort
(trained / frozen_random / removed_remote): a probe and a matched
shuffled-label null probe are trained on the calibration pairs matching the
run's boundary width (re-quantized at the run's q_bits) and applied to the
run's final-step captured latents (forward_values in transcript_tensors.pt)
against the deterministic probe batch tokens. Runs whose width has no
width-matched calibration artifact are skipped as privacy-not-eligible.

Writes <output-root>/privacy_scores.json and prints a human-readable table.
No estimator output here is a mutual-information bound or a privacy
certificate; it is one attack family's measured advantage over a matched null.

Usage:
  .venv/bin/python scripts/score_privacy.py                                      # P1 pilot cohort
  .venv/bin/python scripts/score_privacy.py --config experiments/configs/confirmatory_matrix.yaml \
      --output-root outputs/confirmatory                                         # P2 confirmatory cohort
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))  # pilot_common
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))  # pcr (matches run_pilot.py)

import pilot_common as pc  # noqa: E402

CALIBRATION_WIDTH_NOTE = (
    "width-matched calibration run required before privacy scoring of this cell "
    "(frozen config note); cell is privacy-not-eligible"
)


def run_eligibility(width_dim: int, calibrations: dict[int, dict]) -> tuple[bool, str | None]:
    """Pure eligibility rule for scoring one run's probe tensors.

    calibrations: {width_dim: {"qualified": bool, "run_id": str, ...}} as
    produced by resolve_calibrations (after instrument qualification).
    """
    cal = calibrations.get(width_dim)
    if cal is None:
        return False, (f"width {width_dim} has no completed width-matched calibration artifact: "
                       f"{CALIBRATION_WIDTH_NOTE}")
    if not cal.get("qualified"):
        return False, f"instrument_not_qualified (calibration {cal['run_id']})"
    return True, None


def find_calibration_pairs(seed: int, search_roots: list[Path]) -> Path | None:
    """Locate calibration_pairs.pt for a calibration seed across candidate roots."""
    for root in search_roots:
        candidate = Path(root) / f"calibration-s{seed}" / "calibration_pairs.pt"
        if candidate.is_file():
            return candidate
    return None


def resolve_calibrations(
    matrix: dict, manifests: dict[str, dict], search_roots: list[Path]
) -> dict[int, dict]:
    """Map boundary width (dim) -> calibration artifact info, for every
    calibration entry that is completed (manifest) and present on disk.

    Torch-free and side-effect free so it can be unit-tested.
    """
    calibrations: dict[int, dict] = {}
    for entry in pc.calibration_entries(matrix):
        width_dim = int(matrix["factors"]["latent_width"][entry["width"]])
        run_id = f"calibration-s{entry['seed']}"
        manifest = manifests.get(run_id) or {}
        pairs = find_calibration_pairs(int(entry["seed"]), search_roots)
        if manifest.get("status") != "completed" or pairs is None:
            continue
        calibrations[width_dim] = {
            "key": entry["key"],
            "run_id": run_id,
            "seed": int(entry["seed"]),
            "width_name": entry["width"],
            "width_dim": width_dim,
            "pairs_path": str(pairs),
            "reuse": entry.get("reuse", "none"),
        }
    return calibrations


def load_calibration_events(pairs_path: Path) -> tuple[list[dict], dict]:
    import torch  # deferred: keeps discovery and --help torch-free

    events = torch.load(pairs_path, map_location="cpu", weights_only=False)
    config = pc.load_json(pairs_path.parent / "config.resolved.json")
    return events, config


def probe_batch_labels(matrix: dict) -> tuple[np.ndarray, np.ndarray, tuple[int, int]]:
    """The deterministic probe batch input tokens (identical across all runs).

    Returns (tokens (B*T,) int64, positions (B*T,) int64, (B, T)).
    """
    from pcr.data import load_corpus, make_probe_batch, split_corpus

    fixed = matrix["fixed"]
    corpus_path = Path(fixed["corpus"])
    if not corpus_path.is_absolute():
        corpus_path = pc.REPO_ROOT / corpus_path
    _, heldout = split_corpus(load_corpus(corpus_path), fixed["corpus_split"]["train_fraction"])
    x, _ = make_probe_batch(heldout, fixed["probe_batch_size"], fixed["sequence_length"])
    tokens = x.numpy().astype(np.int64)
    batch, seq = tokens.shape
    positions = np.tile(np.arange(seq, dtype=np.int64), batch)
    return tokens.reshape(-1), positions, (batch, seq)


def train_probe_pair(
    events: list[dict],
    seq_len: int,
    q_bits: int,
    seed: int,
    device,
    epochs: int,
    batch_size: int,
    lr: float,
):
    """Attack probe + matched shuffled-label null, trained on calibration data only."""
    from pcr.privacy import flatten_events, quantize_events_at_dose, train_probe
    from pcr.utils import derive_seed

    quantized = quantize_events_at_dose(events, q_bits)
    latents, tokens, _ = flatten_events(quantized, seq_len)
    width = latents.shape[1]
    probe = train_probe(latents, tokens, width, epochs, batch_size, lr, seed, device)
    shuffle_gen = np.random.default_rng(derive_seed(seed, "null-shuffle", q_bits))
    null_probe = train_probe(
        latents, shuffle_gen.permutation(tokens), width, epochs, batch_size, lr, seed, device
    )
    return probe, null_probe


def score_run_tensors(
    probe,
    null_probe,
    tensors_path: Path,
    tokens: np.ndarray,
    positions: np.ndarray,
    probe_shape: tuple[int, int],
    device,
) -> dict:
    """Apply the calibrated probes to a run's final-step captured latents."""
    import torch
    from pcr.privacy import per_position_accuracy

    samples = torch.load(tensors_path, map_location="cpu", weights_only=False)
    final = max(samples, key=lambda s: s["step"])
    forward = final["forward_values"]  # quantized latents that crossed the boundary
    batch, seq, width = forward.shape
    if (batch, seq) != probe_shape:
        raise ValueError(
            f"{tensors_path}: probe tensor shape {(batch, seq)} != probe batch {probe_shape}"
        )
    latents = forward.reshape(batch * seq, width).numpy()
    acc_pos = per_position_accuracy(probe, latents, tokens, positions, seq, device)
    null_pos = per_position_accuracy(null_probe, latents, tokens, positions, seq, device)
    accuracy = float(np.nanmean(acc_pos))
    null_accuracy = float(np.nanmean(null_pos))
    return {
        "probe_step": int(final["step"]),
        "accuracy": accuracy,
        "null_accuracy": null_accuracy,
        "advantage": accuracy - null_accuracy,
        "per_position_accuracy": acc_pos.tolist(),
        "per_position_null_accuracy": null_pos.tolist(),
    }


def qualify_instrument(events: list[dict], seq_len: int, seed: int, device, args) -> dict:
    """Positive-control dose curve + QUALIFIED verdict (calibration data only)."""
    from pcr.privacy import DETECTION_FLOOR, NULL_TOLERANCE, dose_curve

    curve = dose_curve(
        events,
        seq_len=seq_len,
        seed=seed,
        doses=tuple(args.doses),
        epochs=args.epochs,
        batch_size=args.batch_size,
        lr=args.lr,
        device=device,
    )
    endpoint_increase = curve["advantages"][-1] > curve["advantages"][0]
    qualified = bool(
        curve["monotone_non_decreasing"]
        and endpoint_increase
        and curve["passes_floor"]
        and curve["null_within_tolerance"]
    )
    return {
        "attack_family": curve["attack_family"],
        "doses": curve["doses"],
        "advantages": curve["advantages"],
        "dose_results": [
            {k: r[k] for k in ("q_bits", "accuracy", "null_accuracy", "advantage", "n_train", "n_test")}
            for r in curve["results"]
        ],
        "monotone_non_decreasing": curve["monotone_non_decreasing"],
        "endpoint_increase": endpoint_increase,
        "advantage_at_max_dose": curve["advantage_at_max_dose"],
        "detection_floor": DETECTION_FLOOR,
        "passes_floor": curve["passes_floor"],
        "null_pipeline_advantage": curve["null_pipeline_advantage"],
        "null_tolerance": NULL_TOLERANCE,
        "null_within_tolerance": curve["null_within_tolerance"],
        "qualified": qualified,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(pc.DEFAULT_MATRIX_PATH))
    parser.add_argument("--output-root", default=str(pc.DEFAULT_OUTPUT_ROOT))
    parser.add_argument("--manifest-dir", default=str(pc.DEFAULT_MANIFEST_DIR))
    parser.add_argument("--output", default=None, help="default: <output-root>/privacy_scores.json")
    parser.add_argument("--calibration-roots", nargs="*", default=None,
                        help="directories searched for calibration-s<seed>/ artifacts; "
                             "default: <output-root>, outputs/pilot, outputs/confirmatory")
    # pcr.privacy.train_probe seeds a CPU torch.Generator for init, which
    # accelerators reject; the probe MLP is small, so CPU is the default.
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--batch-size", type=int, default=4096)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--doses", type=int, nargs="+", default=[4, 8, 16, 32])
    args = parser.parse_args(argv)

    output_root = Path(args.output_root)
    out_path = Path(args.output) if args.output else output_root / "privacy_scores.json"

    matrix = pc.load_matrix_forgiving(args.config)
    if "_config_load_repair" in matrix:
        print(f"NOTE: config required a notes-prose repair to parse "
              f"({matrix['_config_load_repair']['scope']}).")
    expected = pc.expected_runs(matrix)
    manifests, unreadable = pc.scan_manifests(args.manifest_dir)
    completed, failures, _extras = pc.classify_runs(expected, manifests, unreadable)

    search_roots = (
        [Path(p) for p in args.calibration_roots]
        if args.calibration_roots
        else [output_root, pc.DEFAULT_OUTPUT_ROOT, pc.DEFAULT_CONFIRMATORY_OUTPUT_ROOT]
    )
    calibrations = resolve_calibrations(matrix, manifests, search_roots)
    if not calibrations:
        print("ERROR: no completed calibration artifacts found for any width; "
              "cannot score privacy.")
        return 1

    from pcr.utils import resolve_device

    device = resolve_device(args.device)
    seq_len = int(matrix["fixed"]["sequence_length"])

    events_by_width: dict[int, list[dict]] = {}
    instruments: dict[int, dict] = {}
    for width_dim in sorted(calibrations):
        cal = calibrations[width_dim]
        events, _cal_config = load_calibration_events(Path(cal["pairs_path"]))
        cal["n_events"] = len(events)
        cal["n_pairs"] = int(sum(int(e["tokens"].numel()) for e in events))
        events_by_width[width_dim] = events
        print(f"calibration: {cal['run_id']} seed={cal['seed']} width={width_dim} "
              f"events={cal['n_events']} pairs={cal['n_pairs']} reuse={cal['reuse']}")
        print(f"qualifying instrument (doses {list(args.doses)}, device={device}) ...")
        instrument = qualify_instrument(events, seq_len, cal["seed"], device, args)
        instruments[width_dim] = instrument
        cal["qualified"] = instrument["qualified"]
        verdict = "QUALIFIED" if instrument["qualified"] else "NOT QUALIFIED"
        print(f"instrument width={width_dim}: {verdict}  "
              f"advantages={['%.4f' % a for a in instrument['advantages']]} "
              f"null_pipeline_advantage={instrument['null_pipeline_advantage']:+.4f}")

    tokens, positions, probe_shape = (None, None, None)
    probe_bank: dict[tuple[int, int], tuple] = {}

    def probes_for(width_dim: int, q_bits: int):
        key = (width_dim, q_bits)
        if key not in probe_bank:
            cal = calibrations[width_dim]
            print(f"training attack/null probes on {cal['run_id']} pairs "
                  f"(width={width_dim}, q_bits={q_bits}) ...")
            probe_bank[key] = train_probe_pair(
                events_by_width[width_dim], seq_len, q_bits, cal["seed"], device,
                args.epochs, args.batch_size, args.lr
            )
        return probe_bank[key]

    results: dict[str, dict] = {}
    split_runs = sorted(
        (e for e in completed if e["mode"] in pc.SPLIT_MODES and e["cohort"] != "calibration"),
        key=lambda e: e["run_id"],
    )
    for entry in split_runs:
        run_id = entry["run_id"]
        run_dir = output_root / run_id
        record = {
            "mode": entry["mode"],
            "span": entry["span"],
            "width": entry["width"],
            "seed": entry["seed"],
            "cell": entry.get("cell") or pc.cell_key(entry["span"], entry["width"]),
        }
        if entry.get("q_bits") is not None:
            record["cell_q_bits"] = entry["q_bits"]
        tensors_path = run_dir / "transcript_tensors.pt"
        config_path = run_dir / "config.resolved.json"
        if not config_path.is_file() or not tensors_path.is_file():
            record.update(eligible=False, reason="missing config.resolved.json or transcript_tensors.pt")
            results[run_id] = record
            continue
        config = pc.load_json(config_path)
        width_dim = int(config["split"]["width"])
        q_bits = int(config["split"]["q_bits"])
        record.update(width_dim=width_dim, q_bits=q_bits)
        eligible, reason = run_eligibility(width_dim, calibrations)
        record.update(eligible=eligible, reason=reason)
        if eligible:
            cal = calibrations[width_dim]
            record.update(calibration_run_id=cal["run_id"], calibration_seed=cal["seed"],
                          calibration_width=width_dim)
            if tokens is None:
                tokens, positions, probe_shape = probe_batch_labels(matrix)
            probe, null_probe = probes_for(width_dim, q_bits)
            scored = score_run_tensors(probe, null_probe, tensors_path, tokens, positions,
                                       probe_shape, device)
            record.update(scored)
            summary_path = run_dir / "metrics_summary.json"
            if summary_path.is_file():
                summary = pc.load_json(summary_path)
                record["bits_per_token_total"] = summary.get("bits_per_token_total")
        results[run_id] = record

    trained_by_cell: dict[str, list[str]] = {}
    for e in expected:
        if e["mode"] == "trained" and e["cohort"] != "calibration" and e.get("cell"):
            trained_by_cell.setdefault(e["cell"], []).append(e["run_id"])
    eligible_cells = sorted(
        cell for cell, run_ids in trained_by_cell.items()
        if all(results.get(rid) is not None and results[rid].get("eligible")
               and "advantage" in results[rid] for rid in run_ids)
    )

    first_width = min(calibrations)
    payload = {
        "note": ("Privacy scoring over the declared transcript; token-inversion family only. "
                 "Membership, property, and history-accumulation attacks remain out of scope "
                 "and this omission must be named wherever these results are cited."),
        "protocol_version": matrix.get("protocol_version"),
        "config_load_repair": matrix.get("_config_load_repair"),
        # first-width entries keep the P1 single-calibration shape intact
        "calibration": {k: v for k, v in calibrations[first_width].items() if k != "qualified"},
        "instrument": instruments[first_width],
        "calibrations": {str(w): calibrations[w] for w in sorted(calibrations)},
        "instruments": {str(w): instruments[w] for w in sorted(instruments)},
        "probe_training": {
            "seeds": {str(w): calibrations[w]["seed"] for w in sorted(calibrations)},
            "epochs": args.epochs, "batch_size": args.batch_size, "lr": args.lr,
            "data": "calibration cohort only; never pilot/confirmatory outcomes",
        },
        "operational_failures": failures,
        "runs": results,
        "privacy_eligible_cells": eligible_cells,
    }
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(payload, indent=2, sort_keys=True))

    print(f"\nper-run token-inversion scores (advantage over matched shuffled null):")
    header = (f"{'run_id':36s} {'cell':11s} {'elig':4s} {'adv':>8s} {'null':>8s} "
              f"{'bits/tok':>9s} {'calib':16s}  note")
    print(header)
    print("-" * len(header))
    for run_id in sorted(results):
        r = results[run_id]
        adv = f"{r['advantage']:+.4f}" if "advantage" in r else "-"
        null = f"{r['null_accuracy']:.4f}" if "null_accuracy" in r else "-"
        bits = f"{r['bits_per_token_total']:.1f}" if r.get("bits_per_token_total") else "-"
        calib = r.get("calibration_run_id", "-")
        note = "" if r["eligible"] else (r.get("reason") or "")
        print(f"{run_id:36s} {r['cell']:11s} {str(r['eligible']):4s} {adv:>8s} {null:>8s} "
              f"{bits:>9s} {calib:16s}  {note}")
    print(f"\nprivacy-eligible cells: {eligible_cells or 'none'}")
    for width_dim in sorted(instruments):
        print(f"instrument width={width_dim} verdict: "
              f"{'QUALIFIED' if instruments[width_dim]['qualified'] else 'NOT QUALIFIED'}")
    print(f"wrote {out_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
