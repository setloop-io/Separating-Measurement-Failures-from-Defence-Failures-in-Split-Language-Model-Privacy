#!/usr/bin/env python3
"""P5 delegation-sweep analysis — the empirical delegation-triangle test
(docs/PREREGISTRATION_P5.md, frozen 2026-09-07).

Privacy qualification (runs standalone via --qualify-only): per defense
{d0, d1}, the gradient-channel variants of the three families are qualified on
the fresh p5cal captures (seeds 9391/9491, dense 4-channel captures) with the
frozen floors (property r-advantage >= 0.10, structure >= 0.02, token-
inversion 0.05; |null pipeline advantage| <= 0.02 each). Forward-channel
variants reuse the existing qualified instruments (919; P4b dense captures).

Per-cell gates (need the 288-run cohort; missing runs are operational
failures, seeds dropped from affected tests only):
  * privacy: worst per-seed advantage <= 0.02 over every QUALIFIED
    family x channel variant, measured on the trained runs' stored probe
    tensors (forward: 919/dense-p4b probes quantized to the cell's q;
    gradients: p5cal probes of the cell's defense);
  * utility: mean Delta_U <= 0.10 AND upper 95% CI <= 0.12 (vs same-seed
    all_local);
  * delegated share: measured analytic remote FLOP fraction >= 0.15.
G_R reported descriptively per cell. Triangle verdict uses the frozen language
(empty: "within the swept space, defense options, and attack suite, no tested
configuration holds all three gates"; non-empty: "cells {...} hold all three
gates"). No universal-law language either way.

Outputs: outputs/delegation/gradient_qualification.json,
outputs/delegation/delegation_analysis.json,
outputs/delegation/delegation_summary.md (verdict up top), and
paper/figures/delegation_triangle.png.

Usage:
  .venv/bin/python scripts/analyze_delegation.py --qualify-only   # now (calibration)
  .venv/bin/python scripts/analyze_delegation.py                  # after the cohort
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "src"))

import pilot_common as pc  # noqa: E402
import stats_utils as su  # noqa: E402
from analyze_pilot import _fmt, collect_run, ensure_matplotlib  # noqa: E402

DEFAULT_CONFIG = ROOT / "experiments" / "configs" / "delegation_matrix.yaml"
DEFAULT_OUTPUT_ROOT = ROOT / "outputs" / "delegation"
DEFAULT_P5CAL_ROOT = ROOT / "outputs" / "p5_calibration"
CALIBRATION_919 = ROOT / "outputs" / "confirmatory" / "calibration-s919" / "calibration_pairs.pt"
DEFAULT_FIGURE_PATH = ROOT / "paper" / "figures" / "delegation_triangle.png"

PRIVACY_THRESHOLD = 0.02
UTILITY_MEAN = 0.10
UTILITY_CI_UPPER = 0.12
SHARE_FLOOR = 0.15
# probe-training subset for gradient-channel qualification: every 10th
# captured step (instrument budget choice; floors frozen; documented)
GRAD_QUAL_STEP_STRIDE = 10

P5_NOTE = ("P5 delegation-sweep analysis under protocol p5-delegation-sweep-1.0 "
           "(frozen 2026-09-07, fresh seeds [21..91]); per docs/PREREGISTRATION_P5.md. "
           "Empirical feasible-set statement within this mechanism family, not a "
           "universal law.")

OMISSIONS = [
    "history-accumulation and canary-membership families (instruments unqualified, P4b)",
    "timing channels",
    "optimizer state beyond the remote module",
    "active/adaptive attackers",
    "natural-sequence membership",
    "cross-run joint attacks",
    "arch2/corpus2 (single-setting sweep by design; replication deferred)",
]


# --------------------------------------------------------------------------- #
# privacy qualification on the p5cal captures
# --------------------------------------------------------------------------- #
def qualify_gradient_channels(p5cal_root: Path, device, log=print) -> dict:
    """Per defense {d0, d1}: qualify family x channel variants on the p5cal
    dense captures with the frozen floors."""
    import torch

    import pcr.privacy_attacks_p4b as pb
    from pcr.data import load_corpus, make_probe_batch, split_corpus

    matrix = pc.load_matrix_forgiving(pc.DEFAULT_CONFIRMATORY_MATRIX_PATH)
    _, heldout = split_corpus(load_corpus(ROOT / matrix["fixed"]["corpus"]),
                              matrix["fixed"]["corpus_split"]["train_fraction"])
    probe_tokens, _ = make_probe_batch(heldout, matrix["fixed"]["probe_batch_size"],
                                       matrix["fixed"]["sequence_length"])

    defenses = {"d0": 8, "d1": 4}
    out = {}
    for defense, q in defenses.items():
        events = []
        for seed in pc.P5_CAL_SEEDS:
            run_dir = p5cal_root / f"p5cal-{defense}-s{seed}"
            samples = torch.load(run_dir / "transcript_tensors.pt", map_location="cpu",
                                 weights_only=False)
            samples = [s for s in samples if s.get("probe_batch_index", 0) == 0]
            # stride for probe-training budget (floors frozen; documented)
            samples = [s for s in samples if s["step"] % GRAD_QUAL_STEP_STRIDE == 0]
            events += pb.dense_samples_to_events(
                samples, [probe_tokens], channel="inbound_gradients", q_bits=q)
        log(f"qualifying gradient channel at {defense} (q={q}): {len(events)} events ...")
        t0 = __import__("time").perf_counter()
        prop = pb.family1_v2_qualify(events, seed=919, matched_test_null=True)
        inv = pb.inversion_channel_qualify(events, 919, device)
        struct = pb.family2_v2_qualify(events, seed=919, device=device)
        out[defense] = {
            "q_bits": q, "n_events": len(events),
            "step_stride": GRAD_QUAL_STEP_STRIDE,
            "sequence_property_v2_x_inbound_gradients": prop,
            "token_inversion_x_inbound_gradients": inv,
            "structure_semantic_v2_x_inbound_gradients": struct,
        }
        for name, result in (("sequence_property_v2", prop), ("token_inversion", inv),
                             ("structure_semantic_v2", struct)):
            log(f"  {name} x inbound_gradients @ {defense}: "
                f"{'QUALIFIED' if result['qualified'] else 'DISQUALIFIED'} "
                f"({time_str(time0=t0)}... )")
    return out


def time_str(time0):
    import time
    return f"{time.perf_counter() - time0:.0f}s elapsed"


# --------------------------------------------------------------------------- #
# per-cell privacy scoring (cohort artifacts)
# --------------------------------------------------------------------------- #
def build_privacy_banks(matrix: dict, qualification: dict, device,
                        p5cal_root: Path, log=print) -> dict:
    """Train probe banks once per qualified variant x q/defense.

    Forward-channel variants: probes on the width-matched 919 calibration,
    quantized to each defense's q. Gradient-channel variants: probes on the
    p5cal captures of the matching defense (already at that q)."""
    import torch

    import pcr.privacy_attacks_p4b as pb

    banks: dict = {}
    events919 = torch.load(CALIBRATION_919, map_location="cpu", weights_only=False)
    for defense, dspec in matrix["factors"]["defenses"].items():
        q = dspec["q_bits"]
        # forward-channel variants (P4b-qualified instruments)
        log(f"  banks @ {defense} (q={q}): token_inversion forward ...", )
        q_events919 = [{"latents": pb.quantize_latents(e["latents"], q),
                        "tokens": e["tokens"]} for e in events919]
        banks[("token_inversion@forward@919", defense)] = pb.inversion_channel_train(
            q_events919, 919, device)
        banks[("sequence_property_v2@forward@p4b", defense)] = pb.family1_v2_train(
            events919, q, seed=919)
        banks[("structure_semantic_v2@forward@p4b", defense)] = pb.family2_v2_train(
            events919, q, 919, device)
        # gradient-channel variants qualified on the p5cal captures
        for variant_key, result in qualification.get(defense, {}).items():
            if not isinstance(result, dict) or not result.get("qualified"):
                continue
            family = variant_key.split("_x_")[0]
            if family == "sequence_property_v2":
                events = _p5cal_events(p5cal_root, defense, q)
                banks[(f"{family}@inbound_gradients@{defense}", defense)] = \
                    pb.family1_v2_train(events, 32, seed=919)
            elif family == "structure_semantic_v2":
                events = _p5cal_events(p5cal_root, defense, q)
                banks[(f"{family}@inbound_gradients@{defense}", defense)] = \
                    pb.family2_v2_train(events, 32, 919, device)
            elif family == "token_inversion":
                events = _p5cal_events(p5cal_root, defense, q)
                banks[(f"{family}@inbound_gradients@{defense}", defense)] = \
                    pb.inversion_channel_train(events, 919, device)
    return banks


def _p5cal_events(p5cal_root: Path, defense: str, q: int) -> list:
    """p5cal dense captures -> inbound-gradient events at the defense's q."""
    import torch

    import pcr.privacy_attacks_p4b as pb
    from pcr.data import load_corpus, make_probe_batch, split_corpus

    matrix = pc.load_matrix_forgiving(pc.DEFAULT_CONFIRMATORY_MATRIX_PATH)
    _, heldout = split_corpus(load_corpus(ROOT / matrix["fixed"]["corpus"]),
                              matrix["fixed"]["corpus_split"]["train_fraction"])
    probe_tokens, _ = make_probe_batch(heldout, matrix["fixed"]["probe_batch_size"],
                                       matrix["fixed"]["sequence_length"])
    events = []
    for seed in pc.P5_CAL_SEEDS:
        samples = torch.load(p5cal_root / f"p5cal-{defense}-s{seed}" / "transcript_tensors.pt",
                             map_location="cpu", weights_only=False)
        samples = [s for s in samples if s.get("probe_batch_index", 0) == 0
                   and s["step"] % GRAD_QUAL_STEP_STRIDE == 0]
        events += pb.dense_samples_to_events(samples, [probe_tokens],
                                             channel="inbound_gradients", q_bits=q)
    return events


def score_cells_privacy(records: dict, matrix: dict, banks: dict, device,
                        output_root: Path, log=print) -> dict:
    """Apply every qualified variant's bank to each trained run's final probe
    sample; per-cell per-variant worst per-seed advantage."""
    import torch

    import pcr.privacy_attacks_p4b as pb
    from pcr.data import load_corpus, make_probe_batch, split_corpus

    matrix_c = pc.load_matrix_forgiving(pc.DEFAULT_CONFIRMATORY_MATRIX_PATH)
    _, heldout = split_corpus(load_corpus(ROOT / matrix_c["fixed"]["corpus"]),
                              matrix_c["fixed"]["corpus_split"]["train_fraction"])
    probe_tokens, _ = make_probe_batch(heldout, matrix_c["fixed"]["probe_batch_size"],
                                       matrix_c["fixed"]["sequence_length"])

    cells: dict[str, dict] = {}
    trained = [r for r in records.values() if r["mode"] == "trained"]
    for record in sorted(trained, key=lambda r: r["run_id"]):
        tensors_path = output_root / record["run_id"] / "transcript_tensors.pt"
        if not tensors_path.is_file():
            continue
        tensors = torch.load(tensors_path, map_location="cpu", weights_only=False)
        final = max((s for s in tensors if s.get("probe_batch_index", 0) == 0),
                    key=lambda s: s["step"])
        cell_key = record["cell"]
        defense = record["defense"]
        q = matrix["factors"]["defenses"][defense]["q_bits"]
        cell = cells.setdefault(cell_key, {})
        for (variant, bank_defense), bank in banks.items():
            if bank_defense != defense:
                continue
            family, channel = variant.split("@")[0], variant.split("@")[1]
            if channel == "forward":
                feats = final["forward_values"]
                if family == "token_inversion":
                    res = pb.inversion_channel_apply(bank, feats, probe_tokens, device)
                elif family == "sequence_property_v2":
                    res = pb.family1_v2_apply(bank, feats, probe_tokens, q,
                                              matched_test_null=True)
                    res = {"advantage": max(v["r_advantage"] for v in res.values())}
                else:
                    res = pb.family2_v2_apply(bank, feats, probe_tokens, q, device)
            else:
                feats = pb.quantize_latents(final["inbound_gradients"], q)
                if family == "token_inversion":
                    res = pb.inversion_channel_apply(bank, feats, probe_tokens, device)
                elif family == "sequence_property_v2":
                    res = pb.family1_v2_apply(bank, feats, probe_tokens, 32,
                                              matched_test_null=True)
                    res = {"advantage": max(v["r_advantage"] for v in res.values())}
                else:
                    res = pb.family2_v2_apply(bank, feats, probe_tokens, 32, device)
            cell.setdefault(variant, []).append(res["advantage"])
    return cells


# --------------------------------------------------------------------------- #
# per-cell gates
# --------------------------------------------------------------------------- #
def evaluate_privacy_gate(cell_scores: dict, qualified_variants: list[str]) -> dict:
    """cell_scores: {variant: [per-seed advantages]}; gate = worst per-seed
    advantage <= 0.02 over every qualified variant."""
    per_variant = {}
    worst = None
    for variant in qualified_variants:
        values = cell_scores.get(variant) or []
        vmax = max(values) if values else None
        per_variant[variant] = {"max_advantage": vmax,
                                "per_seed": values,
                                "pass": (vmax is not None and vmax <= PRIVACY_THRESHOLD)}
        if vmax is not None:
            worst = vmax if worst is None else max(worst, vmax)
    passed = (bool(qualified_variants)
              and all(per_variant[v]["pass"] for v in qualified_variants))
    return {"per_variant": per_variant, "worst_advantage": worst, "pass": passed,
            "threshold": PRIVACY_THRESHOLD}


def evaluate_utility_gate(delta_u: dict) -> dict:
    values = [v for v in delta_u.values() if v is not None]
    ci = su.mean_ci(values)
    return {"delta_u": ci, "mean_pass": ci["mean"] is not None and ci["mean"] <= UTILITY_MEAN,
            "ci_upper_pass": ci["ci_high"] is not None and ci["ci_high"] <= UTILITY_CI_UPPER,
            "thresholds": {"mean": UTILITY_MEAN, "ci_upper": UTILITY_CI_UPPER},
            "pass": bool(ci["mean"] is not None and ci["mean"] <= UTILITY_MEAN
                         and ci["ci_high"] is not None and ci["ci_high"] <= UTILITY_CI_UPPER)}


def evaluate_share_gate(shares: list[float]) -> dict:
    mean_share = su.mean_ci(shares) if shares else {"mean": None}
    return {"remote_share": mean_share,
            "pass": bool(mean_share["mean"] is not None and mean_share["mean"] >= SHARE_FLOOR),
            "floor": SHARE_FLOOR}


def analytic_share(span: int, remote_depth: int, matrix: dict) -> float:
    """Fallback: analytic remote-FLOP share via the validated instrument code
    path (pcr.instrument.model_step_flops), used ONLY when a run's artifacts
    lack the measured remote_share field. The share is token-count-free
    (both terms scale linearly in tokens)."""
    from pcr.instrument import model_step_flops

    fixed = matrix["fixed"]
    bb = fixed["backbone"]
    res = model_step_flops(bb["n_layers"], bb["d_model"], bb["d_ff"],
                           fixed["sequence_length"], 1, "trained",
                           split_width=256, split_span=span,
                           remote_depth=remote_depth)
    return res["remote_fwd_bwd"] / res["total_fwd_bwd"]


def triangle_verdict(held_cells: list[str], rule: dict) -> str:
    lang = rule["triangle_verdict_language"]
    if not held_cells:
        return lang["if_empty"]
    return lang["if_non_empty"].replace("{…}", "{" + ", ".join(held_cells) + "}")


# --------------------------------------------------------------------------- #
# figure
# --------------------------------------------------------------------------- #
def make_triangle_figure(cells: dict, figure_path: Path) -> bool:
    mpl = ensure_matplotlib()
    if mpl is None:
        print("matplotlib unavailable; skipping triangle figure")
        return False
    mpl.use("Agg")
    import matplotlib.pyplot as plt

    spans = sorted({c["span"] for c in cells.values()})
    defenses = ["d0", "d1"]
    by_coords = {(c["span"], c["defense"]): c for c in cells.values()}
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.set_xlim(-0.5, len(defenses) - 0.5)
    ax.set_ylim(-0.5, len(spans) - 0.5)
    ax.invert_yaxis()
    for i, defense in enumerate(defenses):
        for j, span in enumerate(spans):
            cell = by_coords.get((span, defense), {})
            gates = cell.get("gates", {})
            n_pass = sum(1 for g in ("privacy", "utility", "delegated_share")
                         if gates.get(g, {}).get("pass"))
            color = ["#d62728", "#ff9896", "#ffbf00", "#2ca02c"][n_pass]
            ax.add_patch(plt.Rectangle((i - 0.5, j - 0.5), 1, 1, color=color, alpha=0.55))
            text = (f"G_R {gates.get('gr_mean', float('nan')):+.3f}\n"
                    f"dU {gates.get('du_mean', float('nan')):.3f}\n"
                    f"share {gates.get('share_mean', float('nan')):.2f}")
            ax.text(i, j, text, ha="center", va="center", fontsize=8)
            marks = "".join("P" if gates.get(g, {}).get("pass") else "."
                            for g in ("privacy", "utility", "delegated_share"))
            ax.text(i, j + 0.36, marks, ha="center", va="center", fontsize=9,
                    fontweight="bold")
    ax.set_xticks(range(len(defenses)))
    ax.set_xticklabels(["D0 (q8, no grad defense)", "D1 (q4 + clip+noise)"])
    ax.set_yticks(range(len(spans)))
    ax.set_yticklabels([f"span {s}" for s in spans])
    ax.set_title("P5 delegation triangle: per-cell gates (P/U/S marks) with G_R, Delta_U, share")
    fig.tight_layout()
    figure_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(figure_path, dpi=150)
    print(f"wrote {figure_path}")
    return True


# --------------------------------------------------------------------------- #
# markdown
# --------------------------------------------------------------------------- #
def render_markdown(analysis: dict) -> str:
    lines = [
        "# P5 delegation-sweep analysis (protocol p5-delegation-sweep-1.0)",
        "",
        f"> {P5_NOTE}",
        "",
        "## Triangle verdict",
        "",
        f"**{analysis['triangle_verdict']}**",
        "",
        f"Cells holding all three gates: {analysis['cells_holding_all_gates'] or 'none'}",
        "",
        "## Per-cell gate table",
        "",
        "| Cell | privacy | utility | share >= 0.15 | G_R mean | Delta_U [95% CI] | share | holds all |",
        "|---|---|---|---|---:|---|---:|---|",
    ]
    for cell, c in analysis["cells"].items():
        g = c["gates"]
        du = g["utility"]["delta_u"]
        lines.append(
            f"| {cell} | {'pass' if g['privacy']['pass'] else 'FAIL'}"
            f" | {'pass' if g['utility']['pass'] else 'FAIL'}"
            f" | {'pass' if g['delegated_share']['pass'] else 'FAIL'}"
            f" | {_fmt(c.get('gr_mean'))} | {_fmt(du['mean'])} [{_fmt(du['ci_low'])}, {_fmt(du['ci_high'])}]"
            f" | {_fmt(g['delegated_share']['remote_share']['mean'], 3)}"
            f" | {'YES' if c['holds_all'] else 'no'} |"
        )
    lines += ["", "## Privacy qualification (gradient channel, fresh captures)", ""]
    qual = analysis.get("privacy_qualification") or {}
    for defense, variants in sorted(qual.items()):
        for name, result in sorted(variants.items()):
            if not isinstance(result, dict) or "qualified" not in result:
                continue
            lines.append(f"- {name} @ {defense}: "
                         f"{'QUALIFIED' if result['qualified'] else 'DISQUALIFIED'}")
    lines += ["", "## Named omissions", ""]
    for omission in analysis["omissions"]:
        lines.append(f"- {omission}")
    lines += ["", "## Operational failures", ""]
    if analysis["operational_failures"]:
        for failure in analysis["operational_failures"]:
            lines.append(f"- `{failure['run_id']}`: {failure['reason']}")
    else:
        lines.append("- none")
    lines.append("")
    return "\n".join(lines)


# --------------------------------------------------------------------------- #
# main
# --------------------------------------------------------------------------- #
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument("--output-root", default=str(DEFAULT_OUTPUT_ROOT))
    parser.add_argument("--manifest-dir", default=str(pc.DEFAULT_MANIFEST_DIR))
    parser.add_argument("--p5cal-root", default=str(DEFAULT_P5CAL_ROOT))
    parser.add_argument("--qualification-path", default=None,
                        help="default: <output-root>/gradient_qualification.json")
    parser.add_argument("--qualify-only", action="store_true",
                        help="run only the gradient-channel qualification")
    parser.add_argument("--reuse-qualification", action="store_true",
                        help="load an existing qualification JSON instead of recomputing")
    parser.add_argument("--analysis-path", default=None)
    parser.add_argument("--summary-path", default=None)
    parser.add_argument("--figure-path", default=str(DEFAULT_FIGURE_PATH))
    parser.add_argument("--no-figure", action="store_true")
    parser.add_argument("--no-privacy-scoring", action="store_true",
                        help="skip cohort privacy scoring (privacy gate not evaluable; "
                             "used by tests and quick gate-only passes)")
    parser.add_argument("--device", default="cpu")
    args = parser.parse_args(argv)

    from pcr.utils import resolve_device

    device = resolve_device(args.device)
    output_root = Path(args.output_root)
    qual_path = (Path(args.qualification_path) if args.qualification_path
                 else output_root / "gradient_qualification.json")

    matrix = pc.load_matrix_forgiving(args.config)
    rule = matrix["confirmatory_rule"]

    # ---- privacy qualification (gradient channels, fresh captures) --------
    if args.reuse_qualification and qual_path.is_file():
        qualification = json.loads(qual_path.read_text())
    else:
        qualification = qualify_gradient_channels(Path(args.p5cal_root), device)
        output_root.mkdir(parents=True, exist_ok=True)
        qual_path.write_text(json.dumps(qualification, indent=2, sort_keys=True))
        print(f"wrote {qual_path}")
    if args.qualify_only:
        for defense, variants in qualification.items():
            for name, result in sorted(variants.items()):
                if isinstance(result, dict) and "qualified" in result:
                    print(f"{name} @ {defense}: "
                          f"{'QUALIFIED' if result['qualified'] else 'DISQUALIFIED'}")
        return 0

    # ---- discovery ---------------------------------------------------------
    expected = pc.expected_p5_runs(matrix)
    manifests, unreadable = pc.scan_manifests(args.manifest_dir)
    completed, failures, extras = pc.classify_runs(
        expected, manifests, unreadable,
        required_manifest_fields={"cohort": "confirmatory",
                                  "protocol_version": matrix["protocol_version"]},
    )
    records: dict[str, dict] = {}
    for entry in completed:
        record, error = collect_run(output_root, entry)
        if error:
            failures.append({"run_id": entry["run_id"], "mode": entry["mode"],
                             "seed": entry["seed"], "reason": error})
        else:
            record["cell"] = entry.get("cell")
            record["defense"] = entry.get("defense")
            records[entry["run_id"]] = record

    qualified_variants = []
    for defense, variants in qualification.items():
        for name, result in sorted(variants.items()):
            if isinstance(result, dict) and result.get("qualified"):
                # name is "<family>_x_<channel>" from qualification; normalize
                # to the bank/score key "<family>@<channel>@<defense>"
                family = name.split("_x_")[0]
                qualified_variants.append(f"{family}@inbound_gradients@{defense}")
    # forward-channel variants reuse the P4b-qualified instruments
    qualified_variants += ["sequence_property_v2@forward@p4b",
                           "structure_semantic_v2@forward@p4b",
                           "token_inversion@forward@919"]

    # per-cell privacy scores from the cohort's stored probe tensors (when the
    # cohort has been executed; otherwise the gate is not evaluable -> FAIL)
    trained_records = [r for r in records.values() if r["mode"] == "trained"]
    if trained_records and not args.no_privacy_scoring:
        print(f"scoring privacy on {len(trained_records)} trained runs ...")
        banks = build_privacy_banks(matrix, qualification, device,
                                    Path(args.p5cal_root))
        privacy_scores = score_cells_privacy(records, matrix, banks, device,
                                             output_root)
    else:
        privacy_scores = None

    # ---- per-cell gates -----------------------------------------------------
    cells: dict[str, dict] = {}
    for span_name, level in matrix["factors"]["segment_span"].items():
        for defense in matrix["factors"]["defenses"]:
            cell_key = f"{span_name}-{defense}"
            seeds = matrix["factors"]["seed"]
            delta_u, gains, shares = {}, [], []
            share_sources = set()
            for s in seeds:
                trained = records.get(pc.p5_cell_run_id(level["span"], defense, "trained", s))
                frozen = records.get(pc.p5_cell_run_id(level["span"], defense,
                                                       "frozen_random", s))
                local = records.get(f"p5-all_local-s{s}")
                if trained and local:
                    delta_u[str(s)] = (trained["final_eval_loss"]
                                       - local["eval_series"][trained["final_step"]])
                else:
                    delta_u[str(s)] = None
                if trained and frozen:
                    gains.append(frozen["final_eval_loss"] - trained["final_eval_loss"])
                if trained:
                    share = trained["cumulative_remote_flops"].get("remote_share")
                    if share is not None:
                        shares.append(share)  # measured by the run's instrumentation
                        share_sources.add("measured")
                    else:
                        # artifacts lack the field: analytic fallback via the
                        # validated instrument code path (same functions)
                        shares.append(analytic_share(level["span"],
                                                     level["remote_depth"], matrix))
                        share_sources.add("analytic_fallback")
            # privacy scoring of the cohort's stored probe tensors; missing
            # cohort -> gate not evaluable -> FAIL with note
            if privacy_scores is not None:
                cell_scores = {v: privacy_scores.get(cell_key, {}).get(v, [])
                               for v in qualified_variants}
            else:
                cell_scores = {v: [] for v in qualified_variants}
            privacy_gate = evaluate_privacy_gate(cell_scores, qualified_variants)
            if not any(cell_scores[v] for v in qualified_variants):
                privacy_gate["note"] = ("no cohort scores available (cohort not "
                                        "executed or runs missing)")
                privacy_gate["pass"] = False
            utility_gate = evaluate_utility_gate(delta_u)
            share_gate = evaluate_share_gate(shares)
            share_gate["source"] = ("measured" if share_sources == {"measured"}
                                    else " + ".join(sorted(share_sources))
                                    if share_sources else "none")
            holds = bool(privacy_gate["pass"] and utility_gate["pass"] and share_gate["pass"])
            cells[cell_key] = {
                "span": level["span"], "start": level["start"], "defense": defense,
                "remote_depth": level["remote_depth"],
                "delta_u_by_seed": delta_u,
                "gr_mean": float(np.mean(gains)) if gains else None,
                "gr_per_seed": gains,
                "gates": {"privacy": privacy_gate, "utility": utility_gate,
                          "delegated_share": share_gate,
                          "gr_mean": float(np.mean(gains)) if gains else None,
                          "du_mean": utility_gate["delta_u"]["mean"],
                          "share_mean": share_gate["remote_share"]["mean"]},
                "holds_all": holds,
            }

    held = sorted(k for k, c in cells.items() if c["holds_all"])
    analysis = {
        "note": P5_NOTE,
        "protocol_version": matrix.get("protocol_version"),
        "config": args.config,
        "confirmatory_rule": rule,
        "privacy_qualification": qualification,
        "qualified_variants": qualified_variants,
        "cells": cells,
        "cells_holding_all_gates": held,
        "triangle_verdict": triangle_verdict(held, rule),
        "omissions": OMISSIONS,
        "operational_failures": sorted(failures, key=lambda f: f["run_id"]),
        "non_study_manifests_ignored": extras,
    }
    analysis_path = (Path(args.analysis_path) if args.analysis_path
                     else output_root / "delegation_analysis.json")
    summary_path = (Path(args.summary_path) if args.summary_path
                    else output_root / "delegation_summary.md")
    analysis_path.parent.mkdir(parents=True, exist_ok=True)
    analysis_path.write_text(json.dumps(analysis, indent=2, sort_keys=True))
    summary_path.write_text(render_markdown(analysis))
    print(render_markdown(analysis))
    print(f"wrote {analysis_path}\nwrote {summary_path}")
    print(f"TRIANGLE VERDICT: {analysis['triangle_verdict']}")

    if not args.no_figure:
        make_triangle_figure(cells, Path(args.figure_path))
    return 0


if __name__ == "__main__":
    sys.exit(main())
