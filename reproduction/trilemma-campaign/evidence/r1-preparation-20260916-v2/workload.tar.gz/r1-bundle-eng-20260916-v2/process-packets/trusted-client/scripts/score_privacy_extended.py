#!/usr/bin/env python3
"""P4a extended privacy scoring (docs/PREREGISTRATION_P4A.md, frozen 2026-09-07).

Qualifies the four attack families on calibration artifacts (positive controls
at q=32, matched nulls, frozen floors), scores the four P2b frontier cells
(trained runs, q in {4,8,16,32}) on families 1-2 using stored probe tensors
(width-matched seed-919 calibration, quantized on the fly to the cell's q),
scores families 3-4 on the dense/canary calibration captures at q in {4,32}
(declared limitation: confirmatory runs lack dense transcripts), and evaluates
frontier survival: a cell survives iff every QUALIFIED family scores <= its
threshold at that cell's q (advantage <= 0.02; family 4: AUC - 0.5 <= 0.02).

Writes outputs/privacy_extended/privacy_extended.json +
privacy_extended_summary.md. If a family's positive control genuinely fails,
the family is DISQUALIFIED and named — floors are frozen and never tuned.

Usage:
  .venv/bin/python scripts/score_privacy_extended.py
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "src"))

import pilot_common as pc  # noqa: E402

DEFAULT_OUTPUT_ROOT = ROOT / "outputs" / "privacy_extended"
RATE_SWEEP_ROOT = ROOT / "outputs" / "rate_sweep"
CALIBRATION_919 = ROOT / "outputs" / "confirmatory" / "calibration-s919" / "calibration_pairs.pt"
P4A_ROOT = ROOT / "outputs" / "privacy_calibration"
FRONTIER_SEEDS = [7, 17, 27, 37, 47, 57, 67, 87]
FRONTIER_Q = [4, 8, 16, 32]
THRESHOLD_ADVANTAGE = 0.02
THRESHOLD_AUC_ADVANTAGE = 0.02

OMISSIONS = [
    "timing channels",
    "attacks on optimizer state beyond the remote module",
    "active/adaptive attackers that modify queries",
    "semantic attacks beyond byte-structure classes",
    "membership inference of natural (non-canary) sequences",
    "joint cross-run attacks",
    "families 3-4 (history accumulation, canary membership) evaluated on "
    "calibration captures only: confirmatory runs lack dense transcripts",
]


def load_dense_latents(run_dir: Path) -> "torch.Tensor":
    """(S, B, T, W) stacked forward_values over consecutive captured steps."""
    import torch

    samples = torch.load(run_dir / "transcript_tensors.pt", map_location="cpu",
                         weights_only=False)
    samples = [s for s in sorted(samples, key=lambda s: (s["step"], s.get("probe_batch_index", 0)))
               if s.get("probe_batch_index", 0) == 0]
    return torch.stack([s["forward_values"] for s in samples])


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-root", default=str(DEFAULT_OUTPUT_ROOT))
    parser.add_argument("--rate-sweep-root", default=str(RATE_SWEEP_ROOT))
    parser.add_argument("--p4a-root", default=str(P4A_ROOT))
    parser.add_argument("--calibration-919", default=str(CALIBRATION_919))
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--epochs", type=int, default=20)
    args = parser.parse_args(argv)

    import torch

    import pcr.privacy_attacks as pa
    from pcr.data import load_corpus, make_probe_batch, split_corpus
    from pcr.utils import resolve_device

    device = resolve_device(args.device)
    output_root = Path(args.output_root)
    p4a_root = Path(args.p4a_root)
    epochs = args.epochs

    matrix = pc.load_matrix_forgiving(pc.DEFAULT_CONFIRMATORY_MATRIX_PATH)
    _, heldout = split_corpus(load_corpus(ROOT / matrix["fixed"]["corpus"]),
                              matrix["fixed"]["corpus_split"]["train_fraction"])
    probe_tokens, _ = make_probe_batch(heldout, matrix["fixed"]["probe_batch_size"],
                                       matrix["fixed"]["sequence_length"])
    probe_tokens_np = probe_tokens.numpy().astype(np.int64)

    out = {"note": "P4a privacy-instrument broadening; exploratory calibration "
                   "scoring per docs/PREREGISTRATION_P4A.md; floors frozen.",
           "protocol_version": pc.P4A_PROTOCOL,
           "threshold_advantage": THRESHOLD_ADVANTAGE,
           "threshold_auc_advantage": THRESHOLD_AUC_ADVANTAGE,
           "omissions": OMISSIONS,
           "families": {}}

    # ---------------- families 1-2: qualification on seed-919 calibration ---
    events = torch.load(args.calibration_919, map_location="cpu", weights_only=False)
    print(f"qualifying families 1-2 on calibration-s919 ({len(events)} events) ...")
    # family 1's features are per-sequence (1024 sequences): batch 32 matches
    # the P0 probe's ~640-step optimization budget (batch 4096 would give 20)
    q1 = pa.family1_qualify(events, seed=919, epochs=epochs, device=device, batch_size=32)
    q2 = pa.family2_qualify(events, seed=919, epochs=epochs, device=device)
    out["families"]["sequence_property"] = {"qualification": q1}
    out["families"]["structure_semantic"] = {"qualification": q2}
    for q in (q1, q2):
        print(f"  {q['family']}: {'QUALIFIED' if q['qualified'] else 'DISQUALIFIED'}")

    # ---------------- families 3-4: dense / canary calibration runs ---------
    print("loading dense captures ...")
    dense = {}
    for seed in pc.P4A_DENSE_SEEDS:
        for q in pc.P4A_Q_LEVELS:
            run_id = f"p4a-dense-q{q}-s{seed}"
            dense[run_id] = load_dense_latents(p4a_root / run_id)
            print(f"  {run_id}: {tuple(dense[run_id].shape)}")

    dense_q32 = {rid: lat for rid, lat in dense.items() if "-q32-" in rid}
    q3 = pa.family3_qualify(dense_q32, probe_tokens_np, seed=979, epochs=epochs,
                            device=device)
    out["families"]["history_accumulation"] = {"qualification": q3}
    print(f"  history_accumulation: {'QUALIFIED' if q3['qualified'] else 'DISQUALIFIED'}")

    # family 4: inversion probes on dense captures at each q; canary scoring
    print("scoring canary membership ...")
    q4_results = {"family": "canary_membership",
                  "floors": pa.FLOORS["canary_membership"], "per_q": {}}
    for q in pc.P4A_Q_LEVELS:
        pooled = torch.cat([dense[f"p4a-dense-q{q}-s{s}"] for s in pc.P4A_DENSE_SEEDS])
        probe = pa.train_inversion_probe_on_dense(pooled, probe_tokens_np, seed=919,
                                                  epochs=epochs, device=device)
        per_seed = {}
        for seed in pc.P4A_CANARY_SEEDS:
            canaries = torch.load(p4a_root / f"p4a-canary-q{q}-s{seed}" / "canaries.pt",
                                  map_location="cpu", weights_only=False)
            null_canaries = torch.load(
                p4a_root / f"p4a-nocanary-q{q}-s{seed}" / "canaries.pt",
                map_location="cpu", weights_only=False)
            per_seed[str(seed)] = {
                "canary": pa.family4_score_run(probe, canaries, device),
                "null_nocanary": pa.family4_score_run(probe, null_canaries, device),
            }
        aucs = [v["canary"]["auc"] for v in per_seed.values()]
        null_aucs = [v["null_nocanary"]["auc"] for v in per_seed.values()]
        q4_results["per_q"][str(q)] = {
            "per_seed": per_seed,
            "min_auc": min(aucs), "mean_auc": float(np.mean(aucs)),
            "max_abs_null_auc_minus_half": max(abs(a - 0.5) for a in null_aucs),
        }
    floor = pa.FLOORS["canary_membership"]
    q4_32 = q4_results["per_q"]["32"]
    q4_qualified = bool(
        q4_32["min_auc"] > floor["positive_control_auc"]
        and q4_32["max_abs_null_auc_minus_half"] <= floor["null_auc_band"]
    )
    q4_results["qualified"] = q4_qualified
    out["families"]["canary_membership"] = q4_results
    print(f"  canary_membership: {'QUALIFIED' if q4_qualified else 'DISQUALIFIED'}")

    # ---------------- scoring ----------------------------------------------
    scores = {"families_1_2_frontier_cells": {}, "family_3_dense": {}, "family_4_canary": {}}

    if q1["qualified"] or q2["qualified"]:
        print("scoring frontier cells on families 1-2 (probes trained once per q "
              "on calibration-s919 latents, quantized on the fly) ...")
    for q in FRONTIER_Q:
        cell = f"medium-high-q{q}"
        banks = {}
        if q1["qualified"]:
            print(f"  q={q}: training family-1 probes (calibration, q={q}) ...", flush=True)
            banks["sequence_property"] = pa.family1_train(events, q, 919, epochs, device)
        if q2["qualified"]:
            print(f"  q={q}: training family-2 probe (calibration, q={q}) ...", flush=True)
            banks["structure_semantic"] = pa.family2_train(events, q, 919, epochs, device)
        cell_result = {}
        for seed in FRONTIER_SEEDS:
            run_dir = Path(args.rate_sweep_root) / f"trained-medium-high-q{q}-s{seed}"
            tensors = torch.load(run_dir / "transcript_tensors.pt", map_location="cpu",
                                 weights_only=False)
            final = max((s for s in tensors if s.get("probe_batch_index", 0) == 0),
                        key=lambda s: s["step"])
            run_latents = final["forward_values"]
            entry = {}
            if "sequence_property" in banks:
                entry["sequence_property"] = pa.family1_apply(
                    banks["sequence_property"], run_latents, probe_tokens, q, device)
            if "structure_semantic" in banks:
                entry["structure_semantic"] = pa.family2_apply(
                    banks["structure_semantic"], run_latents, probe_tokens, q, device)
            cell_result[str(seed)] = entry
        # cell advantage = max over seeds (conservative; per-family visible)
        summary = {}
        for family, per_prop in (("sequence_property", q1), ("structure_semantic", q2)):
            if not per_prop["qualified"]:
                summary[family] = {"scored": False, "reason": "family disqualified"}
                continue
            if family == "sequence_property":
                props = {}
                for prop in ("vowel_fraction_bucket", "digit_presence"):
                    advs = [cell_result[s][family][prop]["advantage"] for s in cell_result]
                    props[prop] = {"max_advantage": max(advs), "per_seed": advs,
                                   "pass": max(advs) <= THRESHOLD_ADVANTAGE}
                summary[family] = {"scored": True, "per_property": props,
                                   "pass": all(p["pass"] for p in props.values())}
            else:
                advs = [cell_result[s][family]["advantage"] for s in cell_result]
                summary[family] = {"scored": True, "max_advantage": max(advs),
                                   "per_seed": advs,
                                   "pass": max(advs) <= THRESHOLD_ADVANTAGE}
        scores["families_1_2_frontier_cells"][cell] = {
            "per_seed": cell_result, "summary": summary}
        print(f"  {cell}: " + "; ".join(
            f"{f} max_adv={v.get('max_advantage', 'multi-prop')}" if isinstance(v, dict)
            else ""
            for f, v in summary.items()))

    # family 3 scores on dense captures (q=4 and q=32)
    for q in pc.P4A_Q_LEVELS:
        rid_set = [f"p4a-dense-q{q}-s{s}" for s in pc.P4A_DENSE_SEEDS]
        per_run = {}
        for rid in rid_set:
            per_run[rid] = pa.family3_evaluate(dense[rid], probe_tokens_np, seed=979,
                                               epochs=epochs, device=device)
        max_adv = max(r["advantage"] for r in per_run.values())
        scores["family_3_dense"][f"q{q}"] = {
            "per_run": per_run, "max_advantage": max_adv,
            "pass": max_adv <= THRESHOLD_ADVANTAGE if q3["qualified"] else None,
            "scored": bool(q3["qualified"]),
        }

    # family 4 scores per q
    for q in pc.P4A_Q_LEVELS:
        per_q = q4_results["per_q"][str(q)]
        advs = {seed: v["canary"]["auc"] - 0.5 for seed, v in per_q["per_seed"].items()}
        scores["family_4_canary"][f"q{q}"] = {
            "auc_advantage_per_seed": advs,
            "max_auc_advantage": max(advs.values()),
            "pass": (max(advs.values()) <= THRESHOLD_AUC_ADVANTAGE
                     if q4_qualified else None),
            "scored": bool(q4_qualified),
        }

    # ---------------- frontier survival ------------------------------------
    survival = compute_survival(scores, FRONTIER_Q, q3["qualified"], q4_qualified)

    out["scores"] = scores
    out["frontier_survival"] = survival
    out["verdicts"] = {
        "qualified_families": [f for f, v in out["families"].items()
                               if v.get("qualified") or v.get("qualification", {}).get("qualified")],
        "disqualified_families": [f for f, v in out["families"].items()
                                  if not (v.get("qualified")
                                          or v.get("qualification", {}).get("qualified"))],
        "surviving_cells": [c for c, v in survival.items() if v["survives"] is True],
        "shrunk_cells": [c for c, v in survival.items() if v["survives"] is False],
        "undetermined_cells": [c for c, v in survival.items() if v["survives"] is None],
    }

    output_root.mkdir(parents=True, exist_ok=True)
    json_path = output_root / "privacy_extended.json"
    json_path.write_text(json.dumps(out, indent=2, sort_keys=True))
    md_path = output_root / "privacy_extended_summary.md"
    md_path.write_text(render_markdown(out))
    print(render_markdown(out))
    print(f"wrote {json_path}\nwrote {md_path}")
    return 0


def compute_survival(scores: dict, q_levels: list[int], q3_qualified: bool,
                     q4_qualified: bool) -> dict:
    """Frozen survival rule: a cell survives iff every QUALIFIED family scores
    <= its threshold at that cell's q. Families 3-4 apply only at q in {4, 32}
    (declared limitation: confirmatory runs lack dense transcripts); disqualified
    families never gate."""
    survival = {}
    for q in q_levels:
        cell = f"medium-high-q{q}"
        checks = {}
        cell12 = scores["families_1_2_frontier_cells"].get(cell, {}).get("summary", {})
        for family, info in cell12.items():
            if info.get("scored"):
                checks[family] = info["pass"]
        if q in (4, 32):
            if q3_qualified:
                checks["history_accumulation"] = scores["family_3_dense"][f"q{q}"]["pass"]
            if q4_qualified:
                checks["canary_membership"] = scores["family_4_canary"][f"q{q}"]["pass"]
        survival[cell] = {
            "qualified_family_checks": checks,
            # None = UNDETERMINED: no qualified family evaluated this cell
            # (an instrument outcome, not a privacy pass or failure)
            "survives": (all(checks.values()) if checks else None),
            "note": ("no qualified family evaluable at this cell"
                     if not checks else
                     None if q in (4, 32) else
                     "families 3-4 not evaluable at this q (no dense/canary transcripts "
                     "at this q; declared omission)"),
        }
    return survival


def _fmt(v, digits=4):
    return "-" if v is None else f"{v:.{digits}f}"


def render_markdown(out: dict) -> str:
    lines = [
        "# P4a extended privacy scoring (protocol p4a-privacy-broadening-1.0)",
        "",
        "## Qualification verdicts (frozen floors)",
        "",
        "| Family | verdict | key numbers |",
        "|---|---|---|",
    ]
    fams = out["families"]
    if "sequence_property" in fams:
        q = fams["sequence_property"]["qualification"]
        nums = "; ".join(
            f"{p}: adv {v['advantage']:+.4f} (floor {q['floor']}), null pipeline "
            f"{v['null_pipeline_advantage']:+.4f}"
            for p, v in q["per_property"].items())
        lines.append(f"| sequence_property | {'QUALIFIED' if q['qualified'] else 'DISQUALIFIED'} | {nums} |")
    if "structure_semantic" in fams:
        q = fams["structure_semantic"]["qualification"]
        lines.append(f"| structure_semantic | {'QUALIFIED' if q['qualified'] else 'DISQUALIFIED'}"
                     f" | adv {q['advantage']:+.4f} (floor {q['floor']}), null pipeline {q['null_pipeline_advantage']:+.4f} |")
    if "history_accumulation" in fams:
        q = fams["history_accumulation"]["qualification"]
        lines.append(f"| history_accumulation | {'QUALIFIED' if q['qualified'] else 'DISQUALIFIED'}"
                     f" | min adv {q['min_advantage']:+.4f} (floor {q['floor']}), "
                     f"max |null adv| {q['max_abs_null_advantage']:.4f} (band {q['null_band']}) |")
    if "canary_membership" in fams:
        q = fams["canary_membership"]
        q32 = q["per_q"]["32"]
        lines.append(f"| canary_membership | {'QUALIFIED' if q['qualified'] else 'DISQUALIFIED'}"
                     f" | min AUC {q32['min_auc']:.4f} (floor {q['floors']['positive_control_auc']}), "
                     f"max |null AUC - 0.5| {q32['max_abs_null_auc_minus_half']:.4f} |")
    lines += ["", "## Frontier survival", "",
              "| Cell | qualified-family checks | survives |", "|---|---|---|"]
    for cell, v in out["frontier_survival"].items():
        checks = "; ".join(f"{k}: {'pass' if val else 'FAIL'}"
                           for k, val in v["qualified_family_checks"].items())
        status = "YES" if v["survives"] is True else ("NO" if v["survives"] is False
                                                      else "UNDETERMINED")
        lines.append(f"| {cell} | {checks or 'none (no qualified family)'} | {status} |")
    lines += ["", "## Named omissions (per AGENTS.md rule 6)", ""]
    for omission in out["omissions"]:
        lines.append(f"- {omission}")
    lines.append("")
    return "\n".join(lines)


if __name__ == "__main__":
    sys.exit(main())
