#!/usr/bin/env python3
"""Generate experiments/configs/delegation_matrix.yaml (P5 delegation-sweep config).

Reproducible generator per docs/PREREGISTRATION_P5.md (frozen 2026-09-07):
7 spans {1..7} at frozen centered starts {3,3,2,2,1,1,0} x defenses
{d0: q8, no gradient defense / d1: q4 + per-position gradient clip 1.0 +
Gaussian noise 0.1} x modes {trained, frozen_random} x seeds
[21, 31, 41, 51, 61, 71, 81, 91]; remote_depth = ceil(span/2); controls
all_local per seed + removed_remote per span per seed (d0 boundary);
pairing pb-p5-{seed}; cohort confirmatory. The three frozen gates and the
triangle-verdict language are embedded verbatim from the preregistration.

Usage:
  .venv/bin/python scripts/make_delegation_config.py
"""

from __future__ import annotations

import argparse
import math
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import pilot_common as pc  # noqa: E402

SEEDS = [21, 31, 41, 51, 61, 71, 81, 91]
# frozen: start = (8 - span) // 2 for span in 1..7
SPANS = {span: (8 - span) // 2 for span in range(1, 8)}  # {1:3, 2:3, 3:2, 4:2, 5:1, 6:1, 7:0}

GATE_TEXT = {
    "privacy": ("for each qualified attack family x channel, the cell's worst per-seed "
                "advantage <= 0.02; families: token-inversion (P0), sequence-property-v2, "
                "structure-semantic-v2 (P4b); channels: forward latents AND returned "
                "(inbound) gradients; gradient-channel variants qualify on fresh "
                "calibration captures with the same frozen floors (property r-advantage "
                ">= 0.10, structure >= 0.02, token-inversion 0.05; |null| <= 0.02); a "
                "channel-variant that fails qualification is DISQUALIFIED and named"),
    "utility": ("mean Delta_U = L(trained) - L(all_local) <= 0.10 nats with the upper "
                "95% CI <= 0.12"),
    "delegated_share": ("measured analytic remote FLOP fraction (remote fwd+bwd / total "
                        "fwd+bwd, per the validated instrumentation) >= 0.15"),
}
TRIANGLE_EMPTY = ("within the swept space, defense options, and attack suite, no tested "
                  "configuration holds all three gates")
TRIANGLE_NONEMPTY = "cells {…} hold all three gates"

DEFAULT_OUT = ROOT / "experiments" / "configs" / "delegation_matrix.yaml"


def build_config(source_fixed: dict) -> dict:
    fixed = dict(source_fixed)
    fixed["boundary_defense"] = {
        "type": "uniform_per_tensor_affine_quantization",
        "ste_in_training": True,
        "serialization": "true_quantized_packed_codes_plus_8_byte_affine_metadata",
        "note": "q_bits is swept by the defense axis (d0: 8, d1: 4); gradient defense per "
                "the defense axis",
    }
    return {
        "protocol_status": "frozen_for_confirmation",
        "protocol_version": "p5-delegation-sweep-1.0",
        "study": "remote_substitutability_delegation_sweep",
        "purpose": "empirical_delegation_triangle_test_privacy_utility_share",
        "cohort": "confirmatory",
        "freeze_note": (
            "Frozen for the P5 delegation-sweep study on 2026-09-07, BEFORE any run under "
            "this config and before inspecting any artifact produced under it. Seeds are "
            "fresh and disjoint from all prior cohorts (exploratory [101, 202, 303]; P2 "
            "[11..88]; P2b [7..87]; P2c [3..83]; P3 [9..89]; calibration [909, 919, 929] "
            "and P4a/P4b [939, 949, 959, 969, 9390, 9490, 9590, 9690]; P5 calibration "
            "[9391, 9491]). Changes after this freeze require a versioned amendment "
            "written before inspecting affected outcomes."
        ),
        "fixed": fixed,
        "factors": {
            "segment_span": {
                f"s{span}at{start}": {
                    "start": start, "span": span,
                    "remote_depth": math.ceil(span / 2),
                }
                for span, start in SPANS.items()
            },
            "defenses": {
                "d0": {"q_bits": 8, "grad_defense": None},
                "d1": {"q_bits": 4,
                       "grad_defense": {"clip_norm": 1.0, "noise_std": 0.1}},
            },
            "latent_width": {"high": 256},
            "remote_mode": ["trained", "frozen_random"],
            "seed": SEEDS,
        },
        "controls": {
            "all_local": {},
            "removed_remote": {"width": "high", "q_bits": 8,
                               "note": "d0 boundary for removed controls; identity per "
                                       "remote block (no remote trainable params)"},
        },
        "pairing": {
            "block_id": "pb-p5-{seed}",
            "shared_encoder_decoder_initialization": True,
            "shared_minibatch_order": True,
            "shared_trusted_random_streams": True,
            "only_remote_parameter_updates_differ": True,
            "note": "the D1 grad-defense noise stream (derive_seed('grad-defense', seed)) "
                    "is shared within a pair",
        },
        "operational_rate": {
            "unit": "bits_per_token",
            "measurement_stage": "serialized_remote_transcript",
            "includes_repeated_releases": True,
        },
        "matched_controls": ["all_local", "removed_remote"],
        "primary_outcomes": ["heldout_replacement_penalty", "per_family_attack_advantage",
                             "measured_remote_flop_share", "causal_remote_learning_gain"],
        "calibration": {
            "gradient_channel_captures": {
                "cohort": "calibration", "seeds": [9391, 9491], "mode": "trained",
                "segment": {"start": 2, "span": 4}, "width": 256, "remote_depth": 2,
                "steps": 600, "transcript_sample_every": 1,
                "defenses": ["d0", "d1"],
                "note": "dense 4-channel probe captures for gradient-channel attack "
                        "qualification; forward channels reuse qualified instruments "
                        "(919; P4b dense captures)",
            },
        },
        "confirmatory_rule": {
            "inferential_unit": "independent_training_run_seed",
            "pairing": "per-seed paired contrast within block pb-p5-{seed}",
            "gates": GATE_TEXT,
            "triangle_verdict_language": {
                "if_empty": TRIANGLE_EMPTY,
                "if_non_empty": TRIANGLE_NONEMPTY,
            },
            "triangle_note": "an empirical feasible-set statement within this mechanism "
                             "family, not a universal law",
            "missing_data": "at most one retry per run with identical cell identity; a seed "
                            "is dropped from affected tests only (predeclared, never "
                            "outcome-based)",
        },
        "failure_policy": {
            "operational_failure_classes": ["device_error", "out_of_memory", "io_error",
                                            "schema_validation_error"],
            "max_retries": 1,
            "rule": "Failures are recorded with manifest status operational_failure and "
                    "partial artifacts; never excluded based on outcome.",
        },
        "notes": [
            "External motivation: arXiv:2609.04382 (Privacy Failure in Split-LLM Training): "
            "the returned-gradient channel is a privacy surface; per-row gradient clipping + "
            "noising is the D1 defense axis.",
            "remote_depth = ceil(span/2): surrogate blocks at width 256 stacked to match "
            "delegated share with span; removed_remote uses identity per block (zero remote "
            "trainable params).",
            "D1 gradient defense constants (clip 1.0, noise 0.1) frozen arbitrarily but "
            "before outcomes; sensitivity deferred to a later amendment.",
            "Named omissions (per AGENTS.md rule 6): history-accumulation and canary-"
            "membership families (instruments unqualified, P4b); timing; optimizer state "
            "beyond the remote module; active/adaptive attackers; natural-sequence "
            "membership; cross-run joint attacks; arch2/corpus2 (single-setting sweep by "
            "design; replication deferred).",
            "Timing is logged for systems accounting only and enters no privacy claim.",
        ],
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-config", default=str(pc.DEFAULT_CONFIRMATORY_MATRIX_PATH))
    parser.add_argument("--output", default=str(DEFAULT_OUT))
    args = parser.parse_args(argv)

    source = pc.load_matrix_forgiving(args.source_config)
    config = build_config(source["fixed"])
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    text = yaml.safe_dump(config, sort_keys=False, allow_unicode=True, width=100)
    out.write_text(text)
    reloaded = yaml.safe_load(text)
    assert reloaded["protocol_version"] == "p5-delegation-sweep-1.0"
    spans = reloaded["factors"]["segment_span"]
    assert [(v["span"], v["start"], v["remote_depth"]) for v in spans.values()] == [
        (1, 3, 1), (2, 3, 1), (3, 2, 2), (4, 2, 2), (5, 1, 3), (6, 1, 3), (7, 0, 4)]
    print(f"wrote {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
