#!/usr/bin/env python3
"""Generate experiments/configs/replication_matrix.yaml (P3 replication config).

Reproducible generator: copies the shared fixed protocol from
confirmatory_matrix.yaml and defines the three settings per
docs/PREREGISTRATION_P3.md (A2C1, A1C2, A2C2; arch1/arch2 x corpus1/corpus2
minus the already-tested corner). Verifies both corpus sha256 digests against
the files on disk before writing anything; refuses to generate on mismatch.

corpus2 split digest: the corpus1 corpus_split_digest (6cd31100...) predates
this study and its exact derivation is not recoverable from the repo (it is a
static frozen value, unchanged here). For corpus2 the split digest is DEFINED
as sha256( rule_utf8 || corpus_bytes ) with rule =
"first_90_percent_train_last_10_percent_heldout_by_byte_offset" — documented
in the generated config's notes.

Usage:
  .venv/bin/python scripts/make_replication_config.py
"""

from __future__ import annotations

import argparse
import hashlib
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import pilot_common as pc  # noqa: E402

SPLIT_RULE = "first_90_percent_train_last_10_percent_heldout_by_byte_offset"
CORPUS1_SHA = "86c4e6aa9db7c042ec79f339dcb96d42b0075e16b8fc2e86bf0ca57e2dc565ed"
CORPUS1_SPLIT_DIGEST = "6cd31100b2979ed8770cb5b68f9d67759ace427d926197dac604023ef195fb66"
CORPUS2_SHA = "2d5bb2ad5f422765e714617e21fa31bbaf8958aa79682c86fca6660fcc5d1b2b"

ARCH1 = {"vocab_size": 256, "d_model": 256, "n_heads": 8, "n_layers": 8,
         "d_ff": 1024, "max_seq_len": 128, "init_std": 0.02}
ARCH2 = {"vocab_size": 256, "d_model": 192, "n_heads": 6, "n_layers": 12,
         "d_ff": 768, "max_seq_len": 128, "init_std": 0.02}
SEEDS = [9, 19, 29, 39, 49, 59, 69, 89]

DEFAULT_OUT = ROOT / "experiments" / "configs" / "replication_matrix.yaml"


def corpus2_split_digest(corpus_path: Path) -> str:
    """DEFINED as sha256( SPLIT_RULE.encode('utf-8') || corpus_bytes )."""
    payload = SPLIT_RULE.encode("utf-8") + corpus_path.read_bytes()
    return hashlib.sha256(payload).hexdigest()


def build_config(shared_fixed: dict, corpus2_digest: str) -> dict:
    fixed = dict(shared_fixed)
    fixed["boundary_defense"] = {
        "type": "uniform_per_tensor_affine_quantization",
        "q_bits": 8,
        "ste_in_training": True,
        "serialization": "true_quantized_packed_codes_plus_8_byte_affine_metadata",
    }
    return {
        "protocol_status": "frozen_for_confirmation",
        "protocol_version": "p3-replication-1.0",
        "study": "remote_substitutability_replication",
        "purpose": "external_replication_of_causal_remote_learning_gain_H1",
        "cohort": "confirmatory",
        "freeze_note": (
            "Frozen for the P3 external-replication study on 2026-09-06, BEFORE any run "
            "under this config and before inspecting any artifact produced under it. Seeds "
            "are fresh and disjoint from exploratory [101, 202, 303], P2 confirmatory "
            "[11, 22, 33, 44, 55, 66, 77, 88], P2b rate-sweep [7, 17, 27, 37, 47, 57, 67, "
            "87], P2c [3, 13, 23, 33, 43, 53, 63, 83], and calibration [909, 919, 929]. "
            "Changes after this freeze require a versioned amendment written before "
            "inspecting affected outcomes."
        ),
        "settings": {
            "a2c1": {"architecture": "arch2", "corpus": "corpus1",
                     "segment": {"start": 3, "span": 6}},
            "a1c2": {"architecture": "arch1", "corpus": "corpus2",
                     "segment": {"start": 2, "span": 4}},
            "a2c2": {"architecture": "arch2", "corpus": "corpus2",
                     "segment": {"start": 3, "span": 6}},
        },
        "architectures": {"arch1": ARCH1, "arch2": ARCH2},
        "corpora": {
            "corpus1": {"path": "data/raw/tinyshakespeare.txt", "sha256": CORPUS1_SHA,
                        "corpus_split_digest": CORPUS1_SPLIT_DIGEST},
            "corpus2": {"path": "data/raw/war_and_peace.txt", "sha256": CORPUS2_SHA,
                        "corpus_split_digest": corpus2_digest},
        },
        "fixed": fixed,
        "boundary": {"width": 256, "q_bits": 8,
                     "note": "frontier-plateau point from P2/P2b"},
        "factors": {
            "remote_mode": ["trained", "frozen_random"],
            "seed": SEEDS,
        },
        "controls": {"all_local": {}, "removed_remote": {"width": "high", "q_bits": 8}},
        "pairing": {
            "block_id": "pb-p3-{seed}",
            "shared_encoder_decoder_initialization": True,
            "shared_minibatch_order": True,
            "shared_trusted_random_streams": True,
            "only_remote_parameter_updates_differ": True,
        },
        "confirmatory_rule": {
            "inferential_unit": "independent_training_run_seed",
            "pairing": "per-seed paired contrast trained vs frozen_random within block "
                       "pb-p3-{seed}",
            "primary": {
                "setting": "a2c2",
                "test": "one_sided_paired_t_test_over_8_seeds on G_R at step 2000",
                "alpha": 0.05,
                "replicate_if": "p < 0.05 AND mean G_R >= 0.01 nats AND mean G_R > 0 at "
                                "steps 1800/1900/2000 (persistence)",
            },
            "secondary": {
                "settings": ["a2c1", "a1c2"],
                "alpha": 0.025,
                "note": "same gates as primary, Bonferroni over 2 secondary settings",
            },
            "descriptive": ["delta_u_per_setting", "removed_remote_reference_per_setting",
                            "downstream_probe_accuracy_gaps", "cross_setting_sign_and_magnitude"],
            "downstream": {
                "probes": "multinomial logistic from final-layer hidden states of A2C2 "
                          "trained and all_local final checkpoints",
                "properties": ["is_uppercase_letter", "is_vowel", "is_digit", "is_whitespace"],
                "train_stream": "train-split batches, label downstream-train, seed per run",
                "eval_stream": "held-out batches, label downstream-eval, seed per run",
                "reported": "per-seed held-out accuracy per property per mode and the "
                            "trained - all_local gap with seed-level 95% CI",
                "gated": False,
            },
            "missing_data": "at most one retry per run with identical cell identity; a seed "
                            "missing a pair member is dropped from that setting's paired "
                            "tests (predeclared, never outcome-based)",
        },
        "failure_policy": {
            "operational_failure_classes": ["device_error", "out_of_memory", "io_error",
                                            "schema_validation_error"],
            "max_retries": 1,
            "rule": "Failures are recorded with manifest status operational_failure and "
                    "partial artifacts; never excluded based on outcome.",
        },
        "notes": [
            "The remote surrogate block at width 256 with head_dim 32 applies unchanged in "
            "arch2 even though d_model differs (192): the trusted encoder maps 192 -> 256 and "
            "the decoder 256 -> 192 (src/pcr/split.py RemotePath); width > d_model is "
            "structurally supported.",
            "corpus1 corpus_split_digest is the pre-existing frozen value used by all prior "
            "configs; its original derivation predates this study and is not recoverable "
            "from the repo, so it is kept unchanged. The corpus2 corpus_split_digest is "
            "DEFINED as sha256( rule.encode('utf-8') || corpus_bytes ) with rule = "
            "'first_90_percent_train_last_10_percent_heldout_by_byte_offset'; computed by "
            "scripts/make_replication_config.py.",
            "Final checkpoints (final_state.pt) are saved only for A2C2 trained and "
            "all_local runs (save_final_state flag; additive, no effect on training "
            "semantics, RNG consumption, or logging).",
            "Privacy: the boundary (width 256, q=8) was scored in P2/P2b; no new privacy "
            "evaluation in P3; the scope omission (token-inversion family only) still "
            "applies wherever P3 results are cited.",
            "No pooling across settings or with prior protocols; cross-setting consistency "
            "is reported descriptively (sign and magnitude pattern).",
            "Timing is logged for systems accounting only and enters no privacy claim.",
        ],
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-config", default=str(pc.DEFAULT_CONFIRMATORY_MATRIX_PATH))
    parser.add_argument("--output", default=str(DEFAULT_OUT))
    args = parser.parse_args(argv)

    corpus1 = ROOT / "data" / "raw" / "tinyshakespeare.txt"
    corpus2 = ROOT / "data" / "raw" / "war_and_peace.txt"
    for path, expected in ((corpus1, CORPUS1_SHA), (corpus2, CORPUS2_SHA)):
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != expected:
            raise SystemExit(
                f"STOP: {path} sha256 mismatch: expected {expected}, found {actual}. "
                f"Frozen preregistration names a different corpus file; report this.")

    source = pc.load_matrix_forgiving(args.source_config)
    fixed = dict(source["fixed"])
    fixed.pop("corpus", None)  # per-setting corpora live under settings/corpora
    fixed.pop("corpus_sha256", None)
    fixed.pop("corpus_split_digest", None)
    fixed["corpus_split"] = {"rule": SPLIT_RULE, "train_fraction": 0.9}

    config = build_config(fixed, corpus2_split_digest(corpus2))
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    text = yaml.safe_dump(config, sort_keys=False, allow_unicode=True, width=100)
    out.write_text(text)
    reloaded = yaml.safe_load(text)
    assert reloaded["protocol_version"] == "p3-replication-1.0"
    print(f"wrote {out}")
    print(f"corpus2 split digest (defined, see notes): {config['corpora']['corpus2']['corpus_split_digest']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
