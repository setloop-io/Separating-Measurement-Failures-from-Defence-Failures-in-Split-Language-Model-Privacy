#!/usr/bin/env python3
"""P2 confirmatory analysis — implements the frozen confirmatory_rule of
experiments/configs/confirmatory_matrix.yaml verbatim (protocol
p2-confirmatory-1.0; docs/PREREGISTRATION.md).

Discovery: completed confirmatory runs from manifests (cohort="confirmatory",
protocol_version="p2-confirmatory-1.0" required on cell-run manifests);
missing/failed runs are reported as operational failures. Frozen missing-data
rule: a seed missing a trained/frozen pair member is dropped from that cell's
paired test (predeclared, never outcome-based).

Contrasts per seed and span x width cell:
  G_R     = eval_loss(frozen_random) - eval_loss(trained)   at step 2000
  Delta_U = eval_loss(trained) - eval_loss(all_local)
  removed-remote reference = eval_loss(removed_remote) - eval_loss(all_local) per span

Decision rules (values read from the frozen config, not hardcoded here):
  * primary family (medium-high, long-high): one-sided paired t-test over the
    8 seeds; confirm iff p < 0.025 AND mean G_R >= 0.01 nats AND mean G_R > 0
    at eval steps 1800, 1900, 2000 (persistence). Mean/SD/t/df/p/95% CI reported.
  * secondary family (short-low, short-high, medium-low, long-low): two-sided
    paired t-tests at alpha 0.0125 (Bonferroni over 4).
  * interaction: balanced two-way ANOVA on seed-level G_R, span(3) x width(2).
  * sensitivity: Wilcoxon signed-rank per primary cell (reported, not gated).
  * privacy: token-inversion advantage <= 0.02 per cell (width-matched
    calibration); H5 support iff any primary-confirmed cell is privacy-passing.
  * resources: nonzero remote FLOPs and bytes in trained runs.

Statistics are implemented from scratch in scripts/stats_utils.py (t/F CDFs
via the regularized incomplete beta function; no scipy) and validated against
textbook reference values in tests/test_confirmatory.py.

Outputs: outputs/confirmatory/confirmatory_analysis.json,
outputs/confirmatory/confirmatory_summary.md, and
paper/figures/confirmatory_learning_curves.png (if matplotlib is available).

Usage (after scripts/run_confirmatory.py finishes):
  .venv/bin/python scripts/analyze_confirmatory.py
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path
from statistics import mean

sys.path.insert(0, str(Path(__file__).resolve().parent))  # pilot_common, stats_utils, analyze_pilot

import pilot_common as pc  # noqa: E402
import stats_utils as su  # noqa: E402
from analyze_pilot import _fmt, collect_run, make_figure  # noqa: E402

DEFAULT_FIGURE_PATH = pc.REPO_ROOT / "paper" / "figures" / "confirmatory_learning_curves.png"


# --------------------------------------------------------------------------- #
# contrasts
# --------------------------------------------------------------------------- #
def build_cells(records: dict[str, dict], matrix: dict) -> tuple[dict, dict]:
    """Per span x width cell: per-seed G_R (final + by step), Delta_U, drops.

    Returns (cells, meta) where meta carries the eval-step grid actually found.
    """
    spans = list(matrix["factors"]["segment_span"].keys())
    widths = list(matrix["factors"]["latent_width"].keys())
    seeds = matrix["factors"]["seed"]
    cells: dict[str, dict] = {}
    final_step_seen, persistence_steps_seen = None, []
    for span in spans:
        for width in widths:
            key = pc.cell_key(span, width)
            gains_by_seed: dict[str, dict] = {}
            dropped: list[int] = []
            for s in seeds:
                trained = records.get(pc.expected_run_id("trained", s, span, width))
                frozen = records.get(pc.expected_run_id("frozen_random", s, span, width))
                if trained is None or frozen is None:
                    dropped.append(s)  # frozen missing-data rule: drop the seed
                    continue
                shared = sorted(set(trained["eval_series"]) & set(frozen["eval_series"]))
                by_step = {st: frozen["eval_series"][st] - trained["eval_series"][st]
                           for st in shared}
                gains_by_seed[str(s)] = {"by_step": by_step, "final": by_step[max(shared)]}
            eval_steps = sorted({st for g in gains_by_seed.values() for st in g["by_step"]})
            if not eval_steps:
                cells[key] = {"span": span, "width": width, "status": "no_paired_seeds",
                              "seeds_used": [], "dropped_seeds": dropped}
                continue
            final_step = max(eval_steps)
            persistence_steps = eval_steps[-3:]
            final_step_seen = final_step
            persistence_steps_seen = persistence_steps
            final_gains = {s: g["by_step"][final_step] for s, g in gains_by_seed.items()
                           if final_step in g["by_step"]}
            mean_gain_by_step = {}
            for st in persistence_steps:
                values = [g["by_step"][st] for g in gains_by_seed.values() if st in g["by_step"]]
                mean_gain_by_step[str(st)] = mean(values) if values else None
            delta_u = {}
            for s in seeds:
                trained = records.get(pc.expected_run_id("trained", s, span, width))
                local = records.get(pc.expected_run_id("all_local", s))
                if trained is None or local is None or final_step not in local["eval_series"]:
                    delta_u[str(s)] = None
                else:
                    delta_u[str(s)] = (trained["eval_series"].get(final_step)
                                       - local["eval_series"][final_step])
            cells[key] = {
                "span": span, "width": width, "status": "ok",
                "seeds_used": sorted(int(s) for s in final_gains),
                "dropped_seeds": dropped,
                "final_step": final_step,
                "persistence_steps": persistence_steps,
                "gains_by_seed": gains_by_seed,
                "final_gains": final_gains,
                "mean_gain_by_step": mean_gain_by_step,
                "delta_u_by_seed": delta_u,
            }
    meta = {"final_step": final_step_seen, "persistence_steps": persistence_steps_seen}
    return cells, meta


def removed_remote_reference(records: dict[str, dict], matrix: dict) -> dict:
    refs: dict[str, dict] = {}
    for span in matrix["factors"]["segment_span"]:
        per_seed = {}
        for s in matrix["factors"]["seed"]:
            removed = records.get(pc.expected_run_id("removed_remote", s, span=span))
            local = records.get(pc.expected_run_id("all_local", s))
            if not removed or not local:
                per_seed[str(s)] = None
                continue
            step = removed["final_step"]
            per_seed[str(s)] = (removed["eval_series"][step] - local["eval_series"][step]
                                if step in local["eval_series"] else None)
        refs[span] = per_seed
    return refs


# --------------------------------------------------------------------------- #
# frozen decision rules
# --------------------------------------------------------------------------- #
def evaluate_primary_cell(cell: dict, primary_rule: dict) -> dict:
    """confirm iff p < alpha_per_cell AND mean G_R >= threshold AND persistence."""
    alpha = float(primary_rule["alpha_per_cell"])
    threshold = float(primary_rule["practical_effect_threshold_nats"])
    gains = [cell["final_gains"][s] for s in
             sorted(cell["final_gains"], key=lambda x: int(x))]
    test = su.paired_t_test(gains, alternative="greater")
    persistence_pass = bool(cell["mean_gain_by_step"]) and all(
        v is not None and v > 0 for v in cell["mean_gain_by_step"].values()
    )
    p_pass = test["p"] is not None and test["p"] < alpha
    magnitude_pass = test["mean"] is not None and test["mean"] >= threshold
    confirmed = bool(p_pass and magnitude_pass and persistence_pass)
    failed = []
    if not p_pass:
        failed.append("p_value")
    if not magnitude_pass:
        failed.append("practical_effect_threshold")
    if not persistence_pass:
        failed.append("persistence")
    return {"t_test": test, "alpha": alpha, "practical_effect_threshold": threshold,
            "p_pass": p_pass, "magnitude_pass": magnitude_pass,
            "persistence_pass": persistence_pass, "persistence_mean_gains": cell["mean_gain_by_step"],
            "confirmed": confirmed, "failed_conditions": failed,
            "verdict": "CONFIRMED" if confirmed else "NOT CONFIRMED"}


def evaluate_secondary_cell(cell: dict, secondary_rule: dict) -> dict:
    alpha = float(secondary_rule["alpha_per_cell"])
    gains = [cell["final_gains"][s] for s in
             sorted(cell["final_gains"], key=lambda x: int(x))]
    test = su.paired_t_test(gains, alternative="two-sided")
    significant = test["p"] is not None and test["p"] < alpha
    return {"t_test": test, "alpha": alpha, "significant": significant}


# --------------------------------------------------------------------------- #
# privacy
# --------------------------------------------------------------------------- #
def cell_privacy(scored_runs: list[dict], threshold: float) -> dict:
    """Frozen privacy criterion for one cell: every width-matched scored trained
    run must show token-inversion advantage <= threshold.

    scored_runs: per-seed records for the cell's trained runs from
    privacy_scores.json (may contain None for missing runs).
    """
    present = [r for r in scored_runs if r]
    scored = [r for r in present if r.get("advantage") is not None]
    matched = [r for r in scored if r.get("calibration_width") == r.get("width_dim")]
    mismatched = [r for r in scored if r.get("calibration_width") != r.get("width_dim")]
    advantages = {str(r["seed"]): r["advantage"] for r in matched}
    cell_max = max(advantages.values()) if advantages else None
    if mismatched:
        status = "width_mismatch"
    elif not matched:
        status = "not_scored"
    else:
        status = "scored"
    privacy_pass = status == "scored" and cell_max is not None and cell_max <= threshold
    return {"status": status, "threshold": threshold,
            "advantages_by_seed": advantages,
            "mismatched_runs": [r.get("run_id") for r in mismatched],
            "cell_advantage_max": cell_max, "pass": privacy_pass}


def load_privacy_scores(path: Path, autoscore: bool, args) -> tuple[dict | None, str]:
    if path.is_file():
        return pc.load_json(path), str(path)
    if not autoscore:
        return None, f"{path} missing and autoscore disabled"
    scorer = Path(__file__).resolve().parent / "score_privacy.py"
    cmd = [sys.executable, str(scorer), "--config", args.config,
           "--output-root", args.output_root, "--manifest-dir", args.manifest_dir,
           "--output", str(path)]
    print(f"privacy scores missing; running {' '.join(cmd)}")
    proc = subprocess.run(cmd, check=False)
    if proc.returncode != 0 or not path.is_file():
        return None, f"score_privacy.py failed (exit {proc.returncode})"
    return pc.load_json(path), f"{path} (generated by score_privacy.py)"


# --------------------------------------------------------------------------- #
# markdown
# --------------------------------------------------------------------------- #
def render_markdown(analysis: dict) -> str:
    lines = [
        "# P2 confirmatory analysis (protocol p2-confirmatory-1.0)",
        "",
        f"> {pc.CONFIRMATORY_NOTE}",
        "",
    ]
    repair = analysis.get("config_load_repair")
    if repair:
        lines += [f"> WARNING: frozen config needed a notes-prose repair to parse "
                  f"({repair['scope']}).", ""]
    verdicts = analysis["verdicts"]
    lines += ["## Verdicts", ""]
    for cell, verdict in verdicts["primary"].items():
        lines.append(f"- primary cell `{cell}`: **{verdict}**")
    lines.append(f"- H5 (feasible privacy-conditioned frontier): "
                 f"**{'SUPPORTED' if verdicts['h5_supported'] else 'NOT SUPPORTED'}**")
    lines.append(f"- remote resource accounting nonzero in trained runs: "
                 f"**{'yes' if verdicts['resources_nonzero'] else 'no'}**")
    lines.append("")

    lines += [
        "## Primary family (one-sided paired t-test, Bonferroni alpha 0.025 per cell)",
        "",
        "| Cell | n | dropped seeds | mean G_R | SD | t | df | p (one-sided) | 95% CI | mean>=0.01 | persistence | Verdict |",
        "|---|---:|---|---:|---:|---:|---:|---:|---|---|---|---|",
    ]
    for cell, res in analysis["primary_family"].items():
        t = res["t_test"]
        ci = f"[{_fmt(t['ci95_low'])}, {_fmt(t['ci95_high'])}]"
        lines.append(
            f"| {cell} | {t['n']} | {analysis['cells'][cell].get('dropped_seeds') or 'none'}"
            f" | {_fmt(t['mean'])} | {_fmt(t['sd'])} | {_fmt(t['t'])} | {t['df']}"
            f" | {_fmt(t['p'], 5)} | {ci} | {'yes' if res['magnitude_pass'] else 'no'}"
            f" | {'yes' if res['persistence_pass'] else 'no'} | **{res['verdict']}** |"
        )

    lines += [
        "",
        "## Secondary family (two-sided paired t-test, Bonferroni alpha 0.0125 per cell)",
        "",
        "| Cell | n | mean G_R | SD | t | df | p (two-sided) | 95% CI | significant |",
        "|---|---:|---:|---:|---:|---:|---:|---|---|",
    ]
    for cell, res in analysis["secondary_family"].items():
        t = res["t_test"]
        ci = f"[{_fmt(t['ci95_low'])}, {_fmt(t['ci95_high'])}]"
        lines.append(
            f"| {cell} | {t['n']} | {_fmt(t['mean'])} | {_fmt(t['sd'])} | {_fmt(t['t'])}"
            f" | {t['df']} | {_fmt(t['p'], 5)} | {ci} | {'yes' if res['significant'] else 'no'} |"
        )

    anova = analysis["interaction_anova"]
    lines += ["", "## Span x width interaction (two-way ANOVA on seed-level G_R)", ""]
    if anova.get("balanced"):
        lines += ["| Factor | SS | df | MS | F | p |", "|---|---:|---:|---:|---:|---:|"]
        for name, label in (("factor_a", "span"), ("factor_b", "width"),
                            ("interaction", "span x width")):
            row = anova[name]
            lines.append(f"| {label} | {_fmt(row['ss'], 6)} | {row['df']} | {_fmt(row['ms'], 6)}"
                         f" | {_fmt(row['F'], 4)} | {_fmt(row['p'], 5)} |")
        err = anova["error"]
        lines.append(f"| error | {_fmt(err['ss'], 6)} | {err['df']} | {_fmt(err['ms'], 6)} | | |")
    else:
        lines.append(f"- not computed: {anova.get('note')}")

    lines += [
        "",
        "## Wilcoxon signed-rank sensitivity (primary cells; reported, not gated)",
        "",
        "| Cell | n | W+ | z | p (one-sided) | note |",
        "|---|---:|---:|---:|---:|---|",
    ]
    for cell, w in analysis["wilcoxon"].items():
        lines.append(f"| {cell} | {w['n']} | {_fmt(w.get('w_plus'), 2)} | {_fmt(w.get('z'), 3)}"
                     f" | {_fmt(w.get('p_one_sided'), 5)} | {w.get('note', '')} |")

    seeds = analysis["seeds"]
    lines += [
        "",
        "## Per-seed causal gain G_R at the final step",
        "",
        "| Cell | " + " | ".join(f"s{s}" for s in seeds) + " |",
        "|---|" + "---:|" * len(seeds),
    ]
    for cell, c in analysis["cells"].items():
        if c.get("status") != "ok":
            lines.append(f"| {cell} | " + " | ".join("-" for _ in seeds) + " |")
            continue
        lines.append(f"| {cell} | " + " | ".join(
            _fmt(c["final_gains"].get(str(s))) if str(s) in c["final_gains"] else "DROP"
            for s in seeds) + " |")

    lines += [
        "",
        "## Replacement penalty Delta_U = L(trained) - L(all_local), final step",
        "",
        "| Cell | " + " | ".join(f"s{s}" for s in seeds) + " |",
        "|---|" + "---:|" * len(seeds),
    ]
    for cell, c in analysis["cells"].items():
        if c.get("status") != "ok":
            continue
        lines.append(f"| {cell} | " + " | ".join(
            _fmt(c["delta_u_by_seed"].get(str(s))) for s in seeds) + " |")

    lines += [
        "",
        "## Removed-remote reference: L(removed) - L(all_local), final step",
        "",
        "| Span | " + " | ".join(f"s{s}" for s in seeds) + " |",
        "|---|" + "---:|" * len(seeds),
    ]
    for span, per_seed in analysis["removed_remote_reference"].items():
        lines.append(f"| {span} | " + " | ".join(
            _fmt(per_seed.get(str(s))) for s in seeds) + " |")

    privacy = analysis["privacy"]
    lines += [
        "",
        "## Privacy: token-inversion advantage (width-matched calibration; threshold 0.02)",
        "",
        f"source: {privacy.get('source')}; instruments qualified by width: "
        f"{privacy.get('instrument_qualified_by_width')}",
        "",
        "| Cell | status | per-seed advantage | cell max | pass |",
        "|---|---|---|---:|---|",
    ]
    for cell, p in privacy["per_cell"].items():
        advs = ", ".join(f"s{s}:{v:+.4f}" for s, v in sorted(p["advantages_by_seed"].items(),
                                                             key=lambda kv: int(kv[0])))
        lines.append(f"| {cell} | {p['status']} | {advs or '-'} | {_fmt(p['cell_advantage_max'])}"
                     f" | {'yes' if p['pass'] else 'no'} |")

    lines += [
        "",
        "## Remote resource accounting (trained runs)",
        "",
        "| Run | fwd FLOPs | fwd+bwd FLOPs | bytes | bits/token | wall (s) | nonzero |",
        "|---|---:|---:|---:|---:|---:|---|",
    ]
    for row in analysis["resources"]["per_run"]:
        lines.append(f"| {row['run_id']} | {row['fwd_only_flops']} | {row['fwd_bwd_flops']}"
                     f" | {row['bytes_total']} | {_fmt(row.get('bits_per_token_total'), 1)}"
                     f" | {_fmt(row['wall_time_seconds'], 1)} | {row['nonzero']} |")

    lines += ["", "## Operational failures", ""]
    if analysis["operational_failures"]:
        for failure in analysis["operational_failures"]:
            lines.append(f"- `{failure['run_id']}`: {failure['reason']}")
    else:
        lines.append("- none")
    if analysis["non_pilot_manifests_ignored"]:
        lines += ["", "## Manifests outside the confirmatory enumeration (ignored)", ""]
        lines.append(f"- {len(analysis['non_pilot_manifests_ignored'])} manifests "
                     "(pilot cohort, smoke, calibration reuse, ...)")
    lines.append("")
    return "\n".join(lines)


# --------------------------------------------------------------------------- #
# main
# --------------------------------------------------------------------------- #
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(pc.DEFAULT_CONFIRMATORY_MATRIX_PATH))
    parser.add_argument("--output-root", default=str(pc.DEFAULT_CONFIRMATORY_OUTPUT_ROOT))
    parser.add_argument("--manifest-dir", default=str(pc.DEFAULT_MANIFEST_DIR))
    parser.add_argument("--privacy-scores", default=None,
                        help="default: <output-root>/privacy_scores.json")
    parser.add_argument("--analysis-path", default=None,
                        help="default: <output-root>/confirmatory_analysis.json")
    parser.add_argument("--summary-path", default=None,
                        help="default: <output-root>/confirmatory_summary.md")
    parser.add_argument("--figure-path", default=str(DEFAULT_FIGURE_PATH))
    parser.add_argument("--no-figure", action="store_true")
    parser.add_argument("--no-autoscore", action="store_true")
    args = parser.parse_args(argv)

    output_root = Path(args.output_root)
    analysis_path = (Path(args.analysis_path) if args.analysis_path
                     else output_root / "confirmatory_analysis.json")
    summary_path = (Path(args.summary_path) if args.summary_path
                    else output_root / "confirmatory_summary.md")
    privacy_path = (Path(args.privacy_scores) if args.privacy_scores
                    else output_root / "privacy_scores.json")

    matrix = pc.load_matrix_forgiving(args.config)
    rule = matrix["confirmatory_rule"]
    if matrix.get("_config_load_repair"):
        print(f"WARNING: frozen config required a notes-prose repair to parse; "
              f"machine-consumed sections unaffected ({matrix['_config_load_repair']['scope']}).")

    expected = pc.expected_pilot_runs(matrix)
    manifests, unreadable = pc.scan_manifests(args.manifest_dir)
    completed, failures, extras = pc.classify_runs(
        expected, manifests, unreadable,
        required_manifest_fields={"cohort": "confirmatory",
                                  "protocol_version": matrix["protocol_version"]},
    )

    records: dict[str, dict] = {}
    for entry in completed:
        if entry["cohort"] == "calibration":
            continue  # calibration artifacts feed score_privacy.py, not the curves
        record, error = collect_run(output_root, entry)
        if error:
            failures.append({"run_id": entry["run_id"], "mode": entry["mode"],
                             "seed": entry["seed"], "reason": error})
        else:
            records[entry["run_id"]] = record

    cells, meta = build_cells(records, matrix)
    refs = removed_remote_reference(records, matrix)

    primary_results = {}
    for cell_key in rule["primary_family"]["cells"]:
        cell = cells.get(cell_key)
        if not cell or cell.get("status") != "ok":
            primary_results[cell_key] = {"confirmed": False, "verdict": "NOT CONFIRMED",
                                         "failed_conditions": ["no_paired_data"],
                                         "t_test": su.paired_t_test([], "greater"),
                                         "alpha": rule["primary_family"]["alpha_per_cell"],
                                         "persistence_mean_gains": {}}
            continue
        primary_results[cell_key] = evaluate_primary_cell(cell, rule["primary_family"])

    secondary_results = {}
    for cell_key in rule["secondary_family"]["cells"]:
        cell = cells.get(cell_key)
        if not cell or cell.get("status") != "ok":
            secondary_results[cell_key] = {"significant": False,
                                           "t_test": su.paired_t_test([], "two-sided"),
                                           "alpha": rule["secondary_family"]["alpha_per_cell"]}
            continue
        secondary_results[cell_key] = evaluate_secondary_cell(cell, rule["secondary_family"])

    # interaction ANOVA on seed-level G_R (balanced design required)
    spans = list(matrix["factors"]["segment_span"].keys())
    widths = list(matrix["factors"]["latent_width"].keys())
    cell_values = {}
    for span in spans:
        for width in widths:
            cell = cells[pc.cell_key(span, width)]
            if cell.get("status") == "ok":
                cell_values[(span, width)] = [cell["final_gains"][s] for s in
                                              sorted(cell["final_gains"], key=int)]
    try:
        anova = su.two_way_anova_balanced(cell_values, spans, widths)
        anova["balanced"] = True
    except ValueError as exc:
        anova = {"balanced": False, "note": str(exc)}

    wilcoxon = {}
    for cell_key in rule["primary_family"]["cells"]:
        cell = cells.get(cell_key)
        gains = ([cell["final_gains"][s] for s in sorted(cell["final_gains"], key=int)]
                 if cell and cell.get("status") == "ok" else [])
        wilcoxon[cell_key] = su.wilcoxon_signed_rank(gains)

    # privacy (auto-invokes the scorer when the scores file is missing)
    privacy_scores, privacy_detail = load_privacy_scores(privacy_path, not args.no_autoscore, args)
    if privacy_scores is None:
        print(f"WARNING: privacy scores unavailable: {privacy_detail}")
    threshold = float(rule["privacy_criterion"]["threshold_advantage"])
    scored_runs = (privacy_scores or {}).get("runs", {})
    privacy_per_cell = {}
    for span in spans:
        for width in widths:
            key = pc.cell_key(span, width)
            run_records = []
            for s in matrix["factors"]["seed"]:
                record = scored_runs.get(pc.expected_run_id("trained", s, span=span, width=width))
                if record is not None:
                    record = {**record, "run_id": pc.expected_run_id("trained", s, span=span,
                                                                     width=width)}
                run_records.append(record)
            privacy_per_cell[key] = cell_privacy(run_records, threshold)
    qualified_by_width = {w: i.get("qualified")
                          for w, i in (privacy_scores or {}).get("instruments", {}).items()}
    if not qualified_by_width and privacy_scores and privacy_scores.get("instrument"):
        qualified_by_width = {"(single)": privacy_scores["instrument"].get("qualified")}
    confirmed_cells = [c for c, r in primary_results.items() if r.get("confirmed")]
    h5_supported = any(privacy_per_cell[c]["pass"] for c in confirmed_cells)

    # resource accounting in trained runs
    resource_rows = []
    for run_id in sorted(records):
        r = records[run_id]
        if r["mode"] != "trained":
            continue
        flops = r["cumulative_remote_flops"]
        ok = (flops.get("fwd_only", 0) > 0 and flops.get("fwd_bwd", 0) > 0
              and r["cumulative_bytes_total"] > 0)
        resource_rows.append({"run_id": run_id, "cell": pc.cell_key(r["span"], r["width"]),
                              "seed": r["seed"], "fwd_only_flops": flops.get("fwd_only", 0),
                              "fwd_bwd_flops": flops.get("fwd_bwd", 0),
                              "bytes_total": r["cumulative_bytes_total"],
                              "bits_per_token_total": r.get("bits_per_token_total"),
                              "wall_time_seconds": r["wall_time_seconds"], "nonzero": ok})
    resources_pass = bool(resource_rows) and all(row["nonzero"] for row in resource_rows)

    verdicts = {
        "primary": {c: r["verdict"] for c, r in primary_results.items()},
        "h5_supported": h5_supported,
        "resources_nonzero": resources_pass,
    }

    analysis = {
        "note": pc.CONFIRMATORY_NOTE,
        "protocol_version": matrix.get("protocol_version"),
        "config": args.config,
        "config_load_repair": matrix.get("_config_load_repair"),
        "confirmatory_rule": rule,
        "seeds": matrix["factors"]["seed"],
        "final_step": meta["final_step"],
        "persistence_steps": meta["persistence_steps"],
        "runs": records,
        "cells": cells,
        "removed_remote_reference": refs,
        "primary_family": primary_results,
        "secondary_family": secondary_results,
        "interaction_anova": anova,
        "wilcoxon": wilcoxon,
        "privacy": {
            "source": privacy_detail,
            "threshold": threshold,
            "per_cell": privacy_per_cell,
            "instrument_qualified_by_width": qualified_by_width,
        },
        "resources": {"per_run": resource_rows, "pass": resources_pass},
        "operational_failures": sorted(failures, key=lambda f: f["run_id"]),
        "non_pilot_manifests_ignored": extras,
        "verdicts": verdicts,
    }
    analysis_path.parent.mkdir(parents=True, exist_ok=True)
    analysis_path.write_text(json.dumps(analysis, indent=2, sort_keys=True))
    summary_path.write_text(render_markdown(analysis))

    print(render_markdown(analysis))
    print(f"wrote {analysis_path}")
    print(f"wrote {summary_path}")
    for cell, verdict in verdicts["primary"].items():
        print(f"VERDICT primary cell {cell}: {verdict}")
    print(f"VERDICT H5: {'SUPPORTED' if h5_supported else 'NOT SUPPORTED'}")

    if not args.no_figure:
        if records:
            make_figure(records, matrix, Path(args.figure_path))
        else:
            print("no completed runs; skipping figure")
    return 0


if __name__ == "__main__":
    sys.exit(main())
