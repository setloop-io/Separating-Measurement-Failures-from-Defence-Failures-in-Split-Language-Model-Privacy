#!/usr/bin/env python3
"""Run the frozen P1 pilot matrix: 48 exploratory runs + 1 calibration run.

Enumeration (per experiments/configs/pilot_matrix.yaml):
  * 3 all_local            (one per seed)
  * 9 removed_remote       (per seed x span, width per controls section)
  * 36 trained/frozen_random (per seed x span x width)
  * 1 calibration run      (seed 909, for the privacy positive control)

Resume skips require verified artifacts, configuration, output path and retained
execution source. Unverifiable legacy evidence is preserved and stops execution.
Runs execute sequentially. This script does not itself make any
scientific claim; outputs are exploratory-cohort artifacts.

Usage:
  .venv/bin/python scripts/run_pilot.py            # execute remaining runs
  .venv/bin/python scripts/run_pilot.py --dry-run  # enumerate and verify; never train

Prospective preservation rule: existing incomplete/unverifiable evidence stops
execution and is never overwritten by an automatic retry. A separate execution
identity/output directory is required after such a failure. Use --manifest-dir
with --output-root to keep a new execution separate from the original records.

"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from pcr import manifest as manifest_state  # noqa: E402
from pcr.manifest import ManifestVerificationError, completed_manifest_exists, report_resume_status, write_manifest  # noqa: E402
from pcr.run_experiment import DEFAULT_MATRIX, enumerate_pilot_runs, load_matrix  # noqa: E402
from pcr.train import run_cell  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(DEFAULT_MATRIX))
    parser.add_argument("--output-root")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--manifest-dir", help="separate manifest namespace for a new execution; requires fresh outputs")
    args = parser.parse_args()
    if args.manifest_dir:
        manifest_state.MANIFEST_DIR = Path(args.manifest_dir).resolve()

    matrix = load_matrix(args.config)
    if matrix.get("protocol_status") != "frozen_for_pilot":
        raise SystemExit("pilot matrix is not frozen_for_pilot; refusing to run")
    runs = enumerate_pilot_runs(matrix, output_root=args.output_root)

    print(f"enumerated {len(runs)} runs (48 pilot cells + 1 calibration)")
    if args.dry_run:
        return report_resume_status(runs)
    done, failed = 0, 0
    for index, resolved in enumerate(runs, start=1):
        run_id = resolved["run_id"]
        if completed_manifest_exists(run_id, resolved=resolved):
            print(f"[{index}/{len(runs)}] skip {run_id} (artifacts and execution identity verified)")
            continue
        print(
            f"[{index}/{len(runs)}] run {run_id}: mode={resolved['mode']} "
            f"seed={resolved['seed']} split={resolved['split']} steps={resolved['optim']['steps']}",
            flush=True,
        )
        t0 = time.perf_counter()
        try:
            summary = run_cell(resolved)
        except ManifestVerificationError:
            raise  # Never relabel or overwrite preserved evidence on a retry.
        except Exception as exc:  # operational failure: audit, do not retry silently
            failed += 1
            out_dir = Path(resolved["output_dir"])
            leftover = [p for p in out_dir.glob("*") if p.is_file()] if out_dir.is_dir() else []
            write_manifest(
                resolved, status="operational_failure", artifact_paths=leftover,
                captured_channels=[], extra={"failure_error": repr(exc)},
            )
            print(f"[{index}/{len(runs)}] FAILED {run_id}: {exc}", flush=True)
            continue
        done += 1
        elapsed = time.perf_counter() - t0
        print(
            f"[{index}/{len(runs)}] done {run_id}: final_eval_loss="
            f"{summary['final_eval_loss']:.4f} wall_time={elapsed:.1f}s",
            flush=True,
        )
    print(f"finished: {done} executed, {failed} failed, {len(runs) - done - failed} pre-existing")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
