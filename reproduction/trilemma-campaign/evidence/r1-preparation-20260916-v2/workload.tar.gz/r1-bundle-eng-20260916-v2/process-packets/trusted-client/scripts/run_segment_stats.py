#!/usr/bin/env python3
"""Run the frozen P2c segment-statistics matrix: 72 runs.

Enumeration (per experiments/configs/segment_stats_matrix.yaml, protocol
p2c-segment-statistics-1.0, fresh seeds [3, 13, 23, 33, 43, 53, 63, 83]):
  * 8 all_local (one per seed)
  * 64 trained  (per seed x 8 held-out segments, width 256, q_bits 8)

No frozen_random/removed_remote and no new calibration run (prereg scope
notes). Resolution uses pcr.run_experiment.resolve_cell directly: the frozen
config carries named segment levels and q_bits=8 in fixed.boundary_defense.
Pairing block id is "pb-p2c-{seed}"; cohort is "confirmatory".

Resumable via completed manifests. Historical protocol: at most ONE retry
with identical cell identity; every attempt appended to
<output-root>/run_attempts.jsonl; failures are recorded with manifest status
operational_failure and never excluded based on outcome.

Usage:
  .venv/bin/python scripts/run_segment_stats.py            # execute remaining runs
  .venv/bin/python scripts/run_segment_stats.py --dry-run  # enumerate and verify; never train

Prospective preservation rule: existing incomplete/unverifiable evidence stops
execution and is never overwritten by an automatic retry. A separate execution
identity/output directory is required after such a failure. Use --manifest-dir
with --output-root to keep a new execution separate from the original records.

"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

from pcr import manifest as manifest_state  # noqa: E402
from pcr.manifest import ManifestVerificationError, completed_manifest_exists, report_resume_status, write_manifest  # noqa: E402
from pcr.run_experiment import resolve_cell  # noqa: E402
from pcr.train import run_cell  # noqa: E402

import pilot_common as pc  # noqa: E402
from run_confirmatory import log_attempt  # noqa: E402

DEFAULT_CONFIG = ROOT / "experiments" / "configs" / "segment_stats_matrix.yaml"
DEFAULT_OUTPUT_ROOT = ROOT / "outputs" / "segment_stats"


def enumerate_segment_stats_runs(matrix: dict, output_root: str | Path) -> list[dict]:
    """Resolved configs for the 72 executable runs."""
    runs = []
    for entry in pc.expected_segment_stats_runs(matrix):
        if entry["cohort"] == "calibration":
            continue
        runs.append(resolve_cell(
            matrix, entry["mode"], entry["seed"], span=entry["span"], width=entry["width"],
            run_id=entry["run_id"], output_root=output_root,
        ))
    return runs


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument("--output-root", default=str(DEFAULT_OUTPUT_ROOT))
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--manifest-dir", help="separate manifest namespace for a new execution; requires fresh outputs")
    args = parser.parse_args()
    if args.manifest_dir:
        manifest_state.MANIFEST_DIR = Path(args.manifest_dir).resolve()

    matrix = pc.load_matrix_forgiving(args.config)
    if matrix.get("protocol_status") != "frozen_for_confirmation":
        raise SystemExit("segment-stats matrix is not frozen_for_confirmation; refusing to run")
    runs = enumerate_segment_stats_runs(matrix, args.output_root)

    print(f"enumerated {len(runs)} runs (8 all_local + 64 trained)")
    if args.dry_run:
        return report_resume_status(runs)

    output_root = Path(args.output_root)
    attempts_log = output_root / "run_attempts.jsonl"
    max_retries = 0  # immutable failures require a separately identified attempt
    done, failed, skipped = 0, 0, 0
    for index, resolved in enumerate(runs, start=1):
        run_id = resolved["run_id"]
        if completed_manifest_exists(run_id, resolved=resolved):
            print(f"[{index}/{len(runs)}] skip {run_id} (artifacts and execution identity verified)")
            skipped += 1
            continue
        succeeded = False
        for attempt in range(1, max_retries + 2):
            print(
                f"[{index}/{len(runs)}] run {run_id} (attempt {attempt}): "
                f"mode={resolved['mode']} seed={resolved['seed']} split={resolved['split']} "
                f"steps={resolved['optim']['steps']}",
                flush=True,
            )
            log_attempt(attempts_log, run_id, attempt, "start")
            t0 = time.perf_counter()
            try:
                summary = run_cell(resolved)
            except ManifestVerificationError:
                raise  # Never relabel or overwrite preserved evidence on a retry.
            except Exception as exc:  # preserve failure; a new attempt needs a new identity
                out_dir = Path(resolved["output_dir"])
                leftover = [p for p in out_dir.glob("*") if p.is_file()] if out_dir.is_dir() else []
                write_manifest(
                    resolved, status="operational_failure", artifact_paths=leftover,
                    captured_channels=[],
                    extra={"failure_error": repr(exc), "attempt": attempt,
                           "max_retries": max_retries},
                )
                log_attempt(attempts_log, run_id, attempt, "failure", repr(exc))
                print(f"[{index}/{len(runs)}] FAILED {run_id} (attempt {attempt}): {exc}",
                      flush=True)
                continue
            succeeded = True
            elapsed = time.perf_counter() - t0
            log_attempt(attempts_log, run_id, attempt, "success",
                        f"final_eval_loss={summary['final_eval_loss']:.4f}")
            print(
                f"[{index}/{len(runs)}] done {run_id}: final_eval_loss="
                f"{summary['final_eval_loss']:.4f} wall_time={elapsed:.1f}s",
                flush=True,
            )
            break
        if succeeded:
            done += 1
        else:
            failed += 1
    print(f"finished: {done} executed, {failed} failed; new attempts require new identities, {skipped} pre-existing")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
