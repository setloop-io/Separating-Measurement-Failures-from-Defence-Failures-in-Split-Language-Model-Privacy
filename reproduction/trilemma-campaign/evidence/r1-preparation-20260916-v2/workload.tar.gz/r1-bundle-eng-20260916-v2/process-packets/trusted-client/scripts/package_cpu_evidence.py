#!/usr/bin/env python3
"""Relay-verify and package a retained R1 CPU validation tree as engineering evidence."""

from __future__ import annotations

import argparse
import copy
import gzip
import io
import json
import re
import shutil
import subprocess
import tarfile
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from pcr.r1 import enumerate_runs, load_matrix
from pcr.r1_local_validation import analyze_local_validation
from pcr.utils import sha256_bytes, sha256_file

EXCLUDED_NAMES = {"__pycache__", ".pytest_cache"}
SUITE_REQUIRED = {"passed": re.compile(r"(?<!subtests )(\d+) passed"),
                  "seconds": re.compile(r"in ([0-9.]+)s")}
SUITE_OPTIONAL = {"subtests": re.compile(r"(\d+) subtests passed")}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _files(root: Path) -> list[Path]:
    return sorted(path for path in root.rglob("*")
                  if path.is_file() and not set(path.parts) & EXCLUDED_NAMES)


def _suite_stats(path: Path | None) -> dict[str, Any]:
    if path is None:
        raise ValueError("verification log is required")
    tail = path.read_text()[-4000:]
    stats: dict[str, Any] = {}
    for key, pattern in SUITE_REQUIRED.items():
        found = pattern.findall(tail)
        if not found:
            raise ValueError(f"{path.name} has no {key} result line")
        stats[key] = int(found[-1]) if key != "seconds" else float(found[-1])
    for key, pattern in SUITE_OPTIONAL.items():
        found = pattern.findall(tail)
        stats[key] = int(found[-1]) if found else 0
    return stats


def _digest(values: Any, key: str) -> str:
    value = values[key]
    if not isinstance(value, str):
        raise ValueError(f"manifest provenance field {key} is not a string")
    return value


def _aggregate(root: Path, manifests: list[Path]) -> dict[str, Any]:
    bound: dict[str, set[str]] = {
        "source_inventory_sha256": set(), "environment_digest": set(),
        "working_tree_patch_sha256": set(), "git_commit": set()}
    journal_steps, wire_mismatches, wire_total = 0, 0, 0
    remote_packets: set[str] = set()
    attack_results, walls, wires = 0, [], []
    manifests_checked = 0
    for manifest_path in manifests:
        record = json.loads(manifest_path.read_text())
        execution = record["execution_provenance"]
        for field in bound:
            bound[field].add(_digest(execution, field))
        manifests_checked += 1
        output_dir = root / "runs" / record["run_id"]
        journal = output_dir / "remote-process/remote/step-journal.jsonl"
        if journal.is_file():
            journal_steps += sum(1 for line in journal.read_text().splitlines()
                                 if json.loads(line)["status"] == "committed")
        client_audit = output_dir / "client-wire-audit.json"
        if client_audit.is_file():
            client_total = int(json.loads(client_audit.read_text())["total_bytes"])
            remote_total = int(json.loads(
                (output_dir / "remote-process/remote/remote-wire-audit.json").read_text())["total_bytes"])
            wire_mismatches += int(client_total != remote_total)
            wire_total += client_total
            wires.append(client_total)
        packet = output_dir / "remote-process/remote-root/packet.json"
        if packet.is_file():
            remote_packets.add(json.loads(packet.read_text())["inventory_sha256"])
        attack = output_dir / "attack_suite.json"
        if attack.is_file():
            attack_results += len(json.loads(attack.read_text())["results"])
        walls.append(float(json.loads((output_dir / "metrics_summary.json").read_text())["wall_time_seconds"]))
    if any(len(values) != 1 for values in bound.values()) or len(remote_packets) != 1:
        raise ValueError("retained runs bind differing source, environment, patch or remote packets")
    if manifests_checked != 14 or wire_mismatches or len(walls) != 14:
        raise ValueError("retained evidence does not present fourteen consistent bound runs")
    return {
        "bound_manifests": manifests_checked,
        "source_inventory_sha256": bound["source_inventory_sha256"].pop(),
        "environment_digest": bound["environment_digest"].pop(),
        "working_tree_patch_sha256": bound["working_tree_patch_sha256"].pop(),
        "git_commit": bound["git_commit"].pop(),
        "remote_packet_inventory_sha256": remote_packets.pop(),
        "committed_remote_steps": journal_steps,
        "client_remote_wire_total_mismatches": wire_mismatches,
        "split_wire_bytes_total": wire_total,
        "split_wire_bytes_range": [min(wires), max(wires)],
        "attack_reports": len(list(root.glob("runs/*/attack_suite.json"))),
        "attack_target_channel_results": attack_results,
        "semantic_validation_records": len(list(root.glob("runs/*/semantic_validation.json"))),
        "recorded_run_wall_seconds_total": sum(walls),
        "recorded_run_wall_seconds_range": [min(walls), max(walls)],
        "privacy_status": "ENGINEERING_ONLY",
    }


def _archive_tree(root: Path, path: Path) -> list[dict[str, Any]]:
    records = []
    with path.open("xb") as raw, gzip.GzipFile(filename="", fileobj=raw, mode="wb", mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode="w") as archive:
            for source in _files(root):
                payload = source.read_bytes()
                info = tarfile.TarInfo(source.relative_to(root).as_posix())
                info.size, info.mode, info.mtime = len(payload), 0o644, 0
                archive.addfile(info, io.BytesIO(payload))
                records.append({"path": info.name, "bytes": len(payload),
                                "mode": source.stat().st_mode & 0o777,
                                "sha256": sha256_bytes(payload)})
    return records


def _extract_and_check(archive_path: Path, records: list[dict[str, Any]]) -> None:
    with tempfile.TemporaryDirectory(prefix="r1-cpu-verify-") as scratch:
        extract = Path(scratch) / "tree"
        with tarfile.open(archive_path, "r:gz") as archive:
            archive.extractall(extract, filter="data")
        for record in records:
            path = extract / record["path"]
            if (not path.is_file() or path.stat().st_size != record["bytes"] or
                    sha256_file(str(path)) != record["sha256"]):
                raise ValueError(f"extracted evidence differs: {record['path']}")


def package(output_root: Path, evidence: Path, execution_id: str, summary: dict[str, Any]) -> dict[str, Any]:
    output_root, evidence = output_root.resolve(), evidence.resolve()
    if evidence.exists():
        raise ValueError("evidence destination already exists")
    manifests = sorted((output_root / "manifests").glob(f"*--e{execution_id}.json"))
    execution = _aggregate(output_root, manifests)
    summary.setdefault("execution", {}).update(execution)
    summary["execution"]["output_bytes_before_packaging"] = (
        sum(path.stat().st_size for path in _files(output_root)))
    summary["source"].update({
        "git_commit": execution["git_commit"],
        "working_tree_patch_sha256": execution["working_tree_patch_sha256"],
        "source_inventory_sha256": execution["source_inventory_sha256"],
        "environment_digest": execution["environment_digest"]})
    summary_path = output_root / "validation_summary.json"
    if summary_path.exists():
        raise ValueError("validation summary already exists")
    summary_path.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    evidence.mkdir(parents=True)
    archive_name = f"{evidence.name}.tar.gz"
    archive_path = evidence / archive_name
    records = _archive_tree(output_root, archive_path)
    _extract_and_check(archive_path, records)
    archive_sha256 = sha256_file(str(archive_path))
    extracted_bytes = sum(item["bytes"] for item in records)
    index = {"schema_version": "r1-cpu-evidence-index-1.0", "created_at_utc": _now(),
             "file_count": len(records), "extracted_bytes": extracted_bytes,
             "archive": {"path": archive_name, "bytes": archive_path.stat().st_size,
                         "sha256": archive_sha256},
             "scientific_evidence": False, "files": records}
    verification = {"schema_version": "r1-cpu-evidence-verification-1.0", "checked_at_utc": _now(),
                    "archive_sha256": archive_sha256, "files_checked": len(records),
                    "bytes_checked": extracted_bytes, "failures": [], "status": "verified",
                    "scientific_evidence": False}
    readme = f"""# R1 CPU systems evidence package

This package preserves the final local CPU validation of the prospective systems
implementation. It is **engineering evidence only** and cannot support an R1
scientific claim.

- Archive: `{archive_name}`
- SHA-256: `{archive_sha256}`
- Indexed files: {len(records)}
- Extracted bytes: {extracted_bytes:,}
- Compressed bytes: {archive_path.stat().st_size:,}
- Restoration verification: {len(records)}/{len(records)} files, zero failures

`index.json` binds every archived path, size, mode and SHA-256.
`verification.json` records a fresh extraction and full byte check.

The run used real Tiny Shakespeare bytes, real model training, separate trusted and
corpus-free remote processes, authenticated framed tensors, coordinated checkpoints,
semantic artifact validation and draft attacks over all 12 target/channel combinations.
It did not use a GPU, a second host, paid infrastructure, admitted scientific thresholds,
calibration, exploration, confirmation or reserved seeds.

The source was an uncommitted working revision over `{execution["git_commit"][:7]}`;
every run retains the same exact source inventory, environment and patch (inventory
digest `{execution["source_inventory_sha256"]}`). A clean reviewed commit and newly
prepared workload remain mandatory before GPU authorization.
"""
    (evidence / "README.md").write_text(readme)
    (evidence / "index.json").write_text(json.dumps(index, indent=2, sort_keys=True) + "\n")
    (evidence / "verification.json").write_text(json.dumps(verification, indent=2, sort_keys=True) + "\n")
    checksum_rows = [(name, evidence / name) for name in
                     ("README.md", "index.json", "verification.json", archive_name)]
    lines = [f"{sha256_file(str(path))}  {name}" for name, path in sorted(checksum_rows)]
    (evidence / "SHA256SUMS").write_text("\n".join(lines) + "\n")
    return {"evidence": str(evidence), "archive_sha256": archive_sha256,
            "files": len(records), "extracted_bytes": extracted_bytes,
            "status": "verified", "scientific_evidence": False}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--execution-id", required=True)
    parser.add_argument("--full-suite-log", type=Path, required=True)
    parser.add_argument("--targeted-log", type=Path, required=True)
    parser.add_argument("--container-log", type=Path, required=True)
    parser.add_argument("--container-image-spec", type=Path, required=True,
                        help="file containing '<image-id> <size-bytes>' from docker image inspect")
    parser.add_argument("--paper-pages", type=int, required=True)
    parser.add_argument("--paper-latex-warnings", type=int, required=True)
    args = parser.parse_args(argv)
    root = args.root.resolve()
    output_root = args.output_root.resolve()
    image_id, image_size = args.container_image_spec.read_text().split()
    matrix = load_matrix(root / "experiments/configs/r1_exploration.yaml")
    planned = enumerate_runs(matrix, "local_validation", output_root / "runs")
    replay = analyze_local_validation(root, output_root,
                                      copy.deepcopy(planned), args.execution_id)
    if (replay["run_count"] != replay["planned_count"] or replay["failures"] or
            replay["interrupted_runs"] or replay["not_started_runs"]):
        raise ValueError("replay verification failed; refusing to package")
    for log, name in ((args.full_suite_log, "full-test-suite.log"),
                      (args.targeted_log, "r1-targeted-tests.log"),
                      (args.container_log, "container-validation.log")):
        target = output_root / name
        if target.exists():
            raise ValueError(f"{target} already exists")
        shutil.copyfile(log, target)
    full = _suite_stats(args.full_suite_log)
    targeted = _suite_stats(args.targeted_log)
    container = _suite_stats(args.container_log)
    commit = subprocess.run(["git", "-C", str(root), "rev-parse", "HEAD"],
                            check=True, capture_output=True, text=True).stdout.strip()
    summary = {"schema_version": "r1-cpu-validation-summary-1.0",
               "status": "verified_engineering_only", "scientific_evidence": False,
               "execution_id": args.execution_id,
               "source": {"git_commit": commit, "working_tree_clean": False,
                          "note": "Every run retains the exact source archive and patch. A clean "
                                  "committed revision is still required before GPU admission."},
               "execution": {"planned_runs": replay["planned_count"],
                             "completed_runs": replay["run_count"],
                             "failures": len(replay["failures"]),
                             "interrupted_runs": len(replay["interrupted_runs"]),
                             "not_started_runs": len(replay["not_started_runs"])},
               "verification": {
                   "locked_full_suite": {"passed": full["passed"],
                                         "subtests_passed": full["subtests"],
                                         "seconds": full["seconds"], "log": "full-test-suite.log"},
                   "r1_targeted_suite": {"passed": targeted["passed"],
                                         "seconds": targeted["seconds"], "log": "r1-targeted-tests.log"},
                   "container_systems_suite": {"passed": container["passed"],
                                               "seconds": container["seconds"],
                                               "image_id": image_id,
                                               "image_size_bytes": int(image_size),
                                               "registry_digest": None,
                                               "log": "container-validation.log"},
                   "relocated_evidence_replay": {"completed_runs": replay["run_count"],
                                                 "failures": len(replay["failures"]),
                                                 "interrupted_runs": len(replay["interrupted_runs"]),
                                                 "not_started_runs": len(replay["not_started_runs"])},
                   "paper": {"pages": args.paper_pages, "latex_warnings": args.paper_latex_warnings}},
               "boundaries": {"gpu_validated": False, "two_host_validated": False,
                              "paid_execution_authorized": False,
                              "scientific_calibration_authorized": False,
                              "scientific_exploration_authorized": False, "claims_admitted": 0}}
    result = package(output_root, args.evidence, args.execution_id, summary)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
