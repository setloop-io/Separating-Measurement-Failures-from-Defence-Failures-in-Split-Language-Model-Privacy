#!/usr/bin/env python3
"""Verify fresh R1 engineering lineage and write descriptive results.

Run this copied script inside the prepared bundle. Every source, raw input,
launch, per-run manifest and result hash must verify. Privacy and joint
feasibility remain UNDETERMINED; no fresh scientific attacks are yet admitted.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from pcr.r1 import analyze_execution  # noqa: E402


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execution-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    try:
        result = analyze_execution(ROOT, args.execution_root, args.output)
        print(json.dumps({key: result[key] for key in ("completed_count", "planned_count", "privacy", "joint_feasibility")}))
        return 0
    except (ValueError, KeyError, OSError, RuntimeError) as exc:
        print(f"R1 analysis blocked: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
