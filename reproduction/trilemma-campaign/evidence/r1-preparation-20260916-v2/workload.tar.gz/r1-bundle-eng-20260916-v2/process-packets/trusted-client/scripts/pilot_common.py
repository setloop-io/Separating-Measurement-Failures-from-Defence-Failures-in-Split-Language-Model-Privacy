"""Shared discovery helpers for the P1 pilot analysis and privacy scoring.

Stdlib + yaml only (no torch) so run discovery stays light. Run-id naming
mirrors pcr.run_experiment.cell_run_id for the frozen pilot matrix:

  all_local-s{seed}
  removed_remote-{span}-s{seed}             (width fixed by the controls section)
  {trained|frozen_random}-{span}-{width}-s{seed}
  calibration-s{seed}

Everything here reads artifacts only; no pilot code is modified and no
training is launched from these scripts.
"""

from __future__ import annotations

import json
from pathlib import Path

import yaml

REPO_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_MATRIX_PATH = REPO_ROOT / "experiments" / "configs" / "pilot_matrix.yaml"
DEFAULT_CONFIRMATORY_MATRIX_PATH = REPO_ROOT / "experiments" / "configs" / "confirmatory_matrix.yaml"
DEFAULT_OUTPUT_ROOT = REPO_ROOT / "outputs" / "pilot"
DEFAULT_CONFIRMATORY_OUTPUT_ROOT = REPO_ROOT / "outputs" / "confirmatory"
DEFAULT_MANIFEST_DIR = REPO_ROOT / "experiments" / "manifests"

SPLIT_MODES = ("trained", "frozen_random", "removed_remote")

EXPLORATORY_NOTE = (
    "Exploratory-cohort analysis of the P1 pilot; hypothesis-generating only, "
    "not validated evidence for any manuscript claim."
)
CONFIRMATORY_NOTE = (
    "Confirmatory analysis under protocol p2-confirmatory-1.0 (frozen "
    "2026-09-04, fresh seeds [11..88]); per docs/PREREGISTRATION.md."
)


def load_matrix(path: str | Path = DEFAULT_MATRIX_PATH) -> dict:
    with Path(path).open() as handle:
        return yaml.safe_load(handle)


def load_matrix_forgiving(path: str | Path) -> dict:
    """Load a frozen matrix, transparently working around unparseable notes prose.

    The frozen confirmatory_matrix.yaml (2026-09-04) contains a notes entry
    (`- Power (from pilot variance): ...` continuing with a line starting
    `> 0.99`) that makes the whole file unparseable YAML: the ": " starts a
    mapping inside the sequence item and the `>` continuation is an invalid
    block-scalar header. The on-disk file is NOT modified (it is frozen).
    This loader first tries a strict parse; on failure it strict-parses
    everything before the top-level `notes:` block (all machine-consumed
    sections: fixed, factors, calibration, confirmatory_rule, failure_policy)
    and reconstructs notes as plain text lines, preserving content verbatim
    (including the ">"). If the breakage is not confined to the notes block,
    the strict error propagates. Any repair is recorded in
    matrix["_config_load_repair"] and must be surfaced in analysis outputs.
    Fixing the frozen file itself requires a versioned amendment per
    docs/PREREGISTRATION.md.
    """
    text = Path(path).read_text()
    try:
        return yaml.safe_load(text)
    except yaml.YAMLError as exc:
        head, sep, notes_block = text.partition("\nnotes:")
        if not sep:
            raise  # breakage is not in a trailing notes block; refuse to guess
        matrix = yaml.safe_load(head)  # raises if machine-consumed sections are broken
        notes: list[str] = []
        for line in notes_block.splitlines():
            stripped = line.strip()
            if stripped.startswith("- "):
                notes.append(stripped[2:])
            elif stripped and notes:
                notes[-1] += " " + stripped
        matrix["notes"] = notes
        matrix["_config_load_repair"] = {
            "reason": "frozen yaml notes prose is not parseable as YAML",
            "original_error": str(exc).splitlines()[0],
            "scope": "notes text only (parsed as plain lines, verbatim content); "
                     "on-disk frozen file untouched; machine-consumed sections "
                     "parsed strictly and unaffected",
        }
        return matrix


def calibration_entries(matrix: dict) -> list[dict]:
    """Calibration runs declared by a matrix, normalized to a list.

    Pilot shape:   calibration: {seed: 909, mode, span, width, ...}
    Confirmatory:  calibration: {width_low: {...}, width_high: {...}}
    P2b reuse references may omit mode/span/width entirely (e.g.
    ``width_high: {seed: 919, reuse: p2_confirmatory_artifact}``); those are
    normalized from the key name with trained/medium defaults so discovery
    and privacy calibration resolution work uniformly.
    """
    cal = matrix.get("calibration", {})
    if "seed" in cal:
        entries = [{"key": "default", **cal}]
    else:
        entries = [{"key": key, **value} for key, value in cal.items()]
    for entry in entries:
        if "width" not in entry and entry["key"].startswith("width_"):
            entry["width"] = entry["key"].split("width_", 1)[1]
        entry.setdefault("mode", "trained")
        entry.setdefault("span", "medium")
    return entries


def expected_run_id(mode: str, seed: int, span: str | None = None, width: str | None = None) -> str:
    """Canonical run id; must match pcr.run_experiment.cell_run_id."""
    if mode == "all_local":
        return f"all_local-s{seed}"
    if mode == "removed_remote":
        return f"removed_remote-{span}-s{seed}"
    return f"{mode}-{span}-{width}-s{seed}"


def expected_pilot_runs(matrix: dict) -> list[dict]:
    """Canonical pilot enumeration: controls + split cells + calibration run.

    Each entry: run_id, mode, span (level name or None), width (level name or
    None), seed, cohort. For the frozen matrix this is 3 all_local +
    9 removed_remote + 36 trained/frozen_random + 1 calibration = 49 runs.
    """
    seeds = matrix["factors"]["seed"]
    spans = list(matrix["factors"]["segment_span"].keys())
    widths = list(matrix["factors"]["latent_width"].keys())
    cohort = matrix.get("cohort", "exploratory")
    removed_width = matrix.get("controls", {}).get("removed_remote", {}).get("width", "low")
    runs: list[dict] = []
    for seed in seeds:
        runs.append(
            {"run_id": expected_run_id("all_local", seed), "mode": "all_local",
             "span": None, "width": None, "seed": seed, "cohort": cohort, "cell": None}
        )
    for seed in seeds:
        for span in spans:
            runs.append(
                {"run_id": expected_run_id("removed_remote", seed, span=span),
                 "mode": "removed_remote", "span": span, "width": removed_width,
                 "seed": seed, "cohort": cohort, "cell": cell_key(span, removed_width)}
            )
    for seed in seeds:
        for span in spans:
            for width in widths:
                for mode in ("trained", "frozen_random"):
                    runs.append(
                        {"run_id": expected_run_id(mode, seed, span=span, width=width),
                         "mode": mode, "span": span, "width": width,
                         "seed": seed, "cohort": cohort, "cell": cell_key(span, width)}
                    )
    for cal in calibration_entries(matrix):
        runs.append(
            {"run_id": f"calibration-s{cal['seed']}", "mode": cal["mode"],
             "span": cal["span"], "width": cal["width"], "seed": cal["seed"],
             "cohort": "calibration", "cell": None}
        )
    return runs


def load_json(path: str | Path) -> dict:
    return json.loads(Path(path).read_text())


def load_curve(run_dir: str | Path) -> list[dict]:
    """Parse curve.jsonl rows (step, eval_loss, cumulative counters, wall_time)."""
    rows = []
    with (Path(run_dir) / "curve.jsonl").open() as handle:
        for line in handle:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def scan_manifests(manifest_dir: str | Path) -> tuple[dict[str, dict], list[str]]:
    """All manifests keyed by run_id; unreadable files returned by run_id."""
    manifests: dict[str, dict] = {}
    unreadable: list[str] = []
    for path in sorted(Path(manifest_dir).glob("*.json")):
        try:
            manifests[path.stem] = json.loads(path.read_text())
        except (OSError, json.JSONDecodeError):
            unreadable.append(path.stem)
    return manifests, unreadable


def classify_runs(
    expected: list[dict],
    manifests: dict[str, dict],
    unreadable: list[str],
    required_manifest_fields: dict | None = None,
) -> tuple[list[dict], list[dict], list[str]]:
    """Split expected runs into completed entries and operational failures.

    A manifest that is missing, unreadable, or not status=="completed" is an
    operational failure (frozen failure_policy: recorded, never retried here,
    never excluded based on its outcome). Manifests outside the expected
    enumeration (e.g. smoke runs) are returned separately and ignored.

    required_manifest_fields (e.g. {"cohort": "confirmatory", ...}) is checked
    on non-calibration entries only: calibration artifacts may be reused across
    protocols (seed 909 was produced under p1-pilot-0.1).
    """
    by_id = {entry["run_id"]: entry for entry in expected}
    completed: list[dict] = []
    failures: list[dict] = []
    for entry in expected:
        run_id = entry["run_id"]
        if run_id in unreadable:
            failures.append({"run_id": run_id, "mode": entry["mode"], "seed": entry["seed"],
                             "reason": "unreadable_manifest"})
            continue
        manifest = manifests.get(run_id)
        if manifest is None:
            failures.append({"run_id": run_id, "mode": entry["mode"], "seed": entry["seed"],
                             "reason": "missing_manifest"})
        elif manifest.get("status") != "completed":
            failures.append({"run_id": run_id, "mode": entry["mode"], "seed": entry["seed"],
                             "reason": f"manifest_status:{manifest.get('status')}"})
        elif required_manifest_fields and entry["cohort"] != "calibration":
            mismatch = next(
                (k for k, v in required_manifest_fields.items() if manifest.get(k) != v), None
            )
            if mismatch:
                failures.append({"run_id": run_id, "mode": entry["mode"], "seed": entry["seed"],
                                 "reason": f"manifest_field_mismatch:{mismatch}="
                                           f"{manifest.get(mismatch)!r}"})
            else:
                completed.append(entry)
        else:
            completed.append(entry)
    extras = sorted(run_id for run_id in manifests if run_id not in by_id)
    return completed, failures, extras


def eval_series_from_curve(curve: list[dict]) -> dict[int, float]:
    """{step: eval_loss} for rows that carry an eval measurement."""
    return {int(row["step"]): float(row["eval_loss"]) for row in curve if row.get("eval_loss") is not None}


def cell_key(span: str, width: str) -> str:
    return f"{span}-{width}"


# --------------------------------------------------------------------------- #
# rate-sweep (P2b) enumeration: q_bits is a swept factor; run ids are q-qualified
# --------------------------------------------------------------------------- #
def rate_sweep_run_id(mode: str, seed: int, q_bits: int | None = None,
                      span: str = "medium", width: str = "high") -> str:
    """Run id for the P2b rate sweep; must match scripts/run_rate_sweep.py."""
    if mode == "all_local":
        return f"all_local-s{seed}"
    if mode == "removed_remote":
        return f"removed_remote-{span}-q{q_bits}-s{seed}"
    return f"{mode}-{span}-{width}-q{q_bits}-s{seed}"


def rate_sweep_cell_key(span: str, width: str, q_bits: int) -> str:
    return f"{span}-{width}-q{q_bits}"


def expected_rate_sweep_runs(matrix: dict) -> list[dict]:
    """P2b enumeration: all_local per seed; removed_remote per seed x q;
    trained/frozen_random per seed x span x width x q; plus calibration entries
    (reuse-only artifacts, enumerated for discovery, never for execution).
    For the frozen matrix: 8 + 32 + 64 = 104 cell runs + 1 calibration entry.
    """
    seeds = matrix["factors"]["seed"]
    spans = list(matrix["factors"]["segment_span"].keys())
    widths = list(matrix["factors"]["latent_width"].keys())
    q_levels = matrix["factors"]["q_bits"]
    cohort = matrix.get("cohort", "confirmatory")
    removed_width = matrix.get("controls", {}).get("removed_remote", {}).get("width", "high")
    runs: list[dict] = []
    for seed in seeds:
        runs.append({"run_id": rate_sweep_run_id("all_local", seed), "mode": "all_local",
                     "span": None, "width": None, "q_bits": None, "seed": seed,
                     "cohort": cohort, "cell": None})
    for seed in seeds:
        for span in spans:
            for q in q_levels:
                runs.append({"run_id": rate_sweep_run_id("removed_remote", seed, q, span=span),
                             "mode": "removed_remote", "span": span, "width": removed_width,
                             "q_bits": q, "seed": seed, "cohort": cohort,
                             "cell": rate_sweep_cell_key(span, removed_width, q)})
    for seed in seeds:
        for span in spans:
            for width in widths:
                for q in q_levels:
                    for mode in ("trained", "frozen_random"):
                        runs.append({"run_id": rate_sweep_run_id(mode, seed, q, span=span,
                                                                 width=width),
                                     "mode": mode, "span": span, "width": width, "q_bits": q,
                                     "seed": seed, "cohort": cohort,
                                     "cell": rate_sweep_cell_key(span, width, q)})
    for cal in calibration_entries(matrix):
        runs.append({"run_id": f"calibration-s{cal['seed']}", "mode": cal["mode"],
                     "span": cal["span"], "width": cal["width"], "q_bits": None,
                     "seed": cal["seed"], "cohort": "calibration", "cell": None})
    return runs


def expected_runs(matrix: dict) -> list[dict]:
    """Dispatch on matrix shape/study: swept q_bits factor -> rate-sweep;
    the P2c study -> segment-statistics enumeration; otherwise pilot/P2 shape."""
    if "q_bits" in (matrix.get("factors") or {}):
        return expected_rate_sweep_runs(matrix)
    if matrix.get("study") == "remote_substitutability_segment_statistics":
        return expected_segment_stats_runs(matrix)
    return expected_pilot_runs(matrix)


# --------------------------------------------------------------------------- #
# P4a calibration runs (frozen by docs/PREREGISTRATION_P4A.md; no matrix yaml —
# the ids and knobs below ARE the frozen enumeration)
# --------------------------------------------------------------------------- #
P4A_PROTOCOL = "p4a-privacy-broadening-1.0"
P4A_DENSE_SEEDS = (939, 949)
P4A_CANARY_SEEDS = (959, 969)
P4A_Q_LEVELS = (4, 32)
P4A_CANARY = {"count": 16, "length": 32, "repeats": 10, "stream": "canary", "seed": 979}
P4A_STEPS = 600


def expected_p4a_runs() -> list[dict]:
    """The 12 P4a calibration runs: dense-capture (seeds 939/949 x q{4,32}),
    canary-injection and matched no-canary (seeds 959/969 x q{4,32}).
    All trained mode, medium span {start 2, span 4}, width 256, 600 steps,
    cohort calibration, protocol p4a-privacy-broadening-1.0."""
    runs: list[dict] = []
    for seed in P4A_DENSE_SEEDS:
        for q in P4A_Q_LEVELS:
            runs.append({"run_id": f"p4a-dense-q{q}-s{seed}", "kind": "dense",
                         "mode": "trained", "seed": seed, "q_bits": q,
                         "span": "medium", "width": "high",
                         "cohort": "calibration", "protocol_version": P4A_PROTOCOL,
                         "steps": P4A_STEPS, "transcript_sample_every": 1})
    for seed in P4A_CANARY_SEEDS:
        for q in P4A_Q_LEVELS:
            for inject in (True, False):
                tag = "canary" if inject else "nocanary"
                runs.append({"run_id": f"p4a-{tag}-q{q}-s{seed}", "kind": tag,
                             "mode": "trained", "seed": seed, "q_bits": q,
                             "span": "medium", "width": "high",
                             "cohort": "calibration", "protocol_version": P4A_PROTOCOL,
                             "steps": P4A_STEPS, "transcript_sample_every": 200,
                             "canary": {**P4A_CANARY, "steps": P4A_STEPS, "inject": inject}})
    return runs


# --------------------------------------------------------------------------- #
# P4b re-qualification runs (frozen by docs/PREREGISTRATION_P4B.md)
# --------------------------------------------------------------------------- #
P4B_PROTOCOL = "p4b-privacy-requalification-1.0"
P4B_DENSE_SEEDS = (9390, 9490)
P4B_CANARY_SEEDS = (9590, 9690)
P4B_Q_LEVELS = (4, 32)
P4B_CANARY = {"count": 64, "length": 32, "repeats": 10, "stream": "canary", "seed": 9790}
P4B_STEPS = 600


def expected_p4b_runs() -> list[dict]:
    """The 12 P4b calibration runs: dense-capture (seeds 9390/9490 x q{4,32},
    sample_every=10, capture_probe_batches=2), canary-injection and matched
    no-canary (seeds 9590/9690 x q{4,32}, 64 canaries x 10 repeats, stream
    seed 9790). All trained mode, medium span {start 2, span 4}, width 256,
    600 steps, cohort calibration, protocol p4b-privacy-requalification-1.0."""
    runs: list[dict] = []
    for seed in P4B_DENSE_SEEDS:
        for q in P4B_Q_LEVELS:
            runs.append({"run_id": f"p4b-dense-q{q}-s{seed}", "kind": "dense",
                         "mode": "trained", "seed": seed, "q_bits": q,
                         "span": "medium", "width": "high",
                         "cohort": "calibration", "protocol_version": P4B_PROTOCOL,
                         "steps": P4B_STEPS, "transcript_sample_every": 10,
                         "capture_probe_batches": 2})
    for seed in P4B_CANARY_SEEDS:
        for q in P4B_Q_LEVELS:
            for inject in (True, False):
                tag = "canary" if inject else "nocanary"
                runs.append({"run_id": f"p4b-{tag}-q{q}-s{seed}", "kind": tag,
                             "mode": "trained", "seed": seed, "q_bits": q,
                             "span": "medium", "width": "high",
                             "cohort": "calibration", "protocol_version": P4B_PROTOCOL,
                             "steps": P4B_STEPS, "transcript_sample_every": 200,
                             "canary": {**P4B_CANARY, "steps": P4B_STEPS, "inject": inject}})
    return runs


# --------------------------------------------------------------------------- #
# replication (P3) enumeration: setting-qualified run ids (a2c2-trained-s9)
# --------------------------------------------------------------------------- #
def replication_run_id(setting: str, mode: str, seed: int) -> str:
    """Setting-qualified run id; must match scripts/run_replication.py."""
    return f"{setting}-{mode}-s{seed}"


def expected_replication_runs(matrix: dict) -> list[dict]:
    """P3 enumeration: 3 settings x {all_local, removed_remote, trained,
    frozen_random} x 8 seeds = 96 runs."""
    cohort = matrix.get("cohort", "confirmatory")
    runs: list[dict] = []
    for setting in matrix["settings"]:
        for seed in matrix["factors"]["seed"]:
            for mode in ("all_local", "removed_remote", "trained", "frozen_random"):
                runs.append({
                    "run_id": replication_run_id(setting, mode, seed),
                    "mode": mode, "setting": setting, "span": "medium", "width": "high",
                    "seed": seed, "cohort": cohort, "cell": setting,
                })
    return runs


# --------------------------------------------------------------------------- #
# segment-statistics (P2c) enumeration: trained per seed x held-out segment,
# all_local per seed; no frozen/removed runs (prereg scope note)
# --------------------------------------------------------------------------- #
def expected_segment_stats_runs(matrix: dict) -> list[dict]:
    """P2c enumeration: 8 all_local + 8 seeds x 8 held-out cells trained = 72.

    Segment levels are named by coordinates, e.g. "s2at1" for {start:1, span:2}.
    """
    seeds = matrix["factors"]["seed"]
    segments = matrix["factors"]["segment_span"]
    width = next(iter(matrix["factors"]["latent_width"]))  # high (256)
    cohort = matrix.get("cohort", "confirmatory")
    runs: list[dict] = []
    for seed in seeds:
        runs.append({"run_id": expected_run_id("all_local", seed), "mode": "all_local",
                     "span": None, "width": None, "seed": seed, "cohort": cohort,
                     "cell": None})
    for seed in seeds:
        for span_name in segments:
            runs.append({"run_id": expected_run_id("trained", seed, span=span_name,
                                                   width=width),
                         "mode": "trained", "span": span_name, "width": width,
                         "seed": seed, "cohort": cohort,
                         "cell": span_name,
                         "segment": {"start": segments[span_name]["start"],
                                     "span": segments[span_name]["span"]}})
    for cal in calibration_entries(matrix):
        runs.append({"run_id": f"calibration-s{cal['seed']}", "mode": cal["mode"],
                     "span": cal["span"], "width": cal["width"], "seed": cal["seed"],
                     "cohort": "calibration", "cell": None})
    return runs


# --------------------------------------------------------------------------- #
# delegation sweep (P5): span x defense x mode factorial + controls
# --------------------------------------------------------------------------- #
P5_PROTOCOL = "p5-delegation-sweep-1.0"
P5_CAL_SEEDS = (9391, 9491)
P5_CAL_RUNS = [
    {"run_id": f"p5cal-{defense}-s{seed}", "defense": defense, "seed": seed,
     "mode": "trained", "cohort": "calibration", "protocol_version": P5_PROTOCOL,
     "segment": {"start": 2, "span": 4}, "width": 256, "remote_depth": 2,
     "steps": 600, "transcript_sample_every": 1}
    for defense in ("d0", "d1") for seed in P5_CAL_SEEDS
]


def p5_cell_run_id(span: int, defense: str, mode: str, seed: int) -> str:
    return f"p5-s{span}-{defense}-{mode}-s{seed}"


def expected_p5_runs(matrix: dict) -> list[dict]:
    """P5 enumeration: 8 all_local + 7x8 removed_remote + 7 spans x 2 defenses
    x 2 modes x 8 seeds = 288 runs."""
    seeds = matrix["factors"]["seed"]
    spans = matrix["factors"]["segment_span"]
    defenses = matrix["factors"]["defenses"]
    cohort = matrix.get("cohort", "confirmatory")
    runs: list[dict] = []
    for seed in seeds:
        runs.append({"run_id": f"p5-all_local-s{seed}", "mode": "all_local",
                     "span": None, "width": None, "seed": seed, "cohort": cohort,
                     "cell": None})
    for seed in seeds:
        for span_name, level in spans.items():
            runs.append({"run_id": f"p5-removed-{span_name}-s{seed}",
                         "mode": "removed_remote", "span": span_name, "width": "high",
                         "seed": seed, "cohort": cohort, "cell": f"{span_name}-d0",
                         "segment": {"start": level["start"], "span": level["span"],
                                     "remote_depth": level["remote_depth"]}})
    for seed in seeds:
        for span_name, level in spans.items():
            for defense in defenses:
                for mode in ("trained", "frozen_random"):
                    runs.append({
                        "run_id": p5_cell_run_id(level["span"], defense, mode, seed),
                        "mode": mode, "span": span_name, "width": "high",
                        "defense": defense, "seed": seed, "cohort": cohort,
                        "cell": f"{span_name}-{defense}",
                        "segment": {"start": level["start"], "span": level["span"],
                                    "remote_depth": level["remote_depth"]},
                    })
    return runs
