#!/usr/bin/env python3
"""P3 external-replication analysis — implements the frozen confirmatory_rule
of experiments/configs/replication_matrix.yaml (protocol p3-replication-1.0;
docs/PREREGISTRATION_P3.md).

Discovery: completed p3 runs from manifests (cohort="confirmatory",
protocol_version="p3-replication-1.0"); missing/failed runs are reported
operational failures. Frozen missing-data rule: a seed missing a pair member
is dropped from that setting's paired tests (predeclared, never
outcome-based).

Frozen gates per setting (G_R = L(frozen) - L(trained) at step 2000):
  * primary A2C2: one-sided paired t over 8 seeds, alpha 0.05; REPLICATED iff
    p < 0.05 AND mean G_R >= 0.01 nats AND mean G_R > 0 at steps
    1800/1900/2000 (persistence);
  * secondary A2C1, A1C2: same gates, Bonferroni alpha 0.025 each.
Descriptive (ungated): Delta_U and removed-remote reference per setting with
95% CIs; cross-setting sign/magnitude pattern; downstream probe accuracy gaps
from outputs/replication/downstream.json when present.

Outputs: outputs/replication/replication_analysis.json,
outputs/replication/replication_summary.md (verdicts up top), and
paper/figures/replication_curves.png (per-setting learning curves by mode,
seed means). Privacy is not evaluated in P3 (no auto-scoring).

Usage (after scripts/run_replication.py finishes):
  .venv/bin/python scripts/analyze_replication.py
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from statistics import mean

sys.path.insert(0, str(Path(__file__).resolve().parent))

import pilot_common as pc  # noqa: E402
import stats_utils as su  # noqa: E402
from analyze_pilot import _fmt, collect_run, ensure_matplotlib  # noqa: E402

DEFAULT_CONFIG = pc.REPO_ROOT / "experiments" / "configs" / "replication_matrix.yaml"
DEFAULT_OUTPUT_ROOT = pc.REPO_ROOT / "outputs" / "replication"
DEFAULT_FIGURE_PATH = pc.REPO_ROOT / "paper" / "figures" / "replication_curves.png"
PRACTICAL_THRESHOLD = 0.01  # nats, from the frozen replicate_if rule

P3_NOTE = (
    "Confirmatory external-replication analysis under protocol p3-replication-1.0 "
    "(frozen 2026-09-06, fresh seeds [9..89]); per docs/PREREGISTRATION_P3.md. "
    "No pooling across settings; privacy not re-evaluated (token-inversion-family "
    "scope omission still applies)."
)


def build_settings(records: dict[str, dict], matrix: dict) -> tuple[dict, dict]:
    """Per setting: per-seed G_R (by step + final), Delta_U, removed reference."""
    seeds = matrix["factors"]["seed"]
    settings: dict[str, dict] = {}
    final_step_seen, persistence_seen = None, []
    for setting in matrix["settings"]:
        gains_by_seed: dict[str, dict] = {}
        dropped: list[int] = []
        delta_u: dict[str, float | None] = {}
        removed_ref: dict[str, float | None] = {}
        for s in seeds:
            trained = records.get(pc.replication_run_id(setting, "trained", s))
            frozen = records.get(pc.replication_run_id(setting, "frozen_random", s))
            local = records.get(pc.replication_run_id(setting, "all_local", s))
            removed = records.get(pc.replication_run_id(setting, "removed_remote", s))
            delta_u[str(s)] = (trained["final_eval_loss"]
                               - local["eval_series"][trained["final_step"]]
                               ) if trained and local else None
            removed_ref[str(s)] = (removed["final_eval_loss"]
                                   - local["eval_series"][removed["final_step"]]
                                   ) if removed and local else None
            if trained is None or frozen is None:
                dropped.append(s)
                continue
            shared = sorted(set(trained["eval_series"]) & set(frozen["eval_series"]))
            gains_by_seed[str(s)] = {
                "by_step": {st: frozen["eval_series"][st] - trained["eval_series"][st]
                            for st in shared}}
        eval_steps = sorted({st for g in gains_by_seed.values() for st in g["by_step"]})
        if not eval_steps:
            settings[setting] = {"status": "no_paired_seeds", "dropped_seeds": dropped}
            continue
        final_step = max(eval_steps)
        persistence_steps = eval_steps[-3:]
        final_step_seen, persistence_seen = final_step, persistence_steps
        final_gains = {s: g["by_step"][final_step] for s, g in gains_by_seed.items()
                       if final_step in g["by_step"]}
        mean_gain_by_step = {}
        for st in persistence_steps:
            values = [g["by_step"][st] for g in gains_by_seed.values() if st in g["by_step"]]
            mean_gain_by_step[str(st)] = mean(values) if values else None
        settings[setting] = {
            "status": "ok",
            "seeds_used": sorted(int(s) for s in final_gains),
            "dropped_seeds": dropped,
            "final_step": final_step,
            "persistence_steps": persistence_steps,
            "gains_by_seed": gains_by_seed,
            "final_gains": final_gains,
            "mean_gain_by_step": mean_gain_by_step,
            "delta_u": su.mean_ci([v for v in delta_u.values() if v is not None]),
            "delta_u_by_seed": delta_u,
            "removed_ref": su.mean_ci([v for v in removed_ref.values() if v is not None]),
            "removed_ref_by_seed": removed_ref,
        }
    return settings, {"final_step": final_step_seen, "persistence_steps": persistence_seen}


def evaluate_setting(setting: dict, alpha: float) -> dict:
    """Frozen gate: p < alpha AND mean G_R >= 0.01 AND persistence."""
    gains = [setting["final_gains"][s] for s in sorted(setting["final_gains"], key=int)]
    test = su.paired_t_test(gains, alternative="greater")
    persistence_pass = bool(setting["mean_gain_by_step"]) and all(
        v is not None and v > 0 for v in setting["mean_gain_by_step"].values())
    p_pass = test["p"] is not None and test["p"] < alpha
    magnitude_pass = test["mean"] is not None and test["mean"] >= PRACTICAL_THRESHOLD
    replicated = bool(p_pass and magnitude_pass and persistence_pass)
    failed = []
    if not p_pass:
        failed.append("p_value")
    if not magnitude_pass:
        failed.append("practical_effect_0.01_nats")
    if not persistence_pass:
        failed.append("persistence")
    return {"t_test": test, "alpha": alpha,
            "practical_threshold_nats": PRACTICAL_THRESHOLD,
            "persistence_mean_gains": setting["mean_gain_by_step"],
            "p_pass": p_pass, "magnitude_pass": magnitude_pass,
            "persistence_pass": persistence_pass,
            "failed_conditions": failed,
            "replicated": replicated,
            "verdict": "REPLICATED" if replicated else "NOT REPLICATED"}


def cross_setting_pattern(settings: dict, verdicts: dict) -> dict:
    """Descriptive sign/magnitude pattern across settings (no pooling)."""
    pattern = {}
    for name, s in settings.items():
        if s.get("status") != "ok":
            pattern[name] = None
            continue
        gains = list(s["final_gains"].values())
        pattern[name] = {"mean_gain": mean(gains), "sign": "positive" if mean(gains) > 0 else "non-positive",
                         "min_seed_gain": min(gains), "max_seed_gain": max(gains),
                         "verdict": verdicts.get(name, {}).get("verdict")}
    signs = {p["sign"] for p in pattern.values() if p}
    return {"per_setting": pattern,
            "all_positive": signs == {"positive"} if signs else False,
            "note": "descriptive; architectures/corpora are not exchangeable, no pooling"}


# --------------------------------------------------------------------------- #
# figure
# --------------------------------------------------------------------------- #
def make_replication_figure(records: dict[str, dict], matrix: dict,
                            figure_path: Path) -> bool:
    mpl = ensure_matplotlib()
    if mpl is None:
        print("matplotlib unavailable; skipping replication curves figure")
        return False
    mpl.use("Agg")
    import matplotlib.pyplot as plt

    settings = list(matrix["settings"])
    modes = [("all_local", "black"), ("removed_remote", "gray"),
             ("trained", "tab:blue"), ("frozen_random", "tab:red")]
    fig, axes = plt.subplots(1, len(settings), figsize=(5.5 * len(settings), 4.5),
                             sharey=False)
    for ax, setting in zip(axes, settings):
        for mode, color in modes:
            members = [r for r in records.values()
                       if r.get("setting") == setting and r["mode"] == mode]
            if not members:
                continue
            steps = sorted({st for r in members for st in r["eval_series"]})
            per_seed = [[r["eval_series"].get(st, float("nan")) for st in steps]
                        for r in sorted(members, key=lambda r: r["seed"])]
            for ys in per_seed:
                ax.plot(steps, ys, color=color, alpha=0.25, linewidth=0.8)
            mean_ys = [mean([ys[i] for ys in per_seed]) for i in range(len(steps))]
            ax.plot(steps, mean_ys, color=color, linewidth=2.0, label=mode)
        ax.set_title(setting.upper())
        ax.set_xlabel("step")
        ax.grid(alpha=0.3)
    axes[0].set_ylabel("held-out eval loss")
    axes[-1].legend(fontsize=8, loc="best")
    fig.suptitle("P3 replication learning curves (seed means; faint = individual seeds)")
    fig.tight_layout()
    figure_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(figure_path, dpi=150)
    print(f"wrote {figure_path}")
    return True


# --------------------------------------------------------------------------- #
# markdown
# --------------------------------------------------------------------------- #
def render_markdown(analysis: dict) -> str:
    lines = [
        "# P3 external-replication analysis (protocol p3-replication-1.0)",
        "",
        f"> {P3_NOTE}",
        "",
        "## Verdicts",
        "",
        f"- **primary A2C2: {analysis['verdicts']['a2c2']['verdict']}**",
    ]
    for setting in ("a2c1", "a1c2"):
        lines.append(f"- secondary {setting.upper()}: "
                     f"**{analysis['verdicts'][setting]['verdict']}**")
    pattern = analysis["cross_setting_pattern"]
    lines.append(f"- cross-setting pattern: all settings positive mean G_R: "
                 f"**{pattern['all_positive']}** ({pattern['note']})")
    lines += [
        "",
        "## Per-setting tests (one-sided paired t on G_R, step 2000)",
        "",
        "| Setting | role | n | dropped | mean G_R | SD | t | df | p | alpha | "
        ">=0.01 | persists | verdict |",
        "|---|---|---:|---|---:|---:|---:|---:|---:|---:|---|---|---|",
    ]
    for setting, v in analysis["verdicts"].items():
        t = v["t_test"]
        role = "primary" if setting == "a2c2" else "secondary"
        lines.append(
            f"| {setting} | {role} | {t['n']} "
            f"| {analysis['settings'][setting].get('dropped_seeds') or 'none'}"
            f" | {_fmt(t['mean'])} | {_fmt(t['sd'])} | {_fmt(t['t'])} | {t['df']}"
            f" | {_fmt(t['p'], 5)} | {v['alpha']}"
            f" | {'yes' if v['magnitude_pass'] else 'no'}"
            f" | {'yes' if v['persistence_pass'] else 'no'} | **{v['verdict']}** |"
        )
    lines += [
        "",
        "## Descriptive: replacement penalty and removed-remote reference",
        "",
        "| Setting | Delta_U mean [95% CI] | removed ref mean [95% CI] |",
        "|---|---|---|",
    ]
    for setting, s in analysis["settings"].items():
        if s.get("status") != "ok":
            continue
        du, rr = s["delta_u"], s["removed_ref"]
        lines.append(f"| {setting} | {_fmt(du['mean'])} [{_fmt(du['ci_low'])}, "
                     f"{_fmt(du['ci_high'])}] | {_fmt(rr['mean'])} [{_fmt(rr['ci_low'])}, "
                     f"{_fmt(rr['ci_high'])}] |")
    downstream = analysis.get("downstream")
    lines += ["", "## Downstream probes (descriptive, not gated)", ""]
    if downstream:
        lines += ["| Property | gap (trained - all_local) mean [95% CI] |", "|---|---|"]
        for prop, gap in downstream["gaps_trained_minus_all_local"].items():
            ci = gap["ci"]
            lines.append(f"| {prop} | {_fmt(ci['mean'])} [{_fmt(ci['ci_low'])}, "
                         f"{_fmt(ci['ci_high'])}] |")
    else:
        lines.append("- downstream.json not available (run scripts/run_downstream.py "
                     "after the A2C2 runs)")
    lines += ["", "## Operational failures", ""]
    if analysis["operational_failures"]:
        for failure in analysis["operational_failures"]:
            lines.append(f"- `{failure['run_id']}`: {failure['reason']}")
    else:
        lines.append("- none")
    lines.append("")
    return "\n".join(lines)


# --------------------------------------------------------------------------- #
# main
# --------------------------------------------------------------------------- #
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument("--output-root", default=str(DEFAULT_OUTPUT_ROOT))
    parser.add_argument("--manifest-dir", default=str(pc.DEFAULT_MANIFEST_DIR))
    parser.add_argument("--downstream", default=None,
                        help="default: <output-root>/downstream.json (loaded if present)")
    parser.add_argument("--analysis-path", default=None)
    parser.add_argument("--summary-path", default=None)
    parser.add_argument("--figure-path", default=str(DEFAULT_FIGURE_PATH))
    parser.add_argument("--no-figure", action="store_true")
    args = parser.parse_args(argv)

    output_root = Path(args.output_root)
    analysis_path = (Path(args.analysis_path) if args.analysis_path
                     else output_root / "replication_analysis.json")
    summary_path = (Path(args.summary_path) if args.summary_path
                    else output_root / "replication_summary.md")
    downstream_path = (Path(args.downstream) if args.downstream
                       else output_root / "downstream.json")

    matrix = pc.load_matrix_forgiving(args.config)
    rule = matrix["confirmatory_rule"]
    expected = pc.expected_replication_runs(matrix)
    manifests, unreadable = pc.scan_manifests(args.manifest_dir)
    completed, failures, extras = pc.classify_runs(
        expected, manifests, unreadable,
        required_manifest_fields={"cohort": "confirmatory",
                                  "protocol_version": matrix["protocol_version"]},
    )
    records: dict[str, dict] = {}
    for entry in completed:
        record, error = collect_run(output_root, entry)
        if error:
            failures.append({"run_id": entry["run_id"], "mode": entry["mode"],
                             "seed": entry["seed"], "reason": error})
        else:
            record["setting"] = entry["setting"]  # collect_run drops entry-only fields
            records[entry["run_id"]] = record

    settings, meta = build_settings(records, matrix)
    primary_alpha = float(rule["primary"]["alpha"])
    secondary_alpha = float(rule["secondary"]["alpha"])
    verdicts = {}
    for name in matrix["settings"]:
        if settings.get(name, {}).get("status") != "ok":
            verdicts[name] = {"verdict": "NOT REPLICATED", "replicated": False,
                              "failed_conditions": ["no_paired_data"],
                              "t_test": su.paired_t_test([], "greater"),
                              "alpha": primary_alpha if name == "a2c2" else secondary_alpha}
            continue
        alpha = primary_alpha if name == rule["primary"]["setting"] else secondary_alpha
        verdicts[name] = evaluate_setting(settings[name], alpha)

    downstream = json.loads(downstream_path.read_text()) if downstream_path.is_file() else None

    analysis = {
        "note": P3_NOTE,
        "protocol_version": matrix.get("protocol_version"),
        "config": args.config,
        "confirmatory_rule": rule,
        "seeds": matrix["factors"]["seed"],
        "final_step": meta["final_step"], "persistence_steps": meta["persistence_steps"],
        "runs": records, "settings": settings, "verdicts": verdicts,
        "cross_setting_pattern": cross_setting_pattern(settings, verdicts),
        "downstream": downstream,
        "operational_failures": sorted(failures, key=lambda f: f["run_id"]),
        "non_study_manifests_ignored": extras,
    }
    analysis_path.parent.mkdir(parents=True, exist_ok=True)
    analysis_path.write_text(json.dumps(analysis, indent=2, sort_keys=True))
    summary_path.write_text(render_markdown(analysis))

    print(render_markdown(analysis))
    print(f"wrote {analysis_path}")
    print(f"wrote {summary_path}")
    for name, v in verdicts.items():
        print(f"VERDICT {name.upper()}: {v['verdict']}")

    if not args.no_figure:
        if records:
            make_replication_figure(records, matrix, Path(args.figure_path))
        else:
            print("no completed runs; skipping figure")
    return 0


if __name__ == "__main__":
    sys.exit(main())
