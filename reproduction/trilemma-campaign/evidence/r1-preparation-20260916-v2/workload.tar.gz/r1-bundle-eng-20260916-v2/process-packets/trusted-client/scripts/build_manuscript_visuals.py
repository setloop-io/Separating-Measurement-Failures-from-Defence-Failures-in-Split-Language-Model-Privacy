#!/usr/bin/env python3
"""Render manuscript displays from allow-listed summaries, without re-running analyses."""
from pathlib import Path
import hashlib
import json
import os
import tempfile

os.environ.setdefault("MPLCONFIGDIR", str(Path(tempfile.gettempdir()) / "paper3-matplotlib"))
os.environ.setdefault("XDG_CACHE_HOME", str(Path(tempfile.gettempdir()) / "paper3-fontcache"))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
FIG = ROOT / "paper/figures"
TABLE = ROOT / "paper/tables"
SOURCES = {
    "p2": "outputs/confirmatory/confirmatory_analysis.json",
    "p3": "outputs/replication/replication_analysis.json",
    "rate": "outputs/rate_sweep/rate_sweep_analysis.json",
    "segment": "outputs/segment_stats/segment_stats_analysis.json",
    "p5": "outputs/delegation/delegation_analysis.json",
}
BLUE, ORANGE, TEAL, GRAY = "#285f8f", "#ad542d", "#247b77", "#697482"
plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 10, "axes.titlesize": 11,
    "axes.labelsize": 10, "axes.spines.top": False, "axes.spines.right": False,
    "axes.edgecolor": "#adb5bf", "axes.labelcolor": "#23313c",
    "xtick.color": "#475361", "ytick.color": "#475361",
    "pdf.fonttype": 42, "ps.fonttype": 42, "savefig.facecolor": "white",
})


def save(fig, name):
    for ext in ("pdf", "png"):
        fig.savefig(FIG / f"{name}.{ext}", dpi=210, bbox_inches="tight", pad_inches=0.08)
    plt.close(fig)


def schematic():
    fig, ax = plt.subplots(figsize=(8.6, 3.3))
    ax.set(xlim=(0, 10), ylim=(-0.1, 4.1))
    ax.axis("off")
    rows = [(3.25, "All-local", "Local segment", r"$L_0$", GRAY),
            (2.25, "Trained", "Learned remote", r"$L_T$", BLUE),
            (1.25, "Frozen-random", "Frozen remote", r"$L_F$", ORANGE),
            (0.25, "Removed", "Identity bypass", r"$L_B$", TEAL)]
    for y, label, middle, loss, color in rows:
        ax.text(0, y + .28, label, fontweight="bold", va="center", fontsize=10)
        for x, width, text in [(2.0, 2.25, "Trusted input path"),
                               (4.65, 2.45, middle), (7.5, 2.15, "Trusted output path")]:
            ax.add_patch(FancyBboxPatch((x, y), width, .57,
                boxstyle="round,pad=0.045,rounding_size=0.06", linewidth=1,
                edgecolor=color if x == 4.65 else "#bcc7cf",
                facecolor=color + "16" if x == 4.65 else "#f4f6f8"))
            ax.text(x + width/2, y + .285, text, ha="center", va="center", fontsize=9)
        for a, b in [(4.3, 4.6), (7.15, 7.45)]:
            ax.annotate("", (b, y + .285), (a, y + .285),
                        arrowprops={"arrowstyle": "->", "color": GRAY, "lw": 1.1})
        ax.text(9.85, y + .285, loss, va="center", fontsize=11)
    ax.text(5, 4.03, r"Replacement penalty: $\Delta_U=L_T-L_0$     |     Remote-learning gain: $G_R=L_F-L_T$",
            ha="center", va="center", fontsize=10, color=BLUE)
    save(fig, "study_controls")


def gains(data):
    fig, ax = plt.subplots(figsize=(7.5, 4.7), layout="constrained")
    order = ["short-low", "short-high", "medium-low", "medium-high", "long-low", "long-high"]
    records = {**data["p2"]["primary_family"], **data["p2"]["secondary_family"]}
    labels, positions = [], []
    entries = []
    for i, key in enumerate(order):
        color = BLUE if key in data["p2"]["primary_family"] else GRAY
        entries.append((i, records[key]["t_test"], data["p2"]["cells"][key]["final_gains"], color))
        positions.append(i)
        labels.append("P2   " + key.replace("-", " / "))
    for i, (key, label) in enumerate([
            ("a1c2", "8 × 256 / War and Peace"),
            ("a2c1", "12 × 192 / Shakespeare"),
            ("a2c2", "12 × 192 / War and Peace")], start=7):
        entries.append((i, data["p3"]["verdicts"][key]["t_test"], data["p3"]["settings"][key]["final_gains"], TEAL))
        positions.append(i)
        labels.append("P3   " + label)
    for i, row, seed_values, color in entries:
        seeds = list(seed_values.values())
        assert len(seeds) == row["n"] == 8
        ax.scatter(seeds, i + np.linspace(-.12, .12, len(seeds)), s=17, color=color, alpha=.3, linewidths=0)
        ax.errorbar(row["mean"], i,
            xerr=[[row["mean"]-row["ci95_low"]], [row["ci95_high"]-row["mean"]]],
            fmt="o", color=color, capsize=3, ms=5, lw=1.6)
    ax.set_yticks(positions, labels, fontsize=9)
    ax.set_ylim(9.75, -.8)
    ax.axhline(6, color="#d7dee5", linewidth=1)
    ax.axvline(0, color=GRAY, lw=1)
    ax.axvline(.01, color=ORANGE, linestyle="--", lw=1)
    ax.text(.01, 6, "  Practical mean-gain threshold", color=ORANGE, va="center", fontsize=8,
            bbox={"facecolor":"white", "edgecolor":"none", "pad":2})
    ax.set_title("Remote-learning gains across separate cohorts", loc="left", fontweight="bold", fontsize=12)
    ax.set_xlabel(r"$G_R$ (nats per byte); positive favors training", fontsize=10)
    ax.grid(axis="x", color="#e7ebef", lw=.6)
    ax.set_axisbelow(True)
    ax.set_xlim(-.018, .064)
    ax.set_xticks([-.01, 0, .01, .02, .03, .04, .05, .06])
    save(fig, "remote_gain_summary")


def precision_prediction(data):
    fig, axes = plt.subplots(1, 2, figsize=(8.3, 3.9), layout="constrained")
    rows = sorted(data["rate"]["frontier"], key=lambda x: x["q_bits"])
    means = [x["eval_loss"]["mean"] for x in rows]
    lo = [x["eval_loss"]["mean"]-x["eval_loss"]["ci_low"] for x in rows]
    hi = [x["eval_loss"]["ci_high"]-x["eval_loss"]["mean"] for x in rows]
    axes[0].errorbar([x["q_bits"] for x in rows], means, yerr=[lo, hi], fmt="o-", color=BLUE, capsize=4, lw=1.8)
    axes[0].set_xscale("log", base=2)
    axes[0].set_xticks([x["q_bits"] for x in rows], [x["q_bits"] for x in rows])
    axes[0].set(xlabel="Forward latent precision (bits/dimension)", ylabel="Held-out loss (nats per byte)", ylim=(1.66, 1.72))
    axes[0].set_title("A   Precision response (P2b)", loc="left", fontweight="bold")
    axes[0].grid(axis="y", color="#e7ebef")
    axes[0].text(.96, .96, "Fixed span, width and capacity", transform=axes[0].transAxes, ha="right", va="top", fontsize=9, color=GRAY)
    rows = data["segment"]["cell_rows"]
    for pred, color, marker, label in [("pred_S", ORANGE, "s", "Intrinsic dimension"), ("pred_N", TEAL, "o", "Nominal span")]:
        axes[1].errorbar([r["delta_u_mean"] for r in rows], [r[pred] for r in rows],
            xerr=[[r["delta_u_mean"]-r["delta_u"]["ci_low"] for r in rows], [r["delta_u"]["ci_high"]-r["delta_u_mean"] for r in rows]],
            fmt=marker, color=color, alpha=.9, ms=5, elinewidth=.8, capsize=2, label=label)
    axes[1].plot([0, .22], [0, .22], color=GRAY, linestyle="--", lw=1, label="Perfect prediction")
    axes[1].set(xlim=(0, .22), ylim=(0, .22), xlabel=r"Measured $\Delta_U$ (nats per byte)", ylabel=r"Predicted $\Delta_U$ (nats per byte)")
    axes[1].set_title("B   Held-out prediction (P2c)", loc="left", fontweight="bold")
    axes[1].legend(loc="lower right", fontsize=9, frameon=False)
    axes[1].set_xticks([0, .05, .10, .15, .20])
    axes[1].set_yticks([0, .05, .10, .15, .20])
    save(fig, "precision_and_prediction")


def p5_table(data):
    lines = [r"% Generated by scripts/build_manuscript_visuals.py; do not edit values by hand.",
        r"\begin{tabular}{@{}lrrrrrr@{}}", r"\toprule",
        r" & \multicolumn{2}{c}{$\Delta_U$ [95\% CI]} & \multicolumn{2}{c}{$G_R$} & Share & Structure \\",
        r"\cmidrule(lr){2-3}\cmidrule(lr){4-5}",
        r"Span@start & D0 & D1 & D0 & D1 & D0/D1 & D0/D1 \\", r"\midrule"]
    for span in range(1, 8):
        group = sorted([r for r in data["p5"]["cells"].values() if r["span"] == span], key=lambda r:r["defense"])
        assert len(group) == 2
        d0,d1 = group
        assert d0["start"] == d1["start"]
        assert d0["gates"]["share_mean"] == d1["gates"]["share_mean"]
        for r in group:
            assert len(r["delta_u_by_seed"]) == 8
        cells=[f'{span}@{d0["start"]}']
        for r in group:
            ci=r["gates"]["utility"]["delta_u"]
            cells.append(f'{ci["mean"]:.3f} [{ci["ci_low"]:.3f}, {ci["ci_high"]:.3f}]')
        cells.extend([f'{r["gr_mean"]:+.3f}' for r in group])
        # The property-family maximum includes targets whose individual null checks
        # failed. Render the separately qualified structure gate instead; the joint
        # result follows from D0 structure failures and D1 utility failures.
        structure_status = [
            'Pass' if r["gates"]["privacy"]["per_variant"]["structure_semantic_v2@forward@p4b"]["pass"] else 'Fail'
            for r in group
        ]
        cells.extend([f'{d0["gates"]["share_mean"]:.3f}', '/'.join(structure_status)])
        lines.append(' & '.join(cells) + r' \\')
    lines.extend([r"\bottomrule",r"\end{tabular}"])
    (TABLE / "p5_outcomes.tex").write_text('\n'.join(lines)+'\n')


def main():
    FIG.mkdir(exist_ok=True)
    TABLE.mkdir(exist_ok=True)
    data={k:json.loads((ROOT / path).read_text()) for k,path in SOURCES.items()}
    schematic()
    gains(data)
    precision_prediction(data)
    p5_table(data)
    provenance={"generator":"scripts/build_manuscript_visuals.py", "sources":{
        k:{"path":p,"sha256":hashlib.sha256((ROOT/p).read_bytes()).hexdigest(),
           "protocol":data[k]["protocol_version"]} for k,p in SOURCES.items()},
        "note":"Existing means, intervals and predictions rendered unchanged; no training or new inferential tests. No historical token-only feasibility labels reused."}
    (FIG / "manuscript_visuals_provenance.json").write_text(json.dumps(provenance,indent=2)+'\n')
    print("Generated 3 vector/PDF figures, PNG previews, P5 table and source hashes.")


if __name__ == "__main__":
    main()
