#!/usr/bin/env python3
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
REQUIRED = [
    "README.md",
    "PLAN.md",
    "docs/PREREGISTRATION.md",
    "docs/CLAIM_EVIDENCE_LEDGER.md",
    "experiments/configs/pilot_matrix.yaml",
    "experiments/schemas/run_manifest.schema.json",
    "experiments/schemas/transcript.schema.json",
    "experiments/examples/run_manifest.example.json",
    "paper/main.tex",
    "paper/refs.bib",
]


def main() -> None:
    missing = [path for path in REQUIRED if not (ROOT / path).is_file()]
    if missing:
        raise SystemExit(f"missing required scaffold files: {missing}")

    for path in [
        "experiments/schemas/run_manifest.schema.json",
        "experiments/schemas/transcript.schema.json",
        "experiments/examples/run_manifest.example.json",
    ]:
        with (ROOT / path).open(encoding="utf-8") as handle:
            json.load(handle)

    manuscript = (ROOT / "paper/main.tex").read_text(encoding="utf-8")
    prohibited_as_result = ["exact 4:1", "Depth is delegability"]
    for phrase in prohibited_as_result:
        if phrase in manuscript:
            raise SystemExit(f"prohibited result phrase in manuscript: {phrase}")

    print("scaffold validation passed")


if __name__ == "__main__":
    main()

