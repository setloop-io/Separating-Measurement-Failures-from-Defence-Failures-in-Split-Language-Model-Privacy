#!/usr/bin/env python3
"""P3 downstream byte-property probe evaluation (descriptive, not gated).

Loads the A2C2 final checkpoints (trained and all_local per seed, saved via
the additive save_final_state flag), computes final-layer hidden states
(head input, post-ln_f) on dedicated train/held-out downstream streams
(labels "downstream-train"/"downstream-eval", seed per run), trains a
deterministic multinomial logistic probe per byte property
{is_uppercase_letter, is_vowel, is_digit, is_whitespace} on train-split
hidden states, evaluates on held-out, and reports per-seed held-out accuracy
per property per mode plus the trained - all_local gap with a seed-level 95%
CI. Writes outputs/replication/downstream.json.

Usage (after the A2C2 runs finish):
  .venv/bin/python scripts/run_downstream.py
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "src"))

import pilot_common as pc  # noqa: E402
import stats_utils as su  # noqa: E402

DEFAULT_CONFIG = ROOT / "experiments" / "configs" / "replication_matrix.yaml"
DEFAULT_OUTPUT_ROOT = ROOT / "outputs" / "replication"


def load_backbone_from_run(run_dir: Path, device):
    """Rebuild the run's model (Backbone or SplitBackbone) from its resolved
    config and load final_state.pt."""
    import torch

    from pcr.model import BackboneConfig
    from pcr.split import SplitConfig, build_model

    config = json.loads((run_dir / "config.resolved.json").read_text())
    backbone_cfg = BackboneConfig(**config["backbone"])
    split_cfg = SplitConfig(**config["split"]) if config.get("split") else None
    model = build_model(backbone_cfg, config["mode"], split_cfg)
    model.load_state_dict(torch.load(run_dir / "final_state.pt", map_location="cpu",
                                     weights_only=True))
    return model.to(device)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument("--output-root", default=str(DEFAULT_OUTPUT_ROOT))
    parser.add_argument("--output", default=None,
                        help="default: <output-root>/downstream.json")
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--train-batches", type=int, default=16)
    parser.add_argument("--eval-batches", type=int, default=8)
    parser.add_argument("--probe-epochs", type=int, default=200)
    parser.add_argument("--run-ids", nargs="*", default=None,
                        help="restrict to these run ids (dev/smoke)")
    args = parser.parse_args(argv)

    import torch

    from pcr.data import load_corpus, split_corpus
    from pcr.downstream import (PROPERTIES, hidden_states, make_downstream_batches,
                                probe_accuracy, property_labels, train_property_probe)
    from pcr.utils import derive_seed, resolve_device

    matrix = pc.load_matrix_forgiving(args.config)
    output_root = Path(args.output_root)
    out_path = Path(args.output) if args.output else output_root / "downstream.json"
    device = resolve_device(args.device)

    corpus2 = matrix["corpora"]["corpus2"]["path"]
    corpus = load_corpus(ROOT / corpus2)
    train_region, heldout_region = split_corpus(
        corpus, matrix["fixed"]["corpus_split"]["train_fraction"])
    batch_size = matrix["fixed"]["batch_size"]
    seq_len = matrix["fixed"]["sequence_length"]

    seeds = matrix["factors"]["seed"]
    run_ids = []
    for seed in seeds:
        for mode in ("trained", "all_local"):
            run_ids.append(pc.replication_run_id("a2c2", mode, seed))
    if args.run_ids:
        wanted = set(args.run_ids)
        run_ids = [r for r in run_ids if r in wanted]
        missing_requested = sorted(wanted - set(run_ids))
        for rid in missing_requested:  # allow smoke run ids outside the cohort grid
            run_ids.append(rid)

    results: dict[str, dict] = {}
    missing: list[str] = []
    for run_id in run_ids:
        run_dir = output_root / run_id
        if not (run_dir / "final_state.pt").is_file() or not (run_dir / "config.resolved.json").is_file():
            missing.append(run_id)
            continue
        config = json.loads((run_dir / "config.resolved.json").read_text())
        seed = int(config["seed"])
        mode = config["mode"]
        model = load_backbone_from_run(run_dir, device)
        train_b = make_downstream_batches(train_region, batch_size, seq_len, seed,
                                          "downstream-train", args.train_batches)
        eval_b = make_downstream_batches(heldout_region, batch_size, seq_len, seed,
                                         "downstream-eval", args.eval_batches)
        tokens_tr, hidden_tr = hidden_states(model, train_b, device)
        tokens_ev, hidden_ev = hidden_states(model, eval_b, device)
        per_prop = {}
        for prop in PROPERTIES:
            labels_tr = property_labels(tokens_tr, prop)
            labels_ev = property_labels(tokens_ev, prop)
            probe = train_property_probe(
                hidden_tr, labels_tr,
                seed=int(derive_seed("p3-probe", seed, prop, mode)),
                epochs=args.probe_epochs, device=device)
            per_prop[prop] = {
                "train_accuracy": probe_accuracy(probe, hidden_tr, labels_tr, device),
                "held_out_accuracy": probe_accuracy(probe, hidden_ev, labels_ev, device),
            }
        results[run_id] = {"mode": mode, "seed": seed, "properties": per_prop}
        print(f"{run_id}: " + ", ".join(
            f"{p}={v['held_out_accuracy']:.3f}" for p, v in per_prop.items()), flush=True)

    gaps = {}
    for prop in PROPERTIES:
        per_seed = {}
        for seed in seeds:
            trained = results.get(pc.replication_run_id("a2c2", "trained", seed))
            local = results.get(pc.replication_run_id("a2c2", "all_local", seed))
            if trained and local:
                per_seed[str(seed)] = (trained["properties"][prop]["held_out_accuracy"]
                                       - local["properties"][prop]["held_out_accuracy"])
        gaps[prop] = {"per_seed": per_seed, "ci": su.mean_ci(list(per_seed.values()))}

    payload = {
        "note": "P3 downstream probes (descriptive, not gated): multinomial logistic "
                "probes on final-layer hidden states of A2C2 final checkpoints; "
                "token-inversion-family privacy scope omission still applies.",
        "protocol_version": matrix.get("protocol_version"),
        "setting": "a2c2",
        "properties": list(PROPERTIES),
        "streams": {"train": "downstream-train (train split)", "eval": "downstream-eval (held-out)"},
        "probe": {"epochs": args.probe_epochs, "lr": 1e-2, "optimizer": "adam",
                  "init": "deterministic, seeded per (run seed, property, mode)"},
        "train_batches": args.train_batches, "eval_batches": args.eval_batches,
        "runs": results, "gaps_trained_minus_all_local": gaps,
        "missing_checkpoints": missing,
    }
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(payload, indent=2, sort_keys=True))
    print(f"wrote {out_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
