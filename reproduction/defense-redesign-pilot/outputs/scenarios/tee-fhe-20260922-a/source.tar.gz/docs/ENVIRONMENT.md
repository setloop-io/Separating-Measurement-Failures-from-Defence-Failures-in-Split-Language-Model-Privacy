# Local and cluster research environment

Prepared 2026-09-10 (CPU-only P0). Extended 2026-09-17/18 for the cluster stages
and 2026-09-22 for the scientific cohorts.

Execution hosts actually used, all provisioned with the same `uv.lock`-locked
environment (torch 2.14.0): `toula` and `koula` (aarch64 Linux, NVIDIA GB10,
CUDA, deterministic kernels, driver 580.159.03) for training and scoring;
`soula`, `voula`, `sasa` (aarch64 Linux, CPU) for independent verification; the
local Mac (CPU/MPS) for orchestration and analysis. Each host's `~/paper4`
checkout is deployed from committed trees only; campaign manifests record the
exact device and source snapshot per run. The vendored Paper 3 snapshot remains
unmodified everywhere and is hash-verified by every runner.

```bash
uv sync --locked --extra dev
.venv/bin/python scripts/verify_environment.py
.venv/bin/python -m pytest -q
.venv/bin/python scripts/run_experiments.py --config experiments/configs/pilot_draft.yaml --validate-only
.venv/bin/python scripts/run_experiments.py --config experiments/configs/p0_diagnostics.yaml
```

The completed engineering campaign can be checked without retraining:

```bash
.venv/bin/python scripts/analyze_diagnostics.py --run-label p0-20260910-a
```

Run commands from the Paper 4 root. `.venv` is isolated; `uv.lock` fixes resolved
packages. `vendor/paper3/SOURCE.json` pins 20 unmodified files, including the license,
to Paper 3 commit `52191c430110bd8d9dee80538fde22bf1726e56a`. The verification command
checks both the vendored files and the installed `pcr` implementation. The dependency
does not resolve through a mutable sibling working tree or a `sys.path` override.

The environment was created with Python 3.12.12. Campaign `source.json` files record
exact installed versions and platform settings; `source.tar.gz` retains the source
snapshot used for each diagnostic campaign. Bitwise cross-platform equivalence is
not established by locking packages.

The local copy of the public corpus is ignored by Git. To prepare it elsewhere:

```bash
.venv/bin/python scripts/prepare_data.py --source '/path/to/tinyshakespeare.txt'
```

The helper accepts only the expected content digest
`86c4e6aa9db7c042ec79f339dcb96d42b0075e16b8fc2e86bf0ca57e2dc565ed`.
It does not modify the source corpus or access private training data.

Manifests and small JSON summaries are retained in version control; capture tensors
and source archives are distributed through the private reviewer evidence release,
with their hashes retained in the provenance records. See [retrieval instructions](REVIEWER_EVIDENCE.md).
Before any scientific freeze, commit the final protocol/source and retain the full
immutable artifacts in a declared storage location. P0 snapshots are not evidence
of an externally registered protocol.

No cloud GPU instance, OpenResearch installation, paid service, or deployed network
transport was provisioned. Those require a separate workload-specific configuration;
the current runner intentionally supports only engineering execution.

The additional calibration and plaintext-routing CLIs are documented in
[SCENARIO_PROTOCOL.md](SCENARIO_PROTOCOL.md). They use the same locked environment
and add no dependencies. Source archives are restored from the reviewer release under each scenario campaign;
small diagnostics and manifests are retained in Git.

The [warmup/stability](WARMUP_STABILITY_PROTOCOL.md) and
[matched-null precision](NULL_PRECISION_PROTOCOL.md) runners also use this environment
without additional dependencies. Precision scenarios require the saved warmup
checkpoint, panels, manifests, and source archives; missing or modified artifacts
are rejected. The precision analyzer verifies archived sources and stored estimates
without retraining. CPU runtime is an implementation diagnostic, not a hardware
benchmark; NumPy BLAS scheduling is not normalized across platforms.

## TEE/FHE track environment

The TEE/FHE deployment track ([TEE_FHE_EXEC_PROTOCOL.md](TEE_FHE_EXEC_PROTOCOL.md))
runs in a **separate** environment, `.venv-tee`, so the locked main environment and
`uv.lock` stay untouched (the pilot freeze's code/config bindings are thereby
preserved). `.venv-tee` carries the same Python 3.12.12 and the locked package
versions (torch 2.14.0, numpy 2.5.3, pyyaml 6.0.3, jsonschema 4.26.0, scipy 1.18.1)
plus `tenseal==0.3.18`, with the project installed editable and without dev extras:

```bash
uv venv .venv-tee --python 3.12.12
uv pip install --python .venv-tee/bin/python \
  torch==2.14.0 numpy==2.5.3 pyyaml==6.0.3 jsonschema==4.26.0 scipy==1.18.1 tenseal==0.3.18
uv pip install --python .venv-tee/bin/python -e . --no-deps
```

Only `scripts/run_tee_fhe.py` / `scripts/analyze_tee_fhe.py` run under `.venv-tee`;
every other stage uses the main `.venv` exactly as locked. The stage B runner checks
TenSEAL importability and fails loudly if absent — no mock backend is ever
substituted, and its timings are never secure-serving latencies.
