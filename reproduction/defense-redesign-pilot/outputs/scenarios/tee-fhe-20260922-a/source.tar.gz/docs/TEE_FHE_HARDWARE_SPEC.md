# CC-capable instance: procurement and arrival verification spec

Recorded 2026-09-22 for the [TEE–FHE deployment track](TEE_FHE_TRACK.md). This is
the hardware half of milestone 3. It is a procurement/verification specification,
not a measurement and not a security claim.

## What to provision

Any ONE of:

- **Cloud confidential GPU VM**: an instance class that pairs a TDX (or SEV-SNP)
  confidential VM with an NVIDIA CC-capable datacenter GPU — e.g., Azure
  NCCads H100 v5, or GCP confidential A3 (H100) where offered, or equivalent.
- **On-prem/colo**: Intel Xeon with TDX enabled + an H100/H200/B200 GPU with a
  CC-capable VBIOS and driver ≥ 580 series. (The B200 + TDX pairing is the
  configuration with published 1–3% confidential-overhead measurements.)

Required properties, in order: (1) NVIDIA Confidential Computing supported on the
GPU; (2) CPU-side TEE (TDX or SEV-SNP) for the trusted-runtime baseline; (3) SSH
access for the same locked-repo deploy used on the fleet. A few hours of instance
time suffice for the baseline matrix; the GB10 fleet remains the non-confidential
reference.

## Arrival verification (record every output)

1. GPU CC readiness: `nvidia-smi conf-compute -grs` must report CC ready/available;
   `nvidia-smi conf-compute -f` must show nonzero protected-memory capacity.
   (Fleet GB10s fail both — they are the non-confidential reference only.)
2. GPU attestation: run the NVIDIA attestation SDK / nvtrust flow; record the
   measured driver/VBIOS evidence and whether attestation verified.
3. CPU TEE: `dmesg | grep -i tdx` (or SEV-SNP equivalent) confirms the guest;
   record the platform's attestation tooling version.
4. Environment: `uv sync --locked --extra dev` in the repo; the full test suite;
   record python/torch/driver versions in the campaign source snapshot as usual.
5. Trust-model scope statement (carried into every record): CC protects
   data-in-use on CPU/GPU and the interconnect from the host/hypervisor/operator;
   it does not cover length, traffic, timing, rollback/fork, physical, or
   microarchitectural side channels. `hardware_attested: true` is recorded only
   for measurements produced on this instance.

## Fleet-side state while procurement proceeds

Milestone 1 (Bifrost provenance: no attributable artifact found; any build is
independently inspired — recorded) and milestone 2 (frozen same-checkpoint
correctness test, plaintext-emulated, `hardware_attested: false`) plus the FHE
half of milestone 3 (real CKKS encrypted-projection measurement on the GB10 with
transfer and trusted-side processing included, ordinary CPU reference retained)
execute on the fleet under their own prospective protocol
([TEE_FHE_EXEC_PROTOCOL.md](TEE_FHE_EXEC_PROTOCOL.md)). No fleet record claims
enclave confidentiality.
