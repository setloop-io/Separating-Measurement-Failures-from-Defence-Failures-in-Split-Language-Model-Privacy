# Engineering protocol: TEE–FHE deployment track, fleet-side stages

Protocol ID: `p4-tee-fhe-eng-0.1`
Status: **PROSPECTIVE — recorded 2026-09-22 before execution. Engineering only;
every record carries `scientific_evidence: false`, `hardware_attested: false`, and
privacy `undetermined`.**

This protocol executes milestones 1–3 of [TEE_FHE_TRACK.md](TEE_FHE_TRACK.md) as
far as the fleet allows. Milestone 1 is recorded in
[TEE_FHE_HARDWARE_SPEC.md](TEE_FHE_HARDWARE_SPEC.md) (no attributable Bifrost
artifact; anything here is independently inspired by the cited designs, not a
reproduction). Milestone 3's TEE half awaits the CC-capable instance.

## Stage A — same-checkpoint inference correctness (milestone 2)

- Checkpoint: the verified `d0-q8-trained-s419101` qualification checkpoint
  (`outputs/runs/qualification-20260922-a/.../checkpoint.pt`, hash-bound by its
  manifest). Plaintext reference = the same checkpoint's ordinary forward.
- Emulated boundary: the model's linear operators (attention QKV/O, FFN
  up/down, encoder/decoder linears) execute through a serialized in-process
  loopback ("untrusted side"), with real fp32 tensor serialization and the
  observation contract recorded per operator: tensor shape, dtype, serialized
  bytes, direction (in/out), step. Nonlinear operators, layernorms, softmax,
  residuals, and control execute in-process ("trusted side"). No encryption,
  no attestation, no KV caching tricks; the full prefix is recomputed where the
  architecture requires it.
- Frozen evaluation: first 512 windows of the pilot campaign's evaluation panel
  (hash-bound via the pilot's panels record); metrics: max absolute logit
  deviation vs the reference forward, held-out cross-entropy delta, and exact
  output-token agreement over the frozen set.
- Frozen tolerances: max |Δlogit| ≤ 1e-4, |Δloss| ≤ 1e-5, token agreement 100%.
  A failure is recorded as a failed scenario, never patched over.
- The observation contract (which tensors cross the emulated boundary, their
  sizes, and the per-step serialized byte totals) is itself a recorded output —
  it is the traffic/metadata inventory the later attested stages must match.

## Stage B — real CKKS encrypted projection (milestone 3, FHE half)

- Backend: TenSEAL 0.3.18 (Microsoft SEAL CKKS) in a separate track environment
  (`.venv-tee`; the main locked environment is untouched). Backend, parameters,
  and versions are recorded per record.
- Measured operation: one remote-side linear projection of the boundary tensor —
  per-token 256-vectors through the 256→1024 weight map of the trained
  checkpoint's remote block — at n_tokens ∈ {1, 32, 128}, CKKS
  poly_modulus_degree 8192, coeff_mod_bit_sizes [60, 40, 40, 60], scale 2^40.
- Accounting, all recorded: key generation, encryption (trusted side),
  serialized ciphertext bytes (the transfer), homomorphic compute (untrusted
  side), decryption plus decrypt-then-encrypt refresh (trusted side), end-to-end
  latency, and numerical error versus the fp32 plaintext reference. The ordinary
  plaintext CPU reference time is a distinct record; nothing is pooled with it.
- These are real FHE measurements of one encrypted projection at the boundary
  scale. They are not secure-serving latencies (no TEE, no attestation), not
  end-to-end inference times, and not a defense evaluation.

## Claim boundary

Engineering diagnostics with `scientific_evidence: false`. No confidentiality,
integrity, or attestation claim is made; `hardware_attested: false` everywhere.
The D1/D3 pilot records are untouched; this track answers a deployment-cost
question, not the causal remote-learning estimand.