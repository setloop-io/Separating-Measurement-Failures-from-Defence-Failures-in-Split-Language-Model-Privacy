"""Freeze-boundary, freeze-record binding, gates, and tiny end-to-end for the pilot."""
from copy import deepcopy
import json
from pathlib import Path
import shutil

import jsonschema
import pytest
import torch
import yaml

from p4d import freeze, pilot_runs
from p4d import pilot_runs as pr
from p4d import seed_audit
from p4d.experiment import ROOT
from p4d.pilot_analysis import analyze
from p4d.qualification_runs import BUDGET, CELLS, OPTIMIZER, SPLIT

from test_warmup_budget import synthetic_resource


@pytest.fixture(autouse=True)
def one_thread():
    old = torch.get_num_threads()
    torch.set_num_threads(1)
    yield
    torch.set_num_threads(old)


def valid_config():
    return {"protocol_id": pr.PROTOCOL_ID, "cohort": "exploratory", "status": "frozen",
            "full_budget": True, "device": "cpu", "cpu_threads": 2,
            "seeds": list(pr.SEEDS), "cells": deepcopy(CELLS), "modes": list(pr.MODES),
            "freeze_record": "experiments/freeze/p4-defense-pilot-1.0.json",
            "split": dict(SPLIT),
            "backbone": {"vocab_size": 256, "d_model": 256, "n_heads": 8, "n_layers": 8,
                         "d_ff": 1024, "max_seq_len": 128, "init_std": 0.02},
            "data": {"path": "data/raw/gutenberg_p4.txt",
                     "sha256": "af3d0245c0ec27d7021f5fd29256bc845bb20cf9c562b37bbe23663b6ebe7436",
                     "documents": "data/gutenberg_p4.manifest.json",
                     "sequence_length": 128, "batch_size": 32},
            "optimizer": deepcopy(OPTIMIZER), **deepcopy(BUDGET)}


def test_validate_accepts_the_frozen_exploratory_configuration():
    assert pr.validate(valid_config()) == {"expected_runs": 66, "full_budget": True,
                                           **pr.SCIENTIFIC_FLAGS}


def test_committed_config_matches_the_protocol_constants():
    cfg = yaml.safe_load((ROOT / "experiments/configs/pilot.yaml").read_text())
    assert pr.validate(cfg) == {"expected_runs": 66, "full_budget": True, **pr.SCIENTIFIC_FLAGS}


@pytest.mark.parametrize("change", [
    lambda c: c.update(protocol_id="p4-qualification-0.1"),
    lambda c: c.update(cohort="calibration"),
    lambda c: c.update(cohort="engineering"),
    lambda c: c.update(status="engineering_ready"),
    lambda c: c.update(seeds=[419101, 419102]),
    lambda c: c.update(seeds=[411101, 411102]),
    lambda c: c.update(cells=[]),
    lambda c: c.update(cells=[{"id": "d9-q9", "q_bits": 9, "defense": {"name": "none"}}]),
    lambda c: c.update(cells=[c["cells"][0], dict(c["cells"][0])]),
    lambda c: c.update(modes=["trained"]),
    lambda c: c["split"].update(width=128),
    lambda c: c["optimizer"].update(lr=0.001),
    lambda c: c.update(train_steps=2001),
    lambda c: c.update(refit_interval=500),
    lambda c: c.update(probe_windows=8192),
    lambda c: c.update(property_matched_nulls=8),
    lambda c: c.update(structure_matched_nulls=2),
    lambda c: c.update(outer_null_repeats=8),
    lambda c: c.update(mlp_hidden=32),
    lambda c: c.update(null_band=0.05),
    lambda c: c["data"].update(sha256="0" * 64),
    lambda c: c["data"].pop("documents"),
    lambda c: c.update(freeze_record=""),
    lambda c: c.pop("freeze_record"),
])
def test_validate_rejects_any_protocol_deviation(change):
    cfg = valid_config()
    assert pr.validate(cfg)["expected_runs"] == 66
    change(cfg)
    with pytest.raises(ValueError):
        pr.validate(cfg)


def test_validate_only_seed_subsets():
    cfg = valid_config()
    assert pr.validate(cfg, only_seeds=[411101])["expected_runs"] == 22
    assert pr.validate(cfg, only_seeds=[411101, 411103])["expected_runs"] == 44
    assert pr.validate(cfg, only_seeds=pr.SEEDS)["expected_runs"] == 66
    with pytest.raises(ValueError, match="subset"):
        pr.validate(cfg, only_seeds=[419101])
    with pytest.raises(ValueError, match="subset"):
        pr.validate(cfg, only_seeds=[])


def test_validate_accepts_reduced_cells_only_without_full_budget():
    cfg = valid_config()
    cfg["full_budget"] = False
    cfg["cells"] = deepcopy(CELLS[:2])
    cfg["seeds"] = [411101, 411102]
    assert pr.validate(cfg)["expected_runs"] == 2 * (2 * 3 + 1)
    cfg["full_budget"] = True
    with pytest.raises(ValueError, match="three pilot seeds"):
        pr.validate(cfg)


def tiny_pilot_config(tmp_path):
    return {"protocol_id": pr.PROTOCOL_ID, "cohort": "exploratory", "status": "frozen",
            "full_budget": False, "device": "cpu", "cpu_threads": 1,
            "seeds": [411101, 411102], "cells": deepcopy(CELLS[:2]), "modes": list(pr.MODES),
            "freeze_record": str(tmp_path / "freeze.json"),
            "split": dict(SPLIT),
            "backbone": {"vocab_size": 256, "d_model": 32, "n_heads": 1, "n_layers": 6,
                         "d_ff": 64, "max_seq_len": 8, "init_std": 0.02},
            "data": {**synthetic_resource(tmp_path), "sequence_length": 8, "batch_size": 4},
            "optimizer": {"lr": 0.002, "min_lr": 0.0002, "warmup_steps": 1,
                          "weight_decay": 0.1, "grad_clip": 1.0, "betas": [0.9, 0.95]},
            "train_steps": 4, "basis_windows": 16, "refit_interval": 2, "probe_windows": 32,
            "eval_batch_size": 4, "panel_batch_size": 8, "capture_batch_size": 8,
            "property_matched_nulls": 2, "structure_matched_nulls": 2, "outer_null_repeats": 2,
            "positive_doses": [.5, 2.], "ridge_penalty": 1., "null_band": .02,
            "property_positive_floor": .10, "structure_positive_floor": .02,
            "mlp_hidden": 8, "mlp_lr": 3e-3, "mlp_row_batch": 64}


def make_test_freeze(cfg, config_path, tmp_path):
    audit = seed_audit.audit_seeds(ROOT, cohorts=("pilot",), exclude_prefix="p4-pilot-")
    assert audit["passed"], [f for f in audit["findings"] if not f["passed"]]
    audit_path = tmp_path / "seed_audit.json"
    audit_path.write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n")
    verification_path = tmp_path / "verification.json"
    verification_path.write_text(json.dumps({"placeholder_verification": True}) + "\n")
    doc_path = tmp_path / "PILOT_FREEZE.md"
    doc_path.write_text("# synthetic freeze document for tests\n")
    return freeze.make_freeze_record(config_path, doc_path, audit_path,
                                     verification_path, cfg["freeze_record"])


@pytest.fixture
def tiny_freeze(tmp_path):
    cfg = tiny_pilot_config(tmp_path)
    config_path = tmp_path / "pilot.yaml"
    config_path.write_text(yaml.safe_dump(cfg))
    record = make_test_freeze(cfg, config_path, tmp_path)
    return cfg, config_path, record


def test_freeze_record_binds_config_protocol_seeds_corpus_and_head(tiny_freeze):
    cfg, config_path, record = tiny_freeze
    bound = freeze.require_freeze_record(cfg, config_path)
    assert bound["freeze_id"] == "p4-defense-pilot-1.0"
    assert bound["seeds"] == {"pilot": cfg["seeds"]}
    assert bound["seed_audit"]["passed"] is True
    assert bound["amendments"] == []


@pytest.mark.parametrize("tamper", [
    lambda r: r.update(config_sha256="0" * 64),
    lambda r: r.update(protocol_id="p4-qualification-0.1"),
    lambda r: r.update(seeds={"pilot": [411101, 411103]}),
    lambda r: r.update(corpus_sha256="0" * 64),
    lambda r: r.update(code_commit="0" * 40),
])
def test_freeze_record_tampering_refuses_execution(tiny_freeze, tamper):
    cfg, config_path, record = tiny_freeze
    record_path = Path(cfg["freeze_record"])
    tampered = json.loads(record_path.read_text())
    tamper(tampered)
    record_path.write_text(json.dumps(tampered, indent=2) + "\n")
    with pytest.raises(ValueError, match="differ"):
        freeze.require_freeze_record(cfg, config_path)


def test_freeze_record_requires_file_and_key(tmp_path):
    cfg = tiny_pilot_config(tmp_path)
    with pytest.raises(ValueError, match="absent"):
        freeze.require_freeze_record(cfg, tmp_path / "pilot.yaml")
    del cfg["freeze_record"]
    with pytest.raises(ValueError, match="name its freeze record"):
        freeze.require_freeze_record(cfg, tmp_path / "pilot.yaml")


def test_freeze_check_rejects_wrong_head(tiny_freeze, monkeypatch):
    cfg, config_path, record = tiny_freeze
    monkeypatch.setattr(freeze, "git_head", lambda *a, **k: "f" * 40)

    def git_not_ancestor(args):
        class Result:
            returncode = 1 if "merge-base" in args else 0
            stdout = ""
        return Result()
    monkeypatch.setattr(freeze, "_git", git_not_ancestor)
    with pytest.raises(ValueError, match="commit"):
        freeze.require_freeze_record(cfg, config_path)


def test_freeze_check_rejects_source_changes_after_freeze(tiny_freeze, monkeypatch):
    cfg, config_path, record = tiny_freeze
    monkeypatch.setattr(freeze, "git_head", lambda *a, **k: "0" * 40)

    def git_dirty_descendant(args):
        class Result:
            returncode = 0 if "merge-base" in args else 1
            stdout = ""
        return Result()
    monkeypatch.setattr(freeze, "_git", git_dirty_descendant)
    with pytest.raises(ValueError, match="amendment"):
        freeze.require_freeze_record(cfg, config_path)


def test_freeze_check_accepts_clean_descendant_of_the_freeze(tiny_freeze, monkeypatch):
    cfg, config_path, record = tiny_freeze
    monkeypatch.setattr(freeze, "git_head", lambda *a, **k: "0" * 40)

    def git_clean_descendant(args):
        class Result:
            returncode = 0
            stdout = ""
        return Result()
    monkeypatch.setattr(freeze, "_git", git_clean_descendant)
    assert freeze.require_freeze_record(cfg, config_path)["freeze_id"] == record["freeze_id"]


def test_freeze_generator_refuses_a_failed_seed_audit(tmp_path):
    cfg = tiny_pilot_config(tmp_path)
    config_path = tmp_path / "pilot.yaml"
    config_path.write_text(yaml.safe_dump(cfg))
    audit = seed_audit.audit_seeds(ROOT, cohorts=("pilot",), exclude_prefix="p4-pilot-")
    audit["passed"] = False
    audit_path = tmp_path / "seed_audit.json"
    audit_path.write_text(json.dumps(audit, indent=2) + "\n")
    verification_path = tmp_path / "verification.json"
    verification_path.write_text(json.dumps({"placeholder": True}) + "\n")
    doc_path = tmp_path / "doc.md"
    doc_path.write_text("# doc\n")
    with pytest.raises(ValueError, match="refusing to freeze"):
        freeze.make_freeze_record(config_path, doc_path, audit_path,
                                  verification_path, tmp_path / "freeze.json")


def cleanup(label):
    shutil.rmtree(ROOT / "outputs/runs" / label, ignore_errors=True)
    for stale in (ROOT / "experiments/manifests").glob(f"p4-{label}-*.json"):
        stale.unlink()


def test_execution_time_seed_audit_failure_blocks_the_campaign(tmp_path, monkeypatch):
    label = "pytest-pilot-audit"
    cleanup(label)
    config_path = ROOT / "experiments/configs" / f"{label}.yaml"
    try:
        cfg = tiny_pilot_config(tmp_path)
        cfg["freeze_record"] = str(tmp_path / "freeze.json")
        config_path.write_text(yaml.safe_dump(cfg))
        make_test_freeze(cfg, config_path, tmp_path)
        monkeypatch.setattr(pilot_runs, "audit_seeds", lambda *a, **k: {
            "passed": False,
            "findings": [{"check": "pilot vs executed manifests", "overlap": [411101],
                          "passed": False}]})
        with pytest.raises(ValueError, match="Seed audit failed"):
            pr.run(config_path, label=label)
        assert not (ROOT / "outputs/runs" / label).exists()
    finally:
        cleanup(label)
        config_path.unlink(missing_ok=True)


def test_run_schema_v2_accepts_the_exploratory_cohort():
    schema = json.loads((ROOT / "experiments/schemas/run_manifest.schema.json").read_text())
    manifest = {"schema_version": "p4-run-0.2", "run_id": "p4-x-d0-q8-trained-s411101",
                "protocol_id": "p4-defense-pilot-1.0", "cohort": "exploratory",
                "scientific_evidence": True, "seed": 411101, "mode": "trained",
                "cell": "d0-q8", "git_commit": None, "source_tree_sha256": "0" * 64,
                "source_record": "outputs/runs/x/source.json", "corpus_sha256": "0" * 64,
                "matrix_sha256": "0" * 64,
                "freeze_record": "experiments/freeze/p4-defense-pilot-1.0.json",
                "inputs": {}, "started_at": "t", "finished_at": "t",
                "status": "completed", "artifacts": []}
    jsonschema.validate(manifest, schema)


def test_tiny_pilot_campaign_end_to_end(tmp_path, monkeypatch):
    label = "pytest-pilot"
    cleanup(label)
    config_path = ROOT / "experiments/configs" / f"{label}.yaml"
    manifests = ROOT / "experiments/manifests"
    # Hermetic audit root: the real pilot campaign has (correctly) burned the
    # pilot seeds for production; the mechanics test isolates the registry only.
    isolated = tmp_path / "audit_root" / "experiments"
    isolated.mkdir(parents=True)
    (isolated / "manifests").mkdir()
    (isolated / "seed_registry.json").write_text(
        (ROOT / "experiments/seed_registry.json").read_text())
    real_audit = pr.audit_seeds
    monkeypatch.setattr(pr, "audit_seeds",
                        lambda root, cohorts, exclude_prefix: real_audit(
                            tmp_path / "audit_root", cohorts=cohorts,
                            exclude_prefix=exclude_prefix))
    try:
        cfg = tiny_pilot_config(tmp_path)
        cfg["freeze_record"] = str(tmp_path / "freeze.json")
        config_path.write_text(yaml.safe_dump(cfg))
        record = make_test_freeze(cfg, config_path, tmp_path)
        assert pr.validate(cfg) == {"expected_runs": 14, "full_budget": False,
                                    **pr.SCIENTIFIC_FLAGS}
        summary = pr.run(config_path, label=label)
        assert summary["completed"] == summary["expected_runs"] == 14
        assert summary["failed"] == 0
        assert summary["cohort"] == "exploratory" and summary["scientific_evidence"] is True
        assert summary["privacy_outcome"] == "undetermined"
        assert summary["freeze_record"] == cfg["freeze_record"]

        campaign_dir = ROOT / "outputs/runs" / label
        schema = json.loads((ROOT / "experiments/schemas/run_manifest.schema.json").read_text())
        for seed in (411101, 411102):
            trusted_ref, remote_ref = {}, {}
            jobs = [("all-local", "all_local")]
            jobs += [(cell["id"], mode) for cell in cfg["cells"] for mode in pr.MODES]
            for cell_id, mode in jobs:
                run_id = f"p4-{label}-{cell_id}-{mode}-s{seed}"
                manifest = json.loads((manifests / f"{run_id}.json").read_text())
                jsonschema.validate(manifest, schema)
                assert manifest["schema_version"] == "p4-run-0.2"
                assert manifest["cohort"] == "exploratory"
                assert manifest["scientific_evidence"] is True
                assert manifest["freeze_record"] == cfg["freeze_record"]
                assert manifest["status"] == "completed"
                names = {a["path"].split("/")[-1] for a in manifest["artifacts"]}
                assert {"metrics.json", "curve.json", "resolved.json", "checkpoint.pt"} <= names
                metrics = json.loads((campaign_dir / run_id / "metrics.json").read_text())
                assert metrics["cohort"] == "exploratory"
                assert metrics["scientific_evidence"] is True
                assert metrics["privacy_outcome"] == "undetermined"
                if mode == "all_local":
                    assert "captures.pt" not in names
                    continue
                assert "captures.pt" in names
                trusted_ref.setdefault("sha", metrics["trusted_initial_sha256"])
                assert metrics["trusted_initial_sha256"] == trusted_ref["sha"]
                if mode != "removed_remote":
                    remote_ref.setdefault("sha", metrics["remote_initial_sha256"])
                    assert metrics["remote_initial_sha256"] == remote_ref["sha"]
                if mode == "frozen_random":
                    assert metrics["remote_initial_sha256"] == metrics["remote_final_sha256"]
                cell = next(c for c in cfg["cells"] if c["id"] == cell_id)
                if cell["defense"]["name"] == "property_noise":
                    assert [e["step"] for e in metrics["basis_log"]] == [0, 2, 4]
                else:
                    assert metrics["basis_log"] is None
                for target in ("property", "structure"):
                    controls = metrics["controls"][target]
                    assert len(controls["no_signal_trials"]) == 2
                    assert [d["dose"] for d in controls["positive_controls"]] == [0., .5, 2.]
                    verdict = metrics["binding_qualification"][target]
                    assert isinstance(verdict["qualified"], bool) and verdict["reason"]

        verified = analyze(label)
        assert verified["cohort"] == "exploratory" and verified["scientific_evidence"] is True
        assert verified["privacy_outcome"] == "undetermined"
        assert verified["completed"] == 14 and verified["failed"] == 0
        assert verified["freeze_record"] == cfg["freeze_record"]
        assert verified["candidate_scores_recomputed"] and verified["split_runs_recomputed"] == 12
        assert (campaign_dir / "report.md").is_file()
        assert len(verified["cell_verdicts"]) == 2
        for verdict in verified["cell_verdicts"]:
            assert isinstance(verdict["pilot_eligible"], bool) and verdict["reason"]
            utility = verdict["utility"]
            assert set(utility["delta_u_per_seed"]) == {411101, 411102}
            assert utility["t_critical"] > 0 and utility["interval_rule"]
            assert isinstance(utility["passed"], bool)
            assert isinstance(verdict["gain"]["all_pairs_positive"], bool)
            assert verdict["privacy"]["status"] in ("passed", "failed", "undetermined")
            assert isinstance(verdict["privacy"]["undetermined_coverage"], list)
            assert "removed_minus_trained_per_seed" in verdict["removed_remote_comparison"]
        assert len(verified["advantage_table"]) == 12 * 2
        for row in verified["advantage_table"]:
            assert row["target"] in ("property", "structure")
            assert row["mode"] in pr.MODES
            assert isinstance(row["binding_qualified"], bool)
    finally:
        cleanup(label)
        config_path.unlink(missing_ok=True)
