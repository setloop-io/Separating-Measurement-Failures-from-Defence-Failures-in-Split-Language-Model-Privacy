"""Validation, loopback correctness, contract accounting, and CKKS stage boundaries."""
import json

import numpy as np
import pytest
import torch
import yaml
from torch import nn

from pcr.model import BackboneConfig
from pcr.split import SplitConfig
from pcr.train import build_initialized_model

from p4d import tee_fhe_scenarios as tf
from p4d.experiment import ROOT
from p4d.model import attach_defense
from p4d.warmup_scenarios import text_panel


@pytest.fixture(autouse=True)
def one_thread():
    old = torch.get_num_threads()
    torch.set_num_threads(1)
    yield
    torch.set_num_threads(old)


def valid_config():
    return {"protocol_id": tf.PROTOCOL_ID, "kind": "tee_fhe", "cohort": "engineering",
            "status": "engineering_ready", "full_budget": True, "device": "cpu",
            "cpu_threads": 2, "seeds": [410801],
            "checkpoint_manifest": "experiments/manifests/p4-qualification-20260922-a-d0-q8-trained-s419101.json",
            "panels_manifest": "experiments/manifests/p4-pilot-20260922-a-d0-q8-trained-s411101.json",
            **{k: (list(v) if isinstance(v, list) else v) for k, v in tf.BUDGET.items()}}


def test_validate_accepts_the_protocol_configuration_without_source_files():
    assert tf.validate(valid_config()) == {"expected_scenarios": 2, "full_budget": True,
                                           **tf.FLAGS, "hardware_attested": False}


def test_committed_config_matches_the_protocol_constants():
    cfg = yaml.safe_load((ROOT / "experiments/configs/tee_fhe_diagnostics.yaml").read_text())
    assert tf.validate(cfg) == {"expected_scenarios": 2, "full_budget": True,
                                **tf.FLAGS, "hardware_attested": False}


@pytest.mark.parametrize("change", [
    lambda c: c.update(kind="routing"),
    lambda c: c.update(cohort="calibration"),
    lambda c: c.update(status="frozen"),
    lambda c: c.update(protocol_id="p4-tee-fhe-0.1"),
    lambda c: c.update(seeds=[410501]),
    lambda c: c.update(seeds=[410801, 410801]),
    lambda c: c.update(checkpoint_manifest=""),
    lambda c: c.pop("panels_manifest"),
    lambda c: c.update(logit_atol=1e-3),
    lambda c: c.update(loss_atol=1e-4),
    lambda c: c.update(stage_a_windows=256),
    lambda c: c.update(stage_b_n_tokens=[1, 32]),
    lambda c: c.update(stage_b_repetitions=3),
    lambda c: c.update(ckks_poly_modulus_degree=4096),
    lambda c: c.update(ckks_coeff_mod_bit_sizes=[60, 40, 60]),
    lambda c: c.update(ckks_global_scale_exp=41),
])
def test_validate_rejects_any_protocol_deviation(change):
    cfg = valid_config()
    assert tf.validate(cfg)["expected_scenarios"] == 2
    change(cfg)
    with pytest.raises(ValueError):
        tf.validate(cfg)


def fixture_model():
    cfg = BackboneConfig(vocab_size=256, d_model=32, n_heads=1, n_layers=4, d_ff=64,
                         max_seq_len=8, init_std=0.02)
    model = build_initialized_model(cfg, "frozen_random",
                                    SplitConfig(start=1, span=2, width=32, q_bits=8),
                                    42, "tee-fhe-test")
    return attach_defense(model, {"name": "none"})


def fixture_panel(n=16):
    rng = np.random.default_rng(31)
    corpus = torch.tensor(rng.choice(np.array(list(b"A story!?., ") + [10], dtype=np.uint8), 8000))
    return text_panel(corpus, 0, 4000, n, 8, 32)


def tiny_cfg():
    return {"logit_atol": 1e-4, "loss_atol": 1e-5}


def test_stage_a_loopback_is_bitwise_and_contract_accounts_every_call():
    model = fixture_model()
    panel = fixture_panel()
    correctness, contract, outputs = tf.stage_a_evaluate(
        model, panel["tokens"], panel["next_tokens"], 4, tiny_cfg(), torch.device("cpu"))
    assert correctness["passed"]
    # The fp32 serialize/deserialize loopback is bitwise: exactly zero deviation.
    assert correctness["max_abs_logit_deviation"] == 0.0
    assert correctness["abs_loss_delta"] == 0.0
    assert correctness["token_agreement"] == 1.0
    assert torch.equal(outputs["reference_logits"], outputs["emulated_logits"])
    expected_operators = sum(1 for name, m in model.named_modules()
                             if isinstance(m, nn.Linear) and name != "head")
    events, totals = contract["events"], contract["totals"]
    assert totals["total_calls"] == len(events) == expected_operators * 2 * 4
    assert totals["steps"] == 4
    assert totals["total_serialized_bytes"] == sum(e["serialized_bytes"] for e in events)
    assert len(totals["per_operator"]) == expected_operators * 2
    assert all(e["serialized_bytes"] > 0 and e["dtype"] == "torch.float32" for e in events)
    assert {e["step"] for e in events} == {0, 1, 2, 3}
    recomputed = {}
    for e in events:
        key = (e["operator"], e["direction"])
        recomputed.setdefault(key, {"calls": 0, "serialized_bytes": 0})
        recomputed[key]["calls"] += 1
        recomputed[key]["serialized_bytes"] += e["serialized_bytes"]
    recorded = {(row["operator"], row["direction"]): {"calls": row["calls"],
                                                      "serialized_bytes": row["serialized_bytes"]}
                for row in totals["per_operator"]}
    assert recomputed == recorded


def test_stage_a_hooks_are_removed_and_do_not_change_model_numerics():
    model = fixture_model()
    panel = fixture_panel(8)
    with torch.no_grad():
        before = model(panel["tokens"])
    tf.stage_a_evaluate(model, panel["tokens"], panel["next_tokens"], 4, tiny_cfg(),
                        torch.device("cpu"))
    assert not any(m._forward_hooks or m._forward_pre_hooks for m in model.modules())
    with torch.no_grad():
        after = model(panel["tokens"])
    assert torch.equal(before, after)


def test_stage_a_frozen_check_fails_on_corrupted_transport(monkeypatch):
    model = fixture_model()
    panel = fixture_panel(8)
    real_pack = tf.pack_tensor

    def corrupting_pack(tensor):
        packet = bytearray(real_pack(tensor))
        packet[-1] ^= 0x80  # sign bit of the last little-endian fp32 payload value
        return bytes(packet)

    monkeypatch.setattr(tf, "pack_tensor", corrupting_pack)
    correctness, _, _ = tf.stage_a_evaluate(model, panel["tokens"], panel["next_tokens"], 4,
                                            tiny_cfg(), torch.device("cpu"))
    assert not correctness["passed"]
    assert correctness["max_abs_logit_deviation"] > tiny_cfg()["logit_atol"]


def tiny_ckks_cfg():
    # Protocol CKKS constants (scale must match the 40-bit levels for exact mm
    # semantics); only matrix/n_tokens/repetition sizes shrink for the test.
    return {"stage_b_n_tokens": [1, 4], "stage_b_repetitions": 2,
            "ckks_poly_modulus_degree": 8192, "ckks_coeff_mod_bit_sizes": [60, 40, 40, 60],
            "ckks_global_scale_exp": 40}


def test_stage_b_real_ckks_projection_accounting():
    ts = pytest.importorskip("tenseal", reason="TenSEAL lives only in the .venv-tee track env")
    generator = torch.Generator().manual_seed(7)
    weight = torch.randn(16, 4, generator=generator)  # width 4 -> 4*width
    x_window = torch.randn(8, 4, generator=generator)
    records = tf.stage_b(weight, x_window, tiny_ckks_cfg())
    assert records["backend"] == "tenseal" and records["backend_version"]
    assert records["timing_scope"] == tf.TIMING_SCOPE
    assert [r["n_tokens"] for r in records["results"]] == [1, 4]
    for result in records["results"]:
        assert result["reference_seconds_plaintext_cpu"] >= 0
        assert len(result["repetitions"]) == 2
        for rep in result["repetitions"]:
            assert rep["serialized_ciphertext_bytes"] > 0
            for phase in ("context_keygen_seconds", "encryption_seconds",
                          "homomorphic_matmul_seconds", "decryption_seconds",
                          "decrypt_reencrypt_refresh_seconds", "end_to_end_seconds"):
                assert np.isfinite(rep[phase]) and rep[phase] >= 0
            assert np.isfinite(rep["max_abs_error"]) and np.isfinite(rep["relative_error"])
            assert rep["max_abs_error"] < 1e-2  # exact mm semantics at the protocol scale
