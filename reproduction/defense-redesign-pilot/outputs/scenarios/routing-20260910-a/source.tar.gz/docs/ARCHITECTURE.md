# Boundary architecture and implementation status

Design revision: 2026-09-10. The implemented D0/D1/D3 paths support engineering
diagnostics. Scientific calibration and pilot execution are separate milestones.

```mermaid
flowchart LR
  subgraph Trusted input side
    X[Input bytes] --> P[Causal prefix]
    P --> E[LayerNorm and linear encoder]
    E --> D[D0 identity or D1 property noise]
    D --> Q[Per-token forward quantization]
  end
  Q -->|released values and public scale/minimum| R[Remote causal surrogate]
  R -->|returned values| C[Trusted linear decoder]
  P -->|trusted residual| A[Add residual]
  C --> A
  A --> S[Trusted causal suffix and private loss]
```

The reference uses eight byte-level transformer blocks of width 256 and replaces
blocks [2,6) with one remote block at latent width 256. The local residual is
retained, as in the inherited architecture. Causal gain is measured against the
identically initialized frozen remote, not inferred from nominal replaced depth.
The removed comparison retains the encoder/decoder around an identity bypass;
the all-local comparison keeps the original eight blocks.

## Implemented treatments

| Path | Release | Current implementation |
|---|---|---|
| D0 | Q8(z) | Fresh Paper 4 anchor |
| D1 | Q8(z + εB), ε sampled once per sequence/release | Calibrated row-orthonormal B, noise active during training and evaluation |
| D3 | Qq(z), q in {1,2,3} for the draft pilot | Same encoder, width, and surrogate topology as D0 |

Here z has shape (batch, sequence, 256), B has shape (rank, 256), and
ε has shape (batch, 1, rank) with independent N(0,σ²) entries. Shared sequence
noise perturbs the pooled mean; independent token noise would have a mean variance
decreasing with sequence length. Neither construction proves leakage removal.
Punctuation is the initial basis target. Ridge coefficients are rank-reduced by
SVD to produce orthonormal directions. No calibrated basis means a hard error,
not a silently disabled defense. A zero noise dose is the identity control.

P0 fits the basis on the same model's initialized encoder using separate
calibration text. This is only a wiring diagnostic. The scientific pilot must
specify a common pre-defense calibration/checkpoint procedure that preserves the
trained/frozen intervention, the basis freeze/update schedule, and encoder drift
checks. Fitting an unrelated seed's encoder is not coordinate alignment. The
draft runner deliberately cannot execute a scientific cohort with the P0 policy.

The Paper 4 quantizer computes min/max only across one token's latent dimensions.
Paper 3's per-tensor statistics can couple positions, so the quantizer is an
explicit mechanism change requiring fresh controls. The public minimum and scale
are captured. Code packing is not implemented: byte counts estimate a packed
forward payload plus metadata and fp32 return/backward paths. There is no network
transport or latency benchmark in P0.

## Observations and randomness

| Capture key | Mathematical value | Direction relative to remote |
|---|---|---|
| `forward_values` | Released z | Inbound |
| `returned_values` | Surrogate output y | Outbound |
| `inbound_gradients` | dL/dy | Inbound from trusted loss computation |
| `outbound_gradients` | dL/dz | Outbound toward trusted encoder |
| `quantizer_metadata` | Per-token minimum and scale | Inbound with hypothetical packed codes |

These captures preserve values as used by the simulated computation. The probe
adapters consume the released forward values without an additional quantization.
Private input and actual next-byte labels are offline evaluator annotations;
their presence in local captures does not mean they are transmitted to the remote.
The final next-byte label is taken from the corpus target, not a wrapped first byte.

Defense noise has a private generator. Evaluation and capture save and restore
its state and use distinct stream seeds. Attacker training preserves global
Torch RNG state. Logging must not change subsequent training-noise realizations.
Remote checksums establish update integrity only; they do not audit state leakage.

The implemented property ridge probe and next-byte class MLP are **unqualified
Paper 4 adapters**. Their same-model, disjoint-text fitting removes one coordinate
transfer ambiguity but changes the instrument. Positive/null controls and attack
budgets must be frozen and qualified anew for the actual target/channel/defense.

## Subsequent architecture work

D2 requires explicit optimizer ownership: minimize task loss minus λ times the
adversary loss for the trusted encoder, minimize task loss for the surrogate and
decoder, and minimize adversary loss for the training heads. λ=0 and matched
extra-compute controls are required. Evaluation heads must be independent of the
training adversaries. This minimax extension is not yet implemented.

D4 needs a frozen dimension allocation and calibration policy. D5 is only an
invariance diagnostic: permutation preserves the pooled mean and can disturb
causal computation. An active gradient-manipulation attacker needs its own
intervention, budgets, utility accounting, and qualification. None of these
pending extensions is represented by a stronger passive MLP alone.

See [the protocol](PREREGISTRATION.md) for claim prerequisites and
[the research audit](../outputs/deep_research_audit.md) for literature corrections.

A separate [TEE–FHE deployment proposal](TEE_FHE_TRACK.md), motivated by the
new Bifrost source note, studies a different trust boundary and starts with
same-checkpoint inference. It is not implemented by the D0/D1/D3 adapters above.
