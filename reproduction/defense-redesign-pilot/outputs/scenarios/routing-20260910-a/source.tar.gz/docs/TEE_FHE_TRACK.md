# Proposed TEE–FHE deployment track

Status: **secure deployment is a design proposal; a plaintext routing diagnostic is
implemented under [SCENARIO_PROTOCOL.md](SCENARIO_PROTOCOL.md)**. Added 2026-09-10
in response to [the Bifrost research lead](../TEE-FTE.md). This extends the research
roadmap without changing the D1/D3 pilot or interpreting its P0 diagnostics as science.

## Research question and distinct estimands

Under an explicitly accepted CPU-TEE trust assumption, what useful work can an
untrusted accelerator perform on encrypted state, at what measured end-to-end cost?
This is our proposed systems question. It is separate from learning a replacement
module whose utility is compared against a frozen-random surrogate.

For an inference experiment, hold checkpoint and task fixed. Compare deployment
loss with plaintext execution of that same checkpoint, and separately report the
checkpoint's replacement penalty against the original all-local backbone. Exact
execution of a surrogate would not erase the latter penalty. Measure numerical
error and task loss; matching a few generated tokens is insufficient to establish
equivalence on held-out data.

An accelerator executing fixed linear maps has no trained/frozen learning contrast.
Report remote work using measured operator placement, resource use, and ablations
that move the same operators to the trusted CPU. Do not assign this accelerator a
positive G_R by reusing the split-training definition.

## Proposed execution boundary

```mermaid
flowchart LR
  C[Client] -->|channel bound to verified attestation| T[Trusted CPU runtime]
  T --> K[Key handling and private state]
  T --> N[Nonlinear operators and control]
  T --> E[Encrypt selected linear inputs]
  E -->|ciphertexts| A[Untrusted accelerator linear evaluation]
  A -->|ciphertexts| V[Trusted validation and decryption]
  V --> T
  T -->|protected response| C
```

This is a proposed boundary to implement and audit, not evidence that our current
Python environment provides it. Trace request ingress and response egress, key
provisioning, attestation verification, FHE parameters, device buffers, telemetry,
crash dumps, and the termination point of each protected channel. A host-facing
API must not silently terminate the confidential client payload outside the
declared trusted runtime.

Keep confidentiality and correct execution as separate obligations. Specify how
outputs are checked and bound to a request and step, how malformed responses are
handled, and which replay/rollback threats remain omitted. An encrypted payload
alone is not our evidence of a correctly executed computation. Test declared
malicious-server interventions before any positive defense claim.

## Prospective comparison matrix

| Arm | Purpose | Required evidence |
|---|---|---|
| Plaintext functional reference | Same-checkpoint correctness and loss | Exact model, tokenizer, precision, inputs and outputs |
| CPU TEE-only | Trusted execution performance baseline | Actual attestation and hardware; measured protected ingress/egress |
| Hybrid unified | Selected encrypted linear operations | Real FHE backend, serialized traffic, trusted/untrusted memory inventory |
| Hybrid with TEE prefill | Phase-placement ablation | Same decode backend and checkpoint; separate prefill and decode timing |
| Pure-FHE reference, if obtainable | Cryptographic execution comparison | Label measured deployment versus an explicit projection; never pool them |

Keep prompt length, output length, batch size, cache state, and hardware fixed
within a paired comparison. Report cold setup and warm serving separately. Include
time to first token, per-token decode, total latency, throughput, serialized bytes,
trusted CPU memory, accelerator memory, encoded-weight residency, and failure rate.
Prefill savings must not be reported as faster decode kernels. Choose concrete
workloads and repetitions before collecting comparative outcomes.

No latency result is currently imported as a Paper 4 measurement. A local plaintext
emulation may test routing and tensor shapes, but its record must explicitly say
`hardware_attested: false` and cannot support an enclave confidentiality claim.
Likewise, simulated encrypted buffers cannot supply a real-FHE performance result.

## Why training needs a new protocol

For a linear layer y=xW, reverse-mode training computes dW=xᵀ(dL/dy) and
dL/dx=(dL/dy)Wᵀ. Specify where each operand is plaintext or ciphertext, who owns
the updated parameters, and where optimizer moments persist. If x and dL/dy are
both confidential, a design must handle their joint computation rather than assume
the cost of fixed public-weight inference. Publishing updated weights also becomes
a new disclosure decision requiring an explicit adversary and audit.

For a training extension, preserve the matched trained/frozen/removed/all-local
controls and calibrate attacks on the actual accessible state. The current gradient
captures can inform the inventory; their existence does not prove an encrypted
backward path, attested execution, or evaluated active resistance. Do not add a
TEE label to the D1/D3 runner and treat it as an implemented mechanism.

## Milestones before experiment creation

1. Identify an attributable artifact, license, fixed revision, build instructions,
   dependencies, and attestation path. Otherwise label any new implementation as
   independently inspired by the design, not a reproduction of Bifrost.
2. Freeze a small same-checkpoint inference correctness test and the proposed
   observation/metadata contract. Resolve numerical tolerances and output checking.
3. Specify actual TEE-capable hardware and a real FHE backend; measure one encrypted
   projection with transfer and trusted processing included. Retain an ordinary
   CPU reference and an attested CPU-only baseline as distinct records.
4. Freeze the serving matrix and run phase-placement comparisons. Archive the
   full serialized observation view and explicitly audit exposed metadata.
5. Consider training only after defining backward arithmetic, state ownership,
   parameter confidentiality, active integrity, and matched causal controls in a
   separate protocol and cohort.

The diagnostic serializes real fp32 tensors through an in-process loopback and checks
three operator-placement policies against the same initialized model. It recomputes
the full prefix at every generation step: no KV cache, encryption, attestation, or
Bifrost replication is implemented. Its timing cannot be used as secure-serving latency.

The immediate Paper 4 milestone remains [attack calibration](CALIBRATION_PROTOCOL.md)
and D1 basis-policy validation. No hardware, cloud service, or additional dependency
has been provisioned for this proposed track.
