# Draft protocol — Paper 4 defense pilot

Protocol ID: `p4-defense-pilot-0.2-draft` (matches `experiments/configs/pilot_draft.yaml`)
Status: **DRAFT — freeze pending P0. No pilot or confirmatory result is established.**

Engineering diagnostics are authorized preparation, not execution under a frozen pilot.
Before the first pilot run, resolve every pending item below and record the immutable code,
dependency, environment, configuration, calibration, seed, and analysis identifiers.

## 1. Objective and candidate identity

Evaluate D1 property-targeted forward noise and D3 lower forward precision against fresh
Paper 4 controls at span 4, position 2, latent width 256, q=8 reference. D1+D3 is optional
exploration only after its individual treatment controls are specified. D2 adversarial
training is a later extension; D4 is deferred; D5 permutation is an invariance control,
not an advancing privacy candidate. No result quantifies over untested mechanisms.

Pin `pcr` to Paper 3 revision `52191c430110bd8d9dee80538fde22bf1726e56a`. Do not mutate
Paper 3 or rerun its historical matrices. Fresh Paper 4 all-local, removed-remote,
trained, and frozen-random runs provide the required contemporaneous controls.

The isolated `uv.lock` environment uses unmodified vendored `pcr` source and license.
Paper 4 deliberately changes quantization to per-token min/max over the latent dimension,
avoiding cross-position statistics. D0 is therefore a fresh Paper 4 mechanism/control,
not a rerun or pooled replication of Paper 3. Freeze the quantizer axis and any exposed
scale/min/max metadata; no full-transcript bitrate follows from q alone.

## 2. Reference configuration and pairing

- Backbone: 8-layer byte-level decoder, model width 256; tiny-Shakespeare with its specified
  byte tokenizer. Record the actual corpus hash and split offsets. Paper 4 reserves 80% for
  training, 10% calibration, 5% probe fitting, and 5% evaluation, using fractional boundaries
  [0, 0.8, 0.9, 0.95, 1]. This differs from Paper 3's historical 90/10 split and needs fresh
  controls; no window may cross a reserved region's boundary.
- Segment: four blocks beginning at block two; latent width 256. q=8 is the reference;
  D3 varies forward q with the other factors held fixed.
- Planned training budget: 2,000 steps; AdamW, learning rate 3e-4 with cosine decay to 3e-5,
  warmup 100, global training-gradient clip 1.0. Copy and verify remaining batch, sequence,
  architecture, optimizer, and evaluation parameters against the pinned runner before freeze.
  Fixed steps are matched stopping budgets, not proof of equal convergence.
- Match trusted initialization, minibatch order, permitted calibration/basis procedure,
  defense random draws, and stopping budget within each trained/frozen pair. Remote updating
  is the intervention; verify mode application after the complete module is constructed.
- Specify when all-local or removed controls can be reused algebraically and when a distinct
  defense-dependent control is required. Count unique runs from the explicit matrix.

D1 applies sequence-shared Gaussian noise in a calibrated orthonormal subspace **before**
final Q_q quantization. Record basis origin, centering/rank, checkpoint coordinates, amplitude,
release resampling, and any fitting/update schedule. No gradient-defense change is implicit
in D1. D3's q is forward precision, not the serialized rate of the complete transcript.

The current draft candidate grid is D0 q=8; D1 σ∈{0.1,0.5,1.0} at q=8; and D3
q∈{1,2,3}, using batch size 32 and sequence length 128. It is not frozen. A common
per-seed warmup/calibration checkpoint for trained/frozen D1 pairs, the resulting basis,
and its subsequent update/drift policy remain pending validation. The same-encoder
initialization fit in engineering diagnostics does not establish this pilot policy.

`experiments/configs/p0_diagnostics.yaml` uses only three steps, batch size two, and
sequence length 32 at seed 410001, with D0 q=8, D1 σ=0.1 at q=8, and D3 q=2 plus
their matched modes/controls. This is an engineering configuration, not pilot execution.
Validate draft pilot configurations with `scripts/run_experiments.py --validate-only`;
derive unique run counts from the validated matrix before freeze.
The current validated matrices enumerate 10 engineering runs and 66 draft pilot runs;
the latter comprise seven cells × three modes × three seeds, plus three all-local controls.
These are planned configuration counts; validation does not establish execution or qualification.

## 3. Reserved independent cohorts

These are reserved IDs; their presence in this draft is not a freeze or evidence of execution.

| Cohort | Reserved seeds | Permitted use |
|---|---|---|
| Engineering diagnostics | 410001, 410002 | Semantics and calibration pipeline debugging only |
| Calibration | IDs beginning 419101 | Final list, model seeds, attacker seeds, and disjoint text partitions pending |
| Exploratory pilot | 411101, 411102, 411103 | Three paired training seeds after the pilot freeze |
| Confirmation | 412101–412108 | Eight fresh training seeds after a separate confirmatory freeze |

The freeze must include a machine-checked non-overlap record against inherited Paper 3 seed
cohorts and all Paper 4 diagnostic/calibration uses. Repeated use of a common pilot seed
across paired cells is intentional; token rows are not additional independent seeds.

## 4. Qualification and attacker coordinates

Initial primary targets are punctuation sequence-property and next-byte byte-structure
classification. Vowel/newline targets are exploratory until they pass their own controls.
Token inversion is secondary and does not replace either primary family.

| Check | Proposed inherited value | Meaning |
|---|---|---|
| Punctuation property positive-signal floor | r-advantage ≥ 0.10 | Instrument qualification only |
| Next-byte structure positive-signal floor | accuracy advantage ≥ 0.02 | Instrument qualification only |
| Matched calibration null band | absolute null ≤ 0.02 | Required separately for each intended target/view |
| Candidate privacy gate | advantage ≤ 0.02 for every required qualified combination and seed | Cell acceptance; not the property calibration floor |

Requalification is defense-, target-, channel-, capture-, and side-information-specific.
Freeze doses, null construction, attacker architecture/fitting budgets, metrics, and the exact
primary aggregation before execution. Differences of correlations may exceed one and are
not leakage probabilities. No maximum over qualified and unqualified targets may be silently
presented as fully qualified primary evidence.

Use disjoint calibration/evaluation texts and independently specified controls. Equal latent
width does not align different trained models. Either use the evaluated model's coordinates
with explicitly allowed public-data attacker fitting, or qualify a frozen alignment procedure
independently. The same issue applies to property directions learned for D1; record the
mapping and assess training drift rather than assuming transfer.

Sensitivity controls at the declared attacker input test whether the detector can recover a
known signal. Pre-defense signal injection instead tests whether the defense removes that
signal; these are distinct checks and must not be conflated. A failed or absent qualification
record leaves the corresponding view undetermined, never assigned zero leakage.

## 5. Transcript coverage and active attacks

The frozen inventory must name all actual forward/returned tensors, both full-precision
gradient directions, remote state and optimizer state, histories, joint observations, and
timing metadata. Record the captured subset, attacker access, and omitted views separately.
A transformed or quantized capture cannot stand in for the more precise value available to
the remote computation.

The complete declared-transcript audit and active attacker evaluation are prerequisites for
positive defense claims. Forward-only nondetection can be reported only as a probe-specific
observation, with omissions. An empty qualified set or unqualified required channel prevents
eligibility. See [the research plan](RESEARCH_PLAN.md#7-transcript-and-reporting-boundaries)
for the full inherited exclusion list that must accompany privacy summaries until resolved.

Active attacks must modify the prescribed computation or messages, such as bounded malicious
gradient returns. Their intervention, training/utility consequences, calibration, and budgets
need a separate frozen specification. Deeper probes, auxiliary data, and temporal accumulation
on unchanged traces are stronger passive attacks. Active evaluation is currently pending;
stronger passive evaluation cannot satisfy that requirement.

## 6. Outcomes and proposed decisions

All reported outcomes are continuous first. For each cell and seed calculate
G_R = L_frozen − L_trained and Δ_U = L_trained − L_all-local. Report the matched removed
comparison separately. Required attack advantages use matched nulls, with per-target/channel
results visible before aggregation.

A **single cell** is pilot-eligible to advance only if:

1. Mean Δ_U ≤ 0.10 nats and its upper 95% confidence limit ≤ 0.12.
2. Mean G_R ≥ 0.01 nats, with G_R > 0 in all three pilot pairs.
3. Every required qualified passive attack has worst-seed advantage ≤ 0.02, and the intended
   pilot coverage is complete. Missing coverage permits only further engineering.

The pilot does not unlock a positive defense claim. A relative leakage reduction alone is
insufficient. Different strength levels cannot supply separate gates of one composite pass.
Optional failed or stronger levels do not invalidate a distinct eligible cell.

For confirmation, retain all three numerical gate values and add a one-sided paired seed-level
test of positive G_R under a multiplicity family and correction frozen before any confirmatory
outcome. A proposed default is Bonferroni across all selected primary cell contrasts at family
α=0.05; the exact selected contrasts, correction, and power assessment are **pending the
confirmatory freeze**. Do not retrospectively choose a correction because a result passes it.
A positive defense claim additionally requires completed qualified active and full declared
transcript evaluation. These gates do not establish differential privacy, universal security,
or safety against omitted threats.

## 7. Analysis, failures, and random streams

The independent training seed/run is the inferential unit. Report paired seed-level estimates
and 95% confidence intervals; text panels and frames remain nested and their uncertainty is
reported separately. Specify the interval procedure, privacy maxima, selection rule, and
attacker multiplicity before freezing. No hierarchical response surface or monotonic-rate
claim is presumed from this small pilot.

Keep training-defense RNG separate from evaluation/capture, calibration, and attacker RNG.
Changing logging or capture frequency must leave training randomness and trajectory unchanged.
Record root seeds plus derived stream labels, deterministic settings, and device/version details.

Proposed operational failure handling: at most one identical-identity retry; retain failure
records. Missing a required matched partner removes that pair from an estimate and blocks a
complete-cohort gate rather than converting it to a pass. No outcome-based exclusion. A
replacement seed, altered defense, or budget change requires a prospective amendment with a
new identity before the affected outcome is inspected.

## 8. Freeze checklist and amendments

Pending: P0 checks and instrument qualification; exact strength/q matrix and unique run count;
basis/coordinate policy; required transcript views and scoring implementations; exact calibration
seeds/texts/doses; seed-overlap audit; paired initialization/RNG policy; metadata schema; interval
and selection procedures; compute/power assessment; and active protocol prerequisites.

Record immutable artifacts and a dated status change before pilot execution. The confirmatory
protocol freezes separately after exploratory selection. A later source snapshot is not proof
of prior external registration. After a freeze, changes require a numbered amendment with its
reason, timing relative to outcome inspection, affected artifacts, and evidential consequence.
Do not relabel already observed diagnostic or pilot outcomes as confirmation.

The separately proposed [TEE–FHE deployment track](TEE_FHE_TRACK.md) is outside this
pilot. It has no registered cohort or executable configuration and cannot alter this
matrix's controls, thresholds, or estimands without a prospective protocol change.
