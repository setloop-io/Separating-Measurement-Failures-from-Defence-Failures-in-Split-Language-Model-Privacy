# Paper 4 — Defense Redesign Under Calibrated Privacy Instruments

Working title: **Can Structure-Aware Boundary Defenses Preserve Useful Remote Learning?**

Status: **P0 engineering and study design; no Paper 4 scientific result is established.**
The [protocol](docs/PREREGISTRATION.md) is **DRAFT**, pending P0 qualification and a recorded
freeze. Diagnostics are not pilot evidence, and pilot outcomes cannot establish a positive
defense claim.

Start with the [source audit](outputs/deep_research_audit.md),
[implemented architecture](docs/ARCHITECTURE.md),
[P0 execution protocol](docs/P0_ENGINEERING_PROTOCOL.md), and
[environment instructions](docs/ENVIRONMENT.md).

The new [Bifrost source check](TEE-FTE.md) motivates a separate
[TEE–FHE deployment proposal](docs/TEE_FHE_TRACK.md), with its own trust model and
measurement plan. It is outside the current D1/D3 pilot.

Completed on 2026-09-10: **79 tests passed; all 10 P0 engineering runs completed**.
The [verified engineering report](outputs/runs/p0-20260910-a/report.md) links source,
manifest, and capture checks. These three-step diagnostics leave privacy undetermined.

## Research question

Can specified boundary defenses reduce measured attack advantage while preserving utility
and causal remote-learning gain at the same operating point? A negative result concerns only
the tested mechanisms, configurations, training budgets, and qualified attacks. Paper 3 found
an empty empirical feasible set in its tested family; it did not establish universal
impossibility or that leaked properties are necessary for useful computation.

## Initial scope

- **D1:** property-targeted Gaussian noise along calibrated orthonormal directions, shared
  across positions within a sequence and applied before final forward quantization.
- **D3:** lower forward latent precision, with an otherwise matched reference configuration.
- **D1+D3:** optional controlled exploratory interaction, requiring both individual controls.
- **D2:** adversarial encoder training is a subsequent, separately specified extension.
- **D4:** dimension-selective quantization is deferred.
- **D5:** sequence permutation is an invariance control, not a privacy candidate: it preserves
  the mean-pooled representation used by the property probe.

Every candidate is anchored to span 4 at position 2, latent width 256, and the q=8 reference.
D3 varies q at that same anchor. Paper 4 uses fresh trained, frozen-random, removed-remote,
and all-local controls. It does not rerun Paper 3's historical experiment matrices.

## Evidence and gates

The governing prior is Paper 3's final [claim-evidence ledger](../Paper%203%20-%20Privacy-Constrained%20Remote/docs/CLAIM_EVIDENCE_LEDGER.md)
at commit `52191c430110bd8d9dee80538fde22bf1726e56a`; its manuscript clarifications supersede
broader historical decision prose. See [prior evidence](docs/PRIOR_EVIDENCE.md) for scope.
Punctuation is the primary sequence-property target; vowel/newline targets remain exploratory
until separately qualified. Next-byte structure describes byte classes, not unrestricted
semantic recovery. Earlier token-probe nondetection does not establish protection of tokens.

For a single eligible confirmatory cell, the proposed gates are mean replacement penalty
Δ_U ≤ 0.10 nats and its upper 95% confidence limit ≤ 0.12; mean remote gain G_R ≥ 0.01 nats
with a prespecified multiplicity-corrected paired test; and worst-seed advantage ≤ 0.02 for
every required qualified attack/target/channel combination. The property positive-control
floor of 0.10 qualifies an instrument; it is **not** the privacy acceptance threshold.

An activation-only audit cannot establish defense success. Missing or unqualified channels
remain undetermined. A positive defense claim requires the declared complete-transcript
evaluation and qualified active attacks. Stronger passive probes, auxiliary-data attacks,
and history analysis do not become active attacks merely by improving the attacker.

## Reuse and reproducibility

The existing `pcr` implementation is reused from the pinned Paper 3 revision, with Paper 4
extensions isolated in this repository. Paper 3 source, protocols, and results remain
unchanged. See [inherited assets](docs/INHERITED_ASSETS.md) for integration checks and limits.
Do not install an unpinned editable sibling dependency and assume it reproduces the protocol.

Paper 4 uses per-token quantizer statistics along the latent dimension. Its quantization
does not aggregate future positions into a current token's min/max. This changes the
mechanism relative to Paper 3's per-tensor quantizer, so fresh Paper 4 D0 controls are
required; equal q does not make the two mechanisms identical or their results poolable.

The isolated environment is locked with `uv.lock` and contains unmodified vendored `pcr`
source and its license from the pinned revision. Preparation and diagnostic commands are:

```bash
uv sync --locked --extra dev
uv run python scripts/run_experiments.py --config experiments/configs/p0_diagnostics.yaml
```

Only the explicitly labeled engineering diagnostic configuration may run before the pilot
freeze. Use the runner's `--validate-only` option for draft pilot configurations. A P0
budget of three steps with batch size two and sequence length 32 checks execution; it
cannot estimate the planned pilot's utility, privacy, or convergence.

The Paper 4 runner reserves disjoint corpus regions: 80% training, 10% calibration,
5% probe fitting, and 5% evaluation. This differs from Paper 3's historical 90/10 split
and is another reason to use fresh controls. The validated draft pilot has 66 planned
runs; validation and engineering checks do not authorize its execution before freeze.

The manuscript and implementation status are recorded separately from scientific claims in
[the ledger](docs/CLAIM_EVIDENCE_LEDGER.md). `Deep-research.md` is retained as supplied
background; its theoretical claims and predicted defense outcomes are not evidence.

## Repository layout

- `docs/`: research plan, draft protocol, provenance, and claim ledger.
- `src/p4d/`: defense and evaluation extensions to the pinned `pcr` dependency.
- `experiments/configs/`: diagnostic and subsequently frozen study configurations.
- `experiments/manifests/`: execution records with cohort, source, and artifact hashes;
  a manifest is not an instrument qualification verdict.
- `scripts/`, `tests/`: execution, analysis, and implementation checks.
- `outputs/`, `analysis/`: generated artifacts and analysis, with explicit cohort labels.
- `paper/`: manuscript scaffold; prospective studies must not appear as completed results.

## Next milestone

Executable [scenario protocols](docs/SCENARIO_PROTOCOL.md) now cover 36 calibration
diagnostics and six plaintext routing checks. Their runners produce source-bound
manifests and reject scientific or unsupported secure-backend requests. The original
ten P0 training runs remain separate.

Complete the [calibration design](docs/CALIBRATION_PROTOCOL.md), validate the D1
warmup/basis policy, and freeze the concrete 66-run exploratory matrix and its analysis.
Scientific pilot execution remains disabled. D2, active attacks, and cross-setting
replication follow separate specifications. No positive defense result follows from P0.
