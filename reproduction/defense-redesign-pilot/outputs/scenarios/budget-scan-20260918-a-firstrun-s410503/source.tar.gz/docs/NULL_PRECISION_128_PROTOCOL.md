# Engineering protocol: matched-null precision at the pilot operating point

Protocol ID: `p4-null-precision-128-0.1`
Kind: `null_precision_128` (engineering scenario; `scientific_evidence: false`)
Status: **PROSPECTIVE — recorded 2026-09-18 before any execution. Not instrument
qualification, not estimator selection for scientific use, not a freeze.**

This campaign measures the complete control scoring procedure at the pilot
operating point: sequence length 128, the pinned public-domain corpus
([CALIBRATION_TEXT_PROTOCOL.md](CALIBRATION_TEXT_PROTOCOL.md)), and models trained
at the full 2,000-step budget. It follows up the completed
[matched-null precision diagnostics](NULL_PRECISION_PROTOCOL.md), whose assessment
([NULL_PRECISION_DECISION.md](NULL_PRECISION_DECISION.md)) requires larger
independent text panels and evaluation at the pilot sequence length before any
qualification. It scores control conditions only; no normal candidate is scored and
no instrument is qualified by this campaign.

## Inputs and fixed constants

- Sources: the two shared-setup manifests of the `p4-warmup-budget-0.1` campaign
  (seeds 410501/410502), binding their checkpoints, bases, panels, and source
  archives. Campaign label is pinned in the config.
- Scoring seeds: `null_precision_128_engineering` namespace (410601, 410602),
  disjoint from all prior namespaces; 410601 pairs with setup 410501, 410602 with
  410502. Recorded in `experiments/seed_registry.json`.
- Corpus: pinned `gutenberg_p4` digest; panels are the warmup-budget setup panels
  (probe_fit/probe_test, 16,384 windows each, document identities recorded).
- Control model per setup: the `d0` trained branch, re-trained inside this campaign
  from the bound setup checkpoint under the identical sampler, seed, optimizer, and
  device policy (1,500 branch steps, offset 500). Execution **must fail** if the
  re-trained remote-parameter checksum differs from the warmup-budget branch
  record; a mismatch invalidates dependent scenarios and is preserved as a failure,
  never patched over. This binds control scoring to a full-budget trained model.
- Release conditions per setup (release-time interventions on the control model,
  as in the predecessor campaign): `d0_q8` (no defense, q=8), `d1_warm_s1.0_q8`
  (property noise σ=1.0 along the warm basis), `d3_q1` (release quantizer q=1).
  The extremes bracket the draft pilot's defense strengths.
- Estimators: the unchanged `RidgeDesign` matched-null statistic from
  `src/p4d/null_precision.py`; matched-null counts K ∈ {16, 64}; panel sizes
  {8,192, 16,384} sequences; 32 outer donor-derangement repetitions; doses
  {0, 0.5, 2.0} for the post-defense/pre-quantization positive controls with
  codebook-support and exact zero-dose equality checks.
- Primary punctuation target only; next-byte structure precision is a separate
  campaign.

## Outputs and interpretation boundary

Per scenario (2 setups × 3 release conditions = 6, plus 2 model-preparation
records): raw observed/null scores for every repetition, size, K, and dose;
support checks; positive-control scores; manifests binding the warmup-budget
setup manifest, checkpoint, panels, corpus, and the verified branch replay
checksum. The descriptive aggregation (fraction of no-signal trials inside ±0.02,
advantage standard deviations, positive-floor margins) is reported by the analysis
script and the engineering assessment, not by the manifests.

Panel size and K for the scientific qualification are chosen at the calibration
freeze informed by these measurements; this campaign does not enact that choice.
All records keep `scientific_evidence: false`, `qualified: false`, privacy
`undetermined`. Unevaluated: next-byte classes, returned values, quantizer
metadata, gradients, remote/optimizer state, timing, active/adaptive attackers,
joint/cross-run attacks, history, membership, semantics.
