# Engineering assessment: matched-null precision at the pilot operating point

Recorded 2026-09-22. Evidence: campaign `precision-128-20260918-a`, protocol
[p4-null-precision-128-0.1](NULL_PRECISION_128_PROTOCOL.md), eight
`p4-null_precision_128-precision-128-20260918-a-*` manifests (two recorded per-seed
execution subsets: 410601 on toula, 410602 on koula, CUDA, deterministic kernels),
the analyzer-generated [report](../outputs/scenarios/precision-128-20260918-a/report.md)
and [verification](../outputs/scenarios/precision-128-20260918-a/verification.json).
Execution code committed before running as `f14a014`; every manifest re-verified
after merging (schema, per-file source archive, artifact digests, source chain,
replay checksums, stored estimates). This assessment is engineering only — not
instrument qualification, not estimator selection for scientific use, not a freeze.

## What this stage established

1. **Chained control-model replay is bitwise exact.** Each control model was
   re-trained inside the campaign from the bound warmup-budget setup checkpoint
   (1,500 steps, offset 500); replayed remote/trusted checksums matched the bound
   d0-trained branch records bit for bit on both nodes. The release-condition
   scenarios are thereby bound to full-budget trained models, not warmed stubs.
2. **The no-signal precision requirement is met at 16,384 sequences on
   control-only data.** Pooled across both seeds (64 dependent conditional donor
   trials per row): 63–64/64 trials inside ±0.02 for all three release conditions
   (d0 q8, d1 warm σ=1.0 q8, d3 q1) at both K=16 and K=64; advantage SD 0.007–0.008;
   p95 absolute advantage ≤ 0.017. At 8,192 sequences 57–61/64 pass. This resolves
   the blocker recorded in [NULL_PRECISION_DECISION.md](NULL_PRECISION_DECISION.md)
   at the pilot operating point; it does not qualify an instrument.
3. **Positive sensitivity is overwhelming and support is valid.** Every nonzero
   dose (0.5, 2.0) scored advantage ≈ +1.0 against the 0.10 floor at both sizes and
   both K; zero-dose controls equal ordinary donor releases exactly; maximum
   normalized rounding error 0.000031 against the 0.001 tolerance. Sensitivity
   under these controls only.
4. **Estimator read-out.** Increasing K from 16 to 64 barely changes the advantage
   SD (0.0073→0.0072 pooled) — the fitted-probe term dominates, as in the smaller
   predecessor campaign. The single-estimator choice therefore does not hinge on K;
   the calibration freeze can adopt 16,384-sequence panels and K=16 or K=64 with
   measured margins.

## Carry-overs to the calibration freeze

- Panels: 16,384 disjoint within-document windows per probe region at sequence
  length 128 (capacity verified; 8,192 is the documented insufficient-fallback).
- Matched-null estimator unchanged from `null_precision.py`; K ∈ {16, 64} both
  measured acceptable; pick and freeze one with the acceptance rule.
- Release-condition coverage for pilot qualification must span the exact
  (defense, strength, q) cells the pilot scores; this campaign bracketed the
  extremes on control releases only.
- Next-byte structure precision is the separate `p4-structure-precision-0.1`
  campaign; its sources are this campaign's verified control checkpoints.

## Claim boundary

All records remain `scientific_evidence: false`, `qualified: false`, privacy
`undetermined`. No normal candidate was scored. Pooled counts are dependent
conditional donor trials, not population false-positive rates. Unevaluated:
next-byte classes (pending the structure campaign), returned values, quantizer
metadata, gradients, remote/optimizer state, timing, active/adaptive attackers,
joint/cross-run attacks, history, membership, semantics. C1–C7 remain
unestablished.
