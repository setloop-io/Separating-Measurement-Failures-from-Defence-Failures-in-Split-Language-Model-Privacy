# Claim-evidence ledger

Status: **Paper 4 design/P0 engineering; no scientific claim unlocked.**
This ledger replaces the initial scaffold's unsupported universal-impossibility and already
successful/failed defense language. Diagnostic outputs, if produced, establish implementation
behavior only. Pilot and confirmatory studies remain governed by their own recorded freezes.

The current Paper 4 quantizer changes per-tensor statistics to per-token min/max over the
latent dimension. Record that mechanism change in every new manifest/configuration. Fresh
D0 controls are required; equal forward precision is not grounds for pooling Paper 3 and
Paper 4 outcomes. D1 shared-warmup mechanics are implemented and checked; the scientific
warmup duration and basis-drift policy remain pending validation.
Paper 4's 80/10/5/5 training/calibration/probe-fit/evaluation partition also differs from
Paper 3. The validated configurations enumerate 10 engineering and 66 draft pilot runs;
these are configuration counts only, not completed scientific evidence.

## Engineering evidence recorded 2026-09-10

The 10-job `p4-p0-engineering-0.1` matrix completed with zero failed jobs at campaign
`p0-20260910-a`. Its [generated report](../outputs/runs/p0-20260910-a/report.md),
[verification record](../outputs/runs/p0-20260910-a/verification.json), and individual
`experiments/manifests/p4-p0-20260910-a-*.json` records establish execution and artifact
integrity only. Source tree hash:
`e143a79dc0874b146a62b1858df1fe20673b0ef3ccea77dccc132edf13b58aa0`.
The source snapshot includes uncommitted files; the repository had no HEAD at execution.
This is not a scientific freeze or externally registered cohort. All diagnostic probes
remain unqualified, privacy remains undetermined, and C1–C7 below remain unestablished.
The 79-test suite additionally checked implementation semantics; it is not research evidence.

## Prospective Paper 4 claims

| ID | Candidate claim | Required evidence | Current status / permitted language |
|---|---|---|---|
| C1 | D1 satisfies the joint gates at a specified cell | Frozen fresh-seed confirmation: mean Δ_U≤0.10, upper 95% limit≤0.12; mean G_R≥0.01 with corrected paired test; every required qualified attack/view worst seed≤0.02; full declared transcript and qualified active evaluation | Not established; “We test whether…” |
| C2 | D2 adversarial encoder yields an eligible cell | Separately specified minimax training, held-out evaluation attacks, same joint gates and active/transcript prerequisites | Subsequent extension; not in the initial pilot |
| C3 | An eligible cell exists at lower forward precision | Fixed other factors, qualified exact-q attacks, held-out joint-gate evaluation; no assumed monotonicity | Not established; precision is not full-transcript bitrate |
| C4 | No evaluated cell satisfies the joint criteria | Completed frozen finite matrix, all cell-level outcomes, operational failures and unqualified coverage disclosed; no missing score treated as zero | Not established; only an empirical statement about completed tested cells is permitted |
| C5 | Eligibility persists under a specified active attacker | Qualified protocol-manipulating attack with frozen budget, side information, integrity assumptions, matched controls, and training/utility consequences | Pending; stronger passive probes do not satisfy this requirement |
| C6 | A result replicates beyond the reference architecture/corpus | Fresh setting-specific cohorts, new qualification and complete outcomes under a frozen replication protocol | Pending; Paper 3 utility replication supplies no privacy evidence |
| C7 | D1+D3 improves outcomes relative to its components | Controlled interaction cells with matched D1-only, D3-only and reference runs; independent confirmation for a positive claim | Optional exploratory extension, not established |
| X1 | All representation-preserving boundaries face universal impossibility | Explicit task/adversary/communication model and a justified task-specific converse | Not a claim available from this empirical study |
| X2 | Leaked punctuation or other properties are necessary for useful remote work | An identified intervention or applicable formal result separating the claimed necessity from correlation | Not established by prior or planned finite sweeps |

Calibration floors are not acceptance gates. Punctuation is the primary sequence-property
target; vowel/newline targets remain exploratory until individually qualified. Next-byte
structure is byte-class prediction. No activation-only result unlocks a positive defense claim.

## Inherited evidence: cite, do not rerun

Authority: final Paper 3 ledger and manuscript at pinned revision
`52191c430110bd8d9dee80538fde22bf1726e56a`. Its current clarification takes precedence over
historical decision language. See [PRIOR_EVIDENCE.md](PRIOR_EVIDENCE.md) for the complete scope
and [INHERITED_ASSETS.md](INHERITED_ASSETS.md) for reusable interfaces.

| Inherited item | Evidence within Paper 3 | Permitted interpretation |
|---|---|---|
| Reference remote gain: 0.0167 nats, n=8, p≈8.35e−7 | `outputs/confirmatory/confirmatory_analysis.json`, `docs/P2_CONFIRMATORY_DECISION.md`, current ledger clarification, P2 manifests | Trained-versus-frozen gain in the specified cell, with width/span moderation; not remote necessity or superiority over removal |
| Replicated remote gain: 24 positive pairs, means 0.012–0.046 nats | `outputs/replication/replication_summary.md`, P3 protocol/manifests | Remote-gain replication, not broadened privacy replication |
| Four P2b candidates rejected under qualified forward attacks | `outputs/privacy_extended_p4b/privacy_extended_p4b.json`, P4b protocol and calibration/P2b manifests | Punctuation and next-byte structure evidence; secondary property maxima do not independently qualify vowel/newline |
| P5 finite sweep has no eligible tested privacy candidate; 288 runs | `outputs/delegation/delegation_analysis.json`, P5 protocol/manifests | Qualified forward property scores reject all candidates; do not claim both forward families fail every cell |
| P5 D1 Δ_U=0.82–1.56 nats | Same P5 sources | Relative to all-local for bundled precision/backward perturbation; not isolated noise cost or Paper 4 D1 evidence |
| Utility responds to fixed-width forward precision with a practical plateau above q=8 | `outputs/rate_sweep/rate_sweep_analysis.json`, P2b protocol/manifests | No validated complete-transcript rate or extrapolated monotonic law below q=4 |

Generated Paper 3 summaries are local ignored artifacts linked by its ledger to committed
protocols, source, configurations, and manifests. A current source snapshot is not independent
proof of historical pre-outcome registration. This ledger imports neither unverified venue
claims nor numerical results from the earlier decoy-system paper.

## Coverage carried forward

Until Paper 4 independently closes and records each gap, name timing; optimizer state beyond
the remote module; full evolving remote state; active/adaptive attackers; within-run joint
tensor attacks; cross-run joint attacks; natural-sequence membership; semantics beyond
byte-structure classes; returned values; and full-precision inbound/outbound gradients as
unevaluated. History-accumulation/canary-membership instruments, undefended gradient
property/token probes, and all defended gradient probes were unqualified in Paper 3.

A captured or declared channel is not an evaluated attack. Nondetection by a qualified probe
is probe-specific. Missing or unqualified scores are undetermined. No post-hoc maximum or
stronger passive evaluation silently expands qualified scope or satisfies the active requirement.

## Requirements for new entries

Before adding a manuscript result, record the exact Paper 4 code and pinned dependency
revision, environment, protocol/freeze/amendments, matrix hash, seed cohort, data/capture and
calibration hashes, target/channel qualification, selection rule, inferential unit, uncertainty
and multiplicity procedures, generated summary, and corresponding manifests. Distinguish
engineering diagnostics, exploratory pilot, and confirmation. Record failures and omissions
alongside successes. Actual matrix-derived counts replace planned counts only after validation.

`Deep-research.md` remains supplied background, not a source of completed experiments,
universal impossibility, or comparative failures of unimplemented defenses.

## External literature addition — 2026-09-10

Added `chen2026bifrost`, `tramer2019slalom`, and `volos2018graviton` to `paper/refs.bib`
and a scoped related-work paragraph to the manuscript. Source links and verification
boundaries are in [TEE-FTE.md](../TEE-FTE.md). Bifrost is recorded as arXiv v1;
Slalom and Graviton use verified ICLR/USENIX publication records. No external
performance number becomes a Paper 4 result. The [proposed deployment track](TEE_FHE_TRACK.md)
has no executed secure-deployment cohort or verified Bifrost implementation artifact,
and unlocks none of C1–C7.

## Scenario engineering evidence — 2026-09-10

Execution used committed code `a8dff2126832f5fbb2048437c1e0af6a646082a9` and source tree
`4701c7aaccbe8083597fc6181a652d6e9ac1e7d49bda17378626199d303507ed`. All scenario manifests
retain these identities. Source archives and output hashes were independently checked
by `scripts/analyze_scenarios.py`, whose own hash is in each verification record.

| Engineering claim | Evidence | Limit |
|---|---|---|
| All 36 control scenarios completed | [Control report](../outputs/scenarios/controls-20260910-a/report.md), verification JSON and `p4-calibration-controls-20260910-a-*` manifests | Existing three-step P0 captures; no new training cohort |
| All 72 positive-dose floors passed; 17/36 distinct null checks failed | Same generated report; every per-target/view/dose result retained | Sensitivity diagnostics only; every instrument is still unqualified |
| All six routing cases matched logits with maximum error 0.0 and exact generated bytes | [Routing report](../outputs/scenarios/routing-20260910-a/report.md), verification JSON and `p4-routing-routing-20260910-a-*` manifests | Seeded untrained fixture, fp32 loopback, full-prefix recomputation; no secure hardware or cryptography |
| Implementation checks passed | 110 pytest cases in `tests/` at execution revision | Logic/correctness checks, not privacy qualification |

Operational completion is distinct from a calibration gate passing. The null failures
remain in the record and motivate larger independent panels and a justified control
domain before scientific freeze. They do not motivate retrospectively changing the
acceptance threshold. C1–C7 remain unestablished; no manuscript result is unlocked.

## Warmup/stability engineering evidence recorded 2026-09-10

Protocol: [WARMUP_STABILITY_PROTOCOL.md](WARMUP_STABILITY_PROTOCOL.md).
Execution commit `ba8b23d0e84a3a29392973fc81f413f3eb7846a5`, source hash
`4ea238153bc7fd5bee1eaec091b4342a7ce09c7b181c921b7d1260497f1809e3`.
The [report](../outputs/scenarios/warmup-20260910-a/report.md),
[verification](../outputs/scenarios/warmup-20260910-a/verification.json), and 22
`p4-warmup-warmup-20260910-a-*` manifests bind the results to source and artifacts.
See [the engineering assessment](WARMUP_STABILITY_DECISION.md) for follow-up decisions.

| Engineering finding | Evidence | Permitted interpretation |
|---|---|---|
| 22/22 records completed: two setups, twenty branches | Generated report and manifests; source/archive/artifact/pairing/panel checks passed | Operational execution, not scientific results |
| Frozen remote parameters and D1 bases stayed fixed; shared initial trusted weights matched | Branch/setup checksums; 122-test implementation suite at execution revision | Shared-warmup/fork mechanics work under the tested schedule |
| 95th percentile absolute null advantage fell from 0.6793 at 16 sequences to 0.1031 at 1,024 | All sixteen donor repetitions per size in eighteen split branches retained | Descriptive variability reduction; repetitions are dependent |
| 117/288 null checks within ±0.02 at 1,024; 171 failed | Same generated verification and per-branch stability artifacts | Tested panel enlargement does not establish null stability or qualification |
| Final direction cosine to warmed basis 0.7475--0.8659, versus 0.3504--0.4454 to initial basis | Report's eighteen branch rows and saved basis hashes | Warmed coordinates are a useful design starting point; ongoing drift remains |

Each model received sixteen common-warmup and sixteen branch updates. The removed
control is a post-warmup identity intervention. The all-local reference receives its
own warmup. These losses are not evidence of convergence or causal-gain eligibility.
All records remain `scientific_evidence: false`, `qualified: false`, privacy
`undetermined`. The omitted views and attacks are explicitly listed in the protocol,
generated report, and assessment. C1–C7 remain unestablished.

## Matched-null precision engineering evidence recorded 2026-09-10

Protocol: [NULL_PRECISION_PROTOCOL.md](NULL_PRECISION_PROTOCOL.md).
Execution revision `e29fd6376d0133c3340b26ad92c9715fe4682094`, source archive hash
`180f81bbb4d529f45f7d6f89f34240b45c4c0d470ce913e27f003afd421c2caa`.
The [report](../outputs/scenarios/precision-20260910-a/report.md),
[verification](../outputs/scenarios/precision-20260910-a/verification.json), and six
`p4-null_precision-precision-20260910-a-*` manifests bind control-only outcomes to
the two saved common warmup checkpoints. See [the assessment](NULL_PRECISION_DECISION.md).

| Engineering finding | Evidence | Permitted interpretation |
|---|---|---|
| Six scenarios completed, source/artifacts/estimates verified; 137 tests passed | Generated verification and tests at execution revision | Correctness and execution, not instrument qualification |
| Zero-dose releases match exactly; all codebook checks passed, max normalized rounding error 0.00003052 | Per-control support records and verification | Valid quantizer support for synthetic forward controls; metadata not attacked |
| All 72 positive-score checks exceeded 0.10 | Report's six estimator/panel-size rows, 12 scores each | Sensitivity under these controls only; dependent repeated checks |
| At 1,024 sequences and K=64, 107/192 within ±0.02, 85 outside, 37 above +0.02 | Raw no-signal trials and generated report | Conditional donor-score variability remains; not a population error rate |
| At 1,024, SD of mean null correlation falls from 0.0327 (K=1) to 0.0040 (K=64), while fitted-probe r SD is 0.0305 | Generated variance-component table | Averaging inner nulls leaves fitted-probe variability in this procedure |

No normal candidate was scored and no model was trained in this stage. D1/D3
were diagnostic release conditions on a common checkpoint warmed under D0 q8,
not independently trained defense cells. Privacy remains undetermined and all
instruments remain unqualified. The report and assessment explicitly name omitted
views and attacks. C1–C7 remain unestablished.

The assessment's text-capacity arithmetic derives from the source setup's
`panels.json` declarations: each probe region has 55,770 bytes; a disjoint window
uses sequence length plus one byte. Proposed 8,192/16,384-window budgets are data
allocation scenarios, not empirical sample-size guarantees or scientific results.
