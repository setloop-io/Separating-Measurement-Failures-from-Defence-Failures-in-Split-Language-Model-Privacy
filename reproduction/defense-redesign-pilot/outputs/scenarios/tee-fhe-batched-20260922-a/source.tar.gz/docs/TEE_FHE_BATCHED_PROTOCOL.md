# Engineering protocol: batched-matmul corrective and selective split policy

Protocol ID: `p4-tee-fhe-batched-0.1`
Status: **PROSPECTIVE — recorded 2026-09-22 before execution. Engineering only;
`scientific_evidence: false`, `hardware_attested: false`, privacy `undetermined`.**

Follow-up to [TEE_FHE_EXEC_PROTOCOL.md](TEE_FHE_EXEC_PROTOCOL.md), stages C and D.
Stage C exists because an initial estimate ("slot-batching saves ~30×") was
contradicted by a probe measurement (packed block-diagonal matmul ≈ 0.97× of
per-token mm); the protocol now measures the ratio properly instead of asserting
it. Stage D composes the measured per-shape costs into selective deployment
policies.

## Stage C — batched-matmul corrective

- Operation: the stage-B projection (per-token 256-vectors × plaintext
  256→1024 weight), computed (i) per-token via `ckks_vector.mm`, and (ii)
  packed via `CKKSVector.pack_vectors` into b-token blocks with the
  block-diagonal weight (b·256 → b·1024), b ∈ {1, 2, 4} (8192-slot bound).
- Accounting per block count: total and per-token homomorphic time (5 retained
  repetitions each), ciphertext bytes, error vs fp32 reference, and the measured
  packed/per-token ratio; plus keygen-amortized per-token timing (one context,
  32 sequential per-token mms — the serving-realistic constant).
- The op-count explanation (rotations + diagonal multiplies scale with the
  output dimension regardless of packing) is recorded from the measurements, not
  asserted.

## Stage D — selective split policy costs

- Measure the homomorphic per-token mm cost at each remote-linear shape:
  qkv 256→768, proj 256→256, fc 256→1024, mlp_proj 1024→256, five retained
  repetitions each, same CKKS parameters, plus ciphertext bytes per shape.
- Compose the frozen policies over one 128-token sequence (per-token layout;
  refresh and transfer included from the stage-B accounting):
  - `none`: no encrypted operators (plaintext baseline row).
  - `ffn-up-only`: the remote block's fc projection encrypted (1 of 6 remote
    linears).
  - `all-remote-linears`: qkv + proj + fc + mlp_proj encrypted (4 operators;
    the remaining remote-side work stays trusted by declaration).
  Traffic per policy derives from the stage-A observation contract (recorded
  per-operator byte totals), recomputed under the policy's wrapped set. The
  policy table records: homomorphic time, end-to-end estimate, ciphertext bytes,
  traffic bytes, and the traffic+cost ratio to plaintext batched execution.
- Record plainly which policies are conceivable at interactive latency at this
  scale, from these measurements only — no extrapolation to other models,
  hardware, backends, or layouts, and no security claim.

## Execution and boundary

Same `.venv-tee` track environment, same bound checkpoint/window as the parent
protocol, same kind (`tee_fhe`) and seed (410801), new run IDs (`stage-c`,
`stage-d`) under a fresh campaign label. Analyzer re-verifies and aggregates.
No confidentiality, integrity, attestation, utility, or defense claim; the
D1/D3 pilot records are untouched.
