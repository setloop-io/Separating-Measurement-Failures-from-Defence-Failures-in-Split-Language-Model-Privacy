# Engineering assessment: TEE–FHE fleet-side stages

Recorded 2026-09-22. Evidence: campaign `tee-fhe-20260922-a`, protocol
[p4-tee-fhe-eng-0.1](TEE_FHE_EXEC_PROTOCOL.md), two
`p4-tee_fhe-tee-fhe-20260922-a-*` manifests (toula, `.venv-tee` track environment
with TenSEAL 0.3.18), analyzer
[report](../outputs/scenarios/tee-fhe-20260922-a/report.md) and
[verification](../outputs/scenarios/tee-fhe-20260922-a/verification.json).
Execution code committed before running; manifests re-verified after pulling.
Every record carries `hardware_attested: false`, `scientific_evidence: false`,
privacy `undetermined`. Nothing here is a confidentiality, integrity, or
attestation claim, and no timing is a secure-serving latency.

## Stage A — same-checkpoint correctness and the observation contract

The qualification d0-q8 checkpoint (bound by its run manifest) was re-executed
with every linear operator except the LM head routed through a serialized fp32
in-process loopback. Correctness on the frozen 512-window evaluation prefix:
**max |Δlogit| = 0.0, |Δloss| = 0.0, token agreement 100%** against the ordinary
reference — bitwise, as expected of a serialization roundtrip. This validates the
operator-split routing and produces the observation contract later attested
stages must match: per-operator calls/directions/sizes and a grand total of
**5.64 GB serialized** for 512 windows × 128 tokens of boundary traffic in this
split policy (all linears wrapped, one forward per window, no caching).

## Stage B — one real CKKS encrypted projection (TenSEAL, per-token layout)

Measured operation: per-token 256-vectors × the remote block's 256→1024 FFN
up-projection weight, CKKS poly 8192, coeff chain [60,40,40,60], scale 2^40,
five retained repetitions per token count, on the GB10's CPU:

| tokens | keygen | encrypt | homomorphic mm | decrypt | refresh (dec+enc) | end-to-end | ciphertext/token | mm/token | plaintext/token | mm/plaintext |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.096s | 4.8ms | 0.121s | 0.5ms | 2.3ms | 0.224s | 331 KB | 120.8ms | 6.74ms | **18×** |
| 32 | 0.090s | 67ms | 3.70s | 25ms | 82ms | 3.96s | 331 KB | 115.5ms | 0.33ms | **351×** |
| 128 | 0.090s | 270ms | 15.0s | 78ms | 274ms | 15.8s | 331 KB | 117.5ms | 0.013ms | **8,800×** |

Numerical error vs the fp32 reference: ≤ 4.1e-7 mean-abs, ≤ 7.0e-7 max-abs
(relative ≤ 6.5e-7) — fp32-comparable precision.

## What these numbers mean for the deployment track

1. **Per-token CKKS is catastrophically misaligned with batched plaintext at our
   scale**: ~117ms/token homomorphic vs ~13µs/token batched plaintext — a
   ~10⁴× factor, plus ~330× ciphertext expansion (331 KB vs 1 KB) per token.
   One full 128-token boundary projection costs ~15 s here; the remote block has
   six linear maps, so full encrypted remote forward is minutes per
   sequence-batch before any refresh/transfer. This is consistent with the
   literature's structure ([Odin](https://www.alphaxiv.org/abs/2609.12378):
   366 s for full Llama-3-8B-128tok FHE on an H100 with heavy packing
   co-design; [Bifrost](https://www.alphaxiv.org/abs/2606.17421): FHE only a
   layer subset).
2. **Slot-batching is the obvious next stage** (follow-up protocol): 128 tokens
   × 256 values fit in ~4 ciphertexts at 8,192 slots, replacing 128 matmuls
   with ~4 — an expected ~30× reduction of the homomorphic time, before
   transfer. Pack/reshape layout, not new crypto.
3. **The trusted/untrusted split policy drives the total cost**: the 5.64 GB
   contract shows what a naive all-linears loopback means; a Bifrost-style
   selective policy (linear-only-on-accelerator, nonlinears and state on the
   trusted side) shrinks both traffic and encrypted work. The next fleet-side
   stage should encode that selective policy explicitly and re-measure.
4. **TEE-only inference overhead is a different regime entirely** (1–3% on
   B200+TDX per the cited benchmark), but needs the CC-capable instance from
   [TEE_FHE_HARDWARE_SPEC.md](TEE_FHE_HARDWARE_SPEC.md); until then every
   record stays `hardware_attested: false`.

## Claim boundary

Engineering diagnostics; `scientific_evidence: false`, `qualified: false`,
privacy `undetermined`, `hardware_attested: false`. No confidentiality,
integrity, attestation, utility, or defense claim. The D1/D3 pilot records are
untouched. Milestone 3's TEE half and milestone 4 (serving matrix) await the
CC-capable instance.
