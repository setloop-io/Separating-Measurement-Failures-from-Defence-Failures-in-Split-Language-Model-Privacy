"""Batched-matmul and selective-policy stage boundaries (stages C/D of the TEE/FHE track)."""
import numpy as np
import pytest
import torch
import yaml

from p4d import tee_fhe_scenarios as tf
from p4d.experiment import ROOT


@pytest.fixture(autouse=True)
def one_thread():
    old = torch.get_num_threads()
    torch.set_num_threads(1)
    yield
    torch.set_num_threads(old)


def valid_batched_config():
    return {"protocol_id": tf.BATCHED_PROTOCOL_ID, "kind": "tee_fhe", "cohort": "engineering",
            "status": "engineering_ready", "full_budget": True, "device": "cpu",
            "cpu_threads": 2, "seeds": [410801],
            "checkpoint_manifest": "experiments/manifests/p4-qualification-20260922-a-d0-q8-trained-s419101.json",
            "panels_manifest": "experiments/manifests/p4-pilot-20260922-a-d0-q8-trained-s411101.json",
            "stage_a_scenario_manifest": "experiments/manifests/p4-tee_fhe-tee-fhe-20260922-a-stage-a-s410801.json",
            "stage_d_shapes": {k: list(v) for k, v in tf.REMOTE_SHAPES.items()},
            **{k: (list(v) if isinstance(v, list) else v) for k, v in tf.BATCHED_BUDGET.items()}}


def test_validate_batched_accepts_the_protocol_configuration_without_source_files():
    assert tf.validate_batched(valid_batched_config()) == {
        "expected_scenarios": 2, "full_budget": True, "stages": ["stage-c", "stage-d"],
        **tf.FLAGS, "hardware_attested": False}


def test_committed_batched_config_matches_the_protocol_constants():
    cfg = yaml.safe_load((ROOT / "experiments/configs/tee_fhe_batched.yaml").read_text())
    assert tf.validate_batched(cfg)["expected_scenarios"] == 2


@pytest.mark.parametrize("change", [
    lambda c: c.update(protocol_id="p4-tee-fhe-eng-0.1"),
    lambda c: c.update(kind="routing"),
    lambda c: c.update(cohort="calibration"),
    lambda c: c.update(status="frozen"),
    lambda c: c.update(seeds=[410501]),
    lambda c: c.update(stage_c_block_counts=[1, 2, 8]),
    lambda c: c.update(stage_c_amortized_mms=16),
    lambda c: c.update(stage_c_n_tokens=64),
    lambda c: c.update(stage_d_n_tokens=64),
    lambda c: c.update(stage_repetitions=3),
    lambda c: c.update(ckks_poly_modulus_degree=4096),
    lambda c: c.update(ckks_coeff_mod_bit_sizes=[60, 40, 60]),
    lambda c: c.update(ckks_global_scale_exp=41),
    lambda c: c["stage_d_shapes"].update(qkv=[256, 1024]),
    lambda c: c.update(stage_d_shapes={"qkv": [256, 768]}),
    lambda c: c.pop("stage_a_scenario_manifest"),
    lambda c: c.pop("checkpoint_manifest"),
    lambda c: c.pop("panels_manifest"),
    lambda c: c.update(stage_a_scenario_manifest=""),
])
def test_validate_batched_rejects_any_protocol_deviation(change):
    cfg = valid_batched_config()
    change(cfg)
    with pytest.raises(ValueError):
        tf.validate_batched(cfg)


def test_validate_batched_only_stage_subsets():
    cfg = valid_batched_config()
    assert tf.validate_batched(cfg, only_stages=["stage-c"])["expected_scenarios"] == 1
    assert tf.validate_batched(cfg, only_stages=["stage-d"])["expected_scenarios"] == 1
    assert tf.validate_batched(cfg, only_stages=["stage-c", "stage-d"])["expected_scenarios"] == 2
    with pytest.raises(ValueError, match="subset"):
        tf.validate_batched(cfg, only_stages=[])
    with pytest.raises(ValueError, match="subset"):
        tf.validate_batched(cfg, only_stages=["stage-b"])
    with pytest.raises(ValueError, match="subset"):
        tf.validate_batched(cfg, only_stages=["stage-c", "stage-c"])


def tiny_stage_c_cfg():
    return {"stage_c_n_tokens": 8, "stage_c_block_counts": [1, 2], "stage_c_amortized_mms": 4,
            "stage_repetitions": 2, "ckks_poly_modulus_degree": 8192,
            "ckks_coeff_mod_bit_sizes": [60, 40, 40, 60], "ckks_global_scale_exp": 40}


def test_stage_c_packed_matches_per_token_and_accounts_repetitions():
    ts = pytest.importorskip("tenseal", reason="TenSEAL lives only in the .venv-tee track env")
    generator = torch.Generator().manual_seed(7)
    weight = torch.randn(16, 4, generator=generator)  # width 4 -> 4*width
    x_window = torch.randn(8, 4, generator=generator)
    records = tf.stage_c(weight, x_window, tiny_stage_c_cfg())
    baseline = records["baseline_per_token"]
    assert baseline["n_tokens"] == 8 and len(baseline["repetitions"]) == 2
    reference = (x_window @ weight.t()).numpy()
    assert [p["block_count"] for p in records["packed"]] == [1, 2]
    for entry in records["packed"]:
        assert len(entry["repetitions"]) == 2
        assert 0 < entry["packed_per_token_ratio"] < 10
        for rep in entry["repetitions"]:
            assert rep["serialized_ciphertext_bytes"] > 0
            assert rep["per_token_matmul_seconds"] == rep["homomorphic_matmul_seconds"] / 8
            assert rep["max_abs_error"] < 1e-2
    b2 = next(p for p in records["packed"] if p["block_count"] == 2)
    # Block-diagonal packed form reproduces the per-token fp32 reference block-wise.
    assert b2["repetitions"][0]["max_abs_error"] < 1e-2
    amortized = records["keygen_amortized"]
    assert amortized["sequential_mms"] == 4
    assert amortized["mean_per_token_matmul_seconds"] > 0
    assert amortized["keygen_share_seconds_per_token"] >= 0
    assert "measured" in records["op_count_explanation"]
    assert records["timing_scope"] == tf.TIMING_SCOPE


def stub_shape_records():
    def shape(mm, enc, dec, refresh, nbytes, ref_batched):
        return {"mean_per_token": {"encryption_seconds": enc,
                                   "homomorphic_matmul_seconds": mm,
                                   "decryption_seconds": dec,
                                   "decrypt_reencrypt_refresh_seconds": refresh,
                                   "serialized_ciphertext_bytes": nbytes},
                "reference_batched_seconds": ref_batched}
    return {"qkv": shape(0.3, 0.01, 0.01, 0.02, 3000, 0.001),
            "proj": shape(0.1, 0.01, 0.01, 0.02, 2000, 0.0005),
            "mlp_fc": shape(0.4, 0.01, 0.01, 0.02, 4000, 0.002),
            "mlp_proj": shape(0.4, 0.01, 0.01, 0.02, 4000, 0.002)}


def stub_contract_rows():
    prefix = "blocks.2.remote.blocks.0"
    return [{"operator": f"{prefix}.{name}", "direction": direction, "calls": 16,
             "serialized_bytes": value}
            for name, value in (("qkv", 100), ("proj", 50), ("mlp_fc", 200), ("mlp_proj", 200),
                                ("encoder", 60), ("decoder", 60))
            for direction in ("in", "out")] + [
            {"operator": "blocks.0.qkv", "direction": "in", "calls": 16, "serialized_bytes": 999}]


def test_stage_d_policy_table_composition_from_wrapped_operator_set():
    table = tf.compose_policy_table(stub_shape_records(), stub_contract_rows(),
                                    "blocks.2.remote.blocks.0", 512, 128)
    by_policy = {row["policy"]: row for row in table}
    assert list(by_policy) == ["none", "ffn-up-only", "all-remote-linears"]
    none = by_policy["none"]
    assert none["operators"] == []
    assert (none["homomorphic_seconds"] == none["ciphertext_bytes"]
            == none["traffic_bytes"] == none["end_to_end_seconds"] == 0)
    assert none["ratio_to_plaintext_batched"] == 1.0
    assert none["interactive_latency_conceivable"] is True
    ffn = by_policy["ffn-up-only"]
    assert ffn["operators"] == ["blocks.2.remote.blocks.0.mlp_fc"]
    assert ffn["homomorphic_seconds"] == pytest.approx(128 * 0.4)
    assert ffn["ciphertext_bytes"] == 128 * 4000
    # Traffic derives only from the wrapped operator set (in + out, per sequence).
    assert ffn["traffic_bytes"] == pytest.approx(2 * 200 / 512)
    assert ffn["end_to_end_seconds"] == pytest.approx(128 * (0.4 + 0.01 + 0.01 + 0.02))
    assert ffn["ratio_to_plaintext_batched"] == pytest.approx(
        ffn["end_to_end_seconds"] / 0.002)
    all_remote = by_policy["all-remote-linears"]
    assert len(all_remote["operators"]) == 4
    assert all_remote["homomorphic_seconds"] == pytest.approx(128 * (0.3 + 0.1 + 0.4 + 0.4))
    assert all_remote["traffic_bytes"] == pytest.approx(2 * (100 + 50 + 200 + 200) / 512)
    for row in table:
        assert row["conceivability_statement"]
        assert isinstance(row["interactive_latency_conceivable"], bool)


def test_stage_d_policy_table_requires_contract_operators():
    with pytest.raises(ValueError, match="lacks policy operators"):
        tf.compose_policy_table(stub_shape_records(), [], "blocks.2.remote.blocks.0", 512, 128)
