# Local research environment

Prepared 2026-09-10. Execution currently uses CPU engineering diagnostics only.

```bash
uv sync --locked --extra dev
.venv/bin/python scripts/verify_environment.py
.venv/bin/python -m pytest -q
.venv/bin/python scripts/run_experiments.py --config experiments/configs/pilot_draft.yaml --validate-only
.venv/bin/python scripts/run_experiments.py --config experiments/configs/p0_diagnostics.yaml
```

The completed engineering campaign can be checked without retraining:

```bash
.venv/bin/python scripts/analyze_diagnostics.py --run-label p0-20260910-a
```

Run commands from the Paper 4 root. `.venv` is isolated; `uv.lock` fixes resolved
packages. `vendor/paper3/SOURCE.json` pins 20 unmodified files, including the license,
to Paper 3 commit `52191c430110bd8d9dee80538fde22bf1726e56a`. The verification command
checks both the vendored files and the installed `pcr` implementation. The dependency
does not resolve through a mutable sibling working tree or a `sys.path` override.

The environment was created with Python 3.12.12. Campaign `source.json` files record
exact installed versions and platform settings; `source.tar.gz` retains the source
snapshot used for each diagnostic campaign. Bitwise cross-platform equivalence is
not established by locking packages.

The local copy of the public corpus is ignored by Git. To prepare it elsewhere:

```bash
.venv/bin/python scripts/prepare_data.py --source '/path/to/tinyshakespeare.txt'
```

The helper accepts only the expected content digest
`86c4e6aa9db7c042ec79f339dcb96d42b0075e16b8fc2e86bf0ca57e2dc565ed`.
It does not modify the source corpus or access private training data.

Manifests and small JSON summaries are retained in version control; capture tensors
and source archives stay local and their hashes remain in the provenance records.
Before any scientific freeze, commit the final protocol/source and retain the full
immutable artifacts in a declared storage location. P0 snapshots are not evidence
of an externally registered protocol.

No cloud GPU instance, OpenResearch installation, paid service, or deployed network
transport was provisioned. Those require a separate workload-specific configuration;
the current runner intentionally supports only engineering execution.

The additional calibration and plaintext-routing CLIs are documented in
[SCENARIO_PROTOCOL.md](SCENARIO_PROTOCOL.md). They use the same locked environment
and add no dependencies. Source archives remain local under each scenario campaign;
small diagnostics and manifests are retained in Git.
