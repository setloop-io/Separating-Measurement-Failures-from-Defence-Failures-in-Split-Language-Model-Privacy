#!/usr/bin/env python3
"""Copy the inherited public corpus locally after verifying its pinned digest."""
import argparse
from pathlib import Path
from p4d.experiment import ROOT, CORPUS_SHA256, digest

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    args = parser.parse_args()
    if digest(args.source) != CORPUS_SHA256:
        raise SystemExit("Source corpus does not match pinned tiny-Shakespeare digest")
    dst = ROOT / "data/raw/tinyshakespeare.txt"
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_bytes(args.source.read_bytes())
    print(f"Prepared {dst.name}: {CORPUS_SHA256}")
