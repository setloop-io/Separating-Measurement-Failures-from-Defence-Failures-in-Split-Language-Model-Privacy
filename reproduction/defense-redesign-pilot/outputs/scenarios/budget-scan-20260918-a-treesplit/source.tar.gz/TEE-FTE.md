there is very recent and highly relevant research exploring this exact intersection. A prominent example is a 2026 paper titled "Bifrost: Hybrid TEE-FHE Inference for Privacy-Preserving Transformer and LLM Serving".  
Bifrost proposes a hybrid serving architecture specifically designed to overcome the computational bottlenecks of using pure Fully Homomorphic Encryption (FHE) for Large Language Models. In this system, secrets are provisioned only to an attested CPU Trusted Execution Environment (TEE), leaving the host software, accelerator, and device memory outside the trusted computing base.  
The framework uses FHE as a secure delegation mechanism, offloading the throughput-critical, FHE-friendly linear projection layers to an untrusted accelerator. Meanwhile, the CPU TEE natively executes the operations that typically make FHE prohibitively expensive, such as non-linear operators (like Softmax), attention-side control logic, KV-state transitions, and decrypt-then-encrypt refreshes. An extension of this architecture, Bifrost+, further optimizes the process by isolating the prefill and decode phases; it builds the prompt-side KV state entirely inside the CPU TEE and only sends the decode-side state into the hybrid encrypted pipeline.  
While earlier systems like Graviton and Slalom pioneered TEE-hosted neural networks, integrating TEEs directly with FHE to securely delegate processing to untrusted hardware accelerators represents a cutting-edge approach to privacy-preserving LLM inference.

https://arxiv.org/html/2606.17421v1

## Source check — 2026-09-10

The text above is the supplied research lead. Checked against [Bifrost v1](https://arxiv.org/html/2606.17421v1):

- Cite as an arXiv preprint; placeholder DOI/ISBN fields do not verify conference acceptance.
- This is inference with public weights (§3.5), not a demonstrated private-training protocol.
- Length, traffic, timing, rollback/fork, physical and microarchitectural attacks are outside its protection scope (§3.5).
- CPU-TEE-only is faster than the hybrid prototype (§3.4).
- Separate direct hybrid measurements, projected pure-FHE baselines, and simulated ShadowCipherKV checks (§5.1).

No attributable implementation repository was located in the paper links or the bounded
exact-title/identifier search. This is not proof that code is unavailable. The `alpha`
CLI was absent locally; the primary arXiv HTML and metadata were read directly.

The historical comparison also needs precision: [Graviton](https://www.microsoft.com/en-us/research/publication/graviton-trusted-execution-environments-on-gpus/)
develops GPU trusted execution; [Slalom](https://iclr.cc/virtual/2019/poster/655)
delegates linear computation from a TEE to an untrusted GPU with privacy and verification.
They represent distinct trust designs, not interchangeable TEE–FHE implementations.

## Decision for Paper 4

Include Bifrost as related work and a motivation for a **separate proposed deployment
track**. Keep the current D1/D3 calibration and 66-run draft pilot intact. Their
trained-versus-frozen estimand does not become a hardware speedup metric.

The concrete follow-up is in [TEE_FHE_TRACK.md](docs/TEE_FHE_TRACK.md): first establish
the implementation and trust boundary, then compare a trusted-CPU baseline with
encrypted delegation. Training requires its own gradient, parameter-update, optimizer,
and active-integrity design. No Paper 4 result or deployment is established by this note.
