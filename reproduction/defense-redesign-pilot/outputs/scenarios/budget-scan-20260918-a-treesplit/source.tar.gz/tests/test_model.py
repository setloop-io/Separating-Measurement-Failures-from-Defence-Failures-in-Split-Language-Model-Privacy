"""Small CPU integration checks for paired controls and exact observer captures."""
import pytest
import torch
from torch.nn import functional as F
from pcr.model import BackboneConfig
from pcr.train import build_initialized_model, build_optimizer, OptimConfig
from pcr.split import SplitConfig
from p4d.defenses import noise_stream
from p4d.model import BoundaryCapture, attach_defense


@pytest.fixture(autouse=True)
def single_thread_tiny_models():
    previous = torch.get_num_threads()
    torch.set_num_threads(1)
    yield
    torch.set_num_threads(previous)


def make_model(mode="trained", q=3, defense="none"):
    backbone = BackboneConfig(d_model=32, n_heads=1, n_layers=4, d_ff=64, max_seq_len=8)
    split = SplitConfig(start=1, span=2, width=32, q_bits=q)
    model = build_initialized_model(backbone, mode, split, seed=123, pairing_block_id="test-pair")
    basis = torch.eye(32)[:2] if defense == "property_noise" else None
    return attach_defense(model, {"name": defense, "noise_scale": .5}, basis=basis, seed=89)


@pytest.mark.parametrize("defense", ["none", "aggressive_rate", "property_noise"])
def test_split_logits_and_released_prefix_are_causal(defense):
    model = make_model(defense=defense).eval()
    tokens = torch.tensor([[7, 19, 31, 43, 55, 67]])
    changed = torch.tensor([[7, 19, 31, 91, 103, 115]])
    capture, changed_capture = BoundaryCapture(), BoundaryCapture()
    with torch.no_grad(), noise_stream(model, seed=4):
        logits = model(tokens, capture=capture)
    with torch.no_grad(), noise_stream(model, seed=4):
        changed_logits = model(changed, capture=changed_capture)
    torch.testing.assert_close(logits[:, :3], changed_logits[:, :3], rtol=0, atol=0)
    for key in ("forward_values", "returned_values"):
        torch.testing.assert_close(capture.values[key][:, :3], changed_capture.values[key][:, :3],
                                   rtol=0, atol=0)
    for key, values in capture.values["quantizer_metadata"].items():
        torch.testing.assert_close(values[:, :3], changed_capture.values["quantizer_metadata"][key][:, :3],
                                   rtol=0, atol=0)
    assert not torch.allclose(logits[:, 3:], changed_logits[:, 3:])


def test_trained_frozen_pair_identical_initially_and_only_trained_remote_updates():
    trained, frozen = make_model(defense="property_noise"), make_model("frozen_random", defense="property_noise")
    trained_params, frozen_params = dict(trained.named_parameters()), dict(frozen.named_parameters())
    assert trained_params.keys() == frozen_params.keys()
    for key in trained_params:
        assert torch.equal(trained_params[key], frozen_params[key])
    assert all(p.requires_grad for p in trained.remote_parameters())
    assert all(not p.requires_grad for p in frozen.remote_parameters())
    x = torch.tensor([[3, 4, 5, 6, 7, 8], [18, 17, 16, 15, 14, 13]])
    target = torch.tensor([[4, 5, 6, 7, 8, 9], [17, 16, 15, 14, 13, 12]])
    snapshots = [[p.detach().clone() for p in m.remote_parameters()] for m in (trained, frozen)]
    logits_pair = []
    for model in (trained, frozen):
        optimizer = build_optimizer(model, OptimConfig(lr=1e-2))
        logits = model(x)
        logits_pair.append(logits.detach())
        F.cross_entropy(logits.reshape(-1, 256), target.reshape(-1)).backward()
        optimizer.step()
    assert torch.equal(*logits_pair)
    assert any(not torch.equal(old, new) for old, new in zip(snapshots[0], trained.remote_parameters()))
    assert all(torch.equal(old, new) for old, new in zip(snapshots[1], frozen.remote_parameters()))
    assert frozen.remote_path.encoder.weight.grad is not None
    assert torch.count_nonzero(frozen.remote_path.encoder.weight.grad) > 0


@pytest.mark.parametrize("mode", ["trained", "frozen_random", "removed_remote"])
def test_capture_contains_actual_full_precision_boundary_gradients(mode):
    model, capture, actual = make_model(mode=mode, q=2), BoundaryCapture(), {}
    def retain_boundary(module, args, output):
        actual["z"], actual["y"] = args[0], output
        args[0].retain_grad()
        output.retain_grad()
    hook = model.remote_path.remote.register_forward_hook(retain_boundary)
    x, y = torch.tensor([[1, 4, 7, 10, 13, 16]]), torch.tensor([[4, 7, 10, 13, 16, 19]])
    logits = model(x, capture=capture)
    F.cross_entropy(logits.reshape(-1, 256), y.reshape(-1)).backward()
    hook.remove()
    for captured, key in (("forward_values", "z"), ("returned_values", "y")):
        assert torch.equal(capture.values[captured], actual[key].detach())
    for captured, key in (("outbound_gradients", "z"), ("inbound_gradients", "y")):
        assert torch.equal(capture.values[captured], actual[key].grad)
        assert torch.count_nonzero(capture.values[captured]) > 0
        assert not capture.values[captured].requires_grad
    assert torch.unique(capture.values["inbound_gradients"][0, 0]).numel() > 4
    assert capture.values["quantizer_metadata"]["scale"].shape == (1, 6, 1)


def test_attach_preserves_module_objects_and_rejects_unknown_mechanisms():
    model = make_model()
    previous = model.remote_path
    parameters = {key: getattr(previous, key) for key in ("encoder_ln", "encoder", "remote", "decoder")}
    attach_defense(model, {"name": "aggressive_rate"})
    for key, original in parameters.items():
        assert getattr(model.remote_path, key) is original
    with pytest.raises(ValueError, match="Unimplemented defense"):
        attach_defense(model, {"name": "unknown"})
