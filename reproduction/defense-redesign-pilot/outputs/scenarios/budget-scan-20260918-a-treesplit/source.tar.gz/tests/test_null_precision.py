"""Numerical parity, control support, and cohort boundaries for precision diagnostics."""
from copy import deepcopy
import json
import numpy as np
import pytest
import torch
import yaml
from pcr.model import BackboneConfig
from pcr.modes import remote_parameters
from pcr.privacy_attacks_p4b import ridge_fit, ridge_predict, pearson_r
from pcr.split import SplitConfig
from pcr.train import build_initialized_model
from pcr.utils import parameters_checksum
from p4d.defenses import CausalAffineQuantizer
from p4d.experiment import ROOT, measurement
from p4d.model import attach_defense, BoundaryCapture
from p4d.null_precision import RidgeDesign, correlations, no_signal_trials, prequant_capture, quantized_control, signal_spec
from p4d.precision_analysis import check_score
from p4d.precision_scenarios import exercise, restore_model, validate
from p4d.warmup_scenarios import derangement, panel_batches, tensor_hash, text_panel, trusted_checksum


@pytest.fixture(autouse=True)
def one_thread():
    old = torch.get_num_threads()
    torch.set_num_threads(1)
    yield
    torch.set_num_threads(old)


def fixture_model():
    cfg = BackboneConfig(d_model=32, n_heads=1, n_layers=4, d_ff=64, max_seq_len=8)
    split = SplitConfig(start=1, span=2, width=32, q_bits=8)
    m = build_initialized_model(cfg, "frozen_random", split, 42, "precision-test")
    return attach_defense(m, {"name": "property_noise", "noise_scale": .1}, torch.eye(32)[:1], 71)


def fixture_panel(start=0, seed=32, n=32):
    rng = np.random.default_rng(31)
    alphabet = np.array(list(b"A story!?., ") + [10], dtype=np.uint8)
    corpus = torch.tensor(rng.choice(alphabet, 10000))
    return text_panel(corpus, start, start + 2000, n, 8, seed)


@pytest.mark.parametrize("permuted", [False, True])
def test_cached_ensemble_matches_independent_ridge_fits(permuted):
    rng = np.random.default_rng(51)
    x, xt, y, yt = rng.normal(size=(60, 12)), rng.normal(size=(40, 12)), rng.normal(size=60), rng.normal(size=40)
    df = derangement(60, 12) if permuted else np.arange(60)
    dt = derangement(40, 13) if permuted else np.arange(40)
    score = RidgeDesign(x, xt).score(y, yt, 71, [1, 4, 8], df, dt)
    r = pearson_r(ridge_predict(ridge_fit(x[df], y), xt[dt]), yt)
    nulls = []
    rng = np.random.default_rng(71)
    for _ in range(8):
        probe = ridge_fit(x[df], rng.permutation(y))
        nulls.append(pearson_r(ridge_predict(probe, xt[dt][rng.permutation(len(yt))]), yt))
    assert score["r"] == pytest.approx(r, abs=1e-12)
    np.testing.assert_allclose(score["r_null"], nulls, atol=1e-12, rtol=1e-12)
    for e in score["estimators"]:
        assert e["advantage"] == pytest.approx(r - np.mean(nulls[:e["matched_null_count"]]), abs=1e-12)
    one = RidgeDesign(x, xt).score(y, yt, 71, [1], df, dt)
    assert one["estimators"][0]["advantage"] == pytest.approx(score["estimators"][0]["advantage"], abs=1e-12)


def test_constant_and_invalid_inputs_fail_without_becoming_privacy_passes():
    x = np.eye(8)
    design = RidgeDesign(x, x)
    with pytest.raises(ValueError, match="varying"):
        design.score(np.ones(8), np.arange(8), 1)
    with pytest.raises(ValueError, match="permutation"):
        design.score(np.arange(8), np.arange(8), 1, fit_donors=np.zeros(8, dtype=int))
    with pytest.raises(ValueError, match="finite"):
        RidgeDesign(x * np.nan, x)
    with pytest.raises(ValueError, match="counts"):
        design.score(np.arange(8), np.arange(8), 1, [1, 1])
    assert correlations(np.ones((8, 2)), np.arange(8)).tolist() == [0., 0.]


def test_all_trials_and_nested_estimators_are_retained_and_verifiable():
    rng = np.random.default_rng(15)
    x, y = rng.normal(size=(16, 4)), np.arange(16)
    design = RidgeDesign(x, x[::-1].copy())
    rows = no_signal_trials(design, y, y, 6, [1, 4], 12)
    assert len(rows) == 6
    assert rows == no_signal_trials(design, y, y, 6, [1, 4], 12)
    for row in rows:
        check_score(row, [1, 4])
    changed = deepcopy(rows[0])
    changed["estimators"][1]["advantage"] += .001
    with pytest.raises(ValueError, match="recorded"):
        check_score(changed, [1, 4])


@pytest.mark.parametrize("q", [2, 8])
def test_positive_control_has_valid_support_zero_identity_and_no_input_mutation(q):
    generator = torch.Generator().manual_seed(21)
    pre = torch.randn(32, 8, 32, generator=generator)
    old = pre.clone()
    panel = fixture_panel()
    spec = signal_spec(pre.mean(1), panel["tokens"], 32)
    target = np.linspace(0, .25, 32)
    donors = derangement(32, 41)
    quantizer = CausalAffineQuantizer(q)
    for dose in (0., .5, 2.):
        means, support = quantized_control(pre, target, donors, spec, dose, quantizer, 8)
        assert means.shape == (32, 32) and support["support_valid"]
        assert support["maximum_normalized_rounding_error"] <= 1e-3
        if dose == 0:
            assert support["zero_dose_exact"]
            assert torch.equal(means, quantizer(pre[donors])[0].mean(1))
        else:
            assert not torch.equal(means, quantizer(pre[donors])[0].mean(1))
    assert torch.equal(pre, old)


def test_prequant_capture_matches_full_model_release_and_restores_rng():
    model = fixture_model().train()
    panel = fixture_panel()
    before = deepcopy(model.state_dict())
    pre = prequant_capture(model, panel, 8, 66)
    values = []
    with measurement(model, 66), torch.no_grad():
        for x, _ in panel_batches(panel, 8):
            capture = BoundaryCapture()
            model(x, capture=capture)
            values.append(capture.values["forward_values"])
    assert torch.equal(model.remote_path.quantizer(pre)[0], torch.cat(values))
    assert model.training
    assert all(torch.equal(v, model.state_dict()[k]) for k, v in before.items())


def test_checkpoint_restore_preserves_weights_and_changes_only_release_geometry():
    model = fixture_model()
    attach_defense(model, {"name": "none"})
    metrics = {"seed": 42, "trusted_warm_sha256": trusted_checksum(model),
               "remote_final_sha256": parameters_checksum(remote_parameters(model))}
    state = {"state_dict": model.state_dict(), "bases": {"warm": torch.eye(32)[:1]}}
    cfg = {"backbone": vars(model.cfg), "split": vars(model.split)}
    condition = {"id": "d3-q2", "q_bits": 2, "defense": {"name": "aggressive_rate"}}
    restored = restore_model(state, metrics, cfg, condition, 21)
    assert trusted_checksum(restored) == trusted_checksum(model)
    assert restored.remote_path.quantizer.q_bits == 2
    assert not any(p.requires_grad for p in remote_parameters(restored))
    assert model.remote_path.quantizer.q_bits == 8


def test_tiny_control_pipeline_serializes_unqualified_results_without_training(tmp_path):
    model = fixture_model()
    panels = {"basis_fit": fixture_panel(0, 10), "probe_fit": fixture_panel(2000, 11),
              "probe_test": fixture_panel(4000, 12)}
    before = deepcopy(model.state_dict())
    cfg = {"capture_batch_size": 8, "panel_sizes": [16, 32], "ridge_penalty": 1.,
           "outer_null_repeats": 2, "matched_null_counts": [1, 4], "positive_doses": [.5, 2.]}
    result = exercise(model, panels, cfg, 23, {"fixture": True}, tmp_path)
    assert result["scientific_evidence"] is False and result["qualified"] is False
    assert result["privacy_outcome"] == "undetermined" and not result["normal_candidate_scored"]
    assert result["new_training_updates"] == 0
    saved = torch.load(tmp_path / "control_means.pt", weights_only=True)
    assert len(saved["positive_controls"]) == 6
    for p in result["panels"]:
        for d in p["positive_controls"]:
            check_score(d["score"], [1, 4])
            for key, expected in d["features_sha256"].items():
                assert tensor_hash(saved["positive_controls"][f"{p['sequences_per_panel']}-{d['dose']}"][key]) == expected
    assert all(torch.equal(v, model.state_dict()[k]) for k, v in before.items())


@pytest.mark.parametrize("key,value", [("cohort", "confirmation"), ("null_band", .10),
    ("candidate_acceptance_threshold", .10), ("matched_null_counts", [16]), ("outer_null_repeats", 1)])
def test_execution_requires_fixed_engineering_configuration(key, value):
    cfg = yaml.safe_load((ROOT / "experiments/configs/null_precision_diagnostics.yaml").read_text())
    assert validate(cfg)["expected_scenarios"] == 6
    cfg[key] = value
    with pytest.raises(ValueError):
        validate(cfg)


def test_reserved_scientific_seeds_are_refused():
    cfg = yaml.safe_load((ROOT / "experiments/configs/null_precision_diagnostics.yaml").read_text())
    cfg["sources"][0]["control_seed"] = 419101
    with pytest.raises(ValueError, match="reserved"):
        validate(cfg)
