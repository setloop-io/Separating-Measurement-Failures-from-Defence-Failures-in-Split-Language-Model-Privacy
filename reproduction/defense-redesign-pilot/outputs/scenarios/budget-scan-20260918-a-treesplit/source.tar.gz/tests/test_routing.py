from copy import deepcopy
from pathlib import Path
import json
import struct

import pytest
import torch
from torch import nn
import yaml

from pcr.model import BackboneConfig
from pcr.train import build_initialized_model
from p4d.routing import (POLICIES, Router, PlaintextLoopback, pack_tensor, unpack_tensor,
                         install_router, generate)
from p4d.routing_scenarios import validate_config

ROOT = Path(__file__).resolve().parents[1]


def backbone():
    cfg = BackboneConfig(d_model=32,n_heads=1,n_layers=2,d_ff=64,max_seq_len=16)
    return build_initialized_model(cfg,'all_local',None,410201,'routing-test').eval()


def test_tensor_transport_roundtrips_noncontiguous_fp32_exactly():
    x = torch.arange(48,dtype=torch.float32).reshape(2,3,8).transpose(1,2)
    packet = pack_tensor(x)
    assert len(packet) > x.numel()*4
    torch.testing.assert_close(unpack_tensor(packet),x,rtol=0,atol=0)


@pytest.mark.parametrize('packet',[b'',b'xx',struct.pack('!I',100)+b'{}',
    struct.pack('!I',2)+b'{}',pack_tensor(torch.ones(2))[:-1],pack_tensor(torch.ones(2))+b'x'])
def test_malformed_packets_fail_closed(packet):
    with pytest.raises(ValueError):
        unpack_tensor(packet)


def test_nonfinite_or_unimplemented_precision_rejected():
    for x in (torch.tensor([float('nan')]),torch.ones(3,dtype=torch.float64)):
        with pytest.raises(ValueError):
            pack_tensor(x)


@pytest.mark.parametrize('policy',POLICIES)
def test_phase_placement_preserves_logits_tokens_and_expected_calls(policy):
    model = backbone()
    prompt = torch.tensor([[5,10,12]])
    tokens, logits = generate(model,prompt,3)
    router = Router(policy)
    got_tokens, got_logits = generate(install_router(deepcopy(model),router),prompt,3,router)
    assert torch.equal(got_tokens,tokens)
    torch.testing.assert_close(got_logits,logits,atol=1e-6,rtol=0)
    expected = {'local_reference':0,'delegate_all_phases':24,'local_prefill_delegate_decode':16}[policy]
    assert sum(e['delegated'] for e in router.events) == expected
    assert len(router.events)==24
    if policy=='local_prefill_delegate_decode':
        assert not any(e['delegated'] for e in router.events if e['phase']=='prefill')
        assert all(e['delegated'] for e in router.events if e['phase']=='decode')
    if expected:
        assert router.backend.setup_bytes > 0
        assert all(e['request_bytes']>0 and e['response_bytes']>0 for e in router.events if e['delegated'])


def test_routing_cannot_silently_drop_training_gradients():
    model = install_router(backbone(),Router('delegate_all_phases'))
    with pytest.raises(RuntimeError,match='Inference-only'):
        model(torch.tensor([[1,2]]))


def test_plaintext_corruption_is_detectable_by_reference_oracle_only():
    class CorruptingBackend(PlaintextLoopback):
        def evaluate(self,name,packet):
            correct = unpack_tensor(super().evaluate(name,packet))
            return pack_tensor(torch.zeros_like(correct))
    model=backbone()
    prompt=torch.tensor([[1,2,3]])
    _, expected=generate(model,prompt,2)
    router=Router('delegate_all_phases',backend=CorruptingBackend())
    _, got=generate(install_router(deepcopy(model),router),prompt,2,router)
    assert (got-expected).abs().max() > 1e-4
    # This detects a fixture fault using the local oracle; it is not a deployed verifier.


@pytest.mark.parametrize('change',[
    {'backend':'ckks'}, {'hardware_attested':True}, {'ciphertext_only':True},
    {'kv_cache':'encrypted'}, {'cohort':'confirmatory','status':'frozen'}, {'seeds':[412101]}])
def test_unsupported_guarantees_and_scientific_execution_are_refused(change):
    cfg=yaml.safe_load((ROOT/'experiments/configs/routing_diagnostics.yaml').read_text())
    assert validate_config(cfg)==6
    cfg.update(change)
    with pytest.raises(ValueError):
        validate_config(cfg)
