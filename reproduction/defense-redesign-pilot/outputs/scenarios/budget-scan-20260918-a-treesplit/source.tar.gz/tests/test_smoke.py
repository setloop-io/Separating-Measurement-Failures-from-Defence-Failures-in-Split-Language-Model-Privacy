"""Dependency provenance, without borrowing a sibling checkout."""
from importlib.metadata import distribution
from pathlib import Path
import pcr
from p4d.defenses import DefenseConfig


def test_pcr_is_the_installed_pinned_distribution():
    dependency = distribution("privacy-constrained-remote")
    assert dependency.version == "0.0.0"
    installed = Path(dependency.locate_file("pcr/__init__.py")).resolve()
    assert Path(pcr.__file__).resolve() == installed
    assert "site-packages" in installed.parts


def test_defense_config_round_trip_does_not_share_mutable_params():
    original = DefenseConfig("property_noise", params={"noise_scale": 0.5})
    restored = DefenseConfig(**original.to_dict())
    assert restored == original
    restored.params["noise_scale"] = 1.0
    assert original.params["noise_scale"] == 0.5
