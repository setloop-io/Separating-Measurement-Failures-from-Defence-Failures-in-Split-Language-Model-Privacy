"""Budget-scan engineering boundaries: validation, replay, continuation."""
import json
import shutil

import pytest
import yaml

from p4d import budget_scan_scenarios as bs
from p4d import warmup_budget_scenarios as wb
from p4d.experiment import ROOT


@pytest.fixture(autouse=True)
def one_thread():
    import torch
    old = torch.get_num_threads()
    torch.set_num_threads(1)
    yield
    torch.set_num_threads(old)


def tiny_source_config(tmp_path):
    import hashlib
    import numpy as np
    rng = np.random.default_rng(7)
    alphabet = np.array(list(b"A story!?.,;:'- ") + [10], dtype=np.uint8)
    counts = {"train": 3, "calibration": 4, "probe_fit": 2, "evaluation": 2}
    documents, blob, offset = [], bytearray(), 0
    for region, n in counts.items():
        for _ in range(n):
            body = rng.choice(alphabet, 2000).tobytes()
            documents.append({"pg_id": 1000 + offset, "title": f"Doc {offset}",
                              "author": "Test Author", "bytes": len(body),
                              "sha256": hashlib.sha256(body).hexdigest(),
                              "offset": offset, "region": region})
            blob.extend(body)
            offset += len(body)
    corpus_path = tmp_path / "corpus.txt"
    corpus_path.write_bytes(bytes(blob))
    index = {"corpus_sha256": hashlib.sha256(bytes(blob)).hexdigest(),
             "corpus_bytes": len(blob), "documents": documents}
    index_path = tmp_path / "index.json"
    index_path.write_text(json.dumps(index))
    return {"protocol_id": wb.PROTOCOL_ID, "kind": "warmup_budget",
            "cohort": "engineering", "status": "engineering_ready",
            "seeds": [410501], "full_budget": False, "device": "cpu", "cpu_threads": 1,
            "backbone": {"vocab_size": 256, "d_model": 32, "n_heads": 1, "n_layers": 6,
                         "d_ff": 64, "max_seq_len": 8, "init_std": 0.02},
            "split": dict(wb.ANCHOR),
            "data": {"path": str(corpus_path), "sha256": index["corpus_sha256"],
                     "documents": str(index_path), "sequence_length": 8, "batch_size": 4},
            "warmup_steps": 2, "branch_steps": 2, "local_steps": 4,
            "basis_windows": 16, "probe_windows": 32,
            "panel_sizes": [8, 16], "null_repeats": 2, "panel_batch_size": 8,
            "noise_scales": {"d1_s0.1": 0.1, "d1_s1.0": 1.0},
            "optimizer": {"lr": 0.002, "min_lr": 0.0002, "warmup_steps": 1,
                          "weight_decay": 0.1, "grad_clip": 1.0, "betas": [0.9, 0.95]},
            "branches": [dict(b) for b in wb.BRANCHES]}


def tiny_scan_config(source_cfg):
    return {"protocol_id": bs.PROTOCOL_ID, "kind": "warmup_budget",
            "cohort": "engineering", "status": "engineering_ready",
            "full_budget": False, "device": "cpu", "cpu_threads": 1,
            "sources": [{"control_seed": 410503,
                         "setup_manifest": "experiments/manifests/p4-warmup_budget-pytest-bs-source-setup-s410501.json",
                         "trained_manifest": "experiments/manifests/p4-warmup_budget-pytest-bs-source-d0-trained-s410501.json"}],
            "warmup_steps": source_cfg["warmup_steps"],
            "reference_branch_steps": source_cfg["branch_steps"],
            "data": source_cfg["data"],
            "optimizer": source_cfg["optimizer"],
            "branches": [{"branch": "d0", "mode": "trained", "budget": 6},
                         {"branch": "d0", "mode": "frozen_random", "budget": 6},
                         {"branch": "all_local", "mode": "all_local", "budget": 6}]}


def real_config():
    return yaml.safe_load((ROOT / "experiments/configs/budget_scan_diagnostics.yaml").read_text())


def test_validate_accepts_real_config():
    cfg = real_config()
    assert bs.validate(cfg) == {"expected_scenarios": 12, "full_budget": True, **bs.FLAGS}
    assert bs.validate(cfg, only_seeds=[410503])["expected_scenarios"] == 6


@pytest.mark.parametrize("change", [
    lambda c: c.update(cohort="confirmation"),
    lambda c: c.update(status="frozen"),
    lambda c: c.update(kind="null_precision_128"),
    lambda c: c.update(protocol_id="p4-warmup-budget-0.1"),
    lambda c: c["sources"][0].update(control_seed=410501),
    lambda c: c["sources"].pop(),
    lambda c: c["sources"][0].update(control_seed=410504),
    lambda c: c["sources"][0].pop("trained_manifest"),
    lambda c: c["branches"][0].update(budget=4001),
    lambda c: c["branches"].pop(),
    lambda c: c.update(warmup_steps=501),
    lambda c: c.update(reference_branch_steps=1501),
    lambda c: c["optimizer"].update(lr=0.001),
    lambda c: c["data"].update(sequence_length=64),
    lambda c: c["data"].update(sha256="0" * 64),
    lambda c: c["data"].pop("documents"),
])
def test_validate_rejects_any_protocol_deviation(change):
    cfg = real_config()
    assert bs.validate(cfg)["expected_scenarios"] == 12
    change(cfg)
    with pytest.raises(ValueError):
        bs.validate(cfg)


def test_tiny_budget_scan_end_to_end(tmp_path):
    source_cfg = tiny_source_config(tmp_path)
    source_path = ROOT / "experiments/configs/pytest-bs-source.yaml"
    source_path.write_text(yaml.safe_dump(source_cfg))
    scan_cfg = tiny_scan_config(source_cfg)
    scan_path = ROOT / "experiments/configs/pytest-bs-scan.yaml"
    scan_path.write_text(yaml.safe_dump(scan_cfg))
    manifests = ROOT / "experiments/manifests"
    source_dir = ROOT / "outputs/scenarios/pytest-bs-source"
    scan_dir = ROOT / "outputs/scenarios/pytest-bs-scan"
    shutil.rmtree(source_dir, ignore_errors=True)
    shutil.rmtree(scan_dir, ignore_errors=True)
    for pattern in ("p4-warmup_budget-pytest-bs-source-*.json",
                    "p4-warmup_budget-pytest-bs-scan-*.json"):
        for stale in manifests.glob(pattern):
            stale.unlink()
    try:
        source_summary = wb.run(source_path, label="pytest-bs-source")
        assert source_summary["completed"] == source_summary["expected_scenarios"]
        summary = bs.run(scan_path, label="pytest-bs-scan")
        assert summary["completed"] == summary["expected_scenarios"] == 3
        assert summary["failed"] == 0
        assert summary["scientific_evidence"] is False and summary["qualified"] is False
        trained = json.loads(
            (scan_dir / "p4-warmup_budget-pytest-bs-scan-d0-trained-b6-s410503/metrics.json").read_text())
        assert trained["replay"]["matches_reference"] is True
        assert trained["budget_steps"] == 6
        assert [row["step"] for row in trained["curve_tail"]] == [3, 4, 5, 6]
        frozen = json.loads(
            (scan_dir / "p4-warmup_budget-pytest-bs-scan-d0-frozen_random-b6-s410503/metrics.json").read_text())
        assert frozen["replay"] is None
        local = json.loads(
            (scan_dir / "p4-warmup_budget-pytest-bs-scan-all_local-all_local-b6-s410503/metrics.json").read_text())
        assert local["budget_steps"] == 6
        record = json.loads(
            (manifests / "p4-warmup_budget-pytest-bs-scan-d0-trained-b6-s410503.json").read_text())
        assert record["kind"] == "warmup_budget" and record["status"] == "completed"
        assert record["inputs"]["source_run"].endswith("setup-s410501")
        assert record["inputs"]["reference_remote_final_sha256"]
        # Replay must be exact: scan replay at 2 branch steps equals the source's record.
        source_trained = json.loads(
            (source_dir / "p4-warmup_budget-pytest-bs-source-d0-trained-s410501/metrics.json").read_text())
        assert trained["replay"]["remote_sha256"] == source_trained["remote_final_sha256"]
    finally:
        source_path.unlink(missing_ok=True)
        scan_path.unlink(missing_ok=True)
        shutil.rmtree(source_dir, ignore_errors=True)
        shutil.rmtree(scan_dir, ignore_errors=True)
        for pattern in ("p4-warmup_budget-pytest-bs-source-*.json",
                        "p4-warmup_budget-pytest-bs-scan-*.json"):
            for stale in manifests.glob(pattern):
                stale.unlink()
