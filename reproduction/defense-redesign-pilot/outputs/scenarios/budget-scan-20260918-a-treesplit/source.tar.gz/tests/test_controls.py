from copy import deepcopy
from pathlib import Path
import json

import jsonschema
import numpy as np
import pytest
import torch
import yaml

from p4d.calibration import score_properties
from p4d.controls import Panel, observation_panel, donor_null, signal_spec, inject_signal
from p4d.calibration_scenarios import validate_config, exercise_controls, load_bound_captures

ROOT = Path(__file__).resolve().parents[1]


def panel(seed=1, n=64, width=12):
    g = torch.Generator().manual_seed(seed)
    # Deliberately varying sequence properties with independent random observations.
    tokens = torch.full((n, 16), ord('a'), dtype=torch.long)
    for row in range(n):
        tokens[row, :row % 12] = ord('!')
    next_tokens = torch.roll(tokens, -1, dims=1)
    next_tokens[:, -1] = ord('1')  # explicit fixture labels, not a production target generator
    return Panel(torch.randn(n, 16, width, generator=g), tokens, next_tokens)


def test_donor_null_preserves_sequences_and_labels_without_self_donors():
    p = panel()
    before = p.sha256()
    null, donors = donor_null(p, 18)
    assert sorted(donors) == list(range(len(p.values)))
    assert all(i != d for i, d in enumerate(donors))
    assert torch.equal(null.values, p.values[donors])
    assert torch.equal(null.tokens, p.tokens)
    assert null.sha256() == donor_null(p, 18)[0].sha256()
    assert p.sha256() == before


def test_control_injection_uses_fit_scaling_and_has_replayable_zero_identity():
    fit, test = panel(1), panel(2)
    null, _ = donor_null(test, 7)
    spec = signal_spec(fit, 'sequence_property', 'punctuation_fraction', 5)
    assert inject_signal(null, spec, 0).sha256() == null.sha256()
    saved = deepcopy(spec)
    injected = inject_signal(null, spec, 3)
    assert injected.sha256() != null.sha256()
    assert spec['target_mean'] == saved['target_mean']
    assert spec['target_std'] == saved['target_std']
    torch.testing.assert_close(spec['basis'], saved['basis'])
    assert injected.sha256() == inject_signal(null, saved, 3).sha256()


def test_positive_property_signal_is_detectable_on_an_independent_panel():
    fit, test = panel(1, n=128), panel(2, n=128)
    nf, _ = donor_null(fit, 3)
    nt, _ = donor_null(test, 4)
    spec = signal_spec(fit, 'sequence_property', 'punctuation_fraction', 8)
    pf, pt = inject_signal(nf, spec, 10), inject_signal(nt, spec, 10)
    result = score_properties(pf.events(), pt.events(), seed=30)['punctuation_fraction']
    assert result['r'] > .95 and result['advantage'] > .5


def test_control_construction_preserves_global_rng_and_actual_next_labels():
    p = panel()
    state = torch.random.get_rng_state().clone()
    spec = signal_spec(p, 'next_byte_structure', 'next_byte_class', 13)
    out = inject_signal(donor_null(p, 5)[0], spec, 2)
    assert torch.equal(torch.random.get_rng_state(), state)
    assert torch.equal(out.next_tokens, p.next_tokens)
    assert out.values.shape == p.values.shape


@pytest.mark.parametrize('dose', [-1, float('inf'), float('nan')])
def test_invalid_doses_fail(dose):
    p = panel()
    with pytest.raises(ValueError, match='Dose'):
        inject_signal(p, signal_spec(p, 'sequence_property', 'punctuation_fraction', 3), dose)


def test_observation_adapters_use_exact_metadata_and_gradient_values():
    p = panel(width=8)
    event = {**p.events()[0], 'forward_values': p.values,
             'inbound_gradients': p.values / 1000,
             'quantizer_metadata': {'minimum': p.values[..., :1], 'scale': p.values[..., 1:2].abs()}}
    grad = observation_panel([event], 'inbound_gradients')
    torch.testing.assert_close(grad.values, event['inbound_gradients'], rtol=0, atol=0)
    joint = observation_panel([event], 'forward_and_metadata')
    assert joint.values.shape[-1] == 10
    torch.testing.assert_close(joint.values[..., :8], p.values)
    torch.testing.assert_close(joint.values[..., -1:], event['quantizer_metadata']['scale'])
    with pytest.raises(ValueError, match='Unknown view'):
        observation_panel([event], 'full_remote_state')


def test_constant_targets_do_not_create_a_calibration_direction():
    p = panel()
    p.tokens[:] = ord('a')
    with pytest.raises(ValueError, match='Constant calibration target'):
        signal_spec(p, 'sequence_property', 'punctuation_fraction', 0)


def test_control_report_is_bound_and_cannot_promote_engineering_to_qualification():
    fit, test = panel(1), panel(2)
    events = {k: [{**p.events()[0], 'forward_values': p.values}] for k,p in [('fit',fit),('test',test)]}
    binding = {'source_run':'fixture', 'source_manifest_sha256':'a'*64, 'capture_sha256':'b'*64,
               'source_tree_sha256':'c'*64, 'corpus_sha256':'d'*64, 'training_seed':410001,
               'mode':'trained', 'cell':'d0-q8', 'defense':{'name':'none'}, 'q_bits':8,
               'basis_policy':'diagnostic', 'attacker_side_information':'fixture'}
    result = exercise_controls(events, binding, 'forward_values', 'sequence_property',
                               'punctuation_fraction', 410101, [2], 1)
    assert result['qualified'] is False and result['privacy_outcome'] == 'undetermined'
    assert result['binding']['capture_sha256'] == 'b'*64
    schema = json.loads((ROOT/'experiments/schemas/control_diagnostic.schema.json').read_text())
    jsonschema.validate(result,schema)
    result['qualified'] = True
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(result,schema)


def test_matrix_count_and_namespace_protect_scientific_seeds():
    cfg = yaml.safe_load((ROOT/'experiments/configs/calibration_diagnostics.yaml').read_text())
    assert validate_config(cfg) == 36
    cfg['control_seeds'] = [419101]
    with pytest.raises(ValueError, match='reserved'):
        validate_config(cfg)


def test_bound_source_load_rejects_artifact_tampering(tmp_path, monkeypatch):
    import p4d.calibration_scenarios as module
    from p4d.experiment import digest
    manifest = json.loads((ROOT/'experiments/manifests/p4-p0-20260910-a-d0-q8-trained-s410001.json').read_text())
    schema_dir = tmp_path/'experiments/schemas'
    schema_dir.mkdir(parents=True)
    (schema_dir/'run_manifest.schema.json').write_bytes((ROOT/'experiments/schemas/run_manifest.schema.json').read_bytes())
    changed = tmp_path/'artifact.json'
    changed.write_text('{}')
    manifest['artifacts'] = [{'path':'artifact.json','sha256':digest(changed)}]
    (tmp_path/'manifest.json').write_text(json.dumps(manifest))
    changed.write_text('{"changed":true}')
    monkeypatch.setattr(module,'ROOT',tmp_path)
    with pytest.raises(ValueError,match='changed source artifact'):
        load_bound_captures('manifest.json')
