"""Engineering-runner guardrails and measurement integrity; no study execution."""
from copy import deepcopy
import json
from pathlib import Path

import pytest
import torch
import yaml

import p4d.experiment as experiment
from p4d.defenses import PropertyNoiseDefense

ROOT = Path(__file__).resolve().parents[1]


def config(name="p0_diagnostics.yaml"):
    return yaml.safe_load((ROOT / "experiments/configs" / name).read_text())


def test_engineering_matrix_counts_all_controls_and_draft_stays_disabled():
    engineering = experiment.validate_matrix(config(), execute=True)
    assert engineering["run_count"] == 10  # 3 cells x 3 split modes + one local reference.
    assert engineering["execution_enabled"]
    draft = experiment.validate_matrix(config("pilot_draft.yaml"))
    assert draft["run_count"] == 66  # 3 seeds x (7 cells x 3 modes + one local reference).
    assert not draft["execution_enabled"]


def test_run_matrix_refuses_draft_before_corpus_access_or_output_creation(monkeypatch):
    def forbidden_io(*args, **kwargs):
        raise AssertionError("A draft must fail before experiment I/O")
    monkeypatch.setattr(experiment, "digest", forbidden_io)
    monkeypatch.setattr(experiment, "source_provenance", forbidden_io)
    with pytest.raises(ValueError, match="Only engineering diagnostics"):
        experiment.run_matrix(ROOT / "experiments/configs/pilot_draft.yaml")


@pytest.mark.parametrize("cohort,status", [("engineering", "draft"),
                                          ("exploratory", "engineering_ready"),
                                          ("confirmatory", "frozen")])
def test_cohort_and_status_must_both_authorize_engineering(cohort, status):
    cfg = config()
    cfg.update(cohort=cohort, status=status)
    with pytest.raises(ValueError, match="Only engineering diagnostics"):
        experiment.validate_matrix(cfg, execute=True)


@pytest.mark.parametrize("change,error", [
    (lambda c: c.update(seeds=[410001, 410001]), "Duplicate training seed"),
    (lambda c: c.update(seeds=[c["reserved_prior_seeds"][0]]), "overlap inherited"),
    (lambda c: c["cells"].append(deepcopy(c["cells"][0])), "Duplicate cell ID"),
    (lambda c: c["split"].update(width=64), "width256 anchor"),
    (lambda c: c["data"].update(fractions=[0, .8, .8, .95, 1]), "nonoverlapping"),
    (lambda c: c["cells"][1].update(q_bits=4), "D1 comparison keeps q=8"),
    (lambda c: c["cells"][0]["defense"].update(name="sequence_shuffle"), "diagnostic-only"),
    (lambda c: c.update(modes=["trained", "frozen_random"]), "three paired split controls"),
])
def test_validation_rejects_protocol_scope_violations(change, error):
    cfg = config()
    change(cfg)
    with pytest.raises(ValueError, match=error):
        experiment.validate_matrix(cfg)


@pytest.mark.parametrize("training", [True, False])
def test_measurement_restores_training_mode_and_defense_rng_on_exception(training):
    model = PropertyNoiseDefense(4, .5, torch.eye(4)[:2], seed=17).train(training)
    state = model.generator.get_state().clone()
    with pytest.raises(RuntimeError, match="capture interrupted"):
        with experiment.measurement(model, seed=19):
            assert not model.training
            assert torch.count_nonzero(model(torch.zeros(1, 3, 4))) > 0
            raise RuntimeError("capture interrupted")
    assert model.training == training
    assert torch.equal(model.generator.get_state(), state)


def test_tiny_runner_persists_unqualified_diagnostics_and_full_boundary_capture(tmp_path):
    cfg = config()
    cfg["backbone"].update(d_model=32, n_heads=1, n_layers=4, d_ff=64, max_seq_len=8)
    cfg["split"].update(start=1, span=2, width=32)
    cfg["data"].update(sequence_length=6, batch_size=2)
    cfg["optimizer"].update(steps=1)
    cfg.update(eval_batches=1, probe_batches=2, probe_epochs=1)
    # Synthetic byte regions exercise serialization only, not a scientific data split.
    regions = {key: torch.arange(256, dtype=torch.uint8).repeat(8)
               for key in ("train", "calibration", "probe_fit", "evaluation")}
    cell = {"id": "unit-q2", "q_bits": 2, "defense": {"name": "aggressive_rate"}}
    previous = torch.get_num_threads()
    torch.set_num_threads(1)
    try:
        metrics = experiment.run_one(cfg, cell, "frozen_random", 410001, regions, tmp_path / "run")
    finally:
        torch.set_num_threads(previous)
    assert metrics["remote_initial_sha256"] == metrics["remote_final_sha256"]
    assert metrics["cohort"] == "engineering" and not metrics["scientific_evidence"]
    assert metrics["privacy_status"] == metrics["scores"]["privacy_outcome"] == "undetermined"
    assert not metrics["scores"]["qualified"] and not metrics["active_attack_evaluated"]
    # 12 tokens: packed 2-bit forward, two metadata floats/token, three fp32 tensors.
    assert metrics["analytic_bytes_per_training_step"] == 96 + 96 + 3 * 12 * 32 * 4
    inventory = json.loads((tmp_path / "run/transcript_inventory.json").read_text())
    assert inventory["evaluated"] == []
    assert "quantizer metadata attacks" in inventory["unevaluated"]
    assert "active attackers" in inventory["unevaluated"]
    captures = torch.load(tmp_path / "run/captures.pt", weights_only=True)
    for events in captures.values():
        for event in events:
            assert set(experiment.CHANNELS) <= event.keys()
            assert event["tokens"].shape == event["next_tokens"].shape == (2, 6)
            assert torch.isfinite(event["inbound_gradients"]).all()
            assert torch.count_nonzero(event["inbound_gradients"]) > 0
