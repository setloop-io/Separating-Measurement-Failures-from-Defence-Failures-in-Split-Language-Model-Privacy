"""Regressions for calibrated noise, its RNG, and causal quantization."""
import math
import pytest
import torch
from p4d.defenses import CausalAffineQuantizer, PropertyNoiseDefense, SequenceShuffleDefense, noise_stream


def noise_defense(seed=71):
    return PropertyNoiseDefense(4, 0.5, torch.eye(4)[:2], seed=seed)


def test_property_noise_requires_calibrated_orthonormal_basis():
    with pytest.raises(ValueError, match="calibrated directions"):
        PropertyNoiseDefense(4)
    for basis in (torch.zeros(0, 4), torch.ones(2, 3), torch.ones(2, 4),
                  torch.tensor([[float("nan"), 0, 0, 0]])):
        with pytest.raises(ValueError):
            PropertyNoiseDefense(4, property_directions=basis)


@pytest.mark.parametrize("scale", [-0.1, float("nan"), float("inf")])
def test_property_noise_rejects_invalid_scale(scale):
    with pytest.raises(ValueError, match="finite and nonnegative"):
        PropertyNoiseDefense(4, scale, torch.eye(4)[:2])


def test_property_noise_shared_over_positions_and_inside_basis():
    out = noise_defense()(torch.zeros(3, 7, 4))
    assert torch.equal(out, out[:, :1].expand_as(out))
    assert torch.count_nonzero(out[:, :, 2:]) == 0
    assert torch.count_nonzero(out[:, :, :2]) > 0
    assert not torch.equal(out[0], out[1])


def test_property_noise_active_in_eval_with_same_seeded_behavior():
    training, evaluation = noise_defense().train(), noise_defense().eval()
    z = torch.zeros(2, 5, 4)
    assert torch.equal(training(z), evaluation(z))
    assert not torch.equal(evaluation(z), z)


def test_property_noise_preserves_global_torch_rng():
    state = torch.random.get_rng_state().clone()
    noise_defense()(torch.zeros(2, 5, 4))
    assert torch.equal(state, torch.random.get_rng_state())


def test_measurement_stream_repeatable_and_restored_on_error():
    measured, uninterrupted = noise_defense(), noise_defense()
    z = torch.zeros(2, 5, 4)
    with noise_stream(measured, seed=901):
        first = measured(z)
    with noise_stream(measured, seed=901):
        assert torch.equal(first, measured(z))
    with pytest.raises(RuntimeError, match="measurement failure"):
        with noise_stream(measured, seed=902):
            measured(z)
            raise RuntimeError("measurement failure")
    assert torch.equal(measured(z), uninterrupted(z))


def test_noise_stream_restores_nested_modules_and_shuffle():
    modules = torch.nn.ModuleList([noise_defense(), SequenceShuffleDefense(seed=4)])
    before = [m.generator.get_state().clone() for m in modules]
    with noise_stream(modules, seed=99):
        modules[0](torch.zeros(2, 5, 4))
        modules[1](torch.arange(40).reshape(2, 5, 4).float())
    for module, state in zip(modules, before):
        assert torch.equal(module.generator.get_state(), state)


def test_checkpoint_restores_next_defense_draw():
    source = noise_defense()
    z = torch.zeros(2, 5, 4)
    source(z)
    resumed = noise_defense(seed=99)
    resumed.load_state_dict(source.state_dict())
    assert torch.equal(source(z), resumed(z))


def test_zero_noise_preserves_values_gradient_and_rng():
    module = PropertyNoiseDefense(4, 0, torch.eye(4)[:2])
    state = module.generator.get_state().clone()
    z = torch.arange(24).reshape(2, 3, 4).float().requires_grad_()
    out = module(z)
    assert torch.equal(out, z)
    out.sum().backward()
    assert torch.equal(z.grad, torch.ones_like(z))
    assert torch.equal(state, module.generator.get_state())


@pytest.mark.parametrize("q", [1, 2, 3, 8, 16, 32])
def test_quantizer_prefix_ignores_future_tokens_and_other_examples(q):
    quantizer = CausalAffineQuantizer(q)
    x = torch.arange(40).reshape(2, 5, 4).float() / 7
    altered = x.clone()
    altered[0, 3:] = torch.tensor([[-1e5, 1e5, 0, 9], [1e6, -1e6, 4, 0]])
    altered[1] *= -1e8
    original_values, original_metadata = quantizer(x)
    altered_values, altered_metadata = quantizer(altered)
    torch.testing.assert_close(original_values[0, :3], altered_values[0, :3], rtol=0, atol=0)
    for key in original_metadata:
        torch.testing.assert_close(original_metadata[key][0, :3], altered_metadata[key][0, :3],
                                   rtol=0, atol=0)


@pytest.mark.parametrize("q", [1, 2, 3, 8, 16, 32])
def test_quantizer_metadata_decodes_values_and_counts_packed_codes(q):
    quantizer = CausalAffineQuantizer(q)
    x = torch.arange(30).reshape(2, 3, 5).float() / 3 - 4
    values, metadata = quantizer.quantize(x)
    if q == 32:
        assert metadata == {}
        assert torch.equal(values, x)
        assert quantizer.serialized_nbytes(x) == 30 * 4
    else:
        assert set(metadata) == {"minimum", "scale"}
        assert metadata["minimum"].shape == metadata["scale"].shape == (2, 3, 1)
        assert not metadata["minimum"].requires_grad
        assert torch.equal(metadata["minimum"], x.amin(-1, keepdim=True))
        codes = ((x - metadata["minimum"]) / metadata["scale"]).round()
        assert codes.min() >= 0 and codes.max() <= 2**q - 1
        torch.testing.assert_close(values, codes * metadata["scale"] + metadata["minimum"])
        assert torch.all((values - x).abs() <= metadata["scale"] / 2 + 1e-6)
        assert quantizer.serialized_nbytes(x) == math.ceil(30 * q / 8) + 6 * 8


def test_quantizer_constant_vectors_are_finite_and_ste_preserves_gradient():
    quantizer = CausalAffineQuantizer(2)
    x = torch.full((2, 3, 4), -7.0, requires_grad=True)
    values, metadata = quantizer(x)
    assert torch.equal(values, x)
    assert torch.isfinite(metadata["scale"]).all() and (metadata["scale"] > 0).all()
    weights = torch.arange(24).reshape_as(x)
    (values * weights).sum().backward()
    assert torch.equal(x.grad, weights.float())


@pytest.mark.parametrize("q", [0, 33, -1, 2.5, True])
def test_quantizer_rejects_invalid_precision(q):
    with pytest.raises(ValueError):
        CausalAffineQuantizer(q)


@pytest.mark.parametrize("value", [float("nan"), float("inf"), -float("inf")])
def test_quantizer_rejects_nonfinite_representations(value):
    with pytest.raises(ValueError, match="Nonfinite"):
        CausalAffineQuantizer(8)(torch.full((1, 2, 4), value))
