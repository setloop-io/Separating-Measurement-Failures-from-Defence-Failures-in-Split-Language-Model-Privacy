"""Document panels, device resolution, and warmup-budget engineering boundaries."""
import hashlib
import json
import shutil

import numpy as np
import pytest
import torch
import yaml

from p4d import warmup_budget_scenarios as wb
from p4d.corpus import (contiguous_region, document_panel_record, document_text_panel,
                        load_document_index, load_pinned_corpus)
from p4d.devices import device_record, resolve_device
from p4d.experiment import ROOT


@pytest.fixture(autouse=True)
def one_thread():
    old = torch.get_num_threads()
    torch.set_num_threads(1)
    yield
    torch.set_num_threads(old)


def synthetic_resource(tmp_path, doc_bytes=2000):
    rng = np.random.default_rng(7)
    alphabet = np.array(list(b"A story!?.,;:'- ") + [10], dtype=np.uint8)
    counts = {"train": 3, "calibration": 4, "probe_fit": 2, "evaluation": 2}
    documents, blob, offset = [], bytearray(), 0
    for region, n in counts.items():
        for _ in range(n):
            body = rng.choice(alphabet, doc_bytes).tobytes()
            documents.append({"pg_id": 1000 + offset, "title": f"Doc {offset}",
                              "author": "Test Author", "bytes": len(body),
                              "sha256": hashlib.sha256(body).hexdigest(),
                              "offset": offset, "region": region})
            blob.extend(body)
            offset += len(body)
    corpus_path = tmp_path / "corpus.txt"
    corpus_path.write_bytes(bytes(blob))
    index = {"corpus_sha256": hashlib.sha256(bytes(blob)).hexdigest(),
             "corpus_bytes": len(blob), "documents": documents}
    index_path = tmp_path / "index.json"
    index_path.write_text(json.dumps(index))
    return {"path": str(corpus_path), "sha256": index["corpus_sha256"],
            "documents": str(index_path)}


def tiny_config(tmp_path):
    return {"protocol_id": wb.PROTOCOL_ID, "kind": "warmup_budget",
            "cohort": "engineering", "status": "engineering_ready",
            "seeds": [410501], "full_budget": False, "device": "cpu", "cpu_threads": 1,
            "backbone": {"vocab_size": 256, "d_model": 32, "n_heads": 1, "n_layers": 6,
                         "d_ff": 64, "max_seq_len": 8, "init_std": 0.02},
            "split": dict(wb.ANCHOR),
            "data": {**synthetic_resource(tmp_path), "sequence_length": 8, "batch_size": 4},
            "warmup_steps": 2, "branch_steps": 2, "local_steps": 4,
            "basis_windows": 16, "probe_windows": 32,
            "panel_sizes": [8, 16], "null_repeats": 2, "panel_batch_size": 8,
            "noise_scales": {"d1_s0.1": 0.1, "d1_s1.0": 1.0},
            "optimizer": {"lr": 0.002, "min_lr": 0.0002, "warmup_steps": 1,
                          "weight_decay": 0.1, "grad_clip": 1.0, "betas": [0.9, 0.95]},
            "branches": [dict(b) for b in wb.BRANCHES]}


def test_document_panel_disjoint_within_document_and_deterministic(tmp_path):
    cfg = synthetic_resource(tmp_path)
    corpus = load_pinned_corpus(cfg)
    index = load_document_index(cfg)
    docs = index["probe_fit"]
    panel = document_text_panel(corpus, docs, 32, 8, 123, region="probe_fit")
    assert panel["region"] == "probe_fit"
    supports = []
    for i, offset in enumerate(panel["offsets"]):
        offset = int(offset)
        owner = [d for d in docs if d["offset"] <= offset < d["offset"] + d["bytes"]]
        assert len(owner) == 1 and offset + 9 <= owner[0]["offset"] + owner[0]["bytes"]
        assert panel["document_ids"][i] == owner[0]["pg_id"]
        assert torch.equal(panel["tokens"][i], corpus[offset:offset + 8].long())
        assert torch.equal(panel["next_tokens"][i], corpus[offset + 1:offset + 9].long())
        supports.append(set(range(offset, offset + 9)))
    assert len(set.union(*supports)) == sum(map(len, supports))
    same = document_text_panel(corpus, docs, 32, 8, 123, region="probe_fit")
    other = document_text_panel(corpus, docs, 32, 8, 124, region="probe_fit")
    assert torch.equal(same["offsets"], panel["offsets"])
    assert same["document_ids"] == panel["document_ids"]
    assert not torch.equal(other["offsets"], panel["offsets"])
    record = document_panel_record(panel)
    assert record["document_ids"] == panel["document_ids"]
    assert record["sequences"] == 32


def test_document_panel_capacity_and_argument_errors(tmp_path):
    cfg = synthetic_resource(tmp_path)
    corpus = load_pinned_corpus(cfg)
    docs = load_document_index(cfg)["probe_fit"]
    capacity = sum((d["bytes"] - 8) // 9 + 1 for d in docs)
    with pytest.raises(ValueError, match="Insufficient disjoint windows in panel region"):
        document_text_panel(corpus, docs, capacity + 1, 8, 123)
    with pytest.raises(ValueError, match="Invalid panel"):
        document_text_panel(corpus, [], 4, 8, 123)
    out_of_range = [dict(docs[0], bytes=len(corpus) + 1)]
    with pytest.raises(ValueError, match="outside the corpus"):
        document_text_panel(corpus, out_of_range, 4, 8, 123)


def test_corpus_and_document_index_digests_are_enforced(tmp_path):
    cfg = synthetic_resource(tmp_path)
    corpus = load_pinned_corpus(cfg)
    assert corpus.dtype == torch.uint8 and len(corpus) == 11 * 2000
    index = load_document_index(cfg)
    assert set(index) == {"train", "calibration", "probe_fit", "evaluation"}
    assert [d["offset"] for d in index["train"]] == sorted(d["offset"] for d in index["train"])
    with pytest.raises(ValueError, match="digest mismatch"):
        load_pinned_corpus({**cfg, "sha256": "0" * 64})
    with pytest.raises(ValueError, match="does not match the pinned corpus digest"):
        load_document_index({**cfg, "sha256": "0" * 64})
    original = json.loads((tmp_path / "index.json").read_text())
    tampered = json.loads(json.dumps(original))
    tampered["documents"][0]["sha256"] = "0" * 64
    (tmp_path / "bad.json").write_text(json.dumps(tampered))
    with pytest.raises(ValueError, match="content mismatch"):
        load_document_index({**cfg, "documents": str(tmp_path / "bad.json")})
    tampered = json.loads(json.dumps(original))
    tampered["documents"][0]["offset"] += 1
    (tmp_path / "bad.json").write_text(json.dumps(tampered))
    with pytest.raises(ValueError, match="content mismatch"):
        load_document_index({**cfg, "documents": str(tmp_path / "bad.json")})


def test_contiguous_region_requires_one_span(tmp_path):
    cfg = synthetic_resource(tmp_path)
    corpus = load_pinned_corpus(cfg)
    index = load_document_index(cfg)
    region = contiguous_region(corpus, index["train"])
    assert len(region) == 3 * 2000
    assert torch.equal(region, corpus[:6000])
    gap = [dict(d) for d in index["train"]]
    gap[1]["offset"] += 1
    with pytest.raises(ValueError, match="contiguous"):
        contiguous_region(corpus, gap)
    with pytest.raises(ValueError, match="Empty"):
        contiguous_region(corpus, [])


def test_resolve_device_explicit_outcomes():
    assert resolve_device("cpu") == torch.device("cpu")
    assert device_record(resolve_device("cpu")) == {"device": "cpu"}
    with pytest.raises(ValueError, match="Unknown device"):
        resolve_device("auto")
    with pytest.raises(ValueError, match="Unknown device"):
        resolve_device("tpu")
    if torch.cuda.is_available():
        device = resolve_device("cuda:0")
        record = device_record(device)
        assert record["device"] == "cuda:0" and record["device_name"] and record["capability"]
        with pytest.raises(RuntimeError, match="only"):
            resolve_device(f"cuda:{torch.cuda.device_count()}")
    else:
        with pytest.raises(RuntimeError, match="not available"):
            resolve_device("cuda")
    if torch.backends.mps.is_available():
        assert resolve_device("mps").type == "mps"
    else:
        with pytest.raises(RuntimeError, match="not available"):
            resolve_device("mps")


def real_config():
    return yaml.safe_load((ROOT / "experiments/configs/warmup_budget_diagnostics.yaml").read_text())


@pytest.mark.parametrize("change", [
    lambda c: c.update(cohort="confirmation"),
    lambda c: c.update(status="frozen"),
    lambda c: c.update(kind="warmup"),
    lambda c: c.update(protocol_id="p4-warmup-stability-engineering-0.1"),
    lambda c: c.update(seeds=[410301]),
    lambda c: c.update(seeds=[410501]),
    lambda c: c["split"].update(width=128),
    lambda c: c.update(warmup_steps=501),
    lambda c: c.update(branch_steps=1501),
    lambda c: c.update(local_steps=2001),
    lambda c: c.update(basis_windows=2048),
    lambda c: c.update(probe_windows=8192),
    lambda c: c.update(panel_sizes=[1024, 4096]),
    lambda c: c.update(null_repeats=8),
    lambda c: c["noise_scales"].update({"d1_s1.0": 0.5}),
    lambda c: c["optimizer"].update(lr=0.001),
    lambda c: c["data"].update(sequence_length=64),
    lambda c: c["data"].update(sha256="0" * 64),
    lambda c: c["data"].pop("documents"),
    lambda c: c.update(branches=c["branches"][:-1]),
])
def test_validate_rejects_any_protocol_deviation(change):
    cfg = real_config()
    assert wb.validate(cfg) == {"expected_scenarios": 16, "full_budget": True, **wb.FLAGS}
    change(cfg)
    with pytest.raises(ValueError):
        wb.validate(cfg)


def test_validate_accepts_tiny_test_config_with_reserved_namespace_subset(tmp_path):
    cfg = tiny_config(tmp_path)
    assert wb.validate(cfg)["expected_scenarios"] == 8
    cfg["seeds"] = [410301]
    with pytest.raises(ValueError, match="reserved"):
        wb.validate(cfg)


def test_validate_only_seed_subsets():
    cfg = real_config()
    assert wb.validate(cfg, only_seeds=[410501])["expected_scenarios"] == 8
    assert wb.validate(cfg, only_seeds=[410502])["expected_scenarios"] == 8
    assert wb.validate(cfg, only_seeds=[410501, 410502])["expected_scenarios"] == 16
    with pytest.raises(ValueError, match="subset"):
        wb.validate(cfg, only_seeds=[410301])
    with pytest.raises(ValueError, match="subset"):
        wb.validate(cfg, only_seeds=[])


def test_tiny_budget_campaign_end_to_end(tmp_path):
    cfg = tiny_config(tmp_path)
    config_path = tmp_path / "config.yaml"
    config_path.write_text(yaml.safe_dump(cfg))
    label = "pytest-warmup-budget"
    campaign_dir = ROOT / "outputs/scenarios" / label
    manifests = ROOT / "experiments/manifests"
    shutil.rmtree(campaign_dir, ignore_errors=True)
    for stale in manifests.glob(f"p4-warmup_budget-{label}-*.json"):
        stale.unlink()
    try:
        summary = wb.run(config_path, label=label)
        assert summary["completed"] == summary["expected_scenarios"] == 8
        assert summary["failed"] == 0
        assert summary["scientific_evidence"] is False
        assert summary["privacy_outcome"] == "undetermined" and summary["qualified"] is False
        setup_dir = campaign_dir / f"p4-warmup_budget-{label}-setup-s410501"
        setup_metrics = json.loads((setup_dir / "metrics.json").read_text())
        assert setup_metrics["remote_initial_sha256"] == setup_metrics["remote_final_sha256"]
        assert 0 <= setup_metrics["initial_warm_absolute_cosine"] <= 1
        assert len(setup_metrics["curve"]) == 2
        declaration = json.loads((setup_dir / "panels.json").read_text())
        split = declaration["basis_split"]
        assert not set(split["basis_fit"]) & set(split["basis_validation"])
        for name, record in declaration["panels"].items():
            assert record["sequences"] == (16 if name.startswith("basis") else 32)
            assert len(record["document_ids"]) == record["sequences"]
        warm_basis = setup_metrics["bases"]["warm"]["basis_sha256"]
        checkpoint = json.loads((manifests / f"{setup_dir.name}.json").read_text())
        for spec in wb.BRANCHES:
            run_id = f"p4-warmup_budget-{label}-{spec['branch']}-{spec['mode']}-s410501"
            record = json.loads((manifests / f"{run_id}.json").read_text())
            assert record["kind"] == "warmup_budget" and record["status"] == "completed"
            assert record["scientific_evidence"] is False
            assert record["inputs"]["setup_run_id"] == checkpoint["run_id"]
            assert record["inputs"]["checkpoint_sha256"]
            assert record["inputs"]["panels_sha256"]
            assert record["inputs"]["device"] == "cpu"
            metrics = json.loads((campaign_dir / run_id / "metrics.json").read_text())
            assert metrics["privacy_outcome"] == "undetermined"
            if spec["mode"] == "all_local":
                # Own 0..3 stream, not the shared warmup.
                assert [row["step"] for row in metrics["curve"]] == [1, 2, 3, 4]
            else:
                # Branch steps continue the shared warmup's global indices.
                assert [row["step"] for row in metrics["curve"]] == [3, 4]
            if spec["mode"] == "all_local":
                assert not (campaign_dir / run_id / "stability.json").exists()
                continue
            stability = json.loads((campaign_dir / run_id / "stability.json").read_text())
            assert stability["qualified"] is False
            assert [c["sequences_per_panel"] for c in stability["curve"]] == [8, 16]
            assert all(len(c["nulls"]) == 2 for c in stability["curve"])
            if spec["mode"] == "frozen_random":
                assert metrics["remote_initial_sha256"] == metrics["remote_final_sha256"]
            if spec["branch"].startswith("d1"):
                assert metrics["basis_used_sha256"] == warm_basis
            if spec["branch"] == "d3_q1":
                assert metrics["intervention"]["q_bits"] == 1
                assert metrics["release_support"]["support_valid"]
                assert metrics["release_support"]["q_bits"] == 1
            if spec["mode"] == "trained":
                refit = metrics["post_training_basis"]
                assert 0 <= refit["absolute_cosine_to_initial"] <= 1
                assert 0 <= refit["absolute_cosine_to_warm"] <= 1
    finally:
        shutil.rmtree(campaign_dir, ignore_errors=True)
        for stale in manifests.glob(f"p4-warmup_budget-{label}-*.json"):
            stale.unlink()
