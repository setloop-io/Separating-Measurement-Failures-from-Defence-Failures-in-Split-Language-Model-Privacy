"""Evidence transport checks; these tests do not run scientific experiments."""
import hashlib
import importlib.util
import io
from pathlib import Path
import tarfile
import tempfile
import unittest

SPEC = importlib.util.spec_from_file_location('reviewer_evidence', Path(__file__).resolve().parents[1] / 'scripts/reviewer_evidence.py')
evidence = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(evidence)


def archive(name='outputs/run/metrics.json', data=b'{"loss": 1.5}', symlink=False):
    stream = io.BytesIO()
    with tarfile.open(fileobj=stream, mode='w') as tar:
        info = tarfile.TarInfo(name)
        info.size = len(data)
        if symlink:
            info.type = tarfile.SYMTYPE
            info.linkname = '/tmp/outside'
        tar.addfile(info, io.BytesIO(data))
    stream.seek(0)
    return stream


class EvidenceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name).resolve()
        self.record = {'path': 'outputs/run/metrics.json', 'bytes': 13,
                       'sha256': hashlib.sha256(b'{"loss": 1.5}').hexdigest()}
        self.record['bytes'] = len(b'{"loss": 1.5}')

    def test_restore_verify_and_repeat(self):
        evidence.restore_tar(archive(), self.root, [self.record])
        self.assertEqual(evidence.verify_files(self.root, [self.record]), [])
        target = self.root / self.record['path']
        before = target.stat().st_mtime_ns
        evidence.restore_tar(archive(), self.root, [self.record])
        self.assertEqual(before, target.stat().st_mtime_ns)

    def test_missing_and_corrupt_are_not_complete(self):
        self.assertEqual(evidence.verify_record(self.root, self.record), 'missing')
        evidence.restore_tar(archive(), self.root, [self.record])
        (self.root / self.record['path']).write_bytes(b'{"loss": 9.5}')
        self.assertEqual(evidence.verify_record(self.root, self.record), 'hash_mismatch')
        with self.assertRaisesRegex(ValueError, 'Refusing to overwrite'):
            evidence.restore_tar(archive(), self.root, [self.record])
        self.assertEqual((self.root / self.record['path']).read_bytes(), b'{"loss": 9.5}')

    def test_corrupt_archive_payload_is_rejected(self):
        with self.assertRaisesRegex(ValueError, 'hash mismatch'):
            evidence.restore_tar(archive(data=b'{"loss": 9.5}'), self.root, [self.record])
        self.assertFalse((self.root / self.record['path']).exists())

    def test_missing_archive_member_is_rejected(self):
        with self.assertRaisesRegex(ValueError, 'missing 1 indexed'):
            stream = io.BytesIO()
            with tarfile.open(fileobj=stream, mode='w'):
                pass
            stream.seek(0)
            evidence.restore_tar(stream, self.root, [self.record])

    def test_traversal_and_links_are_rejected(self):
        for name in ['../outside', '/absolute', 'outputs/../../outside', 'outputs\\outside']:
            with self.subTest(name=name), self.assertRaises(ValueError):
                evidence.safe_path(self.root, name)
        with self.assertRaisesRegex(ValueError, 'Unexpected archive member'):
            evidence.restore_tar(archive(symlink=True), self.root, [self.record])
        (self.root / 'outputs').symlink_to(self.root.parent, target_is_directory=True)
        with self.assertRaises(ValueError):
            evidence.safe_path(self.root, self.record['path'])

    def test_wrong_output_root_is_missing(self):
        evidence.restore_tar(archive(), self.root, [self.record])
        other = self.root / 'other'
        other.mkdir()
        self.assertEqual(evidence.verify_record(other, self.record), 'missing')


if __name__ == '__main__':
    unittest.main()
