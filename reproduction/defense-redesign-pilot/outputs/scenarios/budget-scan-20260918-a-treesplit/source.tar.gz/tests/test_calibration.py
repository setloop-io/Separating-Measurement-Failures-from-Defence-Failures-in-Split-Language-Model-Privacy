"""Qualification and scoring have different gates and never imply certification."""
import numpy as np
import pytest
import torch
from p4d.calibration import (PRIVACY_ACCEPTANCE, _features, estimate_property_directions,
                             qualification_from_controls, qualified_gate, score_properties)

BINDING = {"defense": "property_noise", "target": "punctuation_fraction",
           "channel": "forward_values", "cell": "test"}


def test_calibration_produces_orthonormal_rank_reduced_signal_basis():
    x = np.concatenate([np.eye(4), -np.eye(4)])
    targets = {"first": x[:, 0], "second": 2 * x[:, 1], "duplicate": 3 * x[:, 0]}
    basis = estimate_property_directions(x, targets)
    assert basis.shape == (2, 4)
    torch.testing.assert_close(basis @ basis.T, torch.eye(2), atol=1e-6, rtol=1e-6)
    torch.testing.assert_close(basis.T @ basis, torch.diag(torch.tensor([1., 1., 0., 0.])),
                               atol=1e-6, rtol=1e-6)


def test_calibration_rejects_uninformative_or_misaligned_targets():
    x = np.concatenate([np.eye(4), -np.eye(4)])
    for targets in ({}, {"constant": np.ones(8)}, {"wrong_shape": np.arange(7)},
                    {"invalid": np.full(8, np.nan)}):
        with pytest.raises(ValueError):
            estimate_property_directions(x, targets)


def test_positive_control_floor_is_distinct_from_privacy_acceptance():
    qualified = qualification_from_controls(.10, .02, "sequence_property", BINDING)
    assert qualified["qualified"]
    assert qualified["positive_floor"] == .10
    assert qualified["acceptance_threshold"] == PRIVACY_ACCEPTANCE == .02
    assert not qualification_from_controls(.05, 0, "sequence_property", BINDING)["qualified"]
    assert qualified_gate({"property": {**qualified, "advantage": .05}}, ["property"]) == "reject"


@pytest.mark.parametrize("positive,null", [(None, 0), (np.nan, 0), (.2, None),
                                           (.2, np.inf), (.2, -.021), (.2, .021)])
def test_qualification_requires_finite_controls_and_two_sided_null(positive, null):
    assert not qualification_from_controls(positive, null, "sequence_property", BINDING)["qualified"]


def test_structure_instrument_has_its_own_control_floor():
    result = qualification_from_controls(.02, -.02, "next_byte_structure", BINDING)
    assert result["qualified"] and result["positive_floor"] == .02
    assert not qualification_from_controls(.019, 0, "next_byte_structure", BINDING)["qualified"]


@pytest.mark.parametrize("entry", [{}, {"qualified": False, "advantage": 0},
                                   {"qualified": True, "advantage": None},
                                   {"qualified": True, "advantage": np.nan},
                                   {"qualified": True, "advantage": np.inf}])
def test_missing_unqualified_or_nonfinite_score_is_undetermined(entry):
    assert qualified_gate({"a": entry}, ["a"]) == "undetermined"


def test_gate_requires_all_requested_scores_and_never_passes_empty_suite():
    scored = {"a": {"qualified": True, "advantage": .02}}
    assert qualified_gate(scored, ["a"]) == "within_qualified_probe_gates"
    assert qualified_gate(scored, ["a", "missing"]) == "undetermined"
    assert qualified_gate({}, []) == "undetermined"
    assert qualified_gate({"a": {"qualified": False, "advantage": 1}}, ["a"]) == "undetermined"


@pytest.mark.parametrize("order", [["missing", "leak"], ["leak", "missing"]])
def test_qualified_leak_rejects_even_with_an_undetermined_channel(order):
    assert qualified_gate({"leak": {"qualified": True, "advantage": .021}}, order) == "reject"


def test_structure_uses_actual_next_tokens_including_final_position(monkeypatch):
    def forbidden_roll(*args, **kwargs):
        raise AssertionError("Rolling labels fabricates a sequence-end target")
    monkeypatch.setattr(np, "roll", forbidden_roll)
    tokens = torch.tensor([[ord("A"), ord("1"), ord(" ")]])
    next_tokens = torch.tensor([[ord("1"), ord(" "), ord("!")]])
    released = torch.tensor([[[.1234, -8.25], [2.1, .009], [-.13, 1.001]]])
    features, labels = _features([{"latents": released, "tokens": tokens,
                                  "next_tokens": next_tokens}], structure=True)
    np.testing.assert_array_equal(labels, np.array([3, 1, 4]))
    np.testing.assert_array_equal(features, released.reshape(-1, 2).numpy())


def test_structure_label_alignment_is_checked():
    event = {"latents": torch.zeros(1, 3, 4), "next_tokens": torch.ones(1, 2).long()}
    with pytest.raises(ValueError, match="do not align"):
        _features([event], structure=True)


def test_constant_property_panel_is_undetermined_not_zero_leakage():
    event = {"latents": torch.arange(48).reshape(4, 3, 4).float(),
             "tokens": torch.full((4, 3), ord("a"))}
    scores = score_properties([event], [event])
    assert all(v["status"] == "undetermined" and v["advantage"] is None for v in scores.values())
