"""Protocol boundaries, replay verification, and device compatibility for the 128 controls."""
from copy import deepcopy
import json
import shutil

import pytest
import torch
import yaml

from p4d import null_precision_128 as np128
from p4d import warmup_budget_scenarios as wb
from p4d.experiment import ROOT
from p4d.null_precision import prequant_capture
from p4d.null_precision_128_analysis import analyze

from test_null_precision import fixture_model, fixture_panel
from test_warmup_budget import tiny_config


@pytest.fixture(autouse=True)
def one_thread():
    old = torch.get_num_threads()
    torch.set_num_threads(1)
    yield
    torch.set_num_threads(old)


def valid_config():
    return {"protocol_id": np128.PROTOCOL_ID, "kind": "null_precision_128",
            "cohort": "engineering", "status": "engineering_ready",
            "full_budget": True, "device": "cpu",
            "sources": [
                {"control_seed": 410601,
                 "setup_manifest": "experiments/manifests/p4-warmup_budget-warmup-budget-20260918-a-setup-s410501.json",
                 "branch_manifest": "experiments/manifests/p4-warmup_budget-warmup-budget-20260918-a-d0-trained-s410501.json"},
                {"control_seed": 410602,
                 "setup_manifest": "experiments/manifests/p4-warmup_budget-warmup-budget-20260918-a-setup-s410502.json",
                 "branch_manifest": "experiments/manifests/p4-warmup_budget-warmup-budget-20260918-a-d0-trained-s410502.json"}],
            "release_conditions": deepcopy(np128.RELEASE_CONDITIONS),
            **deepcopy(np128.BUDGET)}


def test_validate_accepts_the_protocol_configuration_without_source_files():
    assert np128.validate(valid_config()) == {"expected_scenarios": 8, "full_budget": True,
                                              **np128.FLAGS}


def test_committed_config_matches_the_protocol_constants():
    cfg = yaml.safe_load((ROOT / "experiments/configs/null_precision_128_diagnostics.yaml").read_text())
    assert np128.validate(cfg) == {"expected_scenarios": 8, "full_budget": True, **np128.FLAGS}


@pytest.mark.parametrize("change", [
    lambda c: c.update(kind="null_precision"),
    lambda c: c.update(cohort="confirmation"),
    lambda c: c.update(status="frozen"),
    lambda c: c.update(protocol_id="p4-null-precision-engineering-0.1"),
    lambda c: c["sources"][1].update(control_seed=410402),
    lambda c: c["sources"][0].update(control_seed=410602),
    lambda c: c.update(sources=c["sources"][:1]),
    lambda c: c.update(sources=[c["sources"][0], dict(c["sources"][0])]),
    lambda c: c["sources"][1].update(setup_manifest=c["sources"][0]["setup_manifest"]),
    lambda c: c["sources"].append(dict(c["sources"][0])),
    lambda c: c["release_conditions"][1]["defense"].update(noise_scale=0.5),
    lambda c: c.update(release_conditions=c["release_conditions"][:2]),
    lambda c: c.update(panel_sizes=[4096, 16384]),
    lambda c: c.update(matched_null_counts=[1, 16, 64]),
    lambda c: c.update(outer_null_repeats=16),
    lambda c: c.update(capture_batch_size=8),
    lambda c: c["sources"][0].pop("branch_manifest"),
    lambda c: c["sources"][0].update(extra_key=1),
])
def test_validate_rejects_any_protocol_deviation(change):
    cfg = valid_config()
    assert np128.validate(cfg)["expected_scenarios"] == 8
    change(cfg)
    with pytest.raises(ValueError):
        np128.validate(cfg)


def test_validate_only_seed_subsets():
    cfg = valid_config()
    assert np128.validate(cfg, only_seeds=[410601])["expected_scenarios"] == 4
    assert np128.validate(cfg, only_seeds=[410602])["expected_scenarios"] == 4
    assert np128.validate(cfg, only_seeds=[410601, 410602])["expected_scenarios"] == 8
    with pytest.raises(ValueError, match="subset"):
        np128.validate(cfg, only_seeds=[410401])
    with pytest.raises(ValueError, match="subset"):
        np128.validate(cfg, only_seeds=[])


def test_prequant_capture_device_parameter_preserves_old_behavior():
    model = fixture_model()
    panel = fixture_panel()
    reference = prequant_capture(model, panel, 8, 66)
    assert torch.equal(prequant_capture(model, panel, 8, 66, None), reference)
    assert torch.equal(prequant_capture(model, panel, 8, 66, torch.device("cpu")), reference)


def tiny_np128_config(source_label):
    sources = [{"control_seed": control_seed,
                "setup_manifest": f"experiments/manifests/p4-warmup_budget-{source_label}-setup-s{setup_seed}.json",
                "branch_manifest": f"experiments/manifests/p4-warmup_budget-{source_label}-d0-trained-s{setup_seed}.json"}
               for setup_seed, control_seed in ((410501, 410601), (410502, 410602))]
    return {"protocol_id": np128.PROTOCOL_ID, "kind": "null_precision_128",
            "cohort": "engineering", "status": "engineering_ready",
            "full_budget": False, "device": "cpu", "cpu_threads": 1,
            "sources": sources, "release_conditions": deepcopy(np128.RELEASE_CONDITIONS),
            "panel_sizes": [16, 32], "matched_null_counts": [2, 4], "outer_null_repeats": 2,
            "positive_doses": [.5, 2.], "ridge_penalty": 1., "null_band": .02,
            "candidate_acceptance_threshold": .02, "property_positive_floor": .10,
            "capture_batch_size": 8}


def cleanup(*labels):
    manifests = ROOT / "experiments/manifests"
    for label, kind in labels:
        shutil.rmtree(ROOT / "outputs/scenarios" / label, ignore_errors=True)
        for stale in manifests.glob(f"p4-{kind}-{label}-*.json"):
            stale.unlink()


def test_tiny_campaign_replays_and_scores_controls_end_to_end(tmp_path):
    source_label, label = "pytest-np128-source", "pytest-np128"
    source_config = ROOT / "experiments/configs" / f"{source_label}.yaml"
    config_path = ROOT / "experiments/configs" / f"{label}.yaml"
    cleanup((source_label, "warmup_budget"), (label, "null_precision_128"))
    manifests = ROOT / "experiments/manifests"
    try:
        cfg = tiny_config(tmp_path)
        cfg["seeds"] = [410501, 410502]
        # Configs live in the repo so each campaign's source archive binds them.
        source_config.write_text(yaml.safe_dump(cfg))
        source_summary = wb.run(source_config, label=source_label)
        assert source_summary["completed"] == source_summary["expected_scenarios"] == 16
        assert source_summary["failed"] == 0

        cfg = tiny_np128_config(source_label)
        config_path.write_text(yaml.safe_dump(cfg))
        assert np128.validate(cfg) == {"expected_scenarios": 8, "full_budget": False, **np128.FLAGS}
        summary = np128.run(config_path, label=label)
        assert summary["completed"] == summary["expected_scenarios"] == 8
        assert summary["failed"] == 0
        assert summary["scientific_evidence"] is False
        assert summary["privacy_outcome"] == "undetermined" and summary["qualified"] is False

        campaign_dir = ROOT / "outputs/scenarios" / label
        for setup_seed, control_seed in ((410501, 410601), (410502, 410602)):
            prepare_id = f"p4-null_precision_128-{label}-prepare-s{control_seed}"
            record = json.loads((manifests / f"{prepare_id}.json").read_text())
            assert record["kind"] == "null_precision_128" and record["status"] == "completed"
            assert record["scientific_evidence"] is False
            assert record["inputs"]["training_seed"] == setup_seed
            assert record["inputs"]["control_seed"] == control_seed
            prepare = json.loads((campaign_dir / prepare_id / "prepare_metrics.json").read_text())
            replay = prepare["replay_verification"]
            assert replay["verified"] is True and replay["actual"] == replay["expected"]
            assert prepare["new_training_updates"] == 2
            assert prepare["normal_candidate_scored"] is False
            assert prepare["privacy_outcome"] == "undetermined" and prepare["qualified"] is False
            branch_dir = (ROOT / "outputs/scenarios" / source_label /
                          f"p4-warmup_budget-{source_label}-d0-trained-s{setup_seed}")
            branch_metrics = json.loads((branch_dir / "metrics.json").read_text())
            assert replay["expected"]["remote_final_sha256"] == branch_metrics["remote_final_sha256"]
            assert replay["expected"]["trusted_final_sha256"] == branch_metrics["trusted_final_sha256"]
            checkpoint_sha = prepare["control_checkpoint_sha256"]
            for condition in np128.RELEASE_CONDITIONS:
                run_id = f"p4-null_precision_128-{label}-{condition['id']}-s{control_seed}"
                record = json.loads((manifests / f"{run_id}.json").read_text())
                assert record["kind"] == "null_precision_128" and record["status"] == "completed"
                assert record["inputs"]["release_condition"] == condition
                assert record["inputs"]["control_checkpoint_sha256"] == checkpoint_sha
                assert record["inputs"]["device"] == "cpu"
                c = json.loads((campaign_dir / run_id / "controls.json").read_text())
                assert c["binding"] == record["inputs"]
                assert c["adapter"] == np128.ADAPTER
                assert c["scientific_evidence"] is False and c["qualified"] is False
                assert c["privacy_outcome"] == "undetermined"
                assert c["normal_candidate_scored"] is False and c["new_training_updates"] == 0
                assert [p["sequences_per_panel"] for p in c["panels"]] == [16, 32]
                for panel in c["panels"]:
                    assert len(panel["no_signal_trials"]) == 2
                    for trial in panel["no_signal_trials"]:
                        assert [e["matched_null_count"] for e in trial["estimators"]] == [2, 4]
                    assert [d["dose"] for d in panel["positive_controls"]] == [0., .5, 2.]
                    for dose in panel["positive_controls"]:
                        assert [e["matched_null_count"] for e in dose["score"]["estimators"]] == [2, 4]
                        for support in dose["support"].values():
                            assert support["support_valid"]
                            assert support["q_bits"] == condition["q_bits"]
                            if dose["dose"] == 0:
                                assert support["zero_dose_exact"] is True
                saved = torch.load(campaign_dir / run_id / "control_means.pt", weights_only=True)
                assert len(saved["positive_controls"]) == 6

        verified = analyze(label)
        assert verified["scientific_evidence"] is False and verified["qualified"] is False
        assert verified["privacy_outcome"] == "undetermined"
        assert verified["completed"] == 8 and verified["failed"] == 0
        assert verified["replay_checksums_verified"] and verified["stored_estimates_verified"]
        assert (campaign_dir / "report.md").is_file()
        assert len(verified["pooled_controls"]) == 3 * 2 * 2
        for row in verified["pooled_controls"]:
            assert row["diagnostic_nulls"] == 4
            assert 0 <= row["fraction_within_null_band"] <= 1
            assert row["positive_checks"] == 4
    finally:
        cleanup((source_label, "warmup_budget"), (label, "null_precision_128"))
        source_config.unlink(missing_ok=True)
        config_path.unlink(missing_ok=True)
