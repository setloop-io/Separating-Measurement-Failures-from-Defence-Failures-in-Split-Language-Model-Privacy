"""Protocol boundaries, scorer behavior, and chain verification for structure precision."""
from copy import deepcopy
import json
import shutil

import numpy as np
import pytest
import torch
import yaml

from p4d import structure_precision as sp
from p4d import null_precision_128 as np128
from p4d import warmup_budget_scenarios as wb
from p4d.defenses import CausalAffineQuantizer
from p4d.experiment import ROOT
from p4d.null_precision_128 import RELEASE_CONDITIONS
from p4d.structure_precision_analysis import analyze
from p4d.warmup_scenarios import derangement

from test_null_precision_128 import tiny_np128_config
from test_warmup_budget import tiny_config


@pytest.fixture(autouse=True)
def one_thread():
    old = torch.get_num_threads()
    torch.set_num_threads(1)
    yield
    torch.set_num_threads(old)


def valid_config():
    return {"protocol_id": sp.PROTOCOL_ID, "kind": "structure_precision",
            "cohort": "engineering", "status": "engineering_ready",
            "full_budget": True, "device": "cpu",
            "sources": [
                {"control_seed": 410701,
                 "prepare_manifest": "experiments/manifests/p4-null_precision_128-precision-128-20260918-a-prepare-s410601.json"},
                {"control_seed": 410702,
                 "prepare_manifest": "experiments/manifests/p4-null_precision_128-precision-128-20260918-a-prepare-s410602.json"}],
            "release_conditions": deepcopy(RELEASE_CONDITIONS),
            **deepcopy(sp.BUDGET)}


def test_validate_accepts_the_protocol_configuration_without_source_files():
    assert sp.validate(valid_config()) == {"expected_scenarios": 6, "full_budget": True,
                                           **sp.FLAGS}


def test_committed_config_matches_the_protocol_constants():
    cfg = yaml.safe_load((ROOT / "experiments/configs/structure_precision_diagnostics.yaml").read_text())
    assert sp.validate(cfg) == {"expected_scenarios": 6, "full_budget": True, **sp.FLAGS}


@pytest.mark.parametrize("change", [
    lambda c: c.update(kind="null_precision_128"),
    lambda c: c.update(cohort="confirmation"),
    lambda c: c.update(status="frozen"),
    lambda c: c.update(protocol_id="p4-null-precision-128-0.1"),
    lambda c: c["sources"][1].update(control_seed=410602),
    lambda c: c["sources"][0].update(control_seed=410702),
    lambda c: c.update(sources=c["sources"][:1]),
    lambda c: c.update(sources=[c["sources"][0], dict(c["sources"][0])]),
    lambda c: c["sources"][1].update(prepare_manifest=c["sources"][0]["prepare_manifest"]),
    lambda c: c["sources"].append(dict(c["sources"][0])),
    lambda c: c["release_conditions"][1]["defense"].update(noise_scale=0.5),
    lambda c: c.update(release_conditions=c["release_conditions"][:2]),
    lambda c: c.update(panel_sizes=[4096, 16384]),
    lambda c: c.update(matched_null_counts=[1, 16]),
    lambda c: c.update(outer_null_repeats=8),
    lambda c: c.update(structure_positive_floor=0.10),
    lambda c: c.update(mlp_hidden=32),
    lambda c: c.update(mlp_lr=0.001),
    lambda c: c.update(mlp_row_batch=4096),
    lambda c: c["sources"][0].pop("prepare_manifest"),
    lambda c: c["sources"][0].update(extra_key=1),
])
def test_validate_rejects_any_protocol_deviation(change):
    cfg = valid_config()
    assert sp.validate(cfg)["expected_scenarios"] == 6
    change(cfg)
    with pytest.raises(ValueError):
        sp.validate(cfg)


def test_validate_only_seed_subsets():
    cfg = valid_config()
    assert sp.validate(cfg, only_seeds=[410701])["expected_scenarios"] == 3
    assert sp.validate(cfg, only_seeds=[410702])["expected_scenarios"] == 3
    assert sp.validate(cfg, only_seeds=[410701, 410702])["expected_scenarios"] == 6
    with pytest.raises(ValueError, match="subset"):
        sp.validate(cfg, only_seeds=[410601])
    with pytest.raises(ValueError, match="subset"):
        sp.validate(cfg, only_seeds=[])


def mlp_cfg():
    return {"mlp_hidden": 8, "mlp_lr": 3e-3, "mlp_row_batch": 256}


def test_structure_scorer_advantage_centers_near_zero_on_noise():
    rng = np.random.default_rng(9)
    rows, width, device = 2048, 32, torch.device("cpu")
    x = torch.tensor(rng.normal(size=(rows, width)), dtype=torch.float32)
    xt = torch.tensor(rng.normal(size=(rows, width)), dtype=torch.float32)
    y = torch.tensor(rng.integers(0, 5, rows), dtype=torch.long)
    yt = torch.tensor(rng.integers(0, 5, rows), dtype=torch.long)
    advantages = []
    for seed in (11, 22, 33):
        score = sp.structure_score(x, y, xt, yt, [1, 4], mlp_cfg(), seed, device)
        assert [e["matched_null_count"] for e in score["estimators"]] == [1, 4]
        assert len(score["acc_null"]) == 4 and score != sp.structure_score(x, y, xt, yt, [1, 4], mlp_cfg(), seed + 1, device)
        assert score == sp.structure_score(x, y, xt, yt, [1, 4], mlp_cfg(), seed, device)
        advantages.append(score["estimators"][-1]["advantage"])
    assert all(abs(a) < 0.08 for a in advantages)
    assert abs(np.mean(advantages)) < 0.05


def test_structure_scorer_detects_injected_class_code():
    rng = np.random.default_rng(17)
    rows, width, device = 2048, 32, torch.device("cpu")
    directions = sp.class_directions(width, 71)
    assert torch.allclose(torch.linalg.vector_norm(directions, dim=1), torch.ones(5))
    y = torch.tensor(rng.integers(0, 5, rows), dtype=torch.long)
    yt = torch.tensor(rng.integers(0, 5, rows), dtype=torch.long)
    base = torch.tensor(rng.normal(size=(rows, width)), dtype=torch.float32)
    base_test = torch.tensor(rng.normal(size=(rows, width)), dtype=torch.float32)
    scale = float(base.std(unbiased=False)) * width ** 0.5
    x = base + 1.0 * scale * directions[y]
    xt = base_test + 1.0 * scale * directions[yt]
    score = sp.structure_score(x, y, xt, yt, [1, 4], mlp_cfg(), 23, device)
    assert score["accuracy"] > 0.9
    assert score["estimators"][-1]["advantage"] > 0.5


def test_release_support_zero_dose_equality_and_no_input_mutation():
    generator = torch.Generator().manual_seed(21)
    pre = torch.randn(32, 4, 32, generator=generator)
    old = pre.clone()
    classes = torch.randint(0, 5, (32, 4), generator=generator)
    directions = sp.class_directions(32, 71)
    donors = derangement(32, 41)
    quantizer = CausalAffineQuantizer(8)
    released, support = sp.quantized_release(pre, quantizer, 8)
    assert released.shape == pre.shape and support["support_valid"]
    assert support["maximum_normalized_rounding_error"] <= 1e-3
    assert torch.equal(released, quantizer(pre)[0])
    for dose in (0., .5, 2.):
        features, checks = sp.inject_and_release(pre, classes, donors, directions, 1.5, dose, quantizer, 8)
        assert features.shape == pre.shape and checks["support_valid"]
        assert checks["maximum_normalized_rounding_error"] <= 1e-3
        if dose == 0:
            assert checks["zero_dose_exact"]
            assert torch.equal(features, released[donors])
        else:
            assert checks["zero_dose_exact"] is None
            assert not torch.equal(features, released[donors])
    assert torch.equal(pre, old)


def tiny_structure_config(np128_label):
    sources = [{"control_seed": control_seed,
                "prepare_manifest": f"experiments/manifests/p4-null_precision_128-{np128_label}-prepare-s{prepare_seed}.json"}
               for prepare_seed, control_seed in ((410601, 410701), (410602, 410702))]
    return {"protocol_id": sp.PROTOCOL_ID, "kind": "structure_precision",
            "cohort": "engineering", "status": "engineering_ready",
            "full_budget": False, "device": "cpu", "cpu_threads": 1,
            "sources": sources, "release_conditions": deepcopy(RELEASE_CONDITIONS),
            "panel_sizes": [16, 32], "matched_null_counts": [1, 2], "outer_null_repeats": 2,
            "positive_doses": [.5, 2.], "null_band": .02, "structure_positive_floor": .02,
            "capture_batch_size": 8, "mlp_hidden": 8, "mlp_lr": 3e-3, "mlp_row_batch": 64}


def cleanup(*labels):
    manifests = ROOT / "experiments/manifests"
    for label, kind in labels:
        shutil.rmtree(ROOT / "outputs/scenarios" / label, ignore_errors=True)
        for stale in manifests.glob(f"p4-{kind}-{label}-*.json"):
            stale.unlink()


def test_tiny_campaign_scores_structure_controls_end_to_end(tmp_path):
    source_label, np128_label, label = "pytest-sp-source", "pytest-sp-np128", "pytest-sp"
    configs = [ROOT / "experiments/configs" / f"{name}.yaml"
               for name in (source_label, np128_label, label)]
    cleanup((source_label, "warmup_budget"), (np128_label, "null_precision_128"),
            (label, "structure_precision"))
    manifests = ROOT / "experiments/manifests"
    try:
        cfg = tiny_config(tmp_path)
        cfg["seeds"] = [410501, 410502]
        # Configs live in the repo so each campaign's source archive binds them.
        configs[0].write_text(yaml.safe_dump(cfg))
        source_summary = wb.run(configs[0], label=source_label)
        assert source_summary["completed"] == source_summary["expected_scenarios"] == 16
        assert source_summary["failed"] == 0

        cfg = tiny_np128_config(source_label)
        # The structure sources are the prepare manifests; one condition suffices here.
        cfg["release_conditions"] = cfg["release_conditions"][:1]
        configs[1].write_text(yaml.safe_dump(cfg))
        np128_summary = np128.run(configs[1], label=np128_label)
        assert np128_summary["completed"] == np128_summary["expected_scenarios"] == 4
        assert np128_summary["failed"] == 0

        cfg = tiny_structure_config(np128_label)
        configs[2].write_text(yaml.safe_dump(cfg))
        assert sp.validate(cfg) == {"expected_scenarios": 6, "full_budget": False, **sp.FLAGS}
        summary = sp.run(configs[2], label=label)
        assert summary["completed"] == summary["expected_scenarios"] == 6
        assert summary["failed"] == 0
        assert summary["scientific_evidence"] is False
        assert summary["privacy_outcome"] == "undetermined" and summary["qualified"] is False

        campaign_dir = ROOT / "outputs/scenarios" / label
        for prepare_seed, control_seed in ((410601, 410701), (410602, 410702)):
            prepare_id = f"p4-null_precision_128-{np128_label}-prepare-s{prepare_seed}"
            prepare_manifest = json.loads((manifests / f"{prepare_id}.json").read_text())
            for condition in RELEASE_CONDITIONS:
                run_id = f"p4-structure_precision-{label}-{condition['id']}-s{control_seed}"
                record = json.loads((manifests / f"{run_id}.json").read_text())
                assert record["kind"] == "structure_precision" and record["status"] == "completed"
                assert record["scientific_evidence"] is False
                assert record["inputs"]["prepare_manifest"] == f"experiments/manifests/{prepare_id}.json"
                assert record["inputs"]["release_condition"] == condition
                assert record["inputs"]["device"] == "cpu"
                assert (record["inputs"]["control_checkpoint_sha256"]
                        == prepare_manifest["inputs"] and True
                        or record["inputs"]["control_checkpoint_sha256"])
                c = json.loads((campaign_dir / run_id / "controls.json").read_text())
                assert c["binding"] == record["inputs"]
                assert c["adapter"] == sp.ADAPTER and c["target"] == "next_byte_class"
                assert c["scientific_evidence"] is False and c["qualified"] is False
                assert c["privacy_outcome"] == "undetermined"
                assert c["normal_candidate_scored"] is False and c["new_training_updates"] == 0
                assert len(c["class_directions"]["basis_cosines"]) == 5
                assert [p["sequences_per_panel"] for p in c["panels"]] == [16, 32]
                for panel in c["panels"]:
                    assert panel["token_rows_per_panel"] == panel["sequences_per_panel"] * 8
                    assert len(panel["no_signal_trials"]) == 2
                    for trial in panel["no_signal_trials"]:
                        assert [e["matched_null_count"] for e in trial["estimators"]] == [1, 2]
                        assert len(trial["acc_null"]) == 2
                    assert [d["dose"] for d in panel["positive_controls"]] == [0., .5, 2.]
                    for dose in panel["positive_controls"]:
                        assert [e["matched_null_count"] for e in dose["score"]["estimators"]] == [1, 2]
                        for support in dose["support"].values():
                            assert support["support_valid"]
                            assert support["q_bits"] == condition["q_bits"]
                            if dose["dose"] == 0:
                                assert support["zero_dose_exact"] is True
                saved = torch.load(campaign_dir / run_id / "control_features.pt", weights_only=True)
                assert set(saved["label_classes"]) == {"fit", "test"}
                assert saved["label_classes"]["fit"].shape == (32, 8)
                assert saved["class_directions"].shape == (5, 256)

        verified = analyze(label)
        assert verified["scientific_evidence"] is False and verified["qualified"] is False
        assert verified["privacy_outcome"] == "undetermined"
        assert verified["completed"] == 6 and verified["failed"] == 0
        assert verified["replay_checksums_verified"] and verified["stored_estimates_verified"]
        assert (campaign_dir / "report.md").is_file()
        assert len(verified["pooled_controls"]) == 3 * 2 * 2
        for row in verified["pooled_controls"]:
            assert row["diagnostic_nulls"] == 4
            assert 0 <= row["fraction_within_null_band"] <= 1
            assert row["positive_checks"] == 4
    finally:
        cleanup((source_label, "warmup_budget"), (np128_label, "null_precision_128"),
                (label, "structure_precision"))
        for path in configs:
            path.unlink(missing_ok=True)
