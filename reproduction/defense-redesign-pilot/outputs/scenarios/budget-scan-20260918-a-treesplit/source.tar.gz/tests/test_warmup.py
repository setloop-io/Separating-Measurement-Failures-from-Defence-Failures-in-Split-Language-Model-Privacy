"""Scientific-integrity checks for the new engineering schedule and null adapter."""
from copy import deepcopy
import numpy as np
import pytest
import torch
import yaml
from pcr.data import BatchSampler
from pcr.model import BackboneConfig
from pcr.modes import remote_parameters
from pcr.privacy_attacks_p4b import sequence_targets
from pcr.split import SplitConfig
from pcr.train import build_initialized_model
from pcr.utils import parameters_checksum
from p4d import calibration
from p4d.experiment import ROOT, measurement
from p4d.model import BoundaryCapture, attach_defense
from p4d.warmup_scenarios import (
    basis_cosine, basis_snapshot, boundary_means, derangement, fork_branch, panel_batches,
    property_score, stability_curve, tensor_hash, text_panel, train_steps, trusted_checksum, validate,
)


@pytest.fixture(autouse=True)
def one_thread():
    old = torch.get_num_threads()
    torch.set_num_threads(1)
    yield
    torch.set_num_threads(old)


def tiny_model():
    cfg = BackboneConfig(d_model=32, n_heads=1, n_layers=4, d_ff=64, max_seq_len=8)
    split = SplitConfig(start=1, span=2, width=32, q_bits=8)
    model = build_initialized_model(cfg, "frozen_random", split, 1234, "warmup-test")
    return attach_defense(model, {"name": "none"})


def corpus():
    rng = np.random.default_rng(31)
    alphabet = np.array(list(b"A story!?. ") + [10], dtype=np.uint8)
    return torch.tensor(rng.choice(alphabet, 10000))


def test_panels_are_disjoint_including_next_targets_and_deterministically_nested():
    text = corpus()
    a = text_panel(text, 0, 500, 32, 8, 123)
    b = text_panel(text, 500, 1000, 32, 8, 456)
    short = text_panel(text, 0, 500, 16, 8, 123)
    assert torch.equal(short["tokens"], a["tokens"][:16])
    supports = []
    for panel in (a, b):
        for i, offset in enumerate(panel["offsets"]):
            offset = int(offset)
            supports.append(set(range(offset, offset + 9)))
            assert torch.equal(panel["tokens"][i], text[offset:offset + 8].long())
            assert torch.equal(panel["next_tokens"][i], text[offset + 1:offset + 9].long())
    assert len(set.union(*supports)) == sum(map(len, supports))
    with pytest.raises(ValueError, match="Insufficient"):
        text_panel(text, 0, 100, 12, 8, 123)


@pytest.mark.parametrize("variant", ["d0", "d1_initial_basis", "d1_warm_basis"])
def test_selected_forward_view_equals_full_capture_and_preserves_measurement_rng(variant):
    common = tiny_model()
    bases = {"initial": torch.eye(32)[:1], "warm": torch.eye(32)[1:2]}
    model = fork_branch(common, variant, "trained", bases, .1, 17)
    model.train()
    panel = text_panel(corpus(), 0, 1000, 16, 8, 43)
    state = deepcopy(model.state_dict())
    selected = boundary_means(model, panel, 4, 234)
    full = []
    with measurement(model, 234), torch.no_grad():
        for x, _ in panel_batches(panel, 4):
            capture = BoundaryCapture()
            model(x, capture=capture)
            full.append(capture.values["forward_values"].mean(1))
    assert torch.equal(selected, torch.cat(full))
    assert model.training
    assert all(torch.equal(v, model.state_dict()[k]) for k, v in state.items())


def test_common_warmup_fork_training_and_basis_immutability_end_to_end():
    common, text = tiny_model(), corpus()
    fit = text_panel(text, 1000, 2000, 32, 8, 10)
    test = text_panel(text, 2000, 3000, 32, 8, 11)
    initial, _ = basis_snapshot(common, fit, test, 8, 15)
    remote_before = parameters_checksum(remote_parameters(common))
    sampler = BatchSampler(text[:1000], 4, 8, 9, "test")
    opt = {"lr": .002, "warmup_steps": 1}
    train_steps(common, sampler, opt, 2)
    warm, _ = basis_snapshot(common, fit, test, 8, 15)
    assert parameters_checksum(remote_parameters(common)) == remote_before
    assert not torch.equal(initial, warm)
    bases = {"initial": initial, "warm": warm}
    models = [fork_branch(common, "d1_warm_basis", mode, bases, .1, 71)
              for mode in ("trained", "frozen_random", "removed_remote")]
    assert len({trusted_checksum(m) for m in [common, *models]}) == 1
    assert parameters_checksum(remote_parameters(models[0])) == parameters_checksum(remote_parameters(models[1]))
    assert not remote_parameters(models[2])
    assert all(not p.requires_grad for p in remote_parameters(models[1]))
    baseline = deepcopy(common.state_dict())
    for model in models:
        train_steps(model, sampler, opt, 2, 2)
        assert tensor_hash(model.remote_path.defense.directions) == tensor_hash(warm)
        # Diagnostic re-fitting must not overwrite the actual frozen defense basis.
        basis_snapshot(model, fit, test, 8, 15)
        assert tensor_hash(model.remote_path.defense.directions) == tensor_hash(warm)
    assert parameters_checksum(remote_parameters(models[0])) != remote_before
    assert parameters_checksum(remote_parameters(models[1])) == remote_before
    assert all(torch.equal(v, common.state_dict()[k]) for k, v in baseline.items())
    means = [boundary_means(models[0], p, 8, 21) for p in (fit, test)]
    diagnostic = stability_curve(*means, fit["tokens"], test["tokens"], [16, 32], 2, 31)
    assert diagnostic["scientific_evidence"] is False
    assert diagnostic["qualified"] is False
    assert diagnostic["privacy_outcome"] == "undetermined"


def test_primary_statistic_matches_existing_adapter_for_the_same_rng(monkeypatch):
    rng = np.random.default_rng(13)
    x, xt = rng.normal(size=(30, 7)), rng.normal(size=(20, 7))
    y, yt = rng.normal(size=30), rng.normal(size=20)
    monkeypatch.setattr(calibration, "_features", lambda events: (x, {"punctuation_fraction": y})
                        if events == "fit" else (xt, {"punctuation_fraction": yt}))
    old = calibration.score_properties("fit", "test", seed=20)["punctuation_fraction"]
    new = property_score(x, y, xt, yt, 20)
    assert {k: old[k] for k in new} == new
    with pytest.raises(ValueError, match="varying"):
        property_score(x, np.ones(30), xt, yt, 20)


def test_stability_preserves_all_permutations_and_fixed_band():
    rng = np.random.default_rng(55)
    fit = text_panel(corpus(), 0, 2000, 64, 8, 12)
    test = text_panel(corpus(), 2000, 4000, 64, 8, 13)
    means = [torch.tensor(rng.normal(size=(64, 8)), dtype=torch.float32) for _ in range(2)]
    result = stability_curve(*means, fit["tokens"], test["tokens"], [16, 64], 8, 14)
    assert result == stability_curve(*means, fit["tokens"], test["tokens"], [16, 64], 8, 14)
    for c in result["curve"]:
        assert len(c["nulls"]) == 8
        advantages = np.array([r["advantage"] for r in c["nulls"]])
        assert c["within_null_band"] == int((abs(advantages) <= .02).sum())
        assert c["p95_absolute_null_advantage"] == np.quantile(abs(advantages), .95)
        for r in c["nulls"]:
            n = c["sequences_per_panel"]
            donors = derangement(n, r["seeds"]["fit-donors"])
            assert (donors != np.arange(n)).all()
            assert sorted(donors) == list(range(n))


def test_basis_cosine_sign_invariance():
    basis = torch.eye(8)[:1]
    assert basis_cosine(basis, -basis) == 1
    assert basis_cosine(basis, torch.eye(8)[1:2]) == 0


@pytest.mark.parametrize("key,value", [("cohort", "confirmation"), ("seeds", [419101]),
                                        ("null_repeats", 1), ("noise_scale", .5)])
def test_run_validation_protects_scientific_seeds_and_fixed_design(key, value):
    cfg = yaml.safe_load((ROOT / "experiments/configs/warmup_diagnostics.yaml").read_text())
    assert validate(cfg)["expected_scenarios"] == 22
    cfg[key] = value
    with pytest.raises(ValueError):
        validate(cfg)
