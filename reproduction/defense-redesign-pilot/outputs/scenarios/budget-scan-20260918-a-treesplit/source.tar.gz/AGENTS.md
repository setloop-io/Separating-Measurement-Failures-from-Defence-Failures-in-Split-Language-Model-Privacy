# Working rules for this paper

1. This paper builds on Paper 3's empty feasible set in its finite tested mechanism
   family. Never re-run Paper 3 experiments; inherit evidence through its finalized
   claim-evidence ledger. Historical universal or feature-necessity wording is not
   a confirmed result. Preserve the supplied `Deep-research.md` as an input; use
   `outputs/deep_research_audit.md` for its corrections and source checks.
2. A qualified probe's nondetection is not a security certificate. Never call a
   defense "secure" or "private" solely because its measured attacks pass. Scope
   every result to its exact target, channel, defense, side information, and cohort.
3. Keep exploratory and confirmatory cohorts separate. Freeze the protocol, code
   revision, metrics, thresholds, and seed list before confirmatory execution.
4. The inferential unit is the independent training run/seed, not token rows or frames.
5. An empirical defense-success claim requires the same cell to meet the frozen
   utility, causal-gain, and qualified privacy criteria, with the required active
   evaluation complete. Missing/unqualified attacks remain undetermined. The 0.10
   property positive-control floor is not the 0.02 privacy acceptance threshold.
6. Start at span 4 @ 2, width 256, with a fresh q=8 Paper 4 anchor and paired
   trained/frozen-random/removed controls plus all-local. D3 changes q by design.
   Paper 4's per-token quantizer differs from Paper 3's per-tensor quantizer;
   document the difference and do not call the new anchor an exact replication.
7. Privacy claims require the declared complete transcript, matched nulls, and
   calibrated positive controls. Name any omitted channel explicitly.
8. Every manuscript number must resolve through `docs/CLAIM_EVIDENCE_LEDGER.md` to
   a committed manifest and generated summary.
9. Do not edit the archived source papers to support this project. Prior evidence
   is provenance and motivation only.
10. Active attacker evaluation is mandatory before any positive defense claim.
    More powerful offline probes alone do not satisfy this requirement.
11. P0 engineering diagnostics may run before scientific freeze, using separate
    seeds, source snapshots, and manifests marked `scientific_evidence: false`.
    They do not select a winning defense, test hypotheses, or qualify instruments.
12. Keep the vendored Paper 3 snapshot unmodified and verify its recorded hashes.
    Use the isolated locked environment; changes belong in `src/p4d`, not `pcr`.
