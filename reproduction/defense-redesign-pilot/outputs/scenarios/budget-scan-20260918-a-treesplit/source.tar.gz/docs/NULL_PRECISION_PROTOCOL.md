# Matched-null precision and quantized control engineering

Protocol `p4-null-precision-engineering-0.1`. Engineering only; commit this protocol,
configuration, implementation, and tests before execution. No scientific seeds or
new training runs. Six scenarios: two verified shared warmup checkpoints, each
under D0 q=8, D1 warmed-basis sigma=0.1 q=8, and D3 q=2 release conditions.
Control seeds 410401 and 410402 are distinct from all previous namespaces.

These are release conditions applied to the common D0-trained checkpoint, not
models trained with each defense. The checkpoint has sixteen frozen-remote warmup
updates. Reuse its saved nonoverlapping 512-window basis-fit and 1,024-window
probe fit/evaluation panels. Hash-check the source, checkpoint, bases, and panels.
Do not score normal candidates or select a defense. No utility claim is assessed.

## Procedure under test

On mean-forward punctuation features, compare the separately versioned statistic

    A_K = r(fitted probe, test target) - mean(r_null[1:K])

for K in {1,16,64}; the inner nulls use independently shuffled fit labels and test
feature rows, as in the previous single-null adapter. Ridge penalty is 1.0, with
float64 linear algebra. K=1 must match the reference single-target calculation
within numerical tolerance. K is nested within each trial, using the same fitted
probe and null draws. This comparison changes the estimator, not the candidate
acceptance threshold of 0.02. All three variants require fresh qualification.

At panel sizes 256 and 1,024, create 32 outer no-signal controls by independently
deranging whole sequences in the fit and test feature pools. For each outer
control, run the complete A_K procedure. Do not average only the calibration
controls while retaining a single-null candidate statistic. Save all seeds, r,
all 64 r_null values, and each A_K. Report the mean, standard deviation, 95th
percentile absolute advantage, count within the absolute 0.02 band, and count
above +0.02. The latter is a conditional no-signal rejection diagnostic, not a
population false-positive rate. Derangements preserve margins but finite donor
assignments can retain chance association. Repetitions and release conditions
share text/model seeds; they are not independent scientific replications.

The fitted-probe r term is shared across K and is not averaged away by increasing
the number of inner nulls. Report its spread separately from the spread of the
mean matched-null term. Larger K alone may therefore be insufficient.

## Positive control with valid quantizer support

Capture post-defense, pre-quantization tensors in an evaluator-only copy. Before
any final quantization, independently derange fit and test donor sequences and add
a sequence-constant punctuation signal along a seeded unit direction. Center and
scale the target using only the basis-fit calibration panel. Set the feature scale
to sqrt(width) times the standard deviation of the mean raw encoder features on
that panel. Keep direction, normalization, and dose fixed across panel sizes.

Use doses 0, 0.5, and 2.0. Dose zero is an exact equality check against the ordinary
quantized donor values; positive doses test sensitivity. Injection occurs after
D1 perturbation and before one final quantization. It does not ask whether the
defense removes an injected signal. Whole-sequence labels are evaluator-only
synthetic controls, not a causal normal inference mechanism.

Final quantizer min/scale are recomputed from the perturbed tensor, preserving its
actual q-specific codebook relation. Fail on nonfinite values, invalid metadata,
out-of-range codes, or normalized rounding error above 1e-3. Save support checks
and metadata hashes, but score **only the mean-forward values**. Codebook validity
does not establish that the synthetic controls resemble natural representations.
The metadata themselves can reveal the signal; this stage does not score them.

For each dose and panel size, use the same A_K scorer and fixed positive floor
0.10. Save every score, including failed floors and the dose-zero no-signal score.
These numerical checks never assign qualification in an engineering cohort.

## Verification and outcome

The runner produces source/config/checkpoint/panel-bound scenario manifests and
hashes of captured control means, signal specifications, support checks, and raw
statistics. The analyzer verifies provenance, recomputes every A_K from stored
correlations, and aggregates only descriptively. Tests compare the cached ridge
implementation to independently fit probes, check permutation indexing and
constant-target failures, exact zero-dose behavior, valid quantized support,
private RNG restoration, and scientific-cohort refusal.

Every outcome is `scientific_evidence: false`, `qualified: false`, privacy
`undetermined`. Do not change thresholds, discard failures, or retrospectively
qualify an old run. Any new scientific scoring or aggregation rule must be frozen
and evaluated end to end on fresh calibration data before use in the pilot.

Unevaluated: next-byte classes; returned values; quantizer metadata attacks;
full-precision inbound/outbound gradients; evolving remote and optimizer state;
timing; active/adaptive attackers; within-run joint and cross-run attacks; history
accumulation; canary and natural-sequence membership; unrestricted semantics.
This stage neither qualifies the full transcript nor supports a defense claim.
