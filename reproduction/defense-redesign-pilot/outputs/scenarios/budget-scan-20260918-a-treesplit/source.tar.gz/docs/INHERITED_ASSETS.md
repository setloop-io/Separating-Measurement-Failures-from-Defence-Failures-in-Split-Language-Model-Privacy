# Inherited assets and integration limits

Use the existing `pcr` package from Paper 3 revision
`52191c430110bd8d9dee80538fde22bf1726e56a`. Keep the Paper 4 environment and extensions
isolated, record the resolved dependency path/revision, and do not edit or rerun Paper 3's
historical experiments. Fresh Paper 4 controls are necessary new study artifacts.

The isolated environment uses `uv.lock` and unmodified vendored `pcr` source, license,
and package metadata from that revision. Validate the local dataset copy against its
recorded hash. Paper 4's quantizer extension uses per-token min/max along the latent
dimension instead of the inherited per-tensor statistics. This intentional mechanism
change needs fresh D0 controls and explicit quantizer/metadata provenance; equal q does
not justify pooling results with Paper 3.
The runner also changes the historical data partition to disjoint 80% training, 10%
calibration, 5% probe-fit, and 5% evaluation regions. Verify byte boundaries and prevent
window overlap across regions; shared corpus identity is not a shared experimental cohort.

The final Paper 3 [ledger](../../Paper%203%20-%20Privacy-Constrained%20Remote/docs/CLAIM_EVIDENCE_LEDGER.md)
is the authority for inherited evidence. Historical file names and labels are not a license
to repeat superseded claims. This inventory describes reusable interfaces and required checks;
it does not certify Paper 4 integration or qualification.

## Infrastructure to reuse with P0 verification

| Asset in Paper 3 | Path | Paper 4 obligation |
|---|---|---|
| Single-cell training | `src/pcr/train.py` | Verify mode application after construction, matched training semantics, full configuration, and stopping budget |
| Split wrapper and quantizer | `src/pcr/split.py` | Place forward defense before final quantization; distinguish actual messages from transformed capture views |
| Backbone and remote modes | `src/pcr/model.py`, `src/pcr/modes.py` | Test trained/frozen/removed/all-local behavior; share trusted initialization and paired data streams |
| Data and probe panels | `src/pcr/data.py` | Record corpus hash/splits; reserve disjoint calibration/evaluation panels and declare attacker data access |
| Transcript inventory/capture | `src/pcr/transcript.py` | Enumeration is not coverage; preserve available precision and label missing channels |
| FLOP accounting | `src/pcr/instrument.py` | Analytic estimates, not a deployed transport or edge-memory benchmark |
| Manifest and utility helpers | `src/pcr/manifest.py`, `src/pcr/utils.py` | Protocol-qualified IDs, source/dependency hashes, explicit RNG streams and artifact checksums |
| Statistical helpers | `scripts/stats_utils.py` | Freeze paired seed-level analysis and multiplicity; do not inherit unrelated gates blindly |

Inherited defense-noise/capture behavior requires particular care: Paper 3's D1 captures
consume training noise. Paper 4 must use independent training-defense, evaluation/capture,
calibration, and attacker RNG streams and verify capture-frequency invariance before a pilot.

Do not execute inherited pilot, confirmation, rate, segment-statistic, replication, or
P5 delegation matrices. They are reference provenance, not Paper 4 jobs. Read existing
artifacts without rewriting them. New runs belong to Paper 4 configuration, output, and
manifest directories, with fresh seed namespaces.

## Privacy code: reusable instruments, not transferable qualification

| Instrument | Source | Inherited qualification boundary |
|---|---|---|
| Token inversion | `src/pcr/privacy.py` | Prior probe-specific calibration; independently learned latent coordinate transfer is not established |
| Sequence-property-v2 | `src/pcr/privacy_attacks_p4b.py` | Punctuation qualified; vowel/newline nulls failed. Family status does not qualify every target |
| Next-byte structure | `src/pcr/privacy_attacks_p4b.py` | Byte classes only; requalify in each new defense/channel/setting |
| History and canary membership | `src/pcr/privacy_attacks_p4b.py` | Unqualified in Paper 3; code presence is not evidence of coverage |
| Earlier broadened families | `src/pcr/privacy_attacks.py` | Unqualified P4a instruments; diagnostic reference only |
| Gradient-channel workflows | `scripts/run_p5_calibration.py`, `scripts/analyze_delegation.py` | Only baseline structure qualified on processed gradients; all defended variants unqualified |

A target model may have the same width as a calibration backbone yet use unrelated latent
coordinates. Paper 4 must specify permitted same-model public-data fitting or independently
validate a coordinate mapping. The property-direction estimator has the same obligation.
Keep injected controls at the attacker input distinct from pre-defense signal-removal checks.

## Numerical gates: distinguish qualification from acceptance

| Quantity | Proposed value | Use/provenance |
|---|---|---|
| Mean Δ_U | ≤ 0.10 nats, upper 95% confidence limit ≤ 0.12 | Paper 3 P5 utility gate, adopted prospectively for Paper 4 |
| Mean G_R | ≥ 0.01 nats plus a frozen corrected paired test | Practical-gain criterion motivated by Paper 3 P2; P5's share gate was different |
| Qualified candidate attack advantage | Worst seed ≤ 0.02 for every required combination | Paper 3 P5 acceptance gate; retain exact target/channel scope |
| Property positive-signal floor | ≥ 0.10 | Instrument qualification, not privacy acceptance |
| Structure positive-signal floor | ≥ 0.02 | Instrument qualification |
| Calibration null band | Absolute null ≤ 0.02 | Required per intended target/channel/defense |

Exact controls, doses, coordinate policy, and aggregation must be frozen before affected
Paper 4 cohorts. An unqualified or absent required channel leaves eligibility undetermined.
Any positive claim additionally needs complete declared-transcript and active evaluation;
forward nondetection alone cannot establish defense success.

## Extensions to build and qualify

1. D1 noise along orthonormal calibrated directions, shared across sequence positions and
   applied before final forward quantization; independent RNG and identity controls.
2. D3 lower forward precision with unchanged segment, width, capacity, and training controls;
   optional D1+D3 exploration includes the individual treatment controls.
3. Defense-specific transcript captures, matched controls, and scorer integration with
   explicit full-precision views and model-coordinate handling.
4. Separate stronger passive attacks from actual message/computation-manipulating active
   attacks. The latter require their own implementation, intervention controls, and freeze.
5. D2 adversarial training as a later extension; D4 deferred; D5 a mean-pooling invariance
   control, not a privacy candidate.

Paper 1 motivates channel-explicit calibration but uses a different decoy topology. Paper 2
assets are optional conceptual references, not automatically compatible code or transferred
results. Neither paper's mitigation costs or systems figures are Paper 4 evidence.
