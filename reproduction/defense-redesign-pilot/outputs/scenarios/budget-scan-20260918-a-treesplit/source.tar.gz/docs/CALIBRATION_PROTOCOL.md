# Next stage: attack calibration specification

ID: `p4-calibration-0.1-draft`. Status: **DRAFT; not executed or qualified**.
This document defines the work between the completed engineering matrix and the
exploratory pilot freeze. It does not inherit Paper 3 qualification verdicts.

## Target and view registry

| Target | Initial scorer | Initial view | Role |
|---|---|---|---|
| Punctuation fraction | Ridge on sequence-mean features | Released forward values | Primary |
| Actual next-byte class | Five-class MLP on token features | Released forward values | Primary |
| Vowel fraction / newline count | Separate ridge targets | Released forward values | Secondary; independently qualify |
| Public quantizer metadata | Scorer and feature alignment pending | Per-token minimum/scale | Required leakage assessment before complete-view claims |
| Returned values / full-precision gradients | Channel-specific adapters pending | Exact computation values | Required before complete-view claims |
| State, joint/history, membership, timing | Attack designs pending | As specified by each threat model | Explicit omissions until implemented and qualified |

The forward adapters are versioned `p4-probe-adapters-0.1`; the class MLP and actual
next-byte labeling differ from inherited workflows. Fitting occurs in the evaluated
model's coordinates, using only permitted attacker-fit text. Defense calibration,
attacker fit, and attack evaluation cannot use the same held-out targets to select
an intervention. Window overlap within a region must be accounted for; contiguous
corpus regions are not independent corpora or documents.

## Control construction to freeze

For each exact model/defense/strength/q/checkpoint/view/target binding, produce:

1. **Positive sensitivity panel:** inject a known target-dependent signal at the
   declared observer input, preserving the intended feature shape. For a property
   target this can be a centered target signal in a recorded direction; for byte
   classes, a recorded class code in reserved diagnostic directions. Freeze the
   dose, direction, normalization, and attacker budget before qualification scoring.
   Diagnostic injection occurs only in the evaluator's control copy. It is not a
   claim that the normal remote observes these labels.
2. **No-signal panel:** remove feature/target association while retaining the shape,
   precision, marginal scale, and sequence grouping relevant to that view. Specify
   independent donor/permutation identities for fit and test panels. Constant or
   insufficiently varying targets invalidate the test instead of yielding zero.
3. **Normal defended captures:** score the actual released values with a matched
   attack/null pipeline. Controls 1–2 qualify detector sensitivity and specificity;
   they are not these normal candidate scores.
4. **Separate mechanism diagnostic:** pre-defense injection, if used, asks whether
   the defense attenuates a signal. It cannot replace the observer-input positive
   sensitivity control: a correctly removed signal must not make a detector seem
   qualified or unqualified by itself.

The nonzero doses, feature standardization, model checkpoint/basis policy, panel
sizes, sequence lengths, permitted auxiliary information, attack stopping rules,
and worst-seed aggregation are pending. Do not choose them retrospectively to
turn a normal candidate's score into a pass. Proposed calibration seeds
419101–419104 are reserved in `experiments/seed_registry.json`; they have not run.

## Qualification versus candidate decision

The proposed control floors are positive advantage ≥0.10 for a property target and
≥0.02 for next-byte structure, with absolute null advantage ≤0.02. A target qualifies
only when both checks pass under its exact binding. Unknown/nonfinite scores and
failed controls are unqualified/undetermined. Threshold stability across panel and
attacker seeds needs assessment before freeze; two probe epochs in P0 do not qualify
a detector.

The [warmup/stability diagnostic](WARMUP_STABILITY_PROTOCOL.md) tests the unchanged
0.02 null band using 16 donor permutations at each of 16, 64, 256, and 1,024
nonoverlapping sequence windows. It uses fresh engineering seeds and a separately
versioned primary-property-only adapter. Neither a favorable repetition nor a
favorable panel-size average is scientific qualification. Positive-control support,
independent scientific calibration, and the aggregation rule still require freeze.

That campaign completed as `warmup-20260910-a`: 171/288 null checks still failed
the band at 1,024 sequences. Its [assessment](WARMUP_STABILITY_DECISION.md) makes
control-only precision and end-to-end statistical validation the next prerequisite.
This engineering result does not change a threshold or qualify an instrument.

The subsequent [matched-null precision protocol](NULL_PRECISION_PROTOCOL.md)
implements a control-only comparison of K=1/16/64 inner nulls on saved common
warmup checkpoints, using fresh control seeds 410401/410402. It also injects
positive controls after defense but before final quantization, recomputes min/scale,
and checks zero-dose equality and valid codebook support. This addresses support
consistency for that forward control; naturalistic control distributions and
metadata attacks remain separate concerns. Both the positive and no-signal copies
use the same estimator. The pilot does not inherit any preferred K or qualification.

The completed `precision-20260910-a` campaign passed the positive sensitivity and
codebook checks but left 85/192 no-signal trials outside ±0.02 at K=64 and 1,024
sequences. Its [assessment](NULL_PRECISION_DECISION.md) calls for additional
independent text and validation at the pilot sequence length. The current 5%
probe regions cannot supply 1,024 disjoint length-128 windows. Selecting a new
dataset, partition, estimator, or uncertainty rule requires explicit prospective
specification; no retrospective change is made to previous qualification records.

Only after qualification is the separate candidate acceptance threshold of 0.02
applied to normal attack advantage. One qualified positive result can reject a
cell even if other views are missing. Missing required views cannot yield acceptance.
Correlation differences and accuracy differences remain separate metrics; neither
is a leakage probability. No security certificate follows from nondetection.

## Required qualification record and completion condition

Record protocol/source/lock hashes; calibration cohort and derived seeds; model,
checkpoint, basis, and exact treatment identity; view/target/side-information binding;
panel hashes and target variation; positive dose and null construction; attack
architecture/budget; each raw score, matched-null advantage, threshold, and verdict.
The helper functions in `src/p4d/calibration.py` supply scoring and gate logic;
the controlled capture generator and a schema-validated **engineering** record now
exist in `src/p4d/controls.py` and `src/p4d/calibration_scenarios.py`. Their protocol
is [SCENARIO_PROTOCOL.md](SCENARIO_PROTOCOL.md). This does not supply a frozen
scientific qualification record: checkpoint/basis policy, valid control domains,
panel sizing, thresholds, and qualification aggregation still require validation.

Before the pilot executes, freeze this calibration implementation and the pilot's
D1 basis/checkpoint procedure, then qualify the intended pilot views. A record
covering one target does not qualify its entire family. Complete-transcript and
active-attacker qualification require additional protocols and cannot be inferred
from these passive forward controls. No positive defense claim is unlocked here.
