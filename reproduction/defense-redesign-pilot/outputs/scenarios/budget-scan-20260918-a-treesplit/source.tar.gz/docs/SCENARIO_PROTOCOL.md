# Engineering scenario protocols

Established 2026-09-10, before the first scenario campaigns. These are engineering
protocols, not externally registered or confirmatory studies. Code is committed
before execution and each campaign retains the exact source archive and dependency
record. Scientific pilot execution remains disabled.

## A. Control construction and observer-view adapters

ID: `p4-control-engineering-0.1`.
Configuration: [`calibration_diagnostics.yaml`](../experiments/configs/calibration_diagnostics.yaml).

Reuse the existing Paper 4 P0 **trained-mode** captures for D0 q=8, D1 σ=0.1 q=8,
and D3 q=2. These models took three training steps; this is not a new training cohort
or evidence about optimized defenses. Verify source manifests, configuration bindings,
and every input artifact hash before reading captures. Missing ignored tensor files
must produce a clear input error; do not regenerate different captures under their IDs.

| Factor | Engineering choices |
|---|---|
| Inputs | Three hash-bound P0 trained-mode capture sets |
| Views | Forward, returned, inbound gradient, outbound gradient, minimum/scale metadata, forward concatenated with metadata |
| Targets | Punctuation fraction; actual next-byte class |
| Control seed | 410101; separate from reserved scientific calibration seeds |
| Positive doses | 0.5 and 2.0; dimensionless diagnostic signal amplitudes |
| Class probe budget | 30 epochs per scorer call |
| Records | 3 sources × 6 views × 2 targets × 1 seed = 36 |
| Positive-dose scores | 72, plus normal and null scores for each record |

For each view, concatenate sequence batches without changing tensor precision or
applying an analysis quantizer. The current sources are fp32. Metadata uses two
features per token; the combined view appends them to released forward values.
This single combined view is not general within-run joint-tensor coverage.

Construct fit and test nulls with independently seeded **whole-sequence derangements**.
Each sequence receives another sequence's observations; its original input/next-token
labels remain attached. Every donor is used once and no sequence donates to itself.
This preserves the empirical feature distribution and within-sequence structure,
but does not guarantee zero association in a finite panel. Null-band failure is a
finding about the instrument/control setting and must be retained.

Inject known signal into a separate copy of those null observations, after release.
Property injection uses target centering/scaling computed on the fit panel only
and a seeded unit direction, shared over sequence positions. Class injection uses
seeded normalized class codes. Overall feature scaling comes from the fit panel.
The same geometry and scaling are used for test; no evaluation-dependent fit occurs.
All donor identities, control/attacker seeds, geometry, panel hashes and doses are
recorded. Zero-dose identity and input nonmutation are checked by tests.

These synthetic sensitivity controls preserve shape, not every valid codebook or
metadata constraint: for example, injection can move a metadata scale outside its
normal support. Scientific qualification needs a justified control-domain policy
and separately frozen calibration models/panels. This engineering run cannot select
its best dose and retroactively call it confirmatory qualification.

Record positive/null threshold checks separately from normal candidate advantages.
The diagnostic report schema fixes `qualified: false`, `scientific_evidence: false`,
and `privacy_outcome: undetermined`, even when numerical control checks pass.
No normal score becomes a candidate acceptance or rejection under this protocol.
State/optimizer, general joint/history/cross-run, membership, timing, unrestricted
semantics, and active/adaptive attack qualification remain omitted.

## B. Plaintext operator-routing correctness

ID: `p4-routing-engineering-0.1`.
Configuration: [`routing_diagnostics.yaml`](../experiments/configs/routing_diagnostics.yaml).

Use the same initialized eight-layer width-256 backbone for all three policies.
This is a seeded untrained fixture, not a useful language-model checkpoint. Generate
three bytes from synthetic prompts of lengths 8 and 16 using engineering seed 410201.
There are six jobs: two prompt lengths × three placement policies.

| Policy | First generation pass | Later generation passes |
|---|---|---|
| Local reference | All operators local | All operators local |
| Delegate all phases | Four linears per block use loopback | Same delegated linears |
| Local prefill, delegated decode | All operators local | Four linears per block use loopback |

The delegated operators are QKV, attention output projection, and both FFN linears.
Normalization, attention, activations, embedding/head, and control remain local.
The transport is an explicit little-endian fp32 packet with a shape/type header;
weights are serialized once per delegated operator and cached in the loopback worker.
Record actual packet lengths and digests, separating setup from online payloads.
These are serialized bytes, not a deployed network measurement.

Compare generated bytes exactly and last-position logits at absolute tolerance 1e-5
against an unwrapped same-model reference. Require expected operator call counts:
0, 96, and 64 delegated calls respectively per prompt. A mismatch is an operational
failure with retained artifacts. A unit-test corrupting worker checks that a local
reference oracle detects a numerical fault; this is not a deployed active verifier.

All generation passes recompute the entire prefix. There is **no KV cache, FHE,
attestation, GPU, protected channel, or backward transport**. Record these facts in
every result. The runner rejects requests for CKKS, attested hardware, ciphertext-only
execution, or an encrypted KV cache instead of silently substituting this backend.
Wall time is one diagnostic CPU run including lazy setup; no secure-serving latency,
speedup, privacy, remote-learning-gain, or Bifrost reproduction claim is permitted.

## Execution and failure accounting

```bash
.venv/bin/python scripts/run_calibration_scenarios.py --config experiments/configs/calibration_diagnostics.yaml --validate-only
.venv/bin/python scripts/run_routing_scenarios.py --config experiments/configs/routing_diagnostics.yaml --validate-only
.venv/bin/python scripts/run_calibration_scenarios.py --config experiments/configs/calibration_diagnostics.yaml --run-label controls-20260910-a
.venv/bin/python scripts/run_routing_scenarios.py --config experiments/configs/routing_diagnostics.yaml --run-label routing-20260910-a
```

Campaign output belongs in `outputs/scenarios/<label>/`; schema-validated manifests
belong in `experiments/manifests/`. Existing campaign directories are never overwritten.
Each failed scenario retains its error and artifacts; failed control thresholds are
recorded diagnostic outcomes, distinct from an exception that prevents scoring.
No automatic retry or outcome-based exclusion is allowed. Code fixes get a new label.

Next: analyze control-domain and null stability, validate the D1 warmup/basis policy,
and complete a prospective scientific calibration freeze. For the deployment track,
replace the plaintext backend only after artifact, hardware and cryptographic
requirements in [TEE_FHE_TRACK.md](TEE_FHE_TRACK.md) are met.

## Execution records added after the first campaigns

Both matrices ran at commit `a8dff2126832f5fbb2048437c1e0af6a646082a9` with zero
operational failures. See [control outcomes](../outputs/scenarios/controls-20260910-a/report.md)
and [routing outcomes](../outputs/scenarios/routing-20260910-a/report.md). This appended
record does not alter the protocol version archived with those runs.

Recheck provenance and regenerate the descriptive reports without rerunning scenarios:

```bash
.venv/bin/python scripts/analyze_scenarios.py --run-label controls-20260910-a
.venv/bin/python scripts/analyze_scenarios.py --run-label routing-20260910-a
```
