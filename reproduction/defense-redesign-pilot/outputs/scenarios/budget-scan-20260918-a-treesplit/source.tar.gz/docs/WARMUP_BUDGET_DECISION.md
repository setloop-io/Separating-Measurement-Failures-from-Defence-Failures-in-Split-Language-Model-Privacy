# Engineering assessment: shared warmup at the pilot budget

Recorded 2026-09-18. Evidence: campaign `warmup-budget-20260918-a`, protocol
[p4-warmup-budget-0.1](WARMUP_BUDGET_PROTOCOL.md), sixteen
`p4-warmup_budget-warmup-budget-20260918-a-*` manifests. Execution code committed
before running as `0bf707f` (plus its parent `076cd1b`); per-node execution used
`--only-seed` subsets (seed 410501 on toula, 410502 on koula, both CUDA, driver
580.159.03, torch 2.14.0+cu130, deterministic kernels). Every manifest re-verified
after merging both halves on the orchestrator: schema, source archive per file,
artifact digests, and identity all pass. This assessment is engineering only —
not qualification, not a freeze, not a defense result.

## What this stage resolved

1. **The warmup/fork mechanics work at the pilot operating point.** 500 shared
   frozen-remote steps plus 1,500 paired branch steps at sequence length 128 on the
   new corpus completed 16/16 scenarios with zero failures; frozen-remote and
   fixed-basis integrity checks all held; the d3_q1 fork-time quantizer rebuild
   passed its release-support check (valid 1-bit codebook, recorded per branch).
2. **Null precision at scale is much closer to the band.** At 16,384 sequences the
   single-null punctuation advantage p95 fell to 0.018–0.026 across twelve split
   branches (14–16 of 16 repetitions inside ±0.02 per branch), from p95
   0.073–0.108 at 1,024. The 8,192/16,384 matched-null measurement (K=16/64) is
   the separate `p4-null-precision-128-0.1` campaign; this stage's single-null
   curve motivates but does not establish qualification precision.
3. **Document-partitioned panels work.** 16,384 disjoint within-document windows
   per probe region materialized with recorded document identities; author-disjoint
   regions held by construction.

## What the measurements say (engineering dry-run, not scientific utility)

Fixed probe_test panel final losses, seeds 410501/410502:

| Branch | 410501 | 410502 |
|---|---|---|
| all_local (2,000 own steps) | 1.5825 | 1.5653 |
| d0 trained (500+1,500) | 1.6475 | 1.6417 |
| d0 frozen_random | 1.6550 | 1.6505 |
| d0 removed_remote | 1.6397 | 1.6356 |
| d1 σ=0.1 trained | 1.6473 | 1.6414 |
| d1 σ=1.0 trained | 1.6478 | 1.6417 |
| d3 q=1 trained | 1.6659 | 1.6780 |

- G_R-like (frozen − trained): **+0.0075 / +0.0088** — below the proposed 0.01
  pilot gate value, and removed_remote beats the trained remote by 0.006–0.008.
  At this corpus/budget/warmup policy the causal remote gain is small; the pilot
  freeze must either adopt a training budget/warmup policy with a larger measured
  gain margin or expect cells to fail the gain gate. These two engineering seeds
  cannot estimate the pilot's seed distribution.
- Replacement-penalty-like (trained − all_local): +0.065 / +0.076 for d0;
  d1 σ adds ≤0.001; d3 q=1 reaches +0.084 / +0.113 (one seed above the proposed
  0.10 utility gate value).
- **Basis drift is real but decelerating.** Initial↔warm absolute cosine
  0.071/0.160 over the 500-step warmup; warm basis vs post-training refit
  0.256–0.362 after 1,500 branch steps. A fixed warm basis is measurably stale at
  the end of the budget; the freeze must choose and control a basis policy
  (fixed, scheduled refit, or frozen encoder) rather than assume adequacy.
- Post-training refit validation r 0.84–0.91 vs warm-basis 0.78–0.80: punctuation
  signal remains strongly recoverable from released means in all branches,
  including d1 σ=1.0 — expected, since σ perturbs one rank-1 direction per
  sequence and the probe refits in current coordinates. No privacy conclusion.

## Decisions recorded for the freeze path

1. Adopt 16,384-window probe panels (with 8,192 as the comparison point in the
   precision campaign) for qualification planning; capacity is verified.
2. The pilot freeze needs an explicit training-budget/warmup decision informed by
   a budget-scan engineering check (2,000 vs more steps) measuring G_R-like and
   Δ_U-like margins at the same operating point — run before freeze as
   engineering, seeds from the existing warmup_budget namespace only if a new
   protocol amendment records it, else a new namespace.
3. Basis policy candidates for the freeze: (a) fixed warm basis (drift documented
   here), (b) scheduled refit with recorded schedule and pre-quantization
   evaluation against the final basis, (c) frozen encoder after warmup. Each is a
   different mechanism; the freeze must pick one and its controls prospectively.
4. The d3 q=1 utility margin is thin/adverse in one seed; q=1 remains a draft
   cell, but the freeze should note q=2/3 carry most of the precision family's
   plausible eligibility.

All records remain `scientific_evidence: false`, `qualified: false`, privacy
`undetermined`. Unevaluated: next-byte classes, returned values, quantizer
metadata, gradients, remote/optimizer state, timing, active/adaptive attackers,
joint/cross-run attacks, history, membership, semantics. C1–C7 of the ledger
remain unestablished.
