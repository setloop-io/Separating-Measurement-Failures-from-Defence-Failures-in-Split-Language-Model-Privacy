# Engineering protocol: training-budget scan at the pilot operating point

Protocol ID: `p4-budget-scan-0.1`
Kind: `warmup_budget` (engineering scenario; `scientific_evidence: false`)
Status: **PROSPECTIVE — recorded 2026-09-18 before any execution. Not a freeze and
not a utility, causal-gain, or defense result.**

The warmup-budget assessment ([WARMUP_BUDGET_DECISION.md](WARMUP_BUDGET_DECISION.md))
measured a G_R-like margin of +0.0075/+0.0088 at the draft 2,000-step budget —
below the proposed 0.01 pilot gate — with the removed-remote control ahead of the
trained remote. A pilot frozen at an operating point where the gain gate is already
out of reach in engineering would test nothing about defenses. This scan measures
how the frozen/trained gap and the all-local replacement penalty evolve at longer
training budgets at the same anchor, corpus, warmup policy, and evaluation panel,
so the pilot freeze can fix a budget with a measured gain margin. It selects no
cell and qualifies no instrument.

## Inputs and fixed constants

- Sources: the two `p4-warmup-budget-0.1` shared-setup manifests (campaign
  `warmup-budget-20260918-a`, seeds 410501/410502), binding checkpoints, bases,
  panels, and source archives, verified before use.
- Scan records use the `budget_scan_engineering` namespace seeds 410503/410504,
  paired 410503↔410501 and 410504↔410502; branch training resumes the bound setup
  trajectories under the setups' own recorded training seeds and sampler
  (`BatchSampler(train_region, 32, 128, training_seed, "warmup-training")`), so
  each longer branch is the exact deterministic continuation of the corresponding
  warmup-budget branch. Any replay checksum mismatch against a recorded reference
  fails the scenario.
- Corpus: pinned `gutenberg_p4`; evaluation on the setups' fixed probe_test panels
  with the same evaluation seed derivation as the source campaign, making losses
  comparable across campaigns.
- Branches per source seed: `d0` trained and `d0` frozen_random at total budgets
  {4,000, 8,000} steps (branch steps = budget − 500), plus `all_local` at
  {4,000, 8,000} total steps from its own initialization. The 2,000-step points
  are inherited from the source campaign, not re-run. Fresh optimizer at each
  fork; lr 3e-4 cosine to 3e-5 over each branch horizon, warmup 100 inside the
  branch schedule, weight decay 0.1, clip 1.0, betas (0.9, 0.95).
- Expected scenarios: 2 seeds × 6 branches = 12.

## Measurements and boundary

Per branch: final loss on the fixed evaluation panel, loss curves, remote/trusted
checksums, wall time. The assessment joins these with the source campaign's
2,000-step points into a budget response table (frozen−trained and
trained−all_local at 2,000/4,000/8,000). A budget recommendation for the freeze
is recorded there as an engineering input; the freeze makes its own prospective
decision and is not bound by this scan. All records keep
`scientific_evidence: false`, `qualified: false`, privacy `undetermined`.
Unevaluated: everything listed by the source campaign plus privacy attacks of any
kind (this scan runs no attack instrument).
