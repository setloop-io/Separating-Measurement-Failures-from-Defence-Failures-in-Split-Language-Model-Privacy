# Prior evidence and interpretation boundaries

Paper 4 inherits evidence by citation; it does not rerun historical Paper 3 experiments.
The governing source is the final [Paper 3 claim-evidence ledger](../../Paper%203%20-%20Privacy-Constrained%20Remote/docs/CLAIM_EVIDENCE_LEDGER.md)
at revision `52191c430110bd8d9dee80538fde22bf1726e56a`. Its manuscript-clarification and
reviewer-response sections override broader historical decision prose. Generated summaries
referenced there are present locally but ignored by Git; the source/configuration/manifest
revision is not itself a claim that every generated output is committed.

## What Paper 3 establishes

| Finding | Source within Paper 3 | Boundary inherited by Paper 4 |
|---|---|---|
| Trained remote modules improve over frozen-random controls at the medium-high reference: G_R = 0.0167 nats, n=8, p≈8.35e−7 | `outputs/confirmatory/confirmatory_analysis.json`, `docs/P2_CONFIRMATORY_DECISION.md`, ledger clarification | Matched frozen comparison; not remote necessity or superiority over removal. Width/span moderation and negative long-low result remain part of the evidence. |
| Remote-gain direction replicates across the second architecture/corpus settings: 24 positive pairs, setting means 0.012–0.046 nats | `outputs/replication/replication_summary.md`, `docs/P3_REPLICATION_DECISION.md` | Replicated gain does not replicate broadened privacy findings. |
| Qualified punctuation and next-byte structure probes reject the four P2b forward-precision candidates, including q=4 | `outputs/privacy_extended_p4b/privacy_extended_p4b.json`, `docs/PREREGISTRATION_P4B.md` | Finite tested captures and probe settings in the reference architecture/corpus. The broader property maxima include unqualified secondary targets. |
| Every candidate in the P5 tested sweep fails a qualified forward privacy gate | `outputs/delegation/delegation_analysis.json`, `docs/PREREGISTRATION_P5.md` | Empty empirical tested set. Positive forward property scores suffice; it is false that every forward family fails every P5 cell. |
| P5 D1 has Δ_U = 0.82–1.56 nats relative to all-local | Same P5 sources | Bundled q=4 and backward clip/noise treatment; this is not the incremental causal cost of gradient noise. |
| Fixed-width utility improves with forward precision, with a practical plateau above q=8 | `outputs/rate_sweep/rate_sweep_analysis.json`, `docs/PREREGISTRATION_P2B.md` | Not measured full-transcript bitrate, proof of equal convergence, or a monotonic law at untested q<4. |
| The selected intrinsic-dimension predictor fails held-out evaluation; broader H4 is unestablished | `outputs/segment_stats/segment_stats_analysis.json`, `docs/PREREGISTRATION_P2C.md` | Neither arbitrary functional statistics nor representation-preserving boundaries are thereby ruled out. |

Punctuation passes its own qualification checks. Vowel fraction and newline targets fail
calibration null checks and cannot supply qualified primary evidence. Next-byte structure is
byte-class prediction, not general semantic reconstruction. The original cross-model token
probe's nondetection does not show that exact input bytes are protected; width matching does
not validate latent coordinate transfer.

## What Paper 3 does not establish

No selective intervention showed that punctuation or other leaked features are indispensable
for useful remote learning. Coexisting utility and leakage does not establish that identity.
A finite mechanism sweep supplies no universal impossibility theorem or task-specific
communication lower bound. Nor do analytic FLOPs/tensor bytes and local wall time establish
performance on a deployed edge/network system.

The inherited privacy exclusions are timing; optimizer state beyond the remote module; full
evolving remote state; active/adaptive attackers; within-run joint tensor attacks; cross-run
joint attacks; natural-sequence membership; semantics beyond byte-structure classes; returned
values; and full-precision inbound/outbound gradients. History-accumulation and canary-membership
instruments, undefended gradient property/token probes, and all defended gradient probes were
unqualified. Only the baseline structure probe qualified on the processed inbound-gradient
view; processed captures do not cover the full gradient available to the implementation.
Broadened privacy failure was not replicated on the second architecture/corpus.

## Earlier returned-gradient case study

The [returned-gradient case study](https://arxiv.org/abs/2609.04382) motivates explicit backward
channel auditing, injected controls, matched nulls, and frozen thresholds. Its decoy-based
system differs from the surrogate/defense topology in Papers 3 and 4. Do not transfer its
mitigation costs, gradient results, or guarantees to a different implementation. This document
does not claim a peer-reviewed venue or import numerical results without their own provenance.

Paper 3's D1 bundled backward perturbation and lower forward precision. Paper 4's D1 is a
new property-targeted **forward** perturbation. They are different treatments; a shared label
is not shared experimental evidence. Fresh Paper 4 controls and defense-specific qualification
are necessary.

## Status of the supplied research note

`Deep-research.md` is preserved unchanged as supplied background. Its claims that proposed
D1–D5 defenses have already failed, that permutation passes privacy, that Fano's inequality
proves inevitable utility destruction, or that other published defenses fail this instrument
are not Paper 4 results. They must not enter the manuscript as findings. Literature motivates
candidate mechanisms; comparative attack/defense conclusions require matched implementations,
qualified evaluation, and explicit threat models.
