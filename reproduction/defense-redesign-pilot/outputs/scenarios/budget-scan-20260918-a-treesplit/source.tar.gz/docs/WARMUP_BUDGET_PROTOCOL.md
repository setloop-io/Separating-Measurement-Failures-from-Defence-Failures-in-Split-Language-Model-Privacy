# Engineering protocol: shared warmup at the intended pilot budget

Protocol ID: `p4-warmup-budget-0.1`
Kind: `warmup_budget` (engineering scenario; `scientific_evidence: false`)
Status: **PROSPECTIVE — recorded 2026-09-17 before any execution. Not a freeze, not
qualification, not a scientific result.**

This campaign measures, on control and engineering branches only, the quantities that
the pilot freeze must fix: warmup duration accounting, basis drift over the full
2,000-step budget, post-warmup removal mechanics, and property-null stability at the
pilot sequence length on the new corpus. It answers no privacy or defense question.

## Inputs and fixed constants

- Corpus: the Paper 4 public-domain resource specified in
  [CALIBRATION_TEXT_PROTOCOL.md](CALIBRATION_TEXT_PROTOCOL.md), pinned by digest in
  `experiments/configs/warmup_budget_diagnostics.yaml`. The historical
  tiny-Shakespeare partition is not used or modified.
- Seeds: `warmup_budget_engineering` namespace only (410501, 410502), disjoint from
  every prior namespace and from all Paper 3 seeds; recorded in
  `experiments/seed_registry.json`.
- Anchor: span 4 at start 2, latent width 256, remote depth 1, q=8 during warmup.
- Sequence length 128, batch size 32.
- Shared setup per seed: frozen-random remote, no defense, **500 warmup steps**;
  trusted parameters and remote checksums verified (remote must not change).
- Branches train for **1,500 steps** with a fresh optimizer at the branch boundary;
  warmup counts inside the 2,000-step total budget. The `all_local` control trains
  2,000 steps from its own initialization. Removal is post-warmup (at fork).
- Branches per seed (8 scenarios per seed, 16 total):
  `d0`, `d1_s0.1`, `d1_s1.0`, `d3_q1` in trained mode; `d0` frozen_random;
  `d0` removed_remote; `all_local`; plus the shared setup.
  D1 branches use the warm basis fitted at the end of the shared warmup, frozen for
  the whole branch; the d3_q1 branch changes only forward quantizer precision at fork.
- Optimizer: AdamW, lr 3e-4 cosine to 3e-5 over the branch horizon, warmup 100 inside
  the branch schedule, weight decay 0.1, clip 1.0, betas (0.9, 0.95).

## Panels (document-aware)

Panels are drawn on a within-document stride-129 grid; windows never cross document
boundaries and every window includes its final next-byte target. See
CALIBRATION_TEXT_PROTOCOL.md for region and document identity.

- `basis_fit`, `basis_validation`: 4,096 windows each from disjoint document halves
  of the calibration region.
- `probe_fit`, `probe_test`: up to 16,384 windows from the probe-fit and evaluation
  regions respectively.
- Stability measurement sizes: 1,024 / 4,096 / 16,384 sequences per panel, 16 donor
  derangement repetitions per size, primary punctuation target only.

`panels.json` records region bounds, document IDs per window, absolute offsets, and
tensor hashes. Panels are inputs to the later matched-null precision engineering
campaign; they do not qualify any instrument.

Each seed's setup and branches are independent of the other seed's. Per-seed
execution subsets (`--only-seed`) are permitted for engineering execution on
separate hosts; the executed subset is validated against the declared protocol
seeds and recorded in every manifest's `inputs.protocol_seeds` and the campaign
summary. A complete campaign for the protocol is the union of both seeds' records.

## Measurements (all engineering diagnostics)

1. Setup: initial vs warm basis absolute cosine, remote/trusted checksums, warmup loss
   curve.
2. Every branch: paired batches at identical global step indices; frozen-remote and
   fixed-basis integrity checks; final evaluation loss on the fixed probe_test panel;
   post-training diagnostic basis refit with absolute cosines to the initial and warm
   bases; loss curves.
3. Null stability: single-null correlation-difference advantage distribution across
   panel sizes and repetitions on released (post-defense, quantized) means, reported
   per branch without aggregation across seeds.

## Interpretation boundary

These measurements select no pilot cell, strength, or estimator and qualify no
instrument. Warmup duration, budget accounting, and the basis policy adopted at the
pilot freeze must be recorded there regardless of how these branches perform. Any
estimator change for scientific use additionally requires the matched-null precision
campaign at this scale and a prospective amendment. All records keep
`scientific_evidence: false`, `qualified: false`, privacy `undetermined`. Unevaluated:
next-byte classes, returned values, quantizer metadata, gradients, remote/optimizer
state, timing, active/adaptive attackers, joint/cross-run attacks, history,
membership, semantics.
