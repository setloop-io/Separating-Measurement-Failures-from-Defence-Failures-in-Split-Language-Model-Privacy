# Reviewer evidence and reproduction

This repository and its [evidence release](https://github.com/geopolitis/paper-4-defense-redesign/releases/tag/evidence-2026-09-10-v1)
remain **private**. Reviewers need an authenticated GitHub account with repository
access. The inherited Paper 3 evidence is in a
[separate private release](https://github.com/geopolitis/paper-3-privacy-constrained-remote/releases/tag/evidence-2026-09-10-v1);
access to one repository does not grant access to the other.

The release contains all locally retained Paper 4 outputs, the exact corpus, and
the 80 engineering run manifests: **289 files**, including 173 manifest-referenced
artifacts, all capture/checkpoint/panel tensors, and the five campaign source
archives. JSON results, code, logs, and reports are also retained in Git.
Every engineering manifest remains `scientific_evidence: false`. Publication does
not qualify an instrument, freeze a scientific protocol, or establish defense success.

## Retrieve and verify

Install Python 3.11+, the GitHub CLI (`gh`), and `zstd`. Use a fresh checkout:

```bash
gh auth login
gh repo clone geopolitis/paper-4-defense-redesign paper4-review
cd paper4-review
git checkout evidence-2026-09-10-v1
python3 scripts/reviewer_evidence.py list
python3 scripts/reviewer_evidence.py fetch
python3 scripts/reviewer_evidence.py verify --report /tmp/paper4-evidence-verification.json
```

Allow 1 GB for this evidence and its compressed cache, separately from the Python
environment. The [versioned index](../evidence/release-20260910-v1.json) lists every
path, byte size, SHA-256, and archive part. `fetch` authenticates through `gh`,
checks downloads, streams decompression, and verifies the extracted bytes. It
refuses to overwrite differing local evidence. Missing or corrupted files cause
`verify` to exit nonzero. The release also supplies the index and `SHA256SUMS`.

Individual groups can be selected, for example:

```bash
python3 scripts/reviewer_evidence.py fetch --group warmup-20260910-a --group precision-20260910-a --group corpora
```

## Reproduce stored-output analyses

Set up the locked environment, verify the vendored source, and then analyze the
restored campaigns in a disposable checkout:

```bash
uv sync --locked --extra dev
uv run python scripts/verify_environment.py
uv run python scripts/analyze_diagnostics.py --run-label p0-20260910-a
uv run python scripts/analyze_scenarios.py --run-label controls-20260910-a
uv run python scripts/analyze_scenarios.py --run-label routing-20260910-a
uv run python scripts/analyze_warmup.py --run-label warmup-20260910-a
uv run python scripts/analyze_null_precision.py --run-label precision-20260910-a
```

These analyzers check bound evidence and write generated reports. Keep the release
copy for comparison. See [environment instructions](ENVIRONMENT.md),
[scenario protocol](SCENARIO_PROTOCOL.md),
[warmup protocol](WARMUP_STABILITY_PROTOCOL.md), and
[null-precision protocol](NULL_PRECISION_PROTOCOL.md) for the other commands and
their interpretation. The source archives are retained at each campaign's
original `outputs/.../source.tar.gz` path alongside `source.json`. They preserve
the historical engineering implementation independently of later repository edits.

New engineering executions must use fresh campaign labels, as documented in the
protocols; existing records are not overwritten. Scientific cohort execution
remains disabled pending the required qualification and freeze. Cross-platform
bitwise equivalence is not promised by the environment lock.

The corpus is the original 1,115,394-byte Tiny Shakespeare file, SHA-256
`86c4e6aa9db7c042ec79f339dcb96d42b0075e16b8fc2e86bf0ca57e2dc565ed`.
No preprocessing was applied for publication. The recorded 80/10/5/5 split and
per-token quantization remain different from Paper 3's historical configuration.

## Provenance boundary

The [Paper 3 audit](../outputs/paper3_evidence_audit_20260910/report.md) describes
the pre-publication state on 2026-09-10. Its references to local-only evidence
describe that dated snapshot. Paper 3's later evidence release restores access to
the retained files, but cannot recover missing dirty-tree source patches or prove
historical preregistration timing. Paper 4's vendored snapshot does not repair
that limitation. Hash verification establishes availability and byte identity;
it is separate from independently recomputing scientific results.

## Publication checks

The [fresh-checkout verification](../evidence/reproduction-check-20260910.json)
records successful download/restoration of all 289 indexed files from GitHub and
successful execution of all five stored-output analyzers above. Rechecking all
file hashes after those analyzers found no changed original evidence. The locked
environment installed successfully and all 20 vendored Paper 3 source files were
verified. No model training or probe fitting was performed.

All 11 initial release assets also matched their expected sizes and GitHub's
server-side SHA-256 digests; see the [asset verification record](../evidence/github-assets-verified-20260910.json).
