# Engineering protocol: next-byte structure precision at the pilot operating point

Protocol ID: `p4-structure-precision-0.1`
Kind: `structure_precision` (engineering scenario; `scientific_evidence: false`)
Status: **PROSPECTIVE — recorded 2026-09-18 before any execution. Not instrument
qualification, not estimator selection for scientific use, not a freeze.**

Next-byte byte-structure classification is a primary pilot target. This campaign
measures the complete structure-scoring procedure's sensitivity and null precision
at the pilot operating point (sequence length 128, pinned corpus, full-budget
trained control models), the way
[NULL_PRECISION_128_PROTOCOL.md](NULL_PRECISION_128_PROTOCOL.md) does for the
punctuation property. Control conditions only; no normal candidate is scored and
no instrument is qualified here.

## Inputs and fixed constants

- Sources: the two model-preparation (`prepare`) manifests of
  `p4-null-precision-128-0.1` (control seeds 410601/410602), binding the verified
  full-budget `d0` trained control checkpoints and, through them, the
  warmup-budget setups, panels, corpus, and source archives.
- Scoring seeds: `structure_precision_engineering` namespace (410701, 410702),
  paired 410701↔410601 and 410702↔410602. Recorded in `experiments/seed_registry.json`.
- Release conditions: `d0_q8`, `d1_warm_s1.0_q8`, `d3_q1` (identical construction
  to the property precision campaign).
- Scorer: the five-class MLP on per-token released features from
  `src/p4d/calibration.py` (`p4-probe-adapters-0.1` family), labels from the
  actual next bytes. Fitting budget: one pass over the fit panel's token rows,
  Adam lr 3e-3, batch 8,192 rows — recorded, and identical for fitted and null
  scorers.
- Null construction: sequence-level donor derangement pairing released feature
  sequences with label sequences of other sequences (association removed,
  marginals and within-sequence structure retained); 16 outer repetitions.
  Matched-null counts K ∈ {1, 4} (permuted-label refits averaged).
- Positive control: per-token class-code injection in the evaluator's control
  copy at the post-defense/pre-final-quantization point. Five seeded unit
  directions in latent coordinates (absolute cosines to the warm property basis
  recorded); injected offset dose × feature-scale × direction[class] at every
  token position; released through the real quantizer with the same support
  checks and exact zero-dose equality as the property controls. Doses
  {0, 0.5, 2.0}; qualification floor accuracy advantage ≥ 0.02.
- Panel sizes {8,192, 16,384} sequences; token rows are all 128 positions per
  sequence (no row subsampling). Absolute null band ±0.02 on accuracy advantage.

## Outputs and boundary

Per release condition per seed: raw fitted/null accuracy advantages per
repetition, size, and K; positive-control advantages and support checks;
manifests binding the prepare manifest, control checkpoint, panels, and corpus.
The descriptive aggregation (band fractions, advantage SDs, floor margins) is
reported by the analysis script and the engineering assessment. Structure
estimator settings for scientific qualification are frozen later, informed — not
enacted — by these measurements. All records keep `scientific_evidence: false`,
`qualified: false`, privacy `undetermined`. Unevaluated: returned values,
quantizer metadata, gradients, remote/optimizer state, timing, active/adaptive
attackers, joint/cross-run attacks, history, membership, semantics beyond
five-class byte structure, token inversion.
