# Paper 4 public-domain calibration text resource

Protocol ID: `p4-calibration-text-0.1`
Status: **PROSPECTIVE — recorded 2026-09-18 before any use of this resource in
engineering campaigns, qualification, or scientific runs.**

This document specifies the larger text resource required by the
[matched-null precision assessment](NULL_PRECISION_DECISION.md), which found that the
historical corpus's 5% probe regions (55,770 bytes) cannot supply the tested panel
sizes at the pilot sequence length 128 (capacity 432 disjoint windows vs the
8,192/16,384 planning targets). It replaces the draft byte-fraction partition for all
new Paper 4 campaigns; the historical tiny-Shakespeare corpus and its partition are
not modified and remain Paper 3 provenance only.

## Source, license, and integrity

- Source: Project Gutenberg UTF-8 plain-text files, fetched 2026-09-17/18 by
  `scripts/fetch_gutenberg.py` from the URLs recorded per document in
  `data/gutenberg_p4.manifest.json` (committed). Each document's license header was
  retained at fetch time to confirm public-domain status in the USA; boilerplate is
  then removed (below). Redistribution of stripped bodies is permitted for
  public-domain works; the manifest records enough to re-fetch and re-verify every
  byte (per-document SHA-256).
- Preprocessing (exact, versioned here): decode `utf-8-sig`; convert CRLF/CR to LF;
  remove everything up to and including the `*** START OF ... PROJECT GUTENBERG
  EBOOK ... ***` marker line and everything from the `*** END ...` marker line;
  strip leading/trailing blank lines; keep the remaining bytes unnormalized.
  Documents smaller than 100,000 cleaned bytes are excluded.
- Assembly: concatenation of cleaned documents in region order (train, calibration,
  probe_fit, evaluation), then author, then PG ID. Assembly seed 20260917.

## Identity

- Corpus file: `data/raw/gutenberg_p4.txt` (git-ignored), 59,619,533 bytes,
  SHA-256 `af3d0245c0ec27d7021f5fd29256bc845bb20cf9c562b37bbe23663b6ebe7436`.
- Document index and partition: `data/gutenberg_p4.manifest.json` (committed) —
  per-document PG ID, title, author, cleaned digest, byte length, corpus offset, and
  region. 75 documents total.
- Rebuild check: re-running the fetch script against the recorded URLs and
  re-assembling must reproduce the corpus digest; document bodies are also cached
  under `data/raw/gutenberg_src/` (git-ignored) for local verification.

## Partition (document-level, author-disjoint)

Documents are assigned to regions greedily toward byte targets {train 0.60,
calibration 0.15, probe_fit 0.125, evaluation 0.125} at **author granularity**: all
works by one author fall in exactly one region, so no evaluated text shares an
author with any training text. Realized sizes:

| Region | Bytes | Documents | Authors | Approx. disjoint windows at seq 128 (stride 129) |
|---|---|---|---|---|
| train | 35,834,509 | 34 | 13 | ~277,000 |
| calibration | 8,970,404 | 12 | 8 | ~69,000 |
| probe_fit | 7,508,332 | 15 | 8 | ~58,000 |
| evaluation | 7,306,288 | 14 | 7 | ~56,000 |

Exact per-region window counts are computed and recorded by the campaign that
materializes panels (within-document grids lose a partial stride per document);
`panels.json` records the realized grid and per-window document IDs.

Usage policy: `train` feeds model optimization only; `calibration` feeds basis
fitting/validation and control construction only; `probe_fit` fits attacker
scorers; `evaluation` scores them. No window may cross a document boundary, and no
document (or author) appears in two regions. Historical Paper 3 splits are
preserved untouched; this resource is not pooled with any Paper 3 measurement.

## Overlap with the historical corpus

Method: 512 uniformly sampled distinct 32-byte substrings of
`data/raw/tinyshakespeare.txt` (seed 20260917), each checked for verbatim occurrence
anywhere in the new corpus. Result: **0 of 512 found (fraction 0.0000)**; recorded
in the manifest. The resource contains no Shakespeare works by construction
(candidate list excludes them), so substantive overlap is not expected; the sample
bound is recorded rather than assumed.

## Known limitations (carried into every campaign that uses this resource)

- Distribution differs from Shakespearean English; Paper 4 conclusions concern this
  corpus and must not be pooled with Paper 3's corpus-level results.
- Document-level partitioning replaces the draft byte-fraction split; realized
  region fractions are recorded above and in each manifest.
- Author-level disjointness does not remove genre/topic similarity between regions;
  this is ordinary text generalization, not leakage.
- This document allocates data only. It does not qualify an instrument, select an
  estimator, or authorize scientific execution.
