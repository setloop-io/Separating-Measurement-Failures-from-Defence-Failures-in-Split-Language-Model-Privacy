# Warmup and null-stability engineering protocol

Protocol `p4-warmup-stability-engineering-0.1`, executable engineering only.
Configuration: `experiments/configs/warmup_diagnostics.yaml`. This is a follow-up
to the 17 failed null checks in `controls-20260910-a`; it does not repair those
historical records or qualify any instrument. Commit code and this protocol
before execution. Scientific calibration, pilot, and confirmation remain disabled.

## Questions and fixed scope

1. Does a shared frozen-remote warmup support a reproducible D1 basis schedule?
2. How does the existing correlation-difference null statistic vary with panel size?

Use fresh engineering seeds 410301 and 410302. Per seed, record one shared setup
and ten branches: D0, D1 with the initial basis, and D1 with the warmed basis,
each with trained/frozen/removed remote controls, plus one all-local reference.
There are 22 manifests (two setups and twenty branch runs). The anchor is
span 4 at start 2, width 256, one remote block, and per-token q=8 quantization.
D1 noise standard deviation is 0.1 along one punctuation ridge direction, shared
across positions in a sequence. No defense strength is selected in this stage.

## Shared checkpoint and basis policy

Fit a punctuation direction at initialization on 512 separate calibration
windows. Warm the split model for 16 updates with remote weights frozen and no
D1 noise. Fit another direction using the same windows and the warmed encoder.
Archive the shared checkpoint, bases, and checksums. Deep-copy that checkpoint
for every split branch. Reset AdamW in every branch; train for 16 more updates
with the same minibatches, learning-rate schedule, and keyed defense noise.
Only remote parameter updating differs within each trained/frozen pair.

The removed control replaces the remote module with a depth-matched identity
**after** common warmup; it is a post-warmup removal intervention, not a model
trained without a remote module from initialization. The all-local model receives
its own 16+16 updates, with the same data and optimizer reset schedule. Its topology
and initialization differ from the split model, as in the existing initializer.
Report its loss reference descriptively, without a converged utility claim.

Freeze each branch's D1 basis throughout its training. At the end, fit a diagnostic
direction again on the same calibration windows and report absolute cosine to
both saved bases. Re-fitting is measurement only, never an update to the defense.
Also report direction validation correlation on separate calibration windows;
this is a fixed ridge fit evaluated in the same model's coordinates, not transfer
qualification or a test of the Paper 3 segment-prediction hypothesis.

## Text panels and measurement

Use the pinned public corpus with regions: training 0--80%, basis fit 80--85%,
basis validation 85--90%, probe fit 90--95%, probe evaluation 95--100%. Each panel
uses a seeded permutation of a stride-33 grid for sequence length 32; windows
include their actual next-byte target and never overlap, within or across regions.
Panels of 16, 64, 256, and 1,024 are nested prefixes of the same stored maximum
panel. Basis panels have 512 windows each. Store absolute offsets and their hashes.
Windows still come from one corpus, not independent documents or training runs.

Collect only mean-pooled released forward values for the property diagnostic.
Executing the trusted prefix and boundary encoder/defense/quantizer is sufficient
for this view; test equality with full-model capture. Measurement restores model
mode and private defense RNG state. Utility evaluation uses eight fixed batches
from the evaluation panel. No scientific confidence intervals or gate verdicts.

## Fixed null diagnostic

Target: punctuation fraction. Ridge penalty remains 1.0. The primary-target-only
adapter preserves the existing statistic: correlation of the fitted probe minus
correlation of a probe fit to shuffled labels and evaluated on shuffled feature
rows. It uses its own documented keyed RNG, rather than inheriting the multi-target
adapter's RNG draws. This is a new engineering adapter, requiring fresh scientific
qualification before any use for a privacy claim.

For each panel size, generate 16 whole-sequence donor derangements separately in
fit and evaluation panels. Keep true recipient labels, preserve feature support,
and run the same statistic. Report all repetitions, mean advantage, 95th percentile
of absolute advantage, maximum absolute advantage, and count within the existing
absolute 0.02 null band. Do not select favorable permutations or increase the band.
These repetitions share training runs and text panels; they are not independent
scientific replications. Larger panels may still fail. Positive-control construction
and qualification are explicitly outside this stage.

## Claim boundary and checks

Every result is `scientific_evidence: false`, `qualified: false`, and privacy
`undetermined`. No defense selection, hypothesis decision, or positive privacy
claim follows. Unmeasured here: next-byte classes; returned values; quantizer
metadata; full-precision inbound/outbound gradients; evolving remote/optimizer
state; timing; active/adaptive attackers; within-run joint and cross-run attacks;
history accumulation; canary/natural-sequence membership; unrestricted semantics.

Fail on overlapping windows, nonfinite training/scoring, mutable frozen remote
weights or basis, unpaired initial trusted weights, missing artifacts, or checksum
mismatch. Preserve failures. Verify source archives, all artifact hashes, run
counts, branch/checkpoint bindings, and frozen-state checks before reporting.
Tests use synthetic text and tiny models, not reserved scientific seeds.
