# Engineering assessment: matched-null precision

Recorded 2026-09-10. Evidence: [generated report](../outputs/scenarios/precision-20260910-a/report.md),
[verification](../outputs/scenarios/precision-20260910-a/verification.json), and six
`p4-null_precision-precision-20260910-a-*` manifests. Execution code was committed
before running as `e29fd6376d0133c3340b26ad92c9715fe4682094`; source archive hash:
`180f81bbb4d529f45f7d6f89f34240b45c4c0d470ce913e27f003afd421c2caa`.
The implementation suite passed 137 tests. This assessment is engineering only,
not scientific qualification, estimator selection, or a protocol freeze.

## Completed work

Six control scenarios completed and verified, using two saved shared-warmup
checkpoints under three release conditions each. There were no new training
updates or normal candidate scores. Each source checkpoint was warmed under
D0 q8 with remote weights frozen; trained-with-D1/D3 behavior was not tested.

Positive signals are now injected after defense and before final quantization.
The quantizer recomputes minimum and scale. Zero-dose controls reproduce ordinary
donor releases exactly. Every support check passed, with maximum normalized
rounding error 0.00003052 against the declared 0.001 tolerance. This establishes
valid codebook support for synthetic controls, not naturalistic distributions
or absence of metadata leakage. Metadata were checked and hashed, not scored.

All 72 positive-score checks exceeded 0.10 across three estimators, two panel
sizes, two nonzero doses, and six scenarios. These are repeated scores on shared
control conditions, not 72 independent replications. Sensitivity alone does not
qualify the detector.

## What remains unstable

At 1,024 sequences, K=1 placed 78/192 no-signal trials within ±0.02; K=16 placed
110/192 within the band; K=64 placed 107/192 within it. For K=64, 85/192 failed
the absolute band and 37/192 exceeded +0.02. These are dependent conditional
donor trials, not population false-positive rates.

Increasing K from 1 to 64 reduced the standard deviation of the mean matched-null
correlation from 0.0327 to 0.0040 at that panel size. The fitted-probe correlation's
standard deviation remained 0.0305; total advantage SD was still 0.0304 at K=64.
Averaging one term leaves the fitted-probe term in place. The complete control
procedure still does not meet the proposed precision requirement.

Stop treating more inner-null averaging on these fixed panels as the main route
to qualification. No K is selected as a scientific default. Retain all failures
and leave the candidate threshold and current absolute null band at 0.02. A
larger band would not resolve the demonstrated candidate-score uncertainty.

## Next prerequisite: enough independent text

Saved panel declarations give 55,770 bytes in each probe-fit/evaluation region.
Capacity for disjoint windows including the next-byte target is
`floor(region_bytes / (sequence_length + 1))`: 1,690 at length 32, but only 432
at the draft pilot's length 128. The 1,024-window diagnostic cannot simply be
carried over to the pilot length. Overlapping/repeated windows do not add
independent text coverage.

Prepare a separately versioned public-text calibration resource. Record license,
source, digest, preprocessing, document identities, and disjoint training,
calibration, attacker-fit, and evaluation policies. Check content overlap with
the current corpus and preserve historical splits. Declare permitted attacker
data and the evaluation population; extra text alone does not solve coordinate
alignment or distribution shift.

For planning, compare 8,192 and 16,384 disjoint windows per fit/evaluation panel
at length 128. These require 1,056,768 and 2,113,536 bytes per panel respectively,
before separate basis/control data and document-boundary losses. They are data
allocation targets, not sample-size guarantees or frozen scientific cohorts.
Measure the complete procedure's precision on control-only data at the intended
sequence length before reserving the scientific qualification run.

If the raw correlation-difference procedure remains unsuitable, specify and
version an uncertainty-aware decision procedure separately. Do not change the
meaning of the 0.02 effect criterion or treat a nonsignificant test as evidence
that leakage is below it. Insufficient precision means undetermined. Any estimator
or aggregation change needs fresh calibration and a prospective preregistration
amendment before scientific use.

Next-byte, metadata, returned-value, gradient, and active-attack designs remain
separate implementation/qualification work. Scientific warmup duration and
basis-drift policy still need validation over the intended training budget.
The 66-run draft pilot stays disabled. Calibration seeds 419101--419104 and
pilot seeds 411101--411103 remain unused.

## Claim boundary

Every record remains `scientific_evidence: false`, `qualified: false`, privacy
`undetermined`. Unevaluated: next-byte classes; returned values; quantizer metadata
attacks; full-precision inbound/outbound gradients; evolving remote/optimizer
state; timing; active/adaptive attackers; within-run joint and cross-run attacks;
history accumulation; canary/natural-sequence membership; unrestricted semantics.
No defense-effectiveness, utility, causal-gain, or hypothesis claim follows.
