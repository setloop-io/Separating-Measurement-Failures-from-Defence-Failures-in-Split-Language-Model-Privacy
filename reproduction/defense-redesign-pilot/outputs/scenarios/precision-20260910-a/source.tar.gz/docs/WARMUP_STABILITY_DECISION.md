# Engineering assessment: shared warmup and null stability

Recorded 2026-09-10. This is an engineering assessment, not a scientific protocol
freeze or a defense-selection decision. Evidence: the [generated report](../outputs/scenarios/warmup-20260910-a/report.md),
[verification](../outputs/scenarios/warmup-20260910-a/verification.json), and 22
`p4-warmup-warmup-20260910-a-*` manifests. Execution source was committed as
`ba8b23d0e84a3a29392973fc81f413f3eb7846a5` before running. The archived source hash is
`4ea238153bc7fd5bee1eaec091b4342a7ce09c7b181c921b7d1260497f1809e3`.

## What this stage resolved

All two shared setups and twenty branch runs completed. Each split branch began
with the same trusted weights as its seed's common checkpoint. Trained/frozen
branches shared remote initialization; remote weights stayed fixed during common
warmup and all frozen branches. Actual D1 bases remained fixed. Captures preserved
training RNG state. Panel hashes and absolute offsets verified nonoverlap,
including each window's final next-byte target. The implementation suite passed
122 tests before execution, including a tiny end-to-end warmup/fork/capture check.

The common frozen-remote warmup is now an implemented, reproducible schedule
available for further protocol development. Its optimizer reset and post-warmup
removal semantics are explicit. These mechanics no longer require implementation.

## What the measurements say

Increasing the property panel from 16 to 1,024 sequences reduced the pooled 95th
percentile absolute null advantage from 0.6793 to 0.1031. At 1,024, 117/288
diagnostic checks were within ±0.02; 171/288 still failed. These pooled counts share
text, donor schedules, and models and are not 288 independent scientific trials.
Panel enlargement in the tested range is insufficient to stabilize the current
single-null correlation-difference statistic within the proposed band. No previous
qualification verdict is changed, and no favorable permutation is selected.

The initial-to-warmed punctuation basis absolute cosine was 0.4821 and 0.5717 for
the two seeds. Across the eighteen split branches, the final diagnostic direction
had absolute cosine 0.3504--0.4454 to the initial basis and 0.7475--0.8659 to the
warmed basis. This supports fitting in the current checkpoint's coordinates as a
working implementation choice. It does not show that D1 removes punctuation
information or that a frozen basis remains adequate at the planned 2,000-step
budget. Even the warmed basis changes relative to the later fitted direction.
Validation correlations and all descriptive losses remain in the report; they
do not establish converged utility, causal-gain eligibility, or a winning defense.

## Next protocol work, in order

1. **Resolve null precision on control-only data.** Specify the candidate statistic,
   matching no-signal statistic, repetition/aggregation rule, required precision,
   and false-rejection evaluation before using fresh calibration seeds. Assess
   larger independent text panels or a separately versioned statistical procedure.
   Averaging calibration permutations alone can hide variability of a single
   candidate score; the same procedure must be assessed end to end. Keep the
   candidate acceptance threshold at 0.02. Neither raising the null band after
   seeing failures nor choosing favorable repetitions is an acceptable repair.
2. **Finish positive controls and other required views.** Choose a construction
   consistent with each view's actual support, including quantizer metadata and
   precision. Qualify sensitivity and null behavior together on fresh data;
   this stage assessed only the mean-forward punctuation statistic. Next-byte,
   returned-value, gradient, metadata, and active-attack coverage need their own
   qualified records before the corresponding claims.
3. **Specify the scientific shared checkpoint.** Use the implemented warmup/fork
   schedule as the starting design. Fix warmup duration, total-step accounting,
   optimizer reset, removal timing, and a drift policy before execution. Check
   basis adequacy over the intended budget using calibration text only. A fixed
   basis, a scheduled update, or a frozen encoder are different mechanisms and
   require distinct controls; do not switch among them based on held-out leakage.
4. **Freeze and then run the exploratory pilot.** The current draft has 66 branch
   runs. Add explicit setup manifests to its accounting if adopting shared warmup.
   Calibration seeds 419101--419104 and pilot seeds 411101--411103 remain unused.
   Scientific execution remains disabled until its prerequisites are met.

## Claim boundary

Every record is `scientific_evidence: false`, `qualified: false`, privacy
`undetermined`. This stage did not assess next-byte classes, returned values,
quantizer metadata, full-precision inbound/outbound gradients, evolving remote or
optimizer state, timing, active/adaptive attackers, within-run joint or cross-run
attacks, history accumulation, canary/natural-sequence membership, or unrestricted
semantics. No defense-success claim or Paper 4 hypothesis result follows.
