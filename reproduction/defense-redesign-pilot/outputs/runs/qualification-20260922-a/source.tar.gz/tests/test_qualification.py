"""Frozen-cohort boundaries, schema compatibility, refit mechanism, and tiny qualification."""
from copy import deepcopy
import json
import shutil

import jsonschema
import numpy as np
import pytest
import torch
import yaml
from pcr.data import BatchSampler
from pcr.model import BackboneConfig
from pcr.split import SplitConfig
from pcr.train import build_initialized_model

from p4d import qualification_runs as qr
from p4d.experiment import ROOT
from p4d.model import attach_defense
from p4d.qualification_analysis import analyze
from p4d.warmup_budget_scenarios import train_steps
from p4d.warmup_scenarios import tensor_hash, text_panel

from test_warmup_budget import synthetic_resource


@pytest.fixture(autouse=True)
def one_thread():
    old = torch.get_num_threads()
    torch.set_num_threads(1)
    yield
    torch.set_num_threads(old)


def valid_config():
    return {"protocol_id": qr.PROTOCOL_ID, "cohort": "calibration", "status": "frozen",
            "full_budget": True, "device": "cpu", "cpu_threads": 2,
            "seeds": list(qr.SEEDS), "cells": deepcopy(qr.CELLS), "split": dict(qr.SPLIT),
            "backbone": {"vocab_size": 256, "d_model": 256, "n_heads": 8, "n_layers": 8,
                         "d_ff": 1024, "max_seq_len": 128, "init_std": 0.02},
            "data": {"path": "data/raw/gutenberg_p4.txt", "sha256": qr.CORPUS_SHA256,
                     "documents": "data/gutenberg_p4.manifest.json",
                     "sequence_length": 128, "batch_size": 32},
            "optimizer": deepcopy(qr.OPTIMIZER), **deepcopy(qr.BUDGET)}


def test_validate_accepts_the_frozen_calibration_configuration():
    assert qr.validate(valid_config()) == {"expected_runs": 32, "full_budget": True,
                                           **qr.SCIENTIFIC_FLAGS}


def test_committed_config_matches_the_protocol_constants():
    cfg = yaml.safe_load((ROOT / "experiments/configs/qualification.yaml").read_text())
    assert qr.validate(cfg) == {"expected_runs": 32, "full_budget": True, **qr.SCIENTIFIC_FLAGS}


@pytest.mark.parametrize("change", [
    lambda c: c.update(protocol_id="p4-null-precision-128-0.1"),
    lambda c: c.update(cohort="engineering"),
    lambda c: c.update(cohort="exploratory"),
    lambda c: c.update(status="engineering_ready"),
    lambda c: c.update(seeds=[410601, 410602]),
    lambda c: c.update(seeds=[419101, 419102]),
    lambda c: c.update(cells=c["cells"][:-1]),
    lambda c: c["cells"][1]["defense"].update(noise_scale=0.2),
    lambda c: c["split"].update(width=128),
    lambda c: c["split"].update(q_bits=8),
    lambda c: c["optimizer"].update(lr=0.001),
    lambda c: c.update(train_steps=2001),
    lambda c: c.update(refit_interval=500),
    lambda c: c.update(basis_windows=2048),
    lambda c: c.update(probe_windows=8192),
    lambda c: c.update(property_matched_nulls=8),
    lambda c: c.update(structure_matched_nulls=2),
    lambda c: c.update(outer_null_repeats=8),
    lambda c: c.update(property_positive_floor=0.05),
    lambda c: c.update(structure_positive_floor=0.10),
    lambda c: c.update(mlp_hidden=32),
    lambda c: c["data"].update(sha256="0" * 64),
    lambda c: c["data"].pop("documents"),
])
def test_validate_rejects_any_protocol_deviation(change):
    cfg = valid_config()
    assert qr.validate(cfg)["expected_runs"] == 32
    change(cfg)
    with pytest.raises(ValueError):
        qr.validate(cfg)


def test_validate_only_seed_subsets():
    cfg = valid_config()
    assert qr.validate(cfg, only_seeds=[419101])["expected_runs"] == 8
    assert qr.validate(cfg, only_seeds=[419101, 419103])["expected_runs"] == 16
    assert qr.validate(cfg, only_seeds=qr.SEEDS)["expected_runs"] == 32
    with pytest.raises(ValueError, match="subset"):
        qr.validate(cfg, only_seeds=[410601])
    with pytest.raises(ValueError, match="subset"):
        qr.validate(cfg, only_seeds=[])


def combined_schema():
    return json.loads((ROOT / "experiments/schemas/run_manifest.schema.json").read_text())


def test_combined_schema_validates_every_committed_run_manifest():
    schema = combined_schema()
    paths = sorted((ROOT / "experiments/manifests").glob("*.json"))
    run_manifests = [p for p in paths
                     if json.loads(p.read_text()).get("schema_version", "").startswith("p4-run")]
    assert run_manifests, "committed p4-run-0.1 manifests must exist for backwards-compat"
    for path in run_manifests:
        jsonschema.validate(json.loads(path.read_text()), schema)


def v2_manifest(**overrides):
    manifest = {"schema_version": "p4-run-0.2", "run_id": "p4-test-x-trained-s419101",
                "protocol_id": "p4-qualification-0.1", "cohort": "calibration",
                "scientific_evidence": True, "seed": 419101, "mode": "trained", "cell": "d0-q8",
                "git_commit": None, "source_tree_sha256": "0" * 64,
                "source_record": "outputs/runs/x/source.json", "corpus_sha256": "0" * 64,
                "matrix_sha256": "0" * 64, "freeze_record": None, "inputs": {},
                "started_at": "t", "finished_at": "t", "status": "completed", "artifacts": []}
    manifest.update(overrides)
    return manifest


@pytest.mark.parametrize("overrides,valid", [
    ({}, True),
    ({"cohort": "exploratory"}, True),
    ({"cohort": "engineering"}, False),
    ({"cohort": "confirmation"}, False),
    ({"scientific_evidence": False}, False),
    ({"freeze_record": 7}, False),
    ({"inputs": None}, False),
])
def test_run_schema_v2_accepts_scientific_cohorts_only(overrides, valid):
    schema = combined_schema()
    if valid:
        jsonschema.validate(v2_manifest(**overrides), schema)
    else:
        with pytest.raises(jsonschema.ValidationError):
            jsonschema.validate(v2_manifest(**overrides), schema)


@pytest.mark.parametrize("change", [
    lambda m: m.pop("inputs"),
    lambda m: m.pop("freeze_record"),
    lambda m: m.update(unknown_field=1),
    lambda m: m.update(schema_version="p4-run-0.1"),
    lambda m: m.update(cohort="calibration", schema_version="p4-run-0.1"),
])
def test_run_schema_v2_requires_binding_fields_and_v1_stays_engineering(change):
    schema = combined_schema()
    manifest = v2_manifest()
    change(manifest)
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(manifest, schema)


def refit_fixture(seed=42):
    cfg = BackboneConfig(vocab_size=256, d_model=32, n_heads=1, n_layers=4, d_ff=64,
                         max_seq_len=8, init_std=0.02)
    model = build_initialized_model(cfg, "frozen_random",
                                    SplitConfig(start=1, span=2, width=32, q_bits=8),
                                    seed, "refit-test")
    attach_defense(model, {"name": "property_noise", "noise_scale": .1},
                   torch.eye(32)[:1], 71)
    rng = np.random.default_rng(31)
    corpus = torch.tensor(rng.choice(np.array(list(b"A story!?., ") + [10], dtype=np.uint8), 20000))
    fit = text_panel(corpus, 0, 5000, 16, 8, 10)
    validation = text_panel(corpus, 5000, 10000, 16, 8, 11)
    sampler = BatchSampler(corpus[:4000], 4, 8, seed, "refit-test-training")
    optimizer = {"lr": 0.002, "min_lr": 0.0002, "warmup_steps": 1,
                 "weight_decay": 0.1, "grad_clip": 1.0, "betas": [0.9, 0.95]}
    return model, fit, validation, sampler, optimizer


def test_d1_basis_refit_schedule_drift_and_rng_isolation():
    model, fit, validation, sampler, optimizer = refit_fixture()
    defense = model.remote_path.defense
    refit_curve, basis_log = qr.train_with_basis_refits(
        model, sampler, optimizer, 6, 3, fit, validation, 8, 7, torch.device("cpu"))
    assert [entry["step"] for entry in basis_log] == [0, 3, 6]
    assert [row["step"] for row in refit_curve] == [1, 2, 3, 4, 5, 6]
    assert all(entry["basis_sha256"] and np.isfinite(entry["validation_r"]) for entry in basis_log)
    # The drifting trained model changes the fitted basis between early and late refits.
    assert basis_log[0]["basis_sha256"] != basis_log[-1]["basis_sha256"]
    assert torch.allclose(model.remote_path.defense.directions @ model.remote_path.defense.directions.T,
                          torch.eye(1), atol=1e-5)
    refit_state = defense.generator.get_state()

    fresh, fit2, validation2, sampler2, optimizer2 = refit_fixture()
    train_steps(fresh, sampler2, optimizer2, 6, torch.device("cpu"))
    # Refits never advance the defense noise stream: the post-training generator
    # state equals the state after the identical refit-free training.
    assert torch.equal(refit_state, fresh.remote_path.defense.generator.get_state())


def tiny_qualification_config(tmp_path):
    return {"protocol_id": qr.PROTOCOL_ID, "cohort": "calibration", "status": "frozen",
            "full_budget": False, "device": "cpu", "cpu_threads": 1,
            "seeds": [419101, 419102], "cells": deepcopy(qr.CELLS), "split": dict(qr.SPLIT),
            "backbone": {"vocab_size": 256, "d_model": 32, "n_heads": 1, "n_layers": 6,
                         "d_ff": 64, "max_seq_len": 8, "init_std": 0.02},
            "data": {**synthetic_resource(tmp_path), "sequence_length": 8, "batch_size": 4},
            "optimizer": {"lr": 0.002, "min_lr": 0.0002, "warmup_steps": 1,
                          "weight_decay": 0.1, "grad_clip": 1.0, "betas": [0.9, 0.95]},
            "train_steps": 4, "basis_windows": 16, "refit_interval": 2, "probe_windows": 32,
            "eval_batch_size": 4, "panel_batch_size": 8, "capture_batch_size": 8,
            "property_matched_nulls": 2, "structure_matched_nulls": 2, "outer_null_repeats": 2,
            "positive_doses": [.5, 2.], "ridge_penalty": 1., "null_band": .02,
            "property_positive_floor": .10, "structure_positive_floor": .02,
            "mlp_hidden": 8, "mlp_lr": 3e-3, "mlp_row_batch": 64}


def cleanup(label):
    shutil.rmtree(ROOT / "outputs/runs" / label, ignore_errors=True)
    for stale in (ROOT / "experiments/manifests").glob(f"p4-{label}-*.json"):
        stale.unlink()


def test_tiny_qualification_campaign_end_to_end(tmp_path):
    label = "pytest-qualification"
    config_path = ROOT / "experiments/configs" / f"{label}.yaml"
    cleanup(label)
    manifests = ROOT / "experiments/manifests"
    try:
        cfg = tiny_qualification_config(tmp_path)
        # Config lives in the repo so the campaign's source archive binds it.
        config_path.write_text(yaml.safe_dump(cfg))
        assert qr.validate(cfg) == {"expected_runs": 16, "full_budget": False,
                                    **qr.SCIENTIFIC_FLAGS}
        summary = qr.run(config_path, label=label)
        assert summary["completed"] == summary["expected_runs"] == 16
        assert summary["failed"] == 0
        assert summary["cohort"] == "calibration" and summary["scientific_evidence"] is True
        assert summary["privacy_outcome"] == "undetermined"

        campaign_dir = ROOT / "outputs/runs" / label
        schema = combined_schema()
        for seed in (419101, 419102):
            initials = {}
            for cell in [{"id": "all-local"}, *qr.CELLS]:
                mode = "all_local" if cell["id"] == "all-local" else "trained"
                run_id = f"p4-{label}-{cell['id']}-{mode}-s{seed}"
                manifest = json.loads((manifests / f"{run_id}.json").read_text())
                jsonschema.validate(manifest, schema)
                assert manifest["schema_version"] == "p4-run-0.2"
                assert manifest["cohort"] == "calibration"
                assert manifest["scientific_evidence"] is True
                assert manifest["freeze_record"] is None
                assert manifest["status"] == "completed"
                assert manifest["inputs"]["panels_sha256"]
                names = {a["path"].split("/")[-1] for a in manifest["artifacts"]}
                assert {"metrics.json", "curve.json", "resolved.json", "checkpoint.pt"} <= names
                metrics = json.loads((campaign_dir / run_id / "metrics.json").read_text())
                assert metrics["cohort"] == "calibration"
                assert metrics["scientific_evidence"] is True
                assert metrics["privacy_outcome"] == "undetermined"
                if mode == "all_local":
                    assert "captures.pt" not in names and "controls" not in metrics
                    continue
                assert "captures.pt" in names
                initials.setdefault("remote", metrics["remote_initial_sha256"])
                initials.setdefault("trusted", metrics["trusted_initial_sha256"])
                assert metrics["remote_initial_sha256"] == initials["remote"]
                assert metrics["trusted_initial_sha256"] == initials["trusted"]
                if cell["defense"]["name"] == "property_noise":
                    assert [e["step"] for e in metrics["basis_log"]] == [0, 2, 4]
                else:
                    assert metrics["basis_log"] is None
                captures = torch.load(campaign_dir / run_id / "captures.pt", weights_only=True)
                for key, parts in captures.items():
                    for name, tensor in parts.items():
                        assert tensor_hash(tensor) == metrics["captures_sha256"][key][name]
                for target in ("property", "structure"):
                    controls = metrics["controls"][target]
                    assert len(controls["no_signal_trials"]) == 2
                    assert [d["dose"] for d in controls["positive_controls"]] == [0., .5, 2.]
                    verdict = metrics["binding_qualification"][target]
                    assert isinstance(verdict["qualified"], bool) and verdict["reason"]

        verified = analyze(label)
        assert verified["cohort"] == "calibration" and verified["scientific_evidence"] is True
        assert verified["privacy_outcome"] == "undetermined"
        assert verified["completed"] == 16 and verified["failed"] == 0
        assert verified["candidate_scores_recomputed"] and verified["split_runs_recomputed"] == 14
        assert (campaign_dir / "report.md").is_file()
        assert len(verified["qualification_verdicts"]) == 7 * 2
        for verdict in verified["qualification_verdicts"]:
            assert isinstance(verdict["qualified"], bool)
            assert verdict["seeds"] == 2
            assert len(verdict["bindings"]) == 2
    finally:
        cleanup(label)
        config_path.unlink(missing_ok=True)
