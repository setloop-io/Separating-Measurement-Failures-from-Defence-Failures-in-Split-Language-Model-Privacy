# Calibration cohort protocol: instrument qualification dress rehearsal

Protocol ID: `p4-qualification-0.1`
Cohort: `calibration` (scientific calibration evidence; `scientific_evidence: true`)
Status: **PROSPECTIVE — recorded 2026-09-22 before any execution. Not the pilot
freeze and not a defense result.**

This campaign is the complete dress rehearsal of the intended pilot procedure on
the reserved calibration seeds. It trains models under the exact candidate pilot
regime and runs the exact frozen control/scoring procedure per binding, producing
the instrument-qualification records the pilot freeze requires. Nothing here is a
pilot or confirmatory outcome; candidate scores on calibration models are
calibration-cohort exploratory observations only.

## Training regime (identical to the intended pilot)

- Corpus `gutenberg_p4` (pinned digest `af3d0245…7436`), anchor span 4 at start 2,
  latent width 256, remote depth 1, q=8 reference; sequence length 128, batch 32.
- 2,000 steps from initialization, no shared warmup. AdamW lr 3e-4 cosine to
  3e-5, lr warmup 100, weight decay 0.1, clip 1.0, betas (0.9, 0.95). Per-seed
  paired trusted/remote initialization across all cells of a seed.
- Basis policy for D1: rank-1 punctuation basis fit on 4,096-window basis panels
  (document-disjoint fit/validation halves of the calibration region), refit on a
  frozen schedule every 250 steps (at steps 250, 500, …, 2000) plus the initial
  fit at step 0; each basis hashed and logged; releases always use the latest
  basis; the final refit at step 2,000 precedes captures.
- D1 noise: per-sequence Gaussian along the current basis, resampled per release,
  defense RNG seeded per seed, isolated from training/evaluation streams.
- D3: forward quantizer q ∈ {1, 2, 3} trained from initialization (no warmup; q
  applies from step 0).

## Matrix and seeds

Seeds 419101–419104 (calibration namespace; disjointness machine-checked against
Paper 3 and all Paper 4 uses before execution, audit retained). Per seed:
`all_local` plus the full pilot cell set `d0-q8`, `d1-s0.1-q8`, `d1-s0.5-q8`,
`d1-s1.0-q8`, `d3-q1`, `d3-q2`, `d3-q3` in trained mode — 8 runs per seed, 32
total, so the qualification record covers every exact (defense, strength, q)
condition the pilot scores rather than interpolating between brackets. Per-seed
execution subsets on separate hosts are recorded like the engineering campaigns.

## Panels and instruments (identical to the intended pilot)

- Panels: 16,384 disjoint within-document windows from the probe-fit and
  evaluation regions, one shared panel set per region for the whole campaign
  (panel seeds derived from the protocol ID), document identities recorded.
- Punctuation property: ridge on sequence-mean released features, matched-null
  estimator with K = 16; positive floor 0.10, absolute null band 0.02.
- Next-byte structure: five-class MLP on per-token released features with the
  frozen fitting budget; matched-null estimator with K per the structure
  engineering campaign (recorded in the frozen config); positive floor 0.02,
  absolute null band 0.02.
- Positive controls inject the target signal at the observer input (post-defense,
  pre-final-quantization for the release-copy injection), with codebook-support
  and exact zero-dose checks; no-signal controls use sequence-level donor
  derangement.

## Qualification verdicts and candidate scores

Per (seed × cell × target × view) binding: qualified iff the positive control
meets its floor and the no-signal control stays within the band; every raw score
is retained. Per (target × cell-condition) qualification verdict: qualified iff
all four seeds' bindings pass. A failed binding leaves that coverage
**unqualified**; the corresponding pilot coverage is then undetermined, and any
pilot cell requiring it cannot be privacy-eligible. Candidate advantages
(property, structure) on the calibration models are recorded descriptively with
matched nulls; they are not pilot gate outcomes and cannot select strengths.

## Claim boundary

Records carry cohort `calibration` and `scientific_evidence: true` scoped to
calibration: they qualify (or fail to qualify) instruments under the exact pilot
regime. They make no defense-success, utility, or causal-gain claim. Unevaluated:
returned values, quantizer metadata, gradients, remote/optimizer state, timing,
active/adaptive attackers, joint/cross-run attacks, history, membership,
semantics beyond byte classes, token inversion.
