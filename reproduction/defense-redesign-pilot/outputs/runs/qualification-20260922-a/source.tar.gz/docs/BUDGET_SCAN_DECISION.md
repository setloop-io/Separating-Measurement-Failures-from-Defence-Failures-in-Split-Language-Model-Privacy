# Engineering assessment: training-budget response and warmup policy

Recorded 2026-09-22. Evidence: campaign `budget-scan-20260918-a`, protocol
[p4-budget-scan-0.1](BUDGET_SCAN_PROTOCOL.md), twelve
`p4-warmup_budget-budget-scan-20260918-a-*` manifests (per-seed subsets 410503 on
toula, 410504 on koula, CUDA deterministic kernels), plus the no-warmup run-matrix
checks `nowarmup-b2000-20260922-a` and `nowarmup-b8000-20260922-a` (eight
`p4-nowarmup-*` run manifests each, protocol `p4-p0-nowarmup-b{2000,8000}-0.1`,
engineering seeds 410001/410002, toula CUDA). Execution code committed before the
final runs as `1a9ee07`; every scan and run manifest re-verified after merge
(schema, per-file source archive, artifact digests, replay checksums). This
assessment is engineering only — not a pilot outcome, not a freeze, not a defense
or utility result.

## Measured budget response (d0, fixed probe_test panel losses)

| Regime | Budget | Seed | all_local | trained | frozen | G_R-like | Δ_U-like |
|---|---|---|---|---|---|---|---|
| 500-step shared warmup | 2,000 | 410501 | 1.5825 | 1.6475 | 1.6550 | +0.0075 | +0.0650 |
| 500-step shared warmup | 2,000 | 410502 | 1.5653 | 1.6417 | 1.6505 | +0.0088 | +0.0764 |
| 500-step shared warmup | 4,000 | 410501 | 1.4251 | 1.4726 | 1.4750 | +0.0023 | +0.0475 |
| 500-step shared warmup | 4,000 | 410502 | 1.4177 | 1.4670 | 1.4703 | +0.0032 | +0.0493 |
| 500-step shared warmup | 8,000 | 410501 | 1.3245 | 1.3595 | 1.3675 | +0.0080 | +0.0350 |
| 500-step shared warmup | 8,000 | 410502 | 1.3280 | 1.3595 | 1.3688 | +0.0093 | +0.0315 |
| No warmup | 2,000 | 410001 | 1.5630 | 1.6201 | 1.6387 | **+0.0185** | +0.0571 |
| No warmup | 2,000 | 410002 | 1.5797 | 1.6421 | 1.6547 | **+0.0126** | +0.0624 |
| No warmup | 8,000 | 410001 | 1.3212 | 1.3571 | 1.3674 | +0.0103 | +0.0359 |
| No warmup | 8,000 | 410002 | 1.3339 | 1.3627 | 1.3661 | +0.0033 | +0.0288 |

With-warmup rows are from the source campaign's fixed panel (2,000) and this
scan (4,000/8,000; replay-verified continuations). No-warmup rows use
fractional byte cuts on the same corpus (document overlap across region edges is
possible at the cut; disclosed in those configs; eval regions are disjoint from
training regions). Numbers are two engineering seeds each, not pilot-cohort
estimates.

## What this means for the freeze (engineering input, not a decision)

1. **The 2,000-step no-warmup regime is the only measured operating point where
   both seeds clear the proposed 0.01 gain gate** (+0.0185, +0.0126). Longer
   budgets do not rescue the gain: it shrinks (frozen remote catches up) at
   4,000–8,000 in both regimes. The 500-step shared frozen-remote warmup
   suppresses the branch-phase gain below the gate at every budget.
2. **Replacement penalties stay inside the utility gate** in all regimes
   (+0.029 to +0.076), best at long budgets, acceptable at 2,000 no-warmup.
3. **Basis validity requires a schedule, not a warmup.** Prior measurement
   ([WARMUP_BUDGET_DECISION.md](WARMUP_BUDGET_DECISION.md)): a basis fit at
   initialization is near-orthogonal to trained coordinates (|cos| 0.07–0.16);
   a fixed 500-step warm basis drifts to |cos| 0.26–0.36 by budget end. A
   scheduled basis refit during training (with a final refit before captures)
   addresses drift without the gain-suppressing warmup.
4. Removed-minus-trained flips from about zero (2,000 no-warmup) to
   +0.011/+0.015 (8,000 no-warmup): the trained remote only pays for itself
   over bypassing at longer budgets. Descriptive; no gate uses it here.

The pilot freeze should therefore consider a 2,000-step, no-shared-warmup
operating point with scheduled D1 basis refits, while the gates themselves stay
as proposed. This is a non-vacuous operating-point choice from engineering
seeds; the pilot's own seeds decide eligibility.

## Operational incidents and determinism verification (disclosed)

- An early deploy with `rsync --delete` destroyed one node's first scan
  manifests before they were pulled. Affected halves were re-executed; every
  re-execution reproduced first-run losses and remote checksums **bitwise
  exactly** (six branch comparisons per node). Superseded records are retained
  on the orchestrator under `outputs/scenarios/budget-scan-20260918-a-*/`.
- A later tree-split (same commit, different untracked file sets across nodes)
  invalidated cross-node source snapshots for this label; both halves were
  re-executed from a pristine committed tree (`git reset --hard` + `git clean`)
  at one commit. Deploy procedure is now pristine-tree-only.
- These incidents touched no warmup-budget, precision-128, or P0 historical
  records, and all final records re-verify.

## Claim boundary

All records remain `scientific_evidence: false`, `qualified: false`, privacy
`undetermined`. No attack instrument was run in this stage. Unevaluated:
everything listed by the source campaigns. C1–C7 remain unestablished.
