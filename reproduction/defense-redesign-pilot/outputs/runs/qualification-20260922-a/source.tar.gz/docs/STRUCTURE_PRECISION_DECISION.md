# Engineering assessment: next-byte structure precision at the pilot operating point

Recorded 2026-09-22. Evidence: campaign `structure-precision-20260922-a`, protocol
[p4-structure-precision-0.1](STRUCTURE_PRECISION_PROTOCOL.md), six
`p4-structure_precision-structure-precision-20260922-a-*` manifests (per-seed
subsets 410701 on toula, 410702 on koula, CUDA deterministic kernels), the
analyzer-generated [report](../outputs/scenarios/structure-precision-20260922-a/report.md)
and [verification](../outputs/scenarios/structure-precision-20260922-a/verification.json).
Execution code committed before running as `1a9ee07` (records produced at source
tree `675ac6a`, same included tree); all manifests re-verified after merging.
Engineering only — not instrument qualification, not estimator selection, not a
freeze.

## What this stage established

1. **The structure scorer's null construction is exact at the pilot scale.** All
   192 no-signal trials (2 seeds × 3 release conditions × 2 panel sizes × 16
   repetitions, K=1 and K=4) show exactly zero advantage: deranged labels are
   unlearnable and the matched nulls agree perfectly, at both 8,192 and 16,384
   sequences. Null behavior does not limit this instrument here.
2. **Injected-code sensitivity passes with margin.** Positive controls recovered
   the five-direction class code at accuracy ≈ 0.9998 at both nonzero doses,
   advantage ≈ +0.254 over the 0.745 majority-rate null against the 0.02 floor
   (24/24 checks across seeds, conditions, sizes, K). The five class directions'
   absolute cosines to the warm punctuation basis are recorded per scenario.
3. **Natural next-byte signal exists at this boundary.** An orchestrator side
   check (2,048-window probe-fit subset of the d0-q8 control model, 50/50 split,
   same MLP family) measured true-label accuracy 0.8072 vs permuted 0.7633, a
   natural advantage ≈ +0.044 — above the 0.02 acceptance scale. This is an
   informal engineering check, not a control record; the qualification cohort
   measures natural advantages on trained models with the full matched-null
   procedure. Dose-0 rows in this campaign are derangement checks by
   construction, not candidate scores (normal_candidate_scored=false).
4. **K choice is unconstrained by these data** (K=1 and K=4 identical under
   zero-variance nulls); the frozen config adopts K=4 for symmetry with the
   property estimator's matched-null averaging.

## Carry-overs to the calibration freeze

- Structure estimator: five-class MLP (hidden 64, lr 3e-3, one pass, batch
  8,192), matched-null K=4, 16 outer derangement repetitions per binding, panel
  16,384, positive floor 0.02, null band 0.02.
- Zero-dose equality and codebook support held in every scenario; maximum
  normalized rounding error recorded in the verification.
- Structure scoring cost is dominated by MLP refits; budget accordingly for the
  32-binding qualification campaign.

## Claim boundary

All records remain `scientific_evidence: false`, `qualified: false`, privacy
`undetermined`. No normal candidate was scored. Unevaluated: returned values,
quantizer metadata, gradients, remote/optimizer state, timing, active/adaptive
attackers, joint/cross-run attacks, history, membership, semantics beyond
five-class byte structure, token inversion. C1–C7 remain unestablished.
