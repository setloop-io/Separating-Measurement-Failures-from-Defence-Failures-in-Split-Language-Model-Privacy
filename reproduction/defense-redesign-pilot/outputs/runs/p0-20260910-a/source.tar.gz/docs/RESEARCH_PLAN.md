# Research plan

Status: **DRAFT — P0 engineering and qualification precede a pilot freeze.**
This plan replaces unsupported universal-impossibility framing in the initial scaffold.
It does not amend or rerun Paper 3 studies. The final Paper 3 ledger at pinned revision
`52191c430110bd8d9dee80538fde22bf1726e56a` governs inherited claims.

## 1. Question and hypotheses

The question is whether a specified defense can satisfy utility, remote-gain, and qualified
privacy gates **at the same cell**. We estimate outcomes within the finite evaluated family.

- **H1:** property-targeted perturbation yields an eligible cell at the reference segment.
- **H2:** a separately specified adversarial encoder can improve the observed tradeoff beyond
  the initial perturbation and precision candidates. This extension is not in the initial pilot.
- **H3:** lowering forward latent precision yields an eligible cell below the previously tested
  precision range. Monotonic leakage reduction and a threshold crossing are not assumed.
- **H4:** the initial tested family contains no eligible cell. This is a finite empirical
  alternative to H1/H3, not a universal null about representation-preserving mechanisms.
- **H5:** eligibility changes under specified protocol-manipulating attacks. Neither robustness
  nor vulnerability to these active attacks is presumed before evaluation.

A failed finite search establishes neither a task-specific converse nor necessity of the
leaked properties. Attack correlation differences are not mutual-information estimates. Fano's
inequality cannot turn failure of a chosen probe into a privacy guarantee or prove that reducing
its advantage must destroy utility. `Deep-research.md` supplies hypotheses to inspect, not
completed Paper 4 findings or established judgments about other defenses.

## 2. Outcomes and joint eligibility

For matched all-local, trained, and frozen-random losses define Δ_U = L_T − L_0 and
G_R = L_F − L_T. Removed-remote controls address whether learning a remote module improves
over bypassing it. Positive G_R alone does not establish remote necessity or superiority over
removal. Nominal layer share and analytic FLOP share are not causal-gain measures.

A confirmatory candidate must satisfy all of the following at the **same** defense, strength,
precision, segment, and setting:

1. Mean Δ_U ≤ 0.10 nats, with upper 95% confidence limit ≤ 0.12 nats.
2. Mean G_R ≥ 0.01 nats and a positive paired seed-level test under the multiplicity rule
   frozen before confirmation. The primary comparison family is fixed after pilot selection
   and before fresh confirmatory outcomes exist.
3. Every required, qualified attack/target/channel combination has worst-seed matched-null
   advantage ≤ 0.02. Missing or unqualified coverage leaves eligibility undetermined.
4. The declared complete-transcript evaluation and qualified active-attacker evaluation are
   completed before a positive defense claim.

The sequence-property positive-control floor is 0.10; the next-byte structure floor is 0.02;
both use an absolute null band of 0.02. These qualification checks are distinct from the
0.02 acceptance gate applied to candidate attack advantages. Token inversion remains a
secondary check with independently recorded qualification. No family-level qualification
promotes a target whose own null or positive-control check fails.

## 3. Initial candidate family

| Candidate | Initial treatment | Essential control or limitation |
|---|---|---|
| D0 | Fresh Paper 4 reference at q=8 | No new forward defense; retain matched modes and existing backward semantics |
| D1 | Property-targeted forward noise | Zero-strength identity, frozen orthonormal basis, independent random streams |
| D3 | Forward precision q below the q=8 reference | Hold span, width, remote capacity, and budget fixed; precision is not full-transcript bitrate |
| D1+D3 | Optional exploratory combination | Include D1-only and D3-only cells at the same settings to identify the interaction |
| D2 | Next extension: adversarial encoder | Separate implementation, attacker optimization, and evaluation scorers; new protocol |
| D4 | Deferred selective quantization | Requires additional calibration and allocation rules |
| D5 | Permutation invariance control only | Mean pooling is permutation invariant; causal masking can also change model behavior |

Paper 4 D1 is **not** Paper 3's D1. Paper 3 D1 bundled lower forward precision with clipping
and noise on backward paths; its measured replacement penalty is not an isolated noise cost.

The Paper 4 quantizer computes per-token min/max over the latent dimension, rather than
per-tensor statistics that can couple positions. This is a change to the inherited mechanism
and requires fresh Paper 4 D0 controls. Record quantizer axes, precision, and any scale/min/max
metadata in the transcript/accounting policy. These comparisons are not replications pooled
with Paper 3 at equal q, and a quantized tensor is not evidence of serialized wire rate.

For D1, use row-orthonormal directions B in latent coordinates. For sequence i sample
ε_i ~ N(0, σ²I) and apply z'_it = Q_q(z_it + ε_i B), sharing ε_i across positions t but
resampling according to the frozen release policy. This perturbs the mean without relying
on independent token noise that averages away. It does not establish that the target is
removed or that untouched directions contain no leakage. Punctuation defines the primary
basis target; extensions using vowel/newline directions remain exploratory until qualified.
Basis estimation uses permitted calibration data, with its checkpoint, coordinate mapping,
rank, centering, and update policy recorded before affected evaluation.

## 4. P0 — engineering diagnostics and instrument qualification

P0 verifies implementation and determines whether a pilot can be frozen. Diagnostics have
their own IDs, seeds, budgets, and artifact paths. They are not pilot or confirmatory data.

- Pin the inherited code and environment; verify imports resolve to that revision.
  The local dependency is unmodified vendored `pcr` with its license, and `uv.lock` fixes
  the isolated environment. The copied corpus must match its recorded source hash.
- Check defense placement before final forward quantization, no-op behavior, finite gradients,
  orthonormality, quantizer behavior at low q, and replay determinism.
- Verify the remote mode is applied after construction: trained parameters update,
  frozen-random parameters stay fixed, removed mode bypasses the remote, and all-local is
  an actual matched baseline. Shared trusted initialization, batches, and stopping budgets
  remain matched; the trained/frozen intervention is remote updating.
- Separate training-defense, evaluation, capture, calibration, and attacker RNG streams.
  Changing capture frequency must not alter training-noise realizations or training outputs.
- Inventory actual remote-visible tensors and state before scoring. Distinguish tensor-size
  byte estimates from serialization measurements and preserve the full available precision.
- Qualify each target/channel/defense setting with matched nulls and independently specified
  positive controls. Record failures explicitly; do not turn them into privacy passes.
- Resolve latent coordinate alignment. A calibration backbone of equal width is insufficient.
  Use declared same-model public-data attacker fitting or an independently validated mapping;
  assess drift if a D1 basis is frozen while its encoder continues to train.
- Keep attacker-input positive controls, which test detector sensitivity, separate from
  pre-defense injected-signal diagnostics, which test what the defense removes.

P0 can use small fresh Paper 4 controls and inherited artifacts read-only. It cannot rerun
Paper 3's historical matrices. Finite training loss or a passed unit test is not convergence
or a scientific defense outcome.

The initial engineering configuration uses the reference model/segment with D0 q=8,
D1 σ=0.1 at q=8, and D3 q=2, each in trained/frozen/removed modes with a shared all-local
control at seed 410001. Its three-step, batch-two, sequence-length-32 budget is diagnostic
only. These default amplitudes and counts do not freeze the pilot or qualify a privacy probe.

## 5. P1 — exploratory pilot

Use the Paper 3 reference architecture and corpus: an 8-layer, width-256 byte model on
tiny-Shakespeare, span 4 at start 2, latent width 256, q=8 anchor. D3 changes q at that
segment. Budget and optimizer settings are copied explicitly into the eventual frozen matrix.
Paper 4 uses disjoint 80% training, 10% calibration, 5% probe-fit, and 5% evaluation regions,
with byte boundaries at fractions 0, 0.8, 0.9, 0.95, and 1. This changes the historical
90/10 split and requires fresh Paper 4 controls, not pooled historical comparisons.
Initial candidates are D1 and D3; D1+D3 requires a separately declared exploratory factorial
subset. D2, D4, and D5 are not five interchangeable privacy candidates in this pilot.

Use three fresh paired seeds. Determine candidate strengths during P0 and freeze them before
pilot execution. Enumerate controls, calibration cells, and reuse rules before deriving run
counts from the matrix; do not use the original scaffold's count formula.
The validated current draft enumerates 66 planned runs: seven cells in three modes for
each of three seeds, plus one all-local per seed. The engineering configuration enumerates
10 runs. These are configuration counts, not claims of completed experiments.

The current draft proposes D0 q=8, D1 σ∈{0.1,0.5,1.0} at q=8, and D3 q∈{1,2,3}, with
batch size 32, sequence length 128, and a 2,000-step budget. It remains a draft. In particular,
D1's common per-seed warmup/calibration checkpoint and basis fitting schedule must be
validated before freeze; a same-encoder initialization fit used in P0 is not that validation.

A cell can advance for confirmation only if that **same cell** meets the proposed utility,
practical-gain, and required qualified passive-privacy gates, with positive G_R in all three
pilot pairs. Pilot significance is not a confirmatory claim. Missing coverage may motivate
additional engineering, but does not satisfy advancement. A 50% leakage reduction may be
reported descriptively; it cannot replace the absolute privacy gate. A failed strength does
not automatically disqualify a different strength, and different strengths cannot contribute
separate pieces of a composite pass.

## 6. Confirmation and subsequent studies

After pilot selection, freeze cell definitions, independent calibration/confirmation cohorts,
seed list, paired test, multiplicity family, uncertainty procedures, failures, and decision
rules. Eight fresh confirmatory seeds are reserved; assess design power before freezing and
make any increase prospectively. Do not select strength on the same outcomes used to confirm
it. Report all selected cells and all gates, including unfavorable results.

A later precision map may study q below four and reference levels. Such a map measures
forward precision response; it does not establish a full communication frontier. Any
post-selection map is exploratory until separately frozen and evaluated on fresh data.

Active evaluation permits specified deviations from the computation, for example malicious
returned gradients or feature-space-hijacking-style training interventions. Freeze the attack
budget, accessible state, integrity assumptions, effect on utility/training, controls, and
qualification before execution. A deeper probe, auxiliary-data fitting, or history averaging
on an unchanged computation is stronger **passive** evaluation. Neither substitutes for active
coverage. Active code and its protocol remain to be established; no positive defense claim
can precede them.

Replication on the second architecture and corpus is a separate future cohort. Requalify
attacks in each setting and do not import Paper 3's replicated remote-gain result as privacy
evidence. Missing checkpoints or captures require fresh Paper 4 runs, not reconstruction of
unavailable historical evidence.

## 7. Transcript and reporting boundaries

The inventory must include forward latents, returned values, both gradient directions at their
available precision, remote parameters/state and optimizer state, per-step/history views,
within-run joint tensors, cross-run observations, and timing metadata. Each evaluated privacy
statement lists its qualified views, attacker side information, and all omissions.

The inherited gaps are timing, optimizer state beyond the remote module, full evolving remote
state, active/adaptive attackers, within-run joint tensor attacks, cross-run joint attacks,
natural-sequence membership, semantics beyond byte-structure classes, returned values, and
full-precision inbound/outbound gradients. History-accumulation and canary-membership
instruments were unqualified; undefended gradient property/token probes and all defended
gradient probes were also unqualified. Paper 4 must record whether each gap remains or is
closed by new qualification. Declaration and capture alone do not close a gap.

Seed/run is the inferential unit; token rows, windows, and frames remain nested. Separate
training-seed uncertainty from document-panel uncertainty. Resource measurements are labeled
as measured or estimated. Any hierarchical model or deployment study needs an identified
design and its own prespecified analysis; neither is promised by this initial pilot.
