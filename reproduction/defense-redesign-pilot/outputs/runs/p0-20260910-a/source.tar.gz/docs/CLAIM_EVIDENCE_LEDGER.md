# Claim-evidence ledger

Status: **Paper 4 design/P0 engineering; no scientific claim unlocked.**
This ledger replaces the initial scaffold's unsupported universal-impossibility and already
successful/failed defense language. Diagnostic outputs, if produced, establish implementation
behavior only. Pilot and confirmatory studies remain governed by their own recorded freezes.

The current Paper 4 quantizer changes per-tensor statistics to per-token min/max over the
latent dimension. Record that mechanism change in every new manifest/configuration. Fresh
D0 controls are required; equal forward precision is not grounds for pooling Paper 3 and
Paper 4 outcomes. D1 pilot basis/warmup scheduling remains pending validation.
Paper 4's 80/10/5/5 training/calibration/probe-fit/evaluation partition also differs from
Paper 3. The validated configurations enumerate 10 engineering and 66 draft pilot runs;
these are configuration counts only, not completed scientific evidence.

## Prospective Paper 4 claims

| ID | Candidate claim | Required evidence | Current status / permitted language |
|---|---|---|---|
| C1 | D1 satisfies the joint gates at a specified cell | Frozen fresh-seed confirmation: mean Δ_U≤0.10, upper 95% limit≤0.12; mean G_R≥0.01 with corrected paired test; every required qualified attack/view worst seed≤0.02; full declared transcript and qualified active evaluation | Not established; “We test whether…” |
| C2 | D2 adversarial encoder yields an eligible cell | Separately specified minimax training, held-out evaluation attacks, same joint gates and active/transcript prerequisites | Subsequent extension; not in the initial pilot |
| C3 | An eligible cell exists at lower forward precision | Fixed other factors, qualified exact-q attacks, held-out joint-gate evaluation; no assumed monotonicity | Not established; precision is not full-transcript bitrate |
| C4 | No evaluated cell satisfies the joint criteria | Completed frozen finite matrix, all cell-level outcomes, operational failures and unqualified coverage disclosed; no missing score treated as zero | Not established; only an empirical statement about completed tested cells is permitted |
| C5 | Eligibility persists under a specified active attacker | Qualified protocol-manipulating attack with frozen budget, side information, integrity assumptions, matched controls, and training/utility consequences | Pending; stronger passive probes do not satisfy this requirement |
| C6 | A result replicates beyond the reference architecture/corpus | Fresh setting-specific cohorts, new qualification and complete outcomes under a frozen replication protocol | Pending; Paper 3 utility replication supplies no privacy evidence |
| C7 | D1+D3 improves outcomes relative to its components | Controlled interaction cells with matched D1-only, D3-only and reference runs; independent confirmation for a positive claim | Optional exploratory extension, not established |
| X1 | All representation-preserving boundaries face universal impossibility | Explicit task/adversary/communication model and a justified task-specific converse | Not a claim available from this empirical study |
| X2 | Leaked punctuation or other properties are necessary for useful remote work | An identified intervention or applicable formal result separating the claimed necessity from correlation | Not established by prior or planned finite sweeps |

Calibration floors are not acceptance gates. Punctuation is the primary sequence-property
target; vowel/newline targets remain exploratory until individually qualified. Next-byte
structure is byte-class prediction. No activation-only result unlocks a positive defense claim.

## Inherited evidence: cite, do not rerun

Authority: final Paper 3 ledger and manuscript at pinned revision
`52191c430110bd8d9dee80538fde22bf1726e56a`. Its current clarification takes precedence over
historical decision language. See [PRIOR_EVIDENCE.md](PRIOR_EVIDENCE.md) for the complete scope
and [INHERITED_ASSETS.md](INHERITED_ASSETS.md) for reusable interfaces.

| Inherited item | Evidence within Paper 3 | Permitted interpretation |
|---|---|---|
| Reference remote gain: 0.0167 nats, n=8, p≈8.35e−7 | `outputs/confirmatory/confirmatory_analysis.json`, `docs/P2_CONFIRMATORY_DECISION.md`, current ledger clarification, P2 manifests | Trained-versus-frozen gain in the specified cell, with width/span moderation; not remote necessity or superiority over removal |
| Replicated remote gain: 24 positive pairs, means 0.012–0.046 nats | `outputs/replication/replication_summary.md`, P3 protocol/manifests | Remote-gain replication, not broadened privacy replication |
| Four P2b candidates rejected under qualified forward attacks | `outputs/privacy_extended_p4b/privacy_extended_p4b.json`, P4b protocol and calibration/P2b manifests | Punctuation and next-byte structure evidence; secondary property maxima do not independently qualify vowel/newline |
| P5 finite sweep has no eligible tested privacy candidate; 288 runs | `outputs/delegation/delegation_analysis.json`, P5 protocol/manifests | Qualified forward property scores reject all candidates; do not claim both forward families fail every cell |
| P5 D1 Δ_U=0.82–1.56 nats | Same P5 sources | Relative to all-local for bundled precision/backward perturbation; not isolated noise cost or Paper 4 D1 evidence |
| Utility responds to fixed-width forward precision with a practical plateau above q=8 | `outputs/rate_sweep/rate_sweep_analysis.json`, P2b protocol/manifests | No validated complete-transcript rate or extrapolated monotonic law below q=4 |

Generated Paper 3 summaries are local ignored artifacts linked by its ledger to committed
protocols, source, configurations, and manifests. A current source snapshot is not independent
proof of historical pre-outcome registration. This ledger imports neither unverified venue
claims nor numerical results from the earlier decoy-system paper.

## Coverage carried forward

Until Paper 4 independently closes and records each gap, name timing; optimizer state beyond
the remote module; full evolving remote state; active/adaptive attackers; within-run joint
tensor attacks; cross-run joint attacks; natural-sequence membership; semantics beyond
byte-structure classes; returned values; and full-precision inbound/outbound gradients as
unevaluated. History-accumulation/canary-membership instruments, undefended gradient
property/token probes, and all defended gradient probes were unqualified in Paper 3.

A captured or declared channel is not an evaluated attack. Nondetection by a qualified probe
is probe-specific. Missing or unqualified scores are undetermined. No post-hoc maximum or
stronger passive evaluation silently expands qualified scope or satisfies the active requirement.

## Requirements for new entries

Before adding a manuscript result, record the exact Paper 4 code and pinned dependency
revision, environment, protocol/freeze/amendments, matrix hash, seed cohort, data/capture and
calibration hashes, target/channel qualification, selection rule, inferential unit, uncertainty
and multiplicity procedures, generated summary, and corresponding manifests. Distinguish
engineering diagnostics, exploratory pilot, and confirmation. Record failures and omissions
alongside successes. Actual matrix-derived counts replace planned counts only after validation.

`Deep-research.md` remains supplied background, not a source of completed experiments,
universal impossibility, or comparative failures of unimplemented defenses.
