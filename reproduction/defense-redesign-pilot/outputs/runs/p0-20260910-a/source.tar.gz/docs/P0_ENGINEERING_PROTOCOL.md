# P0 engineering execution protocol

ID: `p4-p0-engineering-0.1`. Established 2026-09-10 before the first full P0 matrix.
Status: engineering-ready; **not a scientific preregistration or qualification run**.

## Purpose and matrix

Verify that the proposed treatments can train and be observed with matched control
semantics, without interpreting three training steps as converged performance.
The exact machine-readable configuration is
[`p0_diagnostics.yaml`](../experiments/configs/p0_diagnostics.yaml).

| Factor | Engineering setting |
|---|---|
| Model | Eight layers, d=256, eight heads, FFN=1024, byte vocabulary=256 |
| Replaced segment / surrogate | span=4, start=2, latent width=256, remote depth=1 |
| Cells | D0 q=8; D1 σ=0.1 at q=8; D3 q=2 |
| Modes per cell | Trained, frozen-random, removed-remote |
| All-local | One common baseline per seed |
| Seed | 410001, reserved for engineering only |
| Budget | Three optimizer steps, batch=2, sequence=32, CPU with two Torch threads |
| Calibration / evaluation / probe panels | 16 / 4 / 8 batches respectively |
| Diagnostic class probe | Two epochs; deliberately not a calibrated attack budget |
| Unique jobs | 3×3+1=10 |

Input is the hash-pinned tiny-Shakespeare byte corpus. Disjoint contiguous regions
reserve 80% for training, 10% for basis calibration, 5% for attacker fitting, and
5% for evaluation. Sampling stays within region boundaries. Windows within a
region may overlap; they are not independent documents or inferential replicates.
The D1 basis is fitted on each paired model's identical initialized encoder using
calibration text and then held fixed. This policy is diagnostic only.

## Required checks and recorded artifacts

The test suite checks prefix invariance under changed future tokens, orthonormal
bases, zero-noise identity, evaluation-time perturbation, actual gradient flow,
matched trusted initialization, frozen remote weights, removed bypasses, true
next-byte labels, and RNG restoration even after capture exceptions. Missing or
unqualified scores and an empty required attack set must remain undetermined.

The runner validates matrix identity, control modes, fresh seeds and the reference
segment; verifies vendored and installed Paper 3 source; and records source/file
hashes, dependency versions, Python and host/device settings. Every job records
configuration, training curve, final diagnostic loss, remote checksums, channel
inventory, and available capture hashes in a schema-validated manifest. The
campaign retains a source archive including uncommitted implementation files.
This new repository has no initial commit yet, so `git_commit` can be null; the
source archive/hash is the engineering identity, not a scientific code freeze.

Four value/gradient channels and quantizer metadata are captured for split modes.
Forward property and next-byte probes are exercised only to check their interfaces.
All are marked unqualified; privacy is **undetermined**. Timing, optimizer state,
full evolving remote state, active/adaptive attacks, joint/cross-run/history attacks,
canary/natural membership, unrestricted semantics, metadata attacks, returned-value
attacks, and full-precision gradient attacks remain unevaluated. Capturing a tensor
does not qualify an attack on it.

Each job either completes with finite losses and valid artifacts or records a
failure. No failed run is overwritten or silently excluded. A code/configuration
fix receives a new campaign label and source identity. Engineering outcomes cannot
select a defense, support a hypothesis, or be reused as confirmation. The runner
refuses draft pilot/confirmation execution before accessing data or creating runs.

## Next protocol milestone

After the engineering matrix, complete the separate calibration design: exact
per-target/channel/defense positive-dose and matched-null controls, budgets, seeds,
panel hashes, and aggregation. Then resolve the D1 coordinate/warmup policy and
freeze the exploratory pilot. The current 66-run pilot is a **draft** with its
execution disabled. Active and full declared-transcript evaluation remain required
before any positive defense claim.
