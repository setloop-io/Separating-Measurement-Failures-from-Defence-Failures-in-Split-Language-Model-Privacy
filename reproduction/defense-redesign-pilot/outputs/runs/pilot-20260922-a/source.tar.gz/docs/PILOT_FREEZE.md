# Pilot freeze — Paper 4 defense pilot 1.0

Protocol ID: `p4-defense-pilot-1.0`
Status: **FREEZE EFFECTIVE with the commit landing
`experiments/freeze/p4-defense-pilot-1.0.json`.** Before that commit this document
was a draft and the exploratory pilot was disabled. This document amends and
supersedes the pending items of `p4-defense-pilot-0.2-draft`
([PREREGISTRATION.md](PREREGISTRATION.md)); the draft and all engineering
protocols remain unchanged as records.

## 1. What is frozen

- **Corpus and partition.** `gutenberg_p4` (SHA-256
  `af3d0245c0ec27d7021f5fd29256bc845bb20cf9c562b37bbe23663b6ebe7436`) with
  author-disjoint document regions per
  [CALIBRATION_TEXT_PROTOCOL.md](CALIBRATION_TEXT_PROTOCOL.md). Replaces the draft's
  tiny-Shakespeare fractional split; the historical corpus is untouched. The 66-run
  matrix count of the draft is unchanged (7 cells × 3 modes × 3 seeds + 3 all-local).
- **Anchor and reference.** Span 4 at start 2, latent width 256, remote depth 1,
  per-token affine quantizer, q=8 reference. Backbone per the frozen config.
- **Training regime.** 2,000 steps from initialization; **no shared warmup**;
  AdamW lr 3e-4 cosine to 3e-5, lr warmup 100, weight decay 0.1, clip 1.0, betas
  (0.9, 0.95); batch 32, sequence length 128; per-seed paired trusted/remote
  initialization. Chosen per the budget-response engineering
  ([BUDGET_SCAN_DECISION.md](BUDGET_SCAN_DECISION.md)): the only measured regime
  where both engineering seeds cleared the proposed 0.01 gain gate. Gates are
  unchanged from the draft; this is an operating-point choice, not a gate change.
- **Cells.** `d0-q8`; `d1-s{0.1,0.5,1.0}-q8` (property noise); `d3-q{1,2,3}`
  (forward precision). Modes trained / frozen_random / removed_remote per cell,
  plus one all_local per seed. 66 runs.
- **D1 basis policy.** Scheduled rank-1 punctuation refit: fit at step 0 and every
  250 steps (250, …, 2000) on 4,096-window basis panels (disjoint document halves
  of the calibration region), hashed and logged per refit, final refit at step
  2,000 before captures; releases always use the latest basis. Adopted per the
  measured drift of fixed bases ([WARMUP_BUDGET_DECISION.md](WARMUP_BUDGET_DECISION.md)).
  No basis switching based on held-out leakage is permitted after freeze.
- **Panels.** One shared panel set per region for the whole pilot: 16,384 disjoint
  within-document windows from probe-fit and evaluation regions, document
  identities recorded, panel seeds derived from the protocol ID.
- **Estimators and controls.** Punctuation: ridge on sequence-mean released
  features, matched-null K=16. Next-byte structure: five-class MLP on per-token
  released features with the frozen fitting budget, matched-null K=4. Per binding:
  16 outer donor-derangement no-signal trials (all must satisfy |advantage| ≤ 0.02)
  and positive controls at doses {0, 0.5, 2.0} (nonzero doses must meet the floor:
  property 0.10, structure 0.02), with codebook-support and exact zero-dose checks.
  Candidate advantage = observed score − mean of that binding's matched nulls.
  Justification chain: [NULL_PRECISION_128_DECISION.md](NULL_PRECISION_128_DECISION.md),
  [STRUCTURE_PRECISION_DECISION.md](STRUCTURE_PRECISION_DECISION.md).
- **Seeds.** Pilot cohort 411101–411103; machine-checked non-overlap audit
  (`scripts/audit_seeds.py`) against Paper 3 and every Paper 4 use, retained at
  freeze. Repeated use of a pilot seed across paired cells is intentional; the
  seed/run is the inferential unit.
- **Loss evaluation.** Final loss on the fixed 16,384-window evaluation panel,
  identical windows for all runs.
- **Device policy.** CUDA on the recorded nodes, deterministic kernels; per-seed
  execution subsets recorded in manifests; paired runs of one seed execute on one
  device.

## 2. Gates (unchanged from the draft; interval rule now frozen)

For each cell, over the three pilot seeds: Δ_U = L_trained − L_all-local,
G_R = L_frozen − L_trained; removed-remote comparisons reported separately.

1. **Utility:** mean Δ_U ≤ 0.10 nats AND mean + t(0.95, df=2)·sd/√3 ≤ 0.12 nats
   (one-sided upper 95% Student-t limit, frozen here).
2. **Causal gain:** mean G_R ≥ 0.01 nats AND G_R > 0 in all three pairs.
3. **Privacy:** for every required qualified (target, view) — punctuation and
   next-byte structure on released forward values — worst-seed candidate advantage
   ≤ 0.02, with every required binding qualified and scored (coverage complete).
4. A cell is **pilot-eligible** iff 1–3 hold at the same cell. All cells and all
   gate values are reported, including failures. Optional/failed strengths do not
   invalidate a distinct eligible cell; no composite passes; no relative-reduction
   substitution.

Pilot eligibility is exploratory evidence only. It does not unlock a positive
defense claim: that additionally requires the confirmatory freeze (fresh seeds,
paired test, frozen multiplicity family), the declared complete-transcript
evaluation, and qualified active attacks. Differential privacy, universal
security, and safety against omitted threats are not established by any gate.

## 3. Qualification prerequisite (completed 2026-09-22)

The calibration-cohort campaign `qualification-20260922-a` (32 runs, protocol
[p4-qualification-0.1](QUALIFICATION_PROTOCOL.md)) completed and verified
([verification](../outputs/runs/qualification-20260922-a/verification.json),
[decision record](QUALIFICATION_DECISION.md)). Its per-(target × cell-condition)
verdicts, under the strict all-16-trials rule:

- Punctuation × released forward: **qualified** for d1-s0.1-q8, d1-s0.5-q8,
  d3-q1, d3-q2, d3-q3; **not qualified** for d0-q8 and d1-s1.0-q8 — each had
  exactly one of four bindings fail on marginal no-signal excursions (max
  |advantage| 0.0217 and 0.0245, positive controls ≈ 1.0), matching the measured
  ~1.5% marginal excursion rate of the estimator. This is disclosed as
  reliability evidence; the pilot's own per-binding qualification verdicts
  decide coverage at execution, and any pilot binding left unqualified keeps
  that cell's privacy coverage **undetermined** (ineligible on privacy).
- Next-byte structure × released forward: **qualified** for all 7 cells.

Freeze record: `experiments/freeze/p4-defense-pilot-1.0.json` (config sha256,
code commit, corpus/documents digests, pilot seed-audit record, qualification
verification sha256, this document's sha256 after completion). The freeze
becomes effective with the commit that lands the record; the exploratory pilot
is disabled until then.

## 4. Failure handling and amendments (carried from the draft)

At most one identical-identity retry per run; failure records retained. A missing
required matched partner removes that pair and blocks the complete-cohort gate;
no outcome-based exclusion. Any change after freeze (replacement seed, altered
defense, budget change) requires a numbered amendment with reason, timing relative
to outcome inspection, affected artifacts, and evidential consequence. Already
observed outcomes are never relabeled confirmation.

## 5. Named omissions for every privacy summary

Timing; optimizer state beyond the remote module; full evolving remote state;
active/adaptive attackers; within-run joint tensors; cross-run joint attacks;
natural-sequence and canary membership; semantics beyond byte-structure classes;
returned values; full-precision inbound/outbound gradients; quantizer metadata
attacks; history accumulation; token inversion (secondary, unqualified here).
A captured or declared channel is not an evaluated attack.
