# JAIAI submission draft

This journal adaptation uses **only the manuscript committed on `main` at
`68971068bef8f392998d5cc6620b8209af317997`**. The original manuscript, bibliography,
figures and ancillary evidence remain unchanged. No `review-v2` experiments,
new seed intervals, synthetic-gradient fix or norm-ranking analysis are included.

The requested destination is the **Journal of Artificial Intelligence and
Autonomous Intelligence**, ISSN **3049-2297**, **Volume 3, Issue 1**. The request
appears in the title page and cover letter; the editor assigns publication
metadata. No received/accepted dates, DOI or publication pagination are invented.

**Status: reviewable draft; some author facts and declarations are incomplete.**
The authors have confirmed that the research received no funding and that they
have no conflicts of interest. Both declarations are included in the manuscript,
title page and cover letter. Both authors' approval of the manuscript and agreement
to submission and publication if accepted are recorded in the title page and
cover letter. Georgios Politis's postal address and telephone have been supplied.
The administrative documents identify the remaining
missing information. Do not upload or send these drafts with those fields
unresolved. No manuscript has been submitted and no message has been sent.

## Files and build

- `manuscript.tex`, `abstract.tex`, `references.tex`: shortened main article.
- `supplement.tex`: detailed tables, calibration/shape figures, complete scored
  mitigation matrix, mechanism ledger and verification/provenance record.
- `author-details.tex`: shared author facts and explicitly unconfirmed fields.
- `title-page.tex`, `cover-letter.tex`: separate administrative drafts.
- `AAIML.cls`, `draftrule.sty`: unmodified files downloaded from JAIAI's template.
- `preamble.tex`: submission header and journal caption/citation settings.
- `figures/`: editable diagrams and separate PDF/EPS/300-dpi JPEG figure files.
- `build.py`: offline PDF build, document checks, figure export and ZIP packaging.
- `prepare-supplement.py`: conversion provenance; regenerates the supplement and
  anatomy source from the pinned Git revision. It is not needed for ordinary builds.

Run `python3 jaiai/build.py` from the repository root. Requirements: XeLaTeX with
Times New Roman and Courier New, standard LaTeX packages, Python with `pypdf`,
and Poppler (`pdftops`, `pdftoppm`). On Overleaf, select **XeLaTeX** and compile
`manuscript.tex`, `supplement.tex`, `title-page.tex` or `cover-letter.tex` from
this source directory. All referenced figures are supplied.

PDFs are written to `output/pdf/jaiai/`; the four documents and editable sources
are packaged in `output/jaiai-submission-draft.zip`. Machine checks are recorded
in `output/jaiai-validation.json`. The generated documents require visual
inspection after edits; successful compilation alone does not verify layout.

## Journal requirements used

Sources were checked on **28 October 2026**:

- [Author's guide](https://jaiai.org/authorguide)
- [Journal-hosted LaTeX instructions](https://jaiai.org/files/JAIAIinstruction.pdf)
- [Journal-hosted source archive](https://jaiai.org/jaiai-Latex.zip)
- [Journal-hosted sample](https://jaiai.org/files/sample.pdf)
- [Current issue](https://jaiai.org/current-issue)

The guide's stricter numerical limits are used where its sections disagree:
200–280 abstract words, at most five capitalised keywords in alphabetical order,
title of at most 25 words without abbreviations, and a main article within both
7,500 words and 12 journal pages. The cover letter is below 500 words. The
submission uses numbered square-bracket citations, 10-point centred legends,
TABLE legends above and FIGURE legends below their objects, a separate title
page and one supplementary PDF. See `submission-checklist.md` for remaining facts.

The body guide links to an older sister-journal template and a broken title-page
instruction URL. JAIAI's own footer supplies a working source archive, which
contains `AAIML.cls`; that class and the journal's XeLaTeX instructions were used.
Publisher sample headers were adapted for review rather than copied as false
publication metadata. The site already lists Volume 3, Issue 1; availability for
further submissions to that issue needs the editor's confirmation.

## Editorial changes and scientific boundaries

The title expands “LLM”; the abstract is shortened to the journal range. The main
argument follows Introduction, Materials and Methods, Results, Discussion and
Conclusion, with availability and disclosure sections. Detailed setup, calibration,
shape audit, historical batteries and provenance are supplied separately.

All nine primary seed values and all nine defended diagnostic cell values are
retained unchanged. The supplement also retains the naked-control rows. It
does not add results from a document-disjoint rerun, new control campaigns,
new per-seed confidence intervals or an unmeasured structural fix.

Several inconsistencies within the source were reconciled using its own evidence:

- The remote defended module is described as the latent-native Gram surrogate,
  consistent with the source trust table and mechanism ledger. Some original
  prose incorrectly called it a full transformer stack.
- The first seed-42 container is distinguished from its clean packaged rerun;
  the nine-seed pool is not described as nine uniformly packaged executions.
- The diagnostic matrix uses three fresh seeds across two corpora, not six
  independent seeds. Public gradient-only gate breaks are retained in the supplement.
- The cross-Gram feature's naked-control failure is treated as failed sensitivity,
  not evidence that cross-tensor information is absent.
- The anatomy diagram now marks the scale gauge OFF and its trust table no longer
  asserts that token scale is hidden in that operating configuration.

The original wide cross-system positioning table and three-paper comparison were
removed from the shortened submission rather than recast as a new literature
survey. The main references use only published-venue entries already in the source
bibliography; the original preprint-only entries are not cited. No experimental
results were recomputed, and no new literature or experimental claims were added.

Preserved limitations include the eleven-layer utility failure, 2,000-step
four-layer budget, sequential block split, unchecked forward-arm null, deep-probe
best-epoch selection and padded/unpadded comparison, unreleased raw evidence,
single-seed shape audit, five unmeasured families and no reconstruction/security
guarantee after mitigation. A source inconsistency in calibration frame accounting
was avoided by retaining the source's dose sweep without adding frame counts.

Visual review also found that the original calibration PDF clipped its plot
title. Its page and crop boxes were extended by 18 points to reveal the already
drawn vector title; the plot's content streams and numerical data are unchanged.
This correction affects only the journal copy, not the figure committed on `main`.
