#!/usr/bin/env python3
"""Build and validate the self-contained JAIAI submission draft.

Requirements: Python 3 with pypdf, XeLaTeX, Times New Roman, Courier New,
pdftops and pdftoppm. No experiment data or network access is required.
"""
from pathlib import Path
import hashlib
import io
import json
import re
import shutil
import subprocess
import zipfile

from pypdf import PdfReader, PdfWriter

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
BUILD = ROOT / "tmp" / "jaiai-build"
OUT = ROOT / "output" / "pdf" / "jaiai"
BUILD.mkdir(parents=True, exist_ok=True)
OUT.mkdir(parents=True, exist_ok=True)


def run(command, cwd, log=None):
    result = subprocess.run(command, cwd=cwd, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True)
    if log:
        (BUILD / log).write_text(result.stdout)
    if result.returncode:
        raise RuntimeError(" ".join(map(str, command)) + "\n" + result.stdout[-5000:])


def compile_tex(name, cwd, passes=1):
    for _ in range(passes):
        run(["xelatex", "-interaction=nonstopmode", "-halt-on-error",
             f"-output-directory={BUILD}", f"{name}.tex"], cwd, f"{name}-build.txt")
    log = (BUILD / f"{name}.log").read_text(errors="replace")
    defects = re.findall(
        r"Overfull[^\n]*|Float too large[^\n]*|Missing character[^\n]*|"
        r"LaTeX Warning: Reference[^\n]*undefined|"
        r"Package natbib Warning: Citation[^\n]*undefined|"
        r"There were undefined (?:references|citations)", log
    )
    if defects:
        raise RuntimeError(f"{name} has layout/reference defects: {defects}")


# The original calibration PDF draws its title above its 158.4-point page.
# Extend the page boxes once to reveal that existing vector content. No plot
# values, text, coordinates or content streams are redrawn or modified.
dose_path = HERE / "figures" / "fig_w24_dose.pdf"
dose_reader = PdfReader(dose_path)
if abs(float(dose_reader.pages[0].mediabox.height) - 158.4) < 0.1:
    dose_writer = PdfWriter()
    dose_writer.clone_document_from_reader(dose_reader)
    page = dose_writer.pages[0]
    width, height = float(page.mediabox.width), float(page.mediabox.height)
    page.mediabox.upper_right = (width, height + 18)
    page.cropbox.upper_right = (width, height + 18)
    buffer = io.BytesIO()
    dose_writer.write(buffer)
    dose_path.write_bytes(buffer.getvalue())

figures = ["training-channels", "anatomy", "fig_w24_dose", "fig_w56_shape"]
for name in figures:
    if (HERE / "figures" / f"{name}.tex").exists():
        compile_tex(name, HERE / "figures")
        shutil.copy2(BUILD / f"{name}.pdf", HERE / "figures" / f"{name}.pdf")
    pdf = HERE / "figures" / f"{name}.pdf"
    run(["pdftops", "-eps", str(pdf), str(pdf.with_suffix(".eps"))], HERE)
    run(["pdftoppm", "-jpeg", "-r", "300", "-singlefile", str(pdf),
         str(pdf.with_suffix(""))], HERE)

outputs = {
    "manuscript": "jaiai-manuscript-draft.pdf",
    "supplement": "jaiai-supplement.pdf",
    "title-page": "jaiai-title-page-draft.pdf",
    "cover-letter": "jaiai-cover-letter-draft.pdf",
}
report = {
    "source_branch": "main",
    "source_commit": "68971068bef8f392998d5cc6620b8209af317997",
    "target_issue_requested": "Volume 3, Issue 1",
    "submission_status": "Draft: author details and declarations require confirmation",
    "author_guide": "https://jaiai.org/authorguide",
    "template_url": "https://jaiai.org/jaiai-Latex.zip",
    "template_class_sha256": hashlib.sha256((HERE / "AAIML.cls").read_bytes()).hexdigest(),
    "files": {},
}
for name, filename in outputs.items():
    compile_tex(name, HERE, passes=3)
    target = OUT / filename
    shutil.copy2(BUILD / f"{name}.pdf", target)
    reader = PdfReader(target)
    text = "\n".join(page.extract_text() or "" for page in reader.pages)
    if "??" in text or "\ufffd" in text:
        raise RuntimeError(f"Unresolved text in {target}")
    report["files"][filename] = {
        "pages": len(reader.pages),
        "pdf_extracted_word_count_including_headers": len(text.split()),
        "sha256": hashlib.sha256(target.read_bytes()).hexdigest(),
    }

abstract = (HERE / "abstract.tex").read_text()
report["abstract_word_count"] = len(abstract.split())
assert 200 <= report["abstract_word_count"] <= 290
assert report["files"][outputs["manuscript"]]["pages"] <= 12
assert report["files"][outputs["manuscript"]]["pdf_extracted_word_count_including_headers"] < 7500
main_source = (HERE / "manuscript.tex").read_text()
report["main_figure_count"] = main_source.count(r"\begin{figure}")
report["main_table_count"] = main_source.count(r"\begin{table}")
report["keyword_count"] = 5
report["main_reference_count"] = (HERE / "references.tex").read_text().count(r"\bibitem{")
assert report["main_figure_count"] == 1 and report["main_table_count"] == 3
assert report["main_reference_count"] == 19
report["layout_and_reference_log_check"] = "passed; no overfull boxes, missing glyphs or unresolved references"
report["visual_review"] = "See README: inspect final renders after every substantive edit"
report_path = ROOT / "output" / "jaiai-validation.json"
report_path.write_text(json.dumps(report, indent=2) + "\n")

archive = ROOT / "output" / "jaiai-submission-draft.zip"
with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as bundle:
    for path in sorted(HERE.rglob("*")):
        if path.is_file() and "__pycache__" not in path.parts:
            bundle.write(path, Path("source") / path.relative_to(HERE))
    for filename in outputs.values():
        bundle.write(OUT / filename, Path("documents") / filename)
    bundle.write(report_path, "jaiai-validation.json")
print(json.dumps({"pdfs": report["files"], "abstract_words": report["abstract_word_count"],
                  "archive": str(archive)}, indent=2))
