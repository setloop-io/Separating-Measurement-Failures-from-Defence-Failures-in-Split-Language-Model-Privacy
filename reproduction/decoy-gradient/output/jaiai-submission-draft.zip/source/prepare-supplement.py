#!/usr/bin/env python3
"""Preserve selected technical material from the pinned main source.

Run from anywhere inside the source repository. The generated supplement is
self-contained; this one-time conversion script is not needed to compile it.
"""
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent
SOURCE = "68971068bef8f392998d5cc6620b8209af317997"
source = subprocess.check_output(
    ["git", "show", f"{SOURCE}:main.tex"], cwd=ROOT, text=True
)


def argument(text, start):
    """Return a balanced LaTeX brace argument and its exclusive end index."""
    assert text[start] == "{"
    depth = 1
    i = start + 1
    while depth:
        if text[i] == "{" and text[i - 1] != "\\":
            depth += 1
        if text[i] == "}" and text[i - 1] != "\\":
            depth -= 1
        i += 1
    return text[start + 1:i - 1], i


def float_for(label):
    pos = source.index(r"\label{" + label + "}")
    start = max(source.rfind(r"\begin{table}", 0, pos),
                source.rfind(r"\begin{figure}", 0, pos))
    kind = "table" if source.startswith(r"\begin{table}", start) else "figure"
    end = source.index(r"\end{" + kind + "}", pos) + len(r"\end{" + kind + "}")
    block = source[start:end]
    if kind == "table":
        cstart = block.index(r"\caption{")
        _, cend = argument(block, cstart + len(r"\caption"))
        lstart = block.index(r"\label{")
        _, lend = argument(block, lstart + len(r"\label"))
        caption = block[cstart:cend]
        lab = block[lstart:lend]
        # Move the caption and label above the table, as required by JAIAI.
        block = block[:cstart] + block[cend:lstart] + block[lend:]
        open_end = block.index("\n") + 1
        block = block[:open_end] + caption + "\n" + lab + "\n" + block[open_end:]
        if label in {"tab:sixseed", "tab:positive_control", "tab:shape", "tab:matching"}:
            # Compact, descriptive headings keep the numerical tables legible.
            replacements = {
                "gradient arm (pp)": "Gradient (pp)",
                "forward arm (pp)": "Forward (pp)",
                "negative control (pp)": "Shuffled (pp)",
                "Wilson upper-95 acc.": "Upper-95 acc.",
                "constant baseline": "Baseline",
                "defended ($D{=}1024$, dimension-matched)": "defended ($D{=}1024$)",
                "defended ($D{=}64$, noise, decoys)": "defended ($D{=}64$)",
                "naked ($D{=}1024$, no defence)": "naked ($D{=}1024$)",
                "Vector-matching top-1, against baseline": "Vector top-1 / baseline",
                "Nearest-signature top-1, against baseline": "Signature top-1 / baseline",
                "Gate statistic (pp)": "Gate (pp)",
            }
            for old, new in replacements.items():
                block = block.replace(old, new)
    # Use the journal's uppercase figure/table names for every cross-reference.
    block = re.sub(r"\bTables?~", "TABLE~", block)
    block = re.sub(r"\bFigures?~", "FIGURE~", block).replace("Fig.~", "FIGURE~")
    if label == "fig:anatomy":
        begin = block.index(r"\begin{tikzpicture}")
        end = block.index(r"\end{tikzpicture}") + len(r"\end{tikzpicture}")
        diagram = block[begin:end]
        diagram = diagram.replace(r"\Pi\,\mathrm{diag}(s)\,z\,R", r"\Pi\,z\,R")
        diagram = diagram.replace(
            r"rotation $R$, permutation $\Pi$, scale $s$ (fresh per request, KDF-derived).",
            r"rotation $R$, permutation $\Pi$ (fresh per request, KDF-derived; scale $s$ OFF)."
        ).replace(r"OBFUSCATED: $R,\Pi,s$", r"OBFUSCATED: $R,\Pi$ ($s$ OFF)")
        figure_preamble = r"""\documentclass[11pt]{article}
\usepackage[paperwidth=17cm,paperheight=17cm,margin=3mm]{geometry}
\usepackage{fontspec,tikz,amsmath,amssymb,xcolor}
\setmainfont{Times New Roman}
\usetikzlibrary{arrows.meta,positioning,shapes.geometric}
\pagestyle{empty}
\definecolor{tlncol}{HTML}{1F6F8B}
\definecolor{ucncol}{HTML}{8B3A1F}
\definecolor{leakcol}{HTML}{B00020}
\definecolor{guardcol}{HTML}{1E7D32}
\definecolor{sealedcol}{HTML}{5B2C91}
\newcommand{\abadge}[3]{\node[font=\tiny\bfseries,fill=#1!14,text=#1,draw=#1,rounded corners=1pt,inner sep=1.4pt] at (#2) {#3};}
\newcommand{\stepbox}[4]{\node[draw=#4!70!black,fill=#4!8,rounded corners=2pt,align=left,text width=4.9cm,inner sep=4pt,font=\scriptsize] at (#1) (#2) {#3};}
\newcommand{\wirelbl}[4]{\draw[-{Stealth[length=2.4mm]},thick,#4] (#1) -- (#2) node[midway,font=\tiny,align=center,#4,fill=white,inner sep=1pt]{#3};}
\begin{document}\noindent
"""
        (ROOT / "figures" / "anatomy.tex").write_text(
            figure_preamble + diagram + "\n\\end{document}\n"
        )
        block = block[:begin] + r"\includegraphics[width=\linewidth]{figures/anatomy.pdf}" + block[end:]
    if label == "tab:trust":
        block = block.replace("rotation, permutation, scale;", "rotation and permutation; scale OFF;")
        block = block.replace("token order, token scale, plaintext tokens", "token order, plaintext tokens")
    block = block.replace("figs/", "figures/")
    block = block.replace(r"\_", r"\_\allowbreak ")
    return block + "\n\n"


header = r"""% Generated from main@68971068bef8f392998d5cc6620b8209af317997.
\documentclass{AAIML}
\input{preamble}
\usepackage{longtable}
\input{author-details}
\renewcommand{\thesection}{S\arabic{section}}
\renewcommand{\thetable}{S\arabic{table}}
\renewcommand{\thefigure}{S\arabic{figure}}
\renewcommand{\theequation}{S\arabic{equation}}
\urllink{\small JAIAI \textbar\ Supplementary Information}
\hypersetup{pdftitle={Supplementary Information: Privacy Failure in Split Large Language Model Training}}
\begin{document}
\title{Supplementary Information\\\PaperTitle}
\author{\name \AuthorOne\ and \AuthorTwo\\\addr \KnownAffiliation}
\editor{\CorrespondingAuthor\ (\texttt{\AuthorOneEmail}).}
\maketitle
This supplement retains the detailed numerical tables, mechanism inventory and
verification trail from the manuscript committed on \texttt{main} at
\texttt{6897106} (the full commit hash is recorded in the source package).
It introduces no new experiments. Figure and table
numbers have an S prefix. The main article provides the condensed argument.

Editorial clarifications reconcile the source's own qualifications: the
defended cloud uses a latent-native gauge-equivariant surrogate; seed 42's
original container predates packaging; three fresh diagnostic seeds were
used across two corpora; cross-Gram features also fail on naked controls.
These clarifications do not change the reported measurements.

\section{DETAILED SETUP AND MESSAGE ANATOMY}
\label{sec:system}
The model and corpus fingerprints, trust boundary and per-step anatomy are
preserved below. The cloud's description as a full transformer stack in some
source prose is superseded by its own trust table and mechanism ledger:
the evaluated defended remote module is a gauge-equivariant latent surrogate.
The scale-and-sign gauge is disabled for the radial/invariant clouds.
TABLES~\ref{tab:setup} and~\ref{tab:trust} describe the setup and trust split;
FIGURE~\ref{fig:anatomy} shows one training cycle.
\setlength{\tabcolsep}{3pt}
"""
parts = [header]
for label in ["tab:setup", "tab:trust", "fig:anatomy"]:
    parts.append(float_for(label))
parts.append(r"""\FloatBarrier
\section{DECLARED CHANNELS AND CALIBRATION}
\label{sec:protocol}
\label{sec:calibration}
The channel enumeration describes measurement status, not established
protection against every listed adversary. A constructible active attack is
not an executed attack. Five listed families remain unmeasured.
TABLES~\ref{tab:channels}--\ref{tab:positive_control} and
FIGURE~\ref{fig:dose} retain the channel and calibration records.
""")
for label in ["tab:channels", "fig:dose", "tab:dose", "tab:thresholds", "tab:positive_control"]:
    parts.append(float_for(label))
parts.append(r"""\label{sec:positive_control}
The split-14 deep probe selects its best evaluation epoch over 50 epochs.
Its naked $+24.19$ pp reading is a sensitivity demonstration, not a primary
leak estimate. The defended frame has 80 rows and the naked frame 32; this
comparison evaluates the composite defence, including padding. On the
different isolation-audit representation, the naked boundary also reads at
floor ($+0.66$ pp; shuffled control $+0.50$ pp). Positive controls must
therefore be matched to the tested representation.
\FloatBarrier
\section{PRIMARY AND MITIGATION RESULTS}
\label{sec:results}\label{sec:mechanism}\label{sec:confirmatory}
The primary gradient-arm statistic is a paired effect; the historical gate
instead subtracts a point baseline from an upper confidence bound. These
statistics must not be equated. The eleven-layer primary configuration fails
utility (original $+0.9185$ nats; clean rerun $+0.896$ nats; budget $0.35$).
The four-layer utility passes are 2,000-step sequential-block diagnostics.
""")
parts.append(float_for("tab:sixseed"))
parts.append(float_for("tab:confirmatory"))
parts.append(r"""The original seed-42 cloud container predates release packaging.
Its clean packaged rerun yields paired $+1.017$ pp, historical gate
$+1.147$ pp, 4,096/4,096 exact frames and a negative control at floor.
The nine recorded primary seeds give the source's pooled $+0.92$ pp,
95\% interval $[+0.74,+1.09]$, $\tau=0.23$ pp and $I^2=77\%$.
Three earlier unpackaged units are retained in the artefact estimate for
continuity but are excluded from the primary claim.

On the public-corpus diagnostics, the gradient alone breaks the historical
gate on seeds 52 and 53 ($+1.175$ and $+1.219$ pp); it is not uniformly at
floor across both datasets. The two implemented cross-Gram features read
at floor on naked controls as well as defended captures. Their failure
does not rule out other cross-tensor attacks. Gradient clipping and noise
suppress the implemented probes and zero-support detector; no general
adaptive-attack or formal privacy guarantee is established.
\FloatBarrier
\section{SINGLE-SEED SHAPE AUDIT AND ATTACK LEDGER}
\label{sec:shape}
Each shape cell uses seed 42 only. The eleven-layer depth point uses a
different training budget from the matched 2,000-step ladder, and the
64-wide reference uses a different budget from the 96/128-wide sweep.
These results are attack-specific diagnostics, not population thresholds.
FIGURE~\ref{fig:shape} and TABLE~\ref{tab:shape} show the sweep;
TABLE~\ref{tab:attacker_ledger} records the implemented attacks.
""")
for label in ["fig:shape", "tab:shape", "tab:attacker_ledger"]:
    block = float_for(label)
    if label == "tab:attacker_ledger":
        block = block.replace("no; the feature carries nothing", "not sensitive on naked control")
        block = block.replace(r"\textbf{no longer}", "scored probes at floor")
        block = block.replace("the closed\nrow is the fix", "the last\nrow describes the measured mitigation")
    parts.append(block)
parts.append(r"""\FloatBarrier
\section{SCOPE OF THE MEASUREMENTS}
\label{sec:scope}
All held-out results use sequential fixed-width blocks from a flattened
corpus, not a document-disjoint split. The two-corpus diagnostics do not
establish corpus independence. The implemented gradient probes recover no
rare tokens; sequence, prompt and held-out-text reconstruction are not
established. Accumulated history, stateful remote state, timing metadata,
membership/property inference and response-side recovery remain unmeasured.
Active perturbation is not executed at the mitigation matrix's scale.
Convergence-scale training and general security after mitigation are outside
the evidence. Raw cluster-side tensors and host-only transcripts are not
included in the public release.
\FloatBarrier
""")

start = source.index(r"\section{Artifact and verification index}")
end = source.index(r"\FloatBarrier", source.index(r"\section{The defended cell under its historical attack batteries}"))
appendices = source[start:end]
# Reuse float extraction so every table gets a caption above its contents.
for label in ["tab:availability", "tab:stack", "tab:battery", "tab:matching", "tab:byz"]:
    pos = appendices.index(r"\label{" + label + "}")
    left = appendices.rfind(r"\begin{table}", 0, pos)
    right = appendices.index(r"\end{table}", pos) + len(r"\end{table}")
    appendices = appendices[:left] + float_for(label).strip() + appendices[right:]
# These are supplement sections rather than appendices in the shortened article.
appendices = appendices.replace("Appendix~", "Section~")
appendices = re.sub(r"\bTables?~", "TABLE~", appendices)
appendices = re.sub(r"\bFigures?~", "FIGURE~", appendices)
appendices = appendices.replace(
    r"\section{The defended stack, mechanism by mechanism}",
    r"\FloatBarrier\section{The defended stack, mechanism by mechanism}"
).replace(
    r"\section{The defended cell under its historical attack batteries}",
    r"\FloatBarrier\section{The defended cell under its historical attack batteries}"
)
# A longtable lets the 24-row mechanism inventory break naturally across pages.
pos = appendices.index(r"\label{tab:stack}")
left = appendices.rfind(r"\begin{table}", 0, pos)
right = appendices.index(r"\end{table}", pos) + len(r"\end{table}")
block = appendices[left:right]
cap_pos = block.index(r"\caption{")
_, cap_end = argument(block, cap_pos + len(r"\caption"))
caption = block[cap_pos:cap_end]
begin = block.index(r"\begin{tabular}")
cols, cols_end = argument(block, begin + len(r"\begin{tabular}"))
table_body = block[cols_end:block.index(r"\end{tabular}")]
split = table_body.index(r"\midrule") + len(r"\midrule")
head = table_body[:split]
body = table_body[split:]
longtable = ("{\\scriptsize\n\\setlength{\\tabcolsep}{3pt}\n"
             + r"\begin{longtable}" + "{" + cols + "}\n"
             + caption + r"\label{tab:stack}\\" + "\n"
             + head + "\n\\endfirsthead\n" + head
             + "\n\\endhead\n" + body + "\n\\end{longtable}\n}")
appendices = appendices[:left] + longtable + appendices[right:]
parts.append(appendices)
parts.append("\n\\FloatBarrier\n\\end{document}\n")
output = "".join(parts)
output = output.replace("Appendix~", "Section~").replace("this appendix", "this supplement")
# Keep long code paths inside the narrower publisher text block.
output = re.sub(r"\\path\|([^|]+)\|", r"{\\footnotesize\\path|\1|}", output)
output = output.replace(r"\_", r"\_\allowbreak ")
# Avoid added vertical stretch between adjacent fixed-position objects.
output = output.replace(r"\begin{document}", r"\begin{document}\raggedbottom", 1)
# The anatomy and imported tables contain no external scholarly citations.
assert r"\cite{" not in output, "An imported reference needs publication-status review"
(ROOT / "supplement.tex").write_text(output)
print(f"Wrote supplement from {SOURCE}: {len(output.split())} source words")
