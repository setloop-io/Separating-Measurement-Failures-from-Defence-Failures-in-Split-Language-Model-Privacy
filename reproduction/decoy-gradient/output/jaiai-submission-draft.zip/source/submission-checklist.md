# Submission checklist

Prepared for JAIAI, requested Volume 3, Issue 1, from `main@6897106`.

## Prepared

- [x] Publisher-supplied class, XeLaTeX and Times New Roman.
- [x] Main article within 12 pages and 7,500 words, including references.
- [x] Title without “LLM” abbreviation; abstract within 200–280 words.
- [x] Five capitalised, alphabetically ordered keywords.
- [x] Numbered citations; centred 10-point figure/table legends in the required positions.
- [x] Separate figures in PDF, EPS and 300-dpi JPEG formats.
- [x] Separate supplementary PDF retaining detailed evidence and limitations.
- [x] Separate title page and cover-letter drafts; editable source package.
- [x] Original source on `main` preserved; no `review-v2` experiments imported.
- [x] No invented journal dates, DOI, article number or publication pagination.

## Author facts required before upload

- [ ] Confirm complete names and order: Georgios Politis; Evangelos Pappas.
- [ ] Confirm whether Setloop.io is the affiliation of both authors; supply each
  department/institution/country. The original source lists Setloop.io separately.
- [ ] Confirm corresponding author; the draft proposes Georgios Politis at
  geo.politis@gmail.com. Second-author email: evanz.pappas@gmail.com.
- [x] Georgios Politis's postal address and telephone supplied by the author.
- [x] Funding confirmed by the author: "This research received no funding."
- [x] Conflicts confirmed by the author: "The authors declare that they have no conflicts of interest."
- [x] Both authors approve this manuscript and agree to submission and publication if accepted.
- [ ] Confirm exclusive journal consideration.
- [ ] Supply any public preprint identifier/link and disclose it in the submission.
- [ ] Confirm any human/animal ethics statement that the portal requires; none has
  been invented from the current source.
- [ ] Confirm author contributions if requested by the portal.

## Editorial and portal checks

- [ ] Confirm the editor can consider this submission for Volume 3, Issue 1, which
  already appears on the journal's current-issue page.
- [ ] Replace the clearly labelled draft paragraph in the cover letter with
  confirmed author declarations, then rebuild all documents.
- [ ] Re-render the rebuilt PDFs and inspect every page after the author details change.
- [ ] Check any portal-specific supplementary-size limit and copyright form;
  no form has been signed and no rights declaration has been inferred.
- [ ] Upload the appropriate individual PDFs and sources only after author review.

No external submission, email, copyright signature or payment has been made.
